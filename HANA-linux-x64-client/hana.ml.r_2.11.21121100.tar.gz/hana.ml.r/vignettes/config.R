library(hana.ml.r)
#library(data.table)
library(R6)
library(testthat)
library(futile.logger)
library(sets)
library(RODBC)
#library(ids)
library(uuid)
flog.appender(appender.tee("hanaml_r.log"))
flog.threshold(INFO)
## CHANGE The information for sysName, userName and passwd to reflect what you have on your box
# Feel free to add your connection information here and comment the rest out to make it convenient for you.
#sysName <- 'odbcs'
#sysName <- 'lssjc0094.sjc.sap.corp:30015'
sysName <- 'lsvxc0103.sjc.sap.corp:30315'
userName <- 'PAL_TEST'
passWd <- 'Init12345'
#conn <- hanaml.ConnectionContext(sysName,userName,passWd)
conn <- hanaml.ConnectionContext(sysName, userName, passWd, odbc=FALSE,
                                 jdbcDriver = Sys.getenv("JDBC_DRIVER_PATH"),
                                 identifier.quote = "\"")
#conn <- hanaml.ConnectionContext(sysName, userName, passWd, odbc=FALSE,
#                                  jdbcDriver = '<hdbcli>/ngdbc.jar')


