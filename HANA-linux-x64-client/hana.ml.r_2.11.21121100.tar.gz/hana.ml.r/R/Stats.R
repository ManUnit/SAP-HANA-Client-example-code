#' @title One-way Analysis of variance (ANOVA)
#' @name hanaml.OnewayAnova
#' @description  hanaml.OnewayAnova is a R wrapper for SAP HANA PAL ANOVA.
#' @details
#' The purpose of one-way ANOVA is to determine whether there is
#' any statistically significant difference between the means of three more
#' independent groups.
#' @seealso \code{\link{hanaml.OnewayAnovaRepeated}}
#' @template args-data
#' @param group \code{character, optional}\cr
#' Name of the group column.\cr
#' If not provided, it defaults to the first column of \emph{data}.
#' @param sample \code{character, optional}\cr
#' Name of the sample measurement column.\cr
#' If not provided, it defaults to the second column of \emph{data}
#' @param multcomp.method \code{character, optional}\cr
#' \itemize{
#' Method used to perform multiple comparison tests.
#'   \item{\code{"tukey-kramer"}}
#'   \item{\code{"bonferroni"}}
#'   \item{\code{"dunn-sidak"}}
#'   \item{\code{"scheffe"}}
#'   \item{\code{"fisher-lsd"}}\cr
#'   }
#'  Defaults to 'tukey-kramer'.
#' @param significance.level \code{double, optional}\cr
#' The significance level when the function calculates the confidence
#' interval in multiple comparison tests.\cr
#' Values must be greater than 0 and less than 1.\cr
#' Defaults to 0.05.
#' @return
#' Returns a list of 3 DataFrame:
#' \itemize{
#' \item{\code{DataFrame 1}}\cr
#'  Statistics for each group, structured as follows:
#'  \itemize{
#'   \item{} GROUP, type NVARCHAR(256), group name.
#'   \item{} VALID_SAMPLES, type INTEGER, number of valid samples.
#'   \item{} MEAN, type DOUBLE, group mean.
#'   \item{} SD, type DOUBLE, group standard deviation.
#'   }
#' \item{\code{DataFrame 2}}\cr
#'  Computed results for ANOVA, structured as follows:
#'  \itemize{
#'    \item{}VARIABILITY_SOURCE, type NVARCHAR(100), source of variability,
#'    including between groups, within groups (error) and total.
#'    \item{}SUM_OF_SQUARES, type DOUBLE, sum of squares.
#'    \item{}DEGREES_OF_FREEDOM, type DOUBLE, degrees of freedom.
#'    \item{}MEAN_SQUARES, type DOUBLE, mean squares.
#'    \item{}F_RATIO, type DOUBLE, calculated as mean square between groups
#'    divided by mean square of error.
#'    \item{}P_VALUE, type DOUBLE, associated p-value from the F-distribution.
#'    }
#' \item{\code{DataFrame 3}}\cr
#'  Multiple comparison results, structured as follows:
#'  \itemize{
#'   \item{}FIRST_GROUP, type NVARCHAR(256), the name of the first group to
#'   conduct pairwise test on.\cr
#'   \item{}SECOND_GROUP, type NVARCHAR(256), the name of the second group
#'   to conduct pairwise test on.\cr
#'   \item{}MEAN_DIFFERENCE, type DOUBLE, mean difference between the two
#'   groups.\cr
#'   \item{}SE, type DOUBLE, standard error computed from all data.\cr
#'   \item{}P_VALUE, type DOUBLE, p-value.\cr
#'   \item{}CI_LOWER, type DOUBLE, the lower limit of the confidence
#'   interval.\cr
#'   \item{}CI_UPPER, type DOUBLE, the upper limit of the confidence
#'          interval.
#'  }
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'     GROUP  DATA
#'  1      A   4.0
#'  2      A   5.0
#'  3      A   4.0
#'  4      A   3.0
#'  5      A   2.0
#'  ...
#'  20     C   6.0
#'  21     C   7.0
#'  22     C   5.0
#'  }
#'  Call the function:
#' \preformatted{
#' > result <- hanaml.OnewayAnova(data,
#'                                 multcomp.method = "tukey-kramer",
#'                                 significance.level = 0.05)
#' }
#' Expected output:
#' \preformatted{
#' > result[[1]]
#'    GROUP  VALID_SAMPLES         MEAN        SD
#' 1      A              8     3.625000  0.916125
#' 2      B              8     5.750000  1.581139
#' 3      C              6     6.166667  0.752773
#' 4  Total             22     5.090909  1.600866
#' }
#' @keywords Statistics
#' @export
hanaml.OnewayAnova <- function(data,
                               group = NULL,
                               sample = NULL,
                               multcomp.method = NULL,
                               significance.level = NULL) {

  multcomp.method.map <- list("tukey-kramer" = 0,
                              "bonferroni" = 1,
                              "dunn-sidak" = 2,
                              "scheffe" = 3,
                              "fisher-lsd" = 4)
  multcomp.method <- validateInput("multcomp.method",
                                   multcomp.method,
                                   multcomp.method.map)
  significance.level <- validateInput("significance.level",
                                      significance.level,
                                      "double")
  if (!is.null(significance.level)) {
    if (significance.level > 1 || significance.level < 0){
      msg <- paste("The value range of significance level is",
                   "larger than 0 and smaller than 1")
      flog.error(msg)
      stop(msg)
    }
  }
  cols <- data$columns
  group <- validateInput("group", group, cols, case.sensitive = TRUE)
  sample <- validateInput("sample", sample, cols, case.sensitive = TRUE)
  if (is.null(group)) {
    group <- cols[[1]]
  }
  cols <- cols[!cols %in% group]
  if (is.null(sample)) {
    sample <- cols[[1]]
  }
  if (length(sample) != 1) {
    msg <- "PAL One Way ANOVA requires exactly one data column."
    flog.error(msg)
    stop(msg)
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  data <- data$Select(c(group, sample))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s", unique.id)
  statistics.tbl <- sprintf("#PAL_ONEWAY_ANOVA_STATISTICS_TBL_%s", unique.id)
  anova.tbl <- sprintf("#PAL_ONEWAY_ANOVA_TBL_%s", unique.id)
  mulcomp.tbl <- sprintf("#PAL_ONEWAY_ANOVA_MULCOMP_TBL_%s", unique.id)

  in.tables <- list(data, param.tbl)
  out.tables <- list(statistics.tbl, anova.tbl, mulcomp.tbl)
  tables <- list(param.tbl, statistics.tbl, anova.tbl, mulcomp.tbl)
  param.array <- list(
    tuple("MULTCOMP_METHOD",
          map.null(multcomp.method, multcomp.method.map),
          NULL, NULL),
    tuple("SIGNIFICANCE_LEVEL", NULL, significance.level, NULL)
  )
  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn.context, "PAL_ONEWAY_ANOVA",
                                          in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return (list(conn.context$table(statistics.tbl),
               conn.context$table(anova.tbl),
               conn.context$table(mulcomp.tbl)))
}

#' @title Oneway Repeated Analysis of variance (ANOVA)
#' @name hanaml.OnewayAnovaRepeated
#' @description  hanaml.OnewayAnovaRepeated is a R wrapper
#'  for SAP HANA PAL ANOVA.
#' @details Performs one-way repeated measures analysis of variance, along
#'  with Mauchly's Test of Sphericity and post hoc multiple comparison tests.
#' @seealso \code{\link{hanaml.OnewayAnova}}
#' @template args-data
#' @param subject.id \code{character, optional}\cr
#' Name of the subject ID column.\cr
#' The algorithm treats each row of the data table as a different subject.
#' Hence there should be no duplicate subject ids in this column.\cr
#' If not provided, it defaults to the first columns.
#' @param measures \code{character, optional}\cr
#' Names of the groups (measures).\cr
#' If not provided, defaults to all non subject.id columns.
#' @param multcomp.method \code{character, optional}\cr
#' Method used to perform multiple comparison tests.
#' \itemize{
#'   \item{\code{"tukey-kramer"}}
#'   \item{\code{"bonferroni"}}
#'   \item{\code{"dunn-sidak"}}
#'   \item{\code{"scheffe"}}
#'   \item{\code{"fisher-lsd"}}\cr
#'   }
#'   Defaults to 'bonferroni'.
#' @param significance.level \code{double, optional}\cr
#' The significance level when the function calculates the confidence
#' interval in multiple comparison tests.\cr
#' Values must be greater than 0 and less than 1.\cr
#' Defaults to 0.05.
#' @param se.type \code{character, optional}\cr
#' \itemize{
#' Type of standard error used in multiple comparison tests.
#'  \item{\code{all-data}: computes the standard error from all data. It has
#'  more power if the assumption of sphericity is TRUE, especially with small
#'  data sets.}
#'  \item{\code{two-group}: computes the standard error from only the two groups
#'  being compared. It does not assume sphericity.}
#'  }
#'  Defaults to 'two-group'.
#' @return
#' Return a list of 4 DataFrame:\cr
#' \code{DataFrame 1}\cr
#'  Statistics for each group, structured as follows:
#'  \itemize{
#'   \item{GROUP, type NVARCHAR(256), group name.}
#'   \item{VALID_SAMPLES, type INTEGER, number of valid samples.}
#'   \item{MEAN, type DOUBLE, group mean.}
#'   \item{SD, type DOUBLE, group standard deviation.}
#'   }
#' \code{DataFrame 2}\cr
#' Mauchly test results, structured as follows:
#' \itemize{
#'   \item{STAT_NAME, type NVARCHAR(100), names of test result quantities.}
#'   \item{STAT_VALUE, type DOUBLE, values of test result quantities.}
#'   }
#' \code{DataFrame 3}\cr
#' Computed results for ANOVA , structured as follows:
#' \itemize{
#'   \item{VARIABILITY_SOURCE, type NVARCHAR(100), source of variability,
#'   including between groups, within groups (error) and total.}
#'   \item{SUM_OF_SQUARES, type DOUBLE, sum of squares.}
#'   \item{DEGREES_OF_FREEDOM, type DOUBLE, degrees of freedom.}
#'   \item{MEAN_SQUARES, type DOUBLE, mean squares.}
#'   \item{F_RATIO, type DOUBLE, calculated as mean square between groups
#'   divided by mean square of error.}
#'   \item{P_VALUE, type DOUBLE, associated p-value from the F-distribution.}
#'   \item{P_VALUE_GG, type DOUBLE, p-value of Greehouse-Geisser correction.}
#'   \item{P_VALUE_HF, type DOUBLE, p-value of Huynh-Feldt correction.}
#'   \item{P_VALUE_LB, type DOUBLE, p-value of lower bound correction.}
#'  }
#' \code{DataFrame 4}\cr
#'   Multiple comparison results, structured as follows
#'   \itemize{
#'   \item{FIRST_GROUP, type NVARCHAR(256), the name of the first group to
#'   conduct pairwise test on.}
#'   \item{SECOND_GROUP, type NVARCHAR(256), the name of the second group
#'   to conduct pairwise test on.}
#'   \item{MEAN_DIFFERENCE, type DOUBLE, mean difference between the two
#'   groups.}
#'   \item{SE, type DOUBLE, standard error computed from all data.}
#'   \item{P_VALUE, type DOUBLE, p-value.}
#'   \item{CI_LOWER, type DOUBLE, the lower limit of the confidence
#'   interval.}
#'   \item{CI_UPPER, type DOUBLE, the upper limit of the confidence
#'   interval.}
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'     ID  MEASURE1  MEASURE2  MEASURE3  MEASURE4
#'   1  1       8.0       7.0       1.0       6.0
#'   2  2       9.0       5.0       2.0       5.0
#'   3  3       6.0       2.0       3.0       8.0
#'   4  4       5.0       3.0       1.0       9.0
#'   5  5       8.0       4.0       5.0       8.0
#'   6  6       7.0       5.0       6.0       7.0
#'   7  7      10.0       2.0       7.0       2.0
#'   8  8      12.0       6.0       8.0       1.0
#' }
#'  Call the function:
#' \preformatted{
#'  > result <- hanaml.OnewayAnovaRepeated(data,
#'                                         multcomp.method = "bonferroni",
#'                                         significance.level = 0.05,
#'                                         se.type = "two-group")
#' }
#' Output:
#' \preformatted{
#' > result[[1]]
#'          GROUP    VALid_SAMPLES      MEAN        SD
#'    1  MEASURE1                8     8.125  2.232071
#'    2  MEASURE2                8     4.250  1.832251
#'    3  MEASURE3                8     4.125  2.748376
#'    4  MEASURE4                8     5.750  2.915476
#' }
#' @export
hanaml.OnewayAnovaRepeated <- function(data,
                                       subject.id = NULL,
                                       measures = NULL,
                                       multcomp.method = NULL,
                                       significance.level = NULL,
                                       se.type = NULL) {

  multcomp.method.map <- list("tukey-kramer" = 0,
                              "bonferroni" = 1,
                              "dunn-sidak" = 2,
                              "scheffe" = 3,
                              "fisher-lsd" = 4)
  se.type.map <- list("all-data" = 0, "two-group" = 1)

  multcomp.method <- validateInput("multcomp.method",
                                   multcomp.method,
                                   multcomp.method.map)
  significance.level <- validateInput("significance.level",
                                      significance.level,
                                      "double")
  if (!is.null(significance.level)) {
    if (significance.level > 1 || significance.level < 0){
      msg <- paste("The value range of significance level is",
                   "larger than 0 and smaller than 1")
      flog.error(msg)
      stop(msg)
    }
  }
  se.type <- validateInput("se.type", se.type, se.type.map)
  cols <- data$columns
  subject.id <- validateInput("subject.id", subject.id,
                              cols, case.sensitive = TRUE)
  if (is.null(subject.id)) {
    subject.id <- cols[[1]]
  }
  cols <- cols[! cols %in% subject.id]
  measures <- validateInput("measures", measures, cols, case.sensitive = TRUE)
  if (is.null(measures)) {
    measures <- cols
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  data <- data$Select(c(subject.id, measures))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s", unique.id)
  statistics.tbl <- sprintf("#PAL_ANOVA_REPEATED_STATISTICS_TBL_%s", unique.id)
  mauchly.test.tbl <- sprintf("#PAL_ANOVA_REPEATED_MAUCHLY_TEST_TBL_%s", unique.id)
  anova.tbl <- sprintf("#PAL_ANOVA_REPEATED_TBL_%s", unique.id)
  mulcomp.tbl <- sprintf("#PAL_ANOVA_REPEATED_MULCOMP_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(statistics.tbl, mauchly.test.tbl, anova.tbl, mulcomp.tbl)
  tables <- list(param.tbl, statistics.tbl, mauchly.test.tbl,
                 anova.tbl, mulcomp.tbl)
  param.array <- list(
    tuple("MULTCOMP_METHOD",
          map.null(multcomp.method, multcomp.method.map),
          NULL, NULL),
    tuple("SIGNIFICANCE_LEVEL", NULL, significance.level, NULL),
    tuple("SE_TYPE", map.null(se.type, se.type.map), NULL, NULL)
  )
  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn.context,
                                          "PAL_ONEWAY_REPEATED_MEASURES_ANOVA", in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context,
                          tables)
    stop(msg)
  })
  return (list(conn.context$table(statistics.tbl),
               conn.context$table(mauchly.test.tbl),
               conn.context$table(anova.tbl),
               conn.context$table(mulcomp.tbl)))
}


#' @title Chi-squared Goodness-of-fit(GoF)
#' @name hanaml.ChisqGoF
#' @description
#' Perform the chi-squared goodness-of-fit(GoF) test to tell whether or
#' not an observed distribution differs from an expected chi-squared distribution.
#' @template args-data
#' @template args-key
#' @param observed.data \code{character, optional}\cr
#'  Name of column for counts of actual observations belonging to each category.
#'  If not given, it defaults to the first non-ID column of \emph{data}.
#' @param expected.freq \code{character, optional}\cr
#' Name of the expected frequency column.
#' If not given, it defaults to the first non-ID, non-observed.data columns.
#' @return
#' Returns a list of 2 DataFrame:
#' \itemize{
#'   \item{ Comparsion between the actual counts and the expected counts :
#'   \code{DataFrame}}\cr
#'   structured as follows:
#'   \itemize{
#'     \item{}ID column, with same name and type as \emph{data}'s ID column
#'     \item{}Observed data column, with same name as \emph{data}'s observed.data column,
#'   but always with type DOUBLE.
#'     \item{}EXPECTED column, type DOUBLE, expected count in each category.
#'     \item{}RESIDUAL column, type DOUBLE, the difference between the observed counts and the
#'    expected counts.
#'    }
#'    \item{Statistical outputs : \code{DataFrame}}\cr
#'    including the calculated chi-squared value,
#'    degrees of freedom and p-value, structured as follows:
#'    \itemize{
#'      \item{STAT_NAME}: type NVARCHAR(100), name of statistics.
#'      \item{STAT_VALUE}: type DOUBLE, value of statistics.}
#'   }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#'  > data$Collect()
#'     ID  OBSERVED    P
#'  1   0     519.0  0.3
#'  2   1     364.0  0.2
#'  3   2     363.0  0.2
#'  4   3     200.0  0.1
#'  5   4     212.0  0.1
#'  6   5     193.0  0.1
#' }
#' Create chisquaredfit instance:
#' \preformatted{
#'  > result <- hanaml.ChisqGoF(data, key = "ID")
#'  }
#' Output:
#' \preformatted{
#'   > result[[1]]$Collect()
#'      ID  OBSERVED  EXPECTED  RESIDUAL
#'   1   0     519.0     555.3     -36.3
#'   2   1     364.0     370.2      -6.2
#'   3   2     363.0     370.2      -7.2
#'   4   3     200.0     185.1      14.9
#'   5   4     212.0     185.1      26.9
#'   6   5     193.0     185.1       7.9
#' }
#' @keywords Statistics
#' @export
hanaml.ChisqGoF <- function(data,
                            key,
                            observed.data = NULL,
                            expected.freq = NULL) {

    cols <- data$columns
    if (length(cols) < 3){
      msg <- "Input data should have at least three columns."
      flog.error(msg)
      stop(msg)
    }
    key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
    cols <- cols[! cols %in% key]
    observed.data <- validateInput("observed.data", observed.data,
                                   cols, case.sensitive = TRUE)
    if (is.null(observed.data)){
      observed.data <- cols[[1]]
    } else {
      if (length(observed.data) != 1){
        msg <- "`observed.data` should specify exactly one column."
        flog.error(msg)
        stop(msg)
      }
    }
    cols <- cols[! cols %in% observed.data]
    expected.freq <- validateInput("expected.freq", expected.freq,
                                   cols, case.sensitive = TRUE)
    if (is.null(expected.freq)){
      expected.freq <- cols[[1]]
    }
    if (!inherits(data, "DataFrame")) {
      msg <- "data must be given as a DataFrame"
      flog.error(msg)
      stop(msg)
    }
    CheckConnection(data)
    conn.context <- data$connection.context

    data <- data$Select(list(key, observed.data, expected.freq))
    unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
    result.tbl <- sprintf("#PAL_CHISQUARED_GOF_TEST_RESULT_%s", unique.id)
    statistics.tbl <- sprintf("#PAL_CHISQUARED_GOF_TEST_STATISTICS_%s", unique.id)

    out.tables <- list( result.tbl, statistics.tbl)
    tryCatch({
      errorhelper(CallPalAutoWithConnection(conn.context,
                                            "PAL_CHISQUARED_GOF_TEST",
                                            list(data),
                                            out.tables))
    },
    error = function(err){
      msg <- paste("Error:", err[["message"]])
      flog.error(msg)
      TryDropWithConnection(conn.context, out.tables)
      stop(msg)
    })
    return(list(conn.context$table(result.tbl),
                conn.context$table(statistics.tbl)))
    }


#' @title Chi-squared test of Independence
#' @name hanaml.ChisqIndependence
#' @description   Perform the chi-squared test of independence to tell whether
#' two variables are independent from each other.
#' @template args-data
#' @template args-key
#' @param observed.data \code{character, optional}\cr
#' Names of the observed data columns.
#' If not given, it defaults to all non-ID columns.
#' @param correction \code{logical, optional}\cr
#' If TRUE, and the degrees of freedom is 1, apply
#' Yates's correction for continuity. The effect of
#' the correction is to adjust each observed value by 0.5
#' towards the corresponding expected value.\cr
#' Defaults to FALSE.
#' @return
#' Returns a list of 2 DataFrame:
#' \itemize{
#'   \item{\code{DataFrame 1}}\cr
#'   The expected count table, structured as follows:
#'   \itemize{
#'     \item{}ID column, with same name and type as \emph{data}'s ID column.\cr
#'     \item{}Expected count columns, named by prepending \emph{Expected_} to each
#'   \emph{observed.data} column name, type DOUBLE. There will be as many
#'   columns here as there are \emph{observed.data} columns.
#'   }
#'   \item{\code{DataFrame 2}}\cr
#'    Statistical outputs including the calculated chi-squared value,
#'    degrees of freedom and p-value, structured as follows:
#'    \itemize{
#'      \item{STAT_NAME}: type NVARCHAR(100), name of statistics
#'      \item{STAT_VALUE}: type DOUBLE, value of statistics}
#'   }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'        ID  X1    X2  X3    X4
#' 1    male  25  23.0  11  14.0
#' 2  female  41  20.0  18   6.0
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.ChisqIndependence(data, key="ID")
#' }
#' Expected output:
#' \preformatted{
#' > result[[1]]$Collect()
#'        ID  EXPECTED_X1  EXPECTED_X2  EXPECTED_X3  EXPECTED_X4
#' 1    male    30.493671    19.867089    13.398734     9.240506
#' 2  female    35.506329    23.132911    15.601266    10.759494
#' }
#' @keywords Statistics
#' @export
hanaml.ChisqIndependence <- function(data,
                                     key,
                                     observed.data = NULL,
                                     correction = NULL) {

    cols <- data$columns
    if (length(cols) < 2){
      msg <- "Input data should have at least two columns."
      flog.error(msg)
      stop(msg)
    }
    key <- validateInput("key", key, cols, required = TRUE,
                         case.sensitive = TRUE)
    cols <- cols[! cols %in% key]
    observed.data <- validateInput("observed.data", observed.data,
                                   cols, case.sensitive = TRUE)
    if (is.null(observed.data)){
      observed.data <- cols
    }
    correction <- validateInput("correction", correction, "logical")
    if (!inherits(data, "DataFrame")) {
      msg <- "data must be given as a DataFrame"
      flog.error(msg)
      stop(msg)
    }
    CheckConnection(data)
    conn.context <- data$connection.context

    select.columns <- c(key, observed.data)
    data <- data$Select(select.columns)
    unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
    param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s", unique.id)
    result.tbl <- sprintf("#PAL_CHISQUARED_IND_TEST_RESULT_%s", unique.id)
    statistics.tbl <- sprintf("#PAL_CHISQUARED_IND_TEST_STATISTICS_%s", unique.id)

    in.tables <- list(data, param.tbl)
    out.tables <- list(result.tbl, statistics.tbl)
    tables <- list(param.tbl, result.tbl, statistics.tbl)
    param.array <- list(
      tuple("CORRECTION_TYPE", to.integer(correction), NULL, NULL)
    )
    tryCatch({
      errorhelper(CreateTWithConnection(conn.context,
                                        (ParameterTable$new(param.tbl))$WithData(param.array)))#nolint
      errorhelper(CallPalAutoWithConnection(conn.context,
                                            "PAL_CHISQUARED_IND_TEST",
                                            in.tables, out.tables))
    },
    error = function(err){
      msg <- paste("Error:", err[["message"]])
      flog.error(msg)
      TryDropWithConnection(conn.context, tables)
      stop(msg)
    })
    return(list(conn.context$table(result.tbl),
                conn.context$table(statistics.tbl)))
    }

#' @title Condition Index
#' @name hanaml.ConditionIndex
#' @description hanaml.ConditionIndex is a R wrapper for SAP HANA PAL Condition Index.
#' @details
#' Condition index is used to detect collinearity problem between independent
#' variables which are later used as predictors in a multiple linear regression
#' model.
#' @template args-data
#' @template args-key
#' @template args-feature-multiple
#' @param scaling \code{logical, optional}\cr
#'  Specifies whether or not to scale the input data to have unit variance
#'  before the analysis.\cr
#'  Default to TRUE.
#' @param intercept \code{logical, optional}\cr
#'  Specifies whether or not to consider intercept during the calculation.\cr
#'  Default to TRUE.
#' @template args-threadratio
#' @return
#' Returns a list of 2 DataFrame:
#' \itemize{
#' \item{\code{DataFrame 1}}\cr
#' Condition index results, structured as follows:
#' \itemize{
#'   \item{}COMPONENT_ID, principal component ID.
#'   \item{}EIGENVALUE, eigenvalue.
#'   \item{}CONDITION_INDEX, Condition index.
#'   \item{}FEATURES, variance decomposition proportion for each variable.
#'   \item{}INTERCEPT, variance decomposition proportion for the intercept term.
#' }
#' \item{\code{DataFrame 2}}\cr
#' This table is empty if collinearity problem has not been detected.\cr
#' Distinct values results, structured as follows:
#' \itemize{
#'   \item{STAT_NAME}: Name for the values, including condition number,
#' and the name of variables which are involved in collinearity problem.\cr
#'   \item{STAT_VALUE}: values of the corresponding name.
#' }
#' }
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'   ID X1 X2 X3 X4
#' 1  1 12 52 20 44
#' 2  2 12 57 25 45
#' 3  3 12 54 21 45
#' 4  4 13 52 21 46
#' 5  5 14 54 24 46
#' }
#' Call ConditionIndex function:
#' \preformatted{
#' > ci <- hanaml.ConditionIndex(data, key = "ID", thread.ratio = 0.1)
#' }
#'
#' Output:
#' \preformatted{
#' > ci[[1]]$Collect()
#'   COMPONENT_ID      EIGENVALUE CONDITION_INDEX             X1            X2
#' 1       Comp_1    1.996669e+01         1.00000   1.185761e-05  1.556872e-06
#' 2       Comp_2    2.073585e-02        31.03074   8.776374e-03  2.098206e-04
#' 3       Comp_3    1.226013e-02        40.35575   5.347198e-02  2.570866e-03
#' 4       Comp_4    2.295285e-04       294.94070   2.056656e-01  1.522431e-02
#' 5       Comp_5    8.639595e-05       480.73565   7.320742e-01  9.819934e-01
#'                 X3          X4    INTERCEPT
#' 1    9.911148e-06 3.175778e-06 2.173805e-06
#' 2    3.106275e-02 1.251087e-03 9.070816e-04
#' 3    5.314573e-03 6.389341e-04 2.710487e-03
#' 4    6.578588e-03 9.311208e-01 2.468621e-01
#' 5    9.570342e-01 6.698598e-02 7.495182e-01
#' }
#' @keywords Statistics
#' @export
hanaml.ConditionIndex <- function(data,
                                  key,
                                  features = NULL,
                                  scaling = NULL,
                                  intercept = NULL,
                                  thread.ratio = NULL) {
  scaling <- validateInput("scaling", scaling, "logical")
  intercept <- validateInput("intercept", intercept, "logical")
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
  if (!is.null(thread.ratio)) {
    if (thread.ratio < 0 || thread.ratio > 1) {
      msg <- "The value range should be from 0 to 1."
      flog.error(msg)
      stop(msg)
    }
  }
  cols <- data$columns
  types <- data$dtypes()
  tp.list <- list()
  for (tp in types){
    tp.list <- c(tp.list, tp[[2]])
  }
  key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
  tp.list <- tp.list[! cols %in% key]
  cols <- cols[! cols %in% key]
  cols <- cols[tp.list %in% c("INTEGER", "DOUBLE")]#extract all numerical columns
  features <- validateInput("features", features, cols, case.sensitive = TRUE)
  if (is.null(features)){
    features <- cols
  }

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  param.array <- list(
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
    tuple("INCLUDE_INTERCEPT", to.integer(intercept),
          NULL, NULL),
    tuple("SCALING", to.integer(scaling), NULL, NULL),
    tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL)
  )
  selected <- list(key, features)
  data <- data$Select(selected)

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_CONDITION_INDEX_RESULT_TBL_%s", unique.id)
  helper.tbl <- sprintf("#PAL_CONDITION_INDEX_HELPER_TBL_%s", unique.id)

  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl, helper.tbl)
  tables <- c(param.tbl, out.tables)
  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
                                      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn.context,
                                          "PAL_CONDITION_INDEX", in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, out.tables)
    stop(msg)
  })
  return(list(conn.context$table(result.tbl), conn.context$table(helper.tbl)))
}

#' @title Cumulative Distribution Function
#' @name hanaml.CDF
#' @description hanaml.CDF is a R wrapper for SAP HANA PAL Cumulative Distribution Function
#' @details
#' This algorithm evaluates the Cumulative Distribution
#' Function or complementary cumulative distribution function
#' (CCDF) of a specified probability distribution evaluated
#' at the values in x. CDF describes the value F(x) = P[X<=x]
#' and CCDF the value F_c(x)=1-F(x)=P[X>x] where X is a
#' real-valued random variable.
#' @template args-data
#' @param     distr.info \code{list}\cr
#'            Specifies the probability distribution and its parameters.
#'            It should be specified by 3 parameters in the form of a
#'            list: list(distribution, distr.param1, distr.param2).
#'            distribution can be chosen from:
#'            \itemize{
#'                \item{\code{{'uniform','normal', 'weibull', 'gamma'}}
#'            }}.
#'            The distribution parameters should be chossen
#'            follow the following tabular
#' \tabular{llll}{
#' \strong{Distribution} \tab \strong{Parameter Name}
#' \tab \strong{Parameter Value} \tab \strong{Constraints}\cr
#' Uniform \tab 'DistributionName' \tab 'Uniform' \tab \cr
#'     \tab 'Min' \tab '0.0' \tab Min<Max \cr
#'     \tab 'Max' \tab '1.0' \tab          \cr
#' Normal \tab 'DistributionName' \tab 'Normal' \tab \cr
#'     \tab 'Mean' \tab '0.0' \tab         \cr
#'     \tab 'Variance' \tab '1.0' \tab  Variance>0\cr
#' Weibull \tab 'DistributionName' \tab 'Weilbull' \tab \cr
#'     \tab 'Shape ' \tab '1.0' \tab  Shape>0 \cr
#'     \tab 'Scale' \tab '1.0' \tab  Scale>0\cr
#' Gamma \tab 'DistributionName' \tab 'Gamma' \tab \cr
#'     \tab 'Shape ' \tab '1.0' \tab  Shape>0 \cr
#'     \tab 'Scale' \tab '1.0' \tab  Scale>0\cr
#' }
#' @param     col \code{character, optional}\cr
#'            Name of the data column that needs to be tested.\cr
#'            If it is not given, the input dataframe must only have one column.
#' @param     complementary \code{logical, optional}\cr
#'            By having complementary is TRUE, it calculates the CCDF value.\cr
#'            Defaults to FALSE.
#' @return
#' \itemize{
#'   \item{\code{DataFrame}}\cr
#'   return the cdf value of the distribution, evaluated at input data
#'   \itemize{
#'     \item{INPUT_DATA}: input data x
#'     \item{ROBABILITY}: Probability}
#'  }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$$Collect()
#'   DATACOL
#' 1    37.4
#' 2   277.9
#' 3   463.2
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.CDF(data = data,
#'                        distr.info = list('weibull', 2.11995,277.698),
#'                        correction = FALSE)
#' }
#' Results:
#' \preformatted{
#' > result$Collect()
#'   DATACOL PROBABILITY
#' 1    37.4  0.01416002
#' 2   277.9  0.63268765
#' 3   463.2  0.94809354
#' }
#' @keywords Statistics
#' @export
hanaml.CDF <- function(data,
                       distr.info,
                       col = NULL,
                       complementary = NULL) {
  col.num <- length(data$columns)
  if (is.null(col)) {
    if (col.num != 1) {
      msg <- "If 'col' is not specified, the input dataframe must only have one column."
      flog.error(msg)
      stop(msg)
    } else {
      col <- data$columns
    }
  } else {
    col <- validateInput("col", col, data$columns, case.sensitive = TRUE)
    col <- list(col)
  }

  distribution.map <- list(uniform = c("DistributionName", "Min", "Max"),
                           normal = c("DistributionName", "Mean", "Variance"),
                           weibull = c("DistributionName", "Shape", "Scale"),
                           gamma = c("DistributionName", "Shape", "Scale"))
  if (length(distr.info) == 3 && inherits(distr.info, "list")) {
    distribution <- validateInput("distribution", distr.info[[1]],
                                  distribution.map, case.sensitive = FALSE)
    distr.param.name <- map.null(distribution, distribution.map)
  } else {
    msg <- "distr.info parameters are missing or not in the correct form."
    flog.error(msg)
    stop(msg)
  }

  if (distribution == "uniform") {
    if (!distr.info[[2]] < distr.info[[3]]) {
      msg <- "Min < Max is not satisfied for uniform distribution!"
      flog.error(msg)
      stop(msg)
    }
  } else if (distribution == "normal") {
    if (distr.info[[3]] <= 0) {
      msg <- "Variance has to be greater than 0 for normal distribution!"
      flog.error(msg)
      stop(msg)
    }
  } else if (distribution == "weibull" || distribution == "gamma") {
    if (distr.info[[2]] <= 0 || distr.info[[3]] <= 0) {
      msg <- "Shape and Scale have to be choosen greater than 0!"
      flog.error(msg)
      stop(msg)
    }
  }

  distr.param.data <- list()
  for (i in seq_len(length(distr.info))) {
    distr.param.data <- append(distr.param.data,
                               list(tuple(as.character(distr.param.name[i]),
                                          as.character(distr.info[[i]]))))
  }

  complementary <- validateInput("complementary", complementary, "logical")

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame."
    flog.error(msg)
    stop(msg)
  }

  CheckConnection(data)
  conn <- data$connection.context

  data <- data$Select(col)

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_CDF_PARAM_TBL_%s", unique.id)
  distr.param.tbl <- sprintf("#PAL_CDF_DISTR_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_CDF_RESULT_TBL_%s", unique.id)
  TableSpec <- list(tuple("NAME", nvarchar(50)), tuple("VALUE", nvarchar(50)))
  distribution.table <- Table$new(distr.param.tbl, TableSpec)

  in.tables <- list(data, distr.param.tbl, param.tbl)
  out.tables <- list(result.tbl)
  tables <- c(distr.param.tbl, param.tbl, out.tables)

  param.array <- list(tuple("LOWER_UPPER", to.integer(complementary), NULL, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      distribution.table$WithData(distr.param.data)))
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_DISTRIBUTION_FUNCTION",
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(result.tbl))
}

#' @title Distribution Fitting
#' @name hanaml.DistributionFit
#' @description hanaml.DistributionFit is a R wrapper for SAP HANA PAL
#' Distribution Fitting
#' @details
#' This algorithm adapts the parameters of the chosen probability
#' distribution in a way, s.t.
#' the resulting distribution fits the data. PAL support distribution
#' fitting with Normal, Gamma, Weibull, Exponential, Poisson, and Uniform distribution.
#' @template args-data
#' @param   distr.type \code{{'exp', 'gamma', 'normal', 'poisson',
#' 'uniform', 'weibull'}}\cr
#'      choose the probability distribution from:
#'      \itemize{
#'        \item{\code{'exp'} : Exponential distribution}
#'        \item{\code{'gamma'}: Gamma distribution}
#'        \item{\code{'normal'}: Normal distribution}
#'        \item{\code{'poisson'}: Poisson distribution}
#'        \item{\code{'uniform'}: Uniform distribution}
#'        \item{\code{'weibull'}: Weibull distribution}
#'      }.
#' @param   optimal.method \code{{'maximum.likelihood', 'median.rank'}, optional}\cr
#'  Specifies the estimation method.
#'  \itemize{
#'    \item{\code{'maximum.likelihood'} : use maximum likelihood}
#'    \item{\code{'median.rank'}: median rank
#'    (Valid only when \emph{distr.type} is 'weibull')}
#'  }.
#'  Defaults to 'maximum.likelihood'.
#' @param censored \code{logical, optional}\cr
#' Specify if the data is censored of not.
#' TRUE only valid when \emph{distr.type} is 'weibull'.\cr
#' Defaults to FALSE.
#'
#' @return
#' Returns a list of DataFrame:
#' \itemize{
#'  \item{\code{DataFrame}}\cr
#'  The estimated parameter values.
#'  \itemize{
#'    \item{NAME} Name of distribution parameters
#'    \item{VALUE} corresponding value
#'  }
#'  \item{\code{DataFrame}}\cr
#'  Statistics
#'  \itemize{
#'    \item{STAT_NAME} name of statistics.
#'    \item{STAT_VALUE} Value of statistics.
#'  }
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Head(5)$Collect()
#'    X
#' 1 71
#' 2 83
#' 3 92
#' 4 104
#' 5 120
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.DistributionFit(data=data,
#'                                    distr.type='weibull',
#'                                    optimal.method='maximum.likelihood')
#' }
#' Results:
#' \preformatted{
#' > result[[1]]$Collect()
#'                NAME  VALUE
#' 1 DISTRIBUTIONNAME WEIBULL
#' 2            SCALE   244.4
#' 3            SHAPE 2.06698
#' > result[[2]]$Collect()
#'       STAT_NAME STAT_VALUE
#' 1 LOGLIKELIHOOD  -115.1138
#' }
#' @keywords Statistics
#' @export
hanaml.DistributionFit <- function(data,
                                   distr.type,
                                   optimal.method=NULL,
                                   censored=FALSE) {
  optimal.method.map <- list("maximum.likelihood" = 0, "median.rank" = 1)
  distribution.map <- list(normal = "NORMAL", uniform = "UNIFORM",
                           weibull = "WEIBULL", gamma = "GAMMA",
                           exp = "EXPONENTIAL", poisson = "POISSON")
  distr.type <- validateInput("distr.type", distr.type,
                              distribution.map, case.sensitive = FALSE, required = TRUE)
  optimal.method <- validateInput("optimal.method", optimal.method, optimal.method.map)
  censored <- validateInput("censored", censored, "logical")

  if ( ( !censored) && (length(data$columns) != 1)) {
    msg <- "The input DataFrame must have one column when censored is not set."
    flog.error(msg)
    stop(msg)
  }
  if ( (censored) && (length(data$columns) != 2)) {
    msg <- "The input censored dataframe must have two columns."
    flog.error(msg)
    stop(msg)
  }

  if ( (distr.type != "weibull") && (censored)) {
    msg <- "Censored data is only valid when distr.type is set as weibull!"
    flog.error(msg)
    stop(msg)
  }

  if (!censored) {
    func.name <- "PAL_DISTRIBUTION_FIT"
  } else {
    func.name <- "PAL_DISTRIBUTION_FIT_CENSORED"
  }

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_DISTRIBUTION_FIT_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_DISTRIBUTION_FIT_RESULT_TBL_%s", unique.id)
  stat.tbl <- sprintf("#PAL_DISTRIBUTION_FIT_STAT_TBL_%s", unique.id)

  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl, stat.tbl)
  tables <- c(param.tbl, out.tables)

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context

  param.array <- list(tuple("DISTRIBUTIONNAME", NULL, NULL, map.null(distr.type, distribution.map)),
                      tuple("OPTIMAL_METHOD", map.null(optimal.method, optimal.method.map), NULL, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          func.name,
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(lapply(out.tables, conn$table))
}

#' @title Distribution Quantile
#' @name hanaml.Quantile
#' @description hanaml.Quantile is a R wrapper  for SAP HANA PAL
#' Distribution Quantile.
#' @details
#' This algorithm evaluates the value x where the CDF value p=F(x)=P[X<=x]
#' or CCDF value p=F(x)=P[X>x] of a given probability
#'  density is reached, i.e. it evaluates F^{-1}(p).
#' @param data \code{DataFrame}\cr
#' DataFrame containting the cdf values.
#' @param     distr.info \code{list}\cr
#'            choose the probability distribution and its parameters. :
#'            Specifies the probability distribution and its parameters.
#'            3 parameters should specify it in the form of a list:
#'            list(distribution, distr.param1, distr.param2).
#'            distribution can be choosen from:
#'            \itemize{
#'                \item{\code{{'uniform','normal', 'weibull', 'gamma'}}
#'            }}.
#'            The distribution parameters should be chosen follow the
#'            tabular:
#' \tabular{rrrr}{
#' \strong{Distribution} \tab \strong{Parameter Name} \tab
#' \strong{Parameter Value} \tab \strong{Constraints}\cr
#' Uniform \tab 'DistributionName' \tab 'Uniform' \tab \cr
#'     \tab 'Min' \tab '0.0' \tab Min < Max \cr
#'     \tab 'Max' \tab '1.0' \tab          \cr
#' Normal \tab 'DistributionName' \tab 'Normal' \tab \cr
#'     \tab 'Mean' \tab '0.0' \tab         \cr
#'     \tab 'Variance' \tab '1.0' \tab  Variance > 0\cr
#' Weibull \tab 'DistributionName' \tab 'Weilbull' \tab \cr
#'     \tab 'Shape ' \tab '1.0' \tab  Shape > 0 \cr
#'     \tab 'Scale' \tab '1.0' \tab  Scale > 0\cr
#' Gamma \tab 'DistributionName' \tab 'Gamma' \tab \cr
#'     \tab 'Shape ' \tab '1.0' \tab  Shape > 0 \cr
#'     \tab 'Scale' \tab '1.0' \tab  Scale > 0\cr
#'}
#' @param     col \code{character, optional}\cr
#'            Name of the data column that needs to be tested.\cr
#'            If it is not given, the input dataframe must only have one column.
#' @param     complementary \code{logical, optional}\cr
#'            By having complementary is TRUE, it calculates the CCDF value.\cr
#'            Defaults to FALSE.
#' @return
#' \code{DataFrame}\cr
#'   Returns the cdf value of the distribution, evaluated at input data.
#'   Structured as follow:
#'   \itemize{
#'     \item{INPUT_DATA}: input data\cr
#'     \item{QUANTILE}: quantile
#'   }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'   DATACOL
#' 1   0.300
#' 2   0.500
#' 3   0.632
#' 4   0.800
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Quantile(data=data, list('weibull', 2.11995, 277.698), correction = FALSE)
#' }
#' Results:
#' \preformatted{
#' > result$Collect()
#'   INPUT_DATA QUANTILE
#' 1      0.300 170.7559
#' 2      0.500 233.6085
#' 3      0.632 277.6551
#' 4      0.800 347.5865
#' }
#' @keywords Statistics
#' @export
hanaml.Quantile <- function(data, distr.info, col = NULL, complementary = NULL) {
  col.num <- length(data$columns)
  if (is.null(col)) {
    if (col.num != 1) {
      msg <- "If 'col' is not specified, input dataframe must only have one column."
      flog.error(msg)
      stop(msg)
    } else {
      col <- data$columns
    }
  } else {
    col <- validateInput("col", col, data$columns, case.sensitive = TRUE)
    col <- list(col)
  }

  distribution.map <- list(uniform = c("DistributionName", "Min", "Max"),
                           normal = c("DistributionName", "Mean", "Variance"),
                           weibull = c("DistributionName", "Shape", "Scale"),
                           gamma = c("DistributionName", "Shape", "Scale"))
  if (length(distr.info) == 3 && inherits(distr.info, "list")) {
    distribution <- validateInput("distribution", distr.info[[1]],
                                  distribution.map, case.sensitive = FALSE)
    distr.param.name <- map.null(distribution, distribution.map)
  } else {
    msg <- "distr.info parameters are missing or not in the correct form."
    flog.error(msg)
    stop(msg)
  }

  if (distribution == "uniform") {
    if (!distr.info[[2]] < distr.info[[3]]) {
      msg <- "Min < Max is not satisfied for uniform distribution!"
      flog.error(msg)
      stop(msg)
    }
  } else if (distribution == "normal") {
    if (distr.info[[3]] <= 0) {
      msg <- "Variance has to be greater than 0 for normal distribution!"
      flog.error(msg)
      stop(msg)
    }
  } else if (distribution == "weibull" || distribution == "gamma") {
    if (distr.info[[2]] <= 0 || distr.info[[3]] <= 0) {
      msg <- "Shape and Scale have to be choosen greater than 0!"
      flog.error(msg)
      stop(msg)
    }
  }

  distr.param.data <- list()
  for (i in seq_len(length(distr.info))) {
    distr.param.data <- append(distr.param.data,
                               list(tuple(as.character(distr.param.name[i]),
                                          as.character(distr.info[[i]]))))
  }

  complementary <- validateInput("complementary", complementary, "logical")
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context

  data <- data$Select(col)

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_DISTRQUANT_PARAM_TBL_%s", unique.id)
  distr.param.tbl <- sprintf("#PAL_DISTRQUANT_DISTR_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_DISTRQUANT_RESULT_TBL_%s", unique.id)
  TableSpec <- list(tuple("NAME", nvarchar(50)), tuple("VALUE", nvarchar(50)))

  distribution.table <- Table$new(distr.param.tbl, TableSpec)

  in.tables <- list(data, distr.param.tbl, param.tbl)
  out.tables <- list(result.tbl)
  tables <- c(distr.param.tbl, param.tbl, out.tables)

  param.array <- list(tuple("LOWER_UPPER", to.integer(complementary), NULL, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn, distribution.table$WithData(distr.param.data)))
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_DISTRIBUTION_QUANTILE",
                                          in.tables,
                                          out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(result.tbl))
}

#' @title Entropy
#' @name hanaml.Entropy
#' @description hanaml.Entropy is a R wrapper for SAP HANA PAL Entropy.
#' @details
#' This function is used to calculate the information entropy of attributes.
#' @param data \code{DataFrame}\cr
#' DataFrame containting the data.
#' Attributes with continuous data type are ignored.
#' @template args-threadratio
#' @param     distinct.value.count.detail  \code{logical, optional}\cr
#'            Indicates whether to output the details of distinct
#'            value counts. By having complementary is FALSE,
#'            it does not output detailed distinct value count.\cr
#'            Defaults to TRUE.
#'@param      col \code{character of list of characters, optional}\cr
#'            Name of columns to be processed.\cr
#'            If not provided, it defaults all columns of \emph{data}.
#' @return
#' Returns a list of 2 DataFrame.
#' \itemize{
#'   \item\code{DataFrame 1}
#'   \itemize{
#'    \item{COLUMN_NAME} Name of columns
#'    \item{ENTROPY} ENTROPY
#'    \item{COUNT_OF_DISTINCT_VALUES} Count of distinct value
#'    }
#'   \item \code{DataFrame 2}\cr
#'   \itemize{
#'     \item{COLUMN_NAME} Name of columns
#'     \item{DISTINCT_VALUE} Distinct values of columns
#'     \item{COUNT} Count of each distinct value
#'    }
#'  }
#'
#' @section Examples:
#'\preformatted{
#' > data$Head(5)$Collect()
#'   OUTLOOK TEMP HUMIDITY WINDY       CLASS
#' 1   Sunny   75       70   Yes        Play
#' 2   Sunny   NA       90   Yes Do not Play
#' 3   Sunny   85       NA    No Do not Play
#' 4   Sunny   72       95    No Do not Play
#' 5    <NA>   NA       70  <NA>        Play
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Entropy(data=data, col = c('TEMP', 'WINDY'))
#' }
#' Results:
#' \preformatted{
#' > result[[1]]$Collect()
#'   COLUMN_NAME   ENTROPY COUNT_OF_DISTINCT_VALUES
#' 1        TEMP 2.2538576                       10
#' 2       WINDY 0.6901857                        2
#' > result[[2]]$Collect()
#'    COLUMN_NAME DISTINCT_VALUE COUNT
#' 1         TEMP             75     2
#' 2         TEMP             85     1
#' 3         TEMP             72     2
#' 4         TEMP             83     1
#' 5         TEMP             64     1
#' 6         TEMP             81     1
#' 7         TEMP             71     1
#' 8         TEMP             65     1
#' 9         TEMP             68     1
#' 10        TEMP             70     1
#' 11       WINDY            Yes     6
#' 12       WINDY             No     7
#' }
#' @keywords Statistics
#' @export

hanaml.Entropy <- function(data = NULL,
                           col = NULL,
                           distinct.value.count.detail = NULL,
                           thread.ratio = NULL) {

  cols <- data$columns
  col <- validateInput("col", col, cols, case.sensitive = TRUE)
  if (is.null(col))
    col <- cols

  distinct.value.count.detail <- validateInput("distinct.value.count.detail", distinct.value.count.detail, "logical")
  if (!is.null(thread.ratio)) {
    thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
    if (thread.ratio < 0 || thread.ratio > 1) {
      msg <- "The thread.ratio value range is from 0 to 1!"
      flog.error(msg)
      stop(msg)
    }
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_ENTROPY_PARAM_TBL_%s", unique.id)
  result.1.tbl <- sprintf("#PAL_ENTROPY_RESULT1_TBL_%s", unique.id)
  result.2.tbl <- sprintf("#PAL_ENTROPY_RESULT2_TBL_%s", unique.id)

  in.tables <- list(data, param.tbl)
  out.tables <- list(result.1.tbl, result.2.tbl)
  tables <- c(param.tbl, out.tables)

  param.array <- list(tuple("DISTINCT_VALUE_COUNT_DETAIL", to.integer(distinct.value.count.detail), NULL, NULL),
                      tuple("THREAD_RATIO", NULL, thread.ratio, NULL))

  for (c in col) {
    temp.tup <- tuple("COLUMN", NULL, NULL, c)
    param.array <- append(param.array, list(temp.tup))
  }
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_ENTROPY",
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(lapply(out.tables, conn$table))
}

#' @title Equal Variance Test
#' @name hanaml.ftest.equal.var
#' @description hanaml.ftest.equal.var is a R wrapper
#' for SAP HANA PAL Equal Variance Test.
#' @details
#' This function uses statistical F Test to compare two variances s1 and s2
#' of two samples by dividing them, i.e. F = s1^2 / s2^2.
#' @param data.x \code{DataFrame}\cr
#' DataFrame containting the attribute data.
#' @param data.y \code{DataFrame}\cr
#' DataFrame containting the attribute data.
#' @param     test.type \code{{'two.sides', 'less','greater'}, optional}\cr
#'            States the type of the alternative hypothesis for the F test.
#'            The types are given as follows:
#'            \itemize{
#'                \item{\code{'two.sides'}: The variances are not equal}
#'                \item{\code{'less'}:variance from the first population is
#'                less than the second population variance}
#'                \item{\code{'greater'}:variance from the first population
#'                is greater than the second population variance}
#'            }
#'            Defaults to 'two.sides'.
#' @return
#'   \code{DataFrame}\cr
#'   Statistics, structured as follows:
#'   \itemize{
#'     \item{STAT_NAME} Name of statistics
#'     \item{STAT_VALUE} Value of statistics
#'    }
#' @section Examples:
#' Two input Dataframe:
#' \preformatted{
#'  > df.x$Collect()
#'     X
#'  1  1
#'  2  2
#'  3  4
#'  4  7
#'  5  3
#'
#' > df.y$Collect()
#'       Y
#' 1  10.0
#' 2  15.0
#' 3  12.0
#' }
#' Call the function:
#' \preformatted{
#' > res <- hanaml.ftest.equal.var(data.x, data.y, test.type='two.sides')
#' }
#' Results:
#' \preformatted{
#' > res$Collect()
#'
#'                        STAT_NAME  STAT_VALUE
#' 1                        F Value    0.836842
#' 2    numerator degree of freedom    4.000000
#' 3  denominator degree of freedom    2.000000
#' 4                        p-value    0.783713
#' }
#' @keywords Statistics
#' @export

hanaml.ftest.equal.var <- function(data.x, data.y, test.type = NULL) {

  if (length(data.x$columns) != 1) {
    msg <- "data.x should only have one column!"
    flog.error(msg)
    stop(msg)
  }

  if (length(data.y$columns) != 1) {
    msg <- "data.y should only have one column!"
    flog.error(msg)
    stop(msg)
  }

  test.type.map <- list(two.sides = 0, less = 1, greater = 2)
  test.type <- validateInput("test.type", test.type, test.type.map)

  if (!inherits(data.x, "DataFrame")) {
    msg <- "data.x must be given as a DataFrame."
    flog.error(msg)
    stop(msg)
  }

  if (!inherits(data.y, "DataFrame")) {
    msg <- "data.y must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  conn <- data.x$connection.context
  CheckConnection(data.x)

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_EVT_PARAM_TBL_%s", unique.id)
  stat.tbl <- sprintf("#PAL_EVT_STAT_TBL_%s", unique.id)

  in.tables <- list(data.x, data.y, param.tbl)
  out.tables <- list(stat.tbl)
  tables <- c(param.tbl, out.tables)
  param.array <- list(tuple("TEST_TYPE", map.null(test.type, test.type.map), NULL, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_EQUAL_VARIANCE_TEST",
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(stat.tbl))
}

#' @title Factor Analysis
#' @name hanaml.FactorAnalysis
#' @description hanaml.FactorAnalysis is a R wrapper
#' for SAP HANA PAL Factor Analysis.
#' @details Factor Analysis is a statistical method used to extract a low
#' number of latent factors that can best describe the correlations of a
#' large set of observed variables.
#'
#' @template args-data
#' @template args-key
#' @param     factor.num \code{integer}\cr
#'            number of factors used to explain the covariance structure of
#'            the dataset. It should be choosen between 1
#'            and the number of variables.
#'@param      cols \code{list/vector of characters, optional}\cr
#'            Name of data columns that need to be analyzed.\cr
#'            If it is not provided, it defaults all non-key columns of \code{data}.
#' @param     method \code{{'pcm'}, optional}\cr
#'            Specifies method used for factor analysis.
#'            Currently PAL only supports the principal component method.\cr
#'            Defaults to 'pcm'.
#' @param     rotation \code{{'none', 'varimax', 'promax'}, optional}\cr
#'            Specifies method used to rotate the loadings
#'            \itemize{
#'                \item{\code{'none'}}
#'                \item{\code{'varimax'}}
#'                \item{\code{'promax'}}
#'            }
#'            Defaults to 'varimax'.
#' @param     score \code{{'none', 'regression'}, optional}\cr
#'            Specifies method to compute factor scores:
#'            \itemize{
#'                \item{\code{'none'}}
#'                \item{\code{'regression'}}
#'            }
#'            Defaults to 'regression'.
#' @param      matrix \code{{'covariance', 'correlation'}, optional}\cr
#'            \itemize{
#'                \item{\code{'covariance'} use covariance matrix to perform factor
#'                analysis }
#'                \item{\code{'correlation'} use correlation matrix to perform factor
#'                analysis}
#'            }
#'            Defaults to 'correlation'.
#' @param     kappa \code{double, optional}\cr
#'            only valid when rotation = 'promax'
#'            specifies power of promax rotation.\cr
#'            Defaults to 4.
#'
#' @return
#' Return a list of DataFrame:
#' \itemize{
#'    \item{\code{DataFrame 1}}\cr
#'    Sampling results, structured as follows:
#'    \itemize{
#'      \item{FACTOR_ID}: factor id\cr
#'      \item{EIGENVALUE}: Eigenvalue (i.e. variance explained)\cr
#'      \item{VAR_PROP}: Variance proportion to the total variance explained.\cr
#'      \item{CUM_VAR_PROP}: Cumulative variance proportion to the total variance
#'      explained.
#'    }
#'    \item{\code{DataFrame 2}}\cr
#'    Variance explanation, structured as follows:
#'    \itemize{
#'    \item{FACTOR_ID}: factor id
#'    \item{VAR}: Variance explained without rotation
#'    \item{VAR_PROP}: Variance proportion to the total variance explained without
#'    rotation.
#'    \item{CUM_VAR_PROP}: Cumulative variance proportion to the total variance
#'    explained without rotation.
#'    \item{ROT_VAR}: Variance explained with rotation
#'    \item{ROT_VAR_PROP}: Variance proportion to the total variance explained with
#'    rotation.Note that there is
#'    no rotated variance proportion when performing oblique rotation since
#'    the rotated factors are correlated.
#'    \item{ROT_CUM_VAR_PROP}: Cumulative variance proportion to the total
#'    variance explained with rotation.
#'    }
#'    \item{\code{DataFrame 3}}
#'    \itemize{
#'      \item{NAME}: Variable name.
#'      \item{OBERVED_VARS}: Communalities of observed variable
#'    }
#'    \item{\code{DataFrame 4}}
#'    \itemize{
#'      \item{FACTOR_ID}:  Factor id
#'      \item{LOADINGs_+OBSERVED_VARs}: loadings
#'    }
#'    \item{\code{DataFrame 5}}
#'    \itemize{
#'      \item{FACTOR_ID}:  Factor id
#'      \item{ROT_LOADINGS_+OBSERVED_VARs}: rotated loadings
#'    }
#'    \item{\code{DataFrame 6}}
#'    \itemize{
#'      \item{FACTOR_ID}:  Factor id
#'       \item{STRUCTURE+OBSERVED_VARS}: Structure matrix. It is empty when
#'       rotation is not oblique.
#'    }
#'    \item{\code{DataFrame 7}}
#'    \itemize{
#'      \item{ROTATION}:  rotation
#'      \item{ROTATION_ + i (i sequences from 1 to number of columns in
#'       OBSERVED_VARS (in input table)}: Rotation matrix
#'    }
#'    \item{\code{DataFrame 8}}
#'    \itemize{
#'      \item{FACTOR_ID}:  Factor id
#'      \item{FACTOR_ + i (i sequences from 1 to number of columns in
#'       OBSERVED_VARS (in input table)}: Factor correlation matrix.
#'        It is empty when rotation is not oblique.
#'    }
#'    \item{\code{DataFrame 9}}
#'    \itemize{
#'      \item{NAME}:  Factor id, MEAN, SD
#'      \item{OBSERVED_VARS (in input table) column name}: Score coefficients,
#'       means and standard deviations of observed variables.
#'    }
#'    \item{\code{DataFrame 10}}
#'    \itemize{
#'      \item{FACTOR_ID}:  Factor id
#'      \item{FACTOR_ + i (i sequences from 1 to number of columns in
#'       OBSERVED_VARS (in input table))}: scores
#'    }
#'    \item{\code{DataFrame 11}}
#'       Placeholder for future features:
#'       \itemize{
#'       \item{STAT_NAME}:  statistic name.
#'       \item{STAT_VALUE}: statistic value.}
#'  }
#'
#' @section Examples:
#'  Input DataFrame data:
#' \preformatted{
#' >data$Head(6)$Collect()
#'   ID  X1  X2  X3  X4  X5  X6
#' 1  1   1   1   3   3   1   1
#' 2  2   1   2   3   3   1   1
#' 3  3   1   1   3   4   1   1
#' 4  4   1   1   3   3   1   2
#' }
#' Call the function:
#' \preformatted{
#' > fa <- hanaml.FactorAnalysis(data=data,
#'                               factor.num=2,
#'                               method='pcm',
#'                               rotation='promax',
#'                               score='regression',
#'                               matrix='correlation',
#'                               kappa=4)
#' }
#' Output:
#' \preformatted{
#' > fa[[1]]$Collect()
#'   FACTOR_ID EIGENVALUE    VAR_PROP CUM_VAR_PROP
#' 1  FACTOR_1 3.69603077 0.616005129    0.6160051
#' 2  FACTOR_2 1.07311448 0.178852413    0.7948575
#' 3  FACTOR_3 1.00077409 0.166795682    0.9616532
#' 4  FACTOR_4 0.16100348 0.026833913    0.9884871
#' 5  FACTOR_5 0.04096116 0.006826860    0.9953140
#' 6  FACTOR_6 0.02811601 0.004686002    1.0000000
#' }
#' @keywords Statistics
#' @export
hanaml.FactorAnalysis <- function(data,
                                  key,
                                  factor.num,
                                  cols = NULL,
                                  method = NULL,
                                  rotation = NULL,
                                  score = NULL,
                                  matrix = NULL,
                                  kappa = NULL) {
  columns <- data$columns
  key <- validateInput("key", key, columns, case.sensitive = TRUE, required = TRUE)
  columns <- columns[!columns %in% key]

  if (is.null(cols)) {
    cols <- columns
  } else {
    cols <- validateInput("cols", cols, columns, case.sensitive = TRUE)
  }

  selected <- append(list(key), cols)

  factor.num <- validateInput("factor.num", factor.num, "integer", required = TRUE)

  method.map <- list(pcm = 0)
  rotation.map <- list(none = 0, varimax = 1, promax = 2)
  score.map <- list(none = 0, regression = 1)
  matrix.map <- list(covariance = 0, correlation = 1)

  method <- validateInput("method", method, method.map)
  rotation <- validateInput("rotation", rotation, rotation.map)
  score <- validateInput("score", score, score.map)
  matrix <- validateInput("matrix", matrix, matrix.map)
  kappa <- validateInput("kappa", kappa, "double")

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context
  data <- data$Select(selected)

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_PARAM_TBL_%s", unique.id)
  eigval.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_EIGVAL_TBL_%s", unique.id)
  var.expl.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_VAR_EXPL_TBL_%s", unique.id)
  com.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_COM_TBL_%s", unique.id)
  loadings.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_LOADINGS_TBL_%s", unique.id)
  rot.loading.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_ROT_LOADING_TBL_%s", unique.id)
  struct.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_STRUCT_TBL_%s", unique.id)
  rotation.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_ROTATION_TBL_%s", unique.id)
  fac.cor.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_FAC_COR_TBL_%s", unique.id)
  score.model.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_SCORE_MODEL_TBL_%s", unique.id)
  score.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_SCORE_TBL_%s", unique.id)
  stat.tbl <- sprintf("#PAL_FACTOR_ANALYSIS_STAT_TBL_%s", unique.id)


  in.tables <- list(data, param.tbl)
  out.tables <- list(eigval.tbl, var.expl.tbl, com.tbl,
                     loadings.tbl, rot.loading.tbl, struct.tbl,
                     rotation.tbl, fac.cor.tbl, score.model.tbl,
                     score.tbl, stat.tbl)
  tables <- c(param.tbl, out.tables)

  param.array <- list(tuple("FACTOR_NUMBER", factor.num, NULL, NULL),
                      tuple("METHOD", map.null(method, method.map), NULL, NULL),
                      tuple("ROTATION", map.null(rotation, rotation.map), NULL, NULL),
                      tuple("SCORE", map.null(score, score.map), NULL, NULL),
                      tuple("COR", map.null(matrix, matrix.map), NULL, NULL),
                      tuple("KAPPA", NULL, kappa, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_FACTOR_ANALYSIS",
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(lapply(out.tables, conn$table))
}


#' @title Grubbs' Test for Outliers
#' @name hanaml.GrubbsTest
#' @description hanaml.GrubbsTest is a R wrapper
#' for SAP HANA PAL Grubbs' Test.
#' @details
#' Grubbs' test is used to detect a single outlier in a gaussian distributed
#' data set.\cr It can be applied iteratively to detect multiple outliers.
#' @param data \code{DataFrame}\cr
#' DataFrame containting the data points structured as follows:
#' \itemize{
#'   \item{SOURCE_ID : \code{INTEGER}}\cr
#'   \item{RAW_DATA: \code{INTEGER or DOUBLE}}\cr
#'}
#'@param      key \code{character}\cr
#'            Name of the ID column of \code{data}.\cr
#' @param     col \code{character, optional}\cr
#'            Name of the data column that needs to be tested.
#'            If not provided, it defaults the non-key columns of \emph{data}.
#' @param     method \code{{'two.sided', 'one.sided.min','one.sided.max',
#' 'iter.two.sided'},optional}\cr
#'            Specifies the method to test against the hypothesis. The test methods
#'            are given as follows:
#'            \itemize{
#'                \item{\code{'two.sided'} use the two-sided test.}
#'                \item{\code{'one.sided.min'} use the one-sided test for
#'                minimum value.}
#'                \item{\code{'one.sided.max'} use the one-sided test for
#'                maximum value.}
#'                \item{\code{'iter.two.sided'} perform two-sided test
#'                iteratively to detect multiple outliers.}
#'            }
#'            Defaults to 'two.sided'.
#' @param     alpha \code{double, optional}\cr
#'            specifies the significance level at which the algorithm will
#'            reject the hypothesis that there are no outliers in the given
#'            data set.
#'            Defaults to 0.05.
#'
#' @return
#' Returns a list of DataFrame.\cr
#' \itemize{
#'   \item{\code{DataFrame 1}}\cr
#'    Detected outliers, structured as follows:
#'    \itemize{
#'      \item{SOURCE_ID} : ID of the outlier data point.
#'      \item{RAW_DATA} : the corresponding value.
#'    }
#'   \item{\code{DataFrame 2}}\cr
#'    Statistical information of the tests.
#'    \itemize{
#'      \item{SOURCE_ID} : ID of the outlier data point.
#'      \item{STAT_NAME} : Statistics name.
#'      \item{STAT_VALUE} : Statistics value.
#'    }
#'  }
#'
#' @section Examples:
#'\preformatted{
#' > data$Collect()
#'     ID       VAL
#' 1  100  4.254843
#' 2  200  0.135000
#' 3  300 11.072257
#' 4  400 14.797838
#' 5  500 12.125133
#' 6  600 14.265839
#' 7  700  7.731352
#' 8  800  6.856739
#' 9  900 15.094403
#' 10 101  8.149382
#' 11 201  9.160144
#'}
#' Call the function:
#' \preformatted{
#' > result <- hanaml.GrubbsTest(data=data,
#'                               method = 'one.sided.min',
#'                               alpha = 0.2)
#' }
#' Results:
#' \preformatted{
#' > result[[1]]$Collect()
#'    ID   VAL
#' 1 200 0.135
#' > result[[2]]$Collect()
#'    ID                STAT_NAME STAT_VALUE
#' 1 200                     MEAN  9.4220845
#' 2 200 STANDARD_SAMPLE_VARIANCE  4.6759352
#' 3 200                        T  1.9102192
#' 4 200                        G  1.9861448
#' 5 200                        U  0.5660752
#' }
#' @keywords Statistics
#' @export

hanaml.GrubbsTest <- function(data, key, col = NULL, method = NULL, alpha = NULL) {
  columns <- data$columns
  key <- validateInput("key", key, columns, case.sensitive = TRUE, required = TRUE)
  columns <- columns[!columns %in% key]

  if (is.null(col)) {
    if (length(columns) == 1) {
      col <- columns
    } else {
      msg <- "data must have two columns."
      flog.error(msg)
      stop(msg)
    }
  } else {
    col <- validateInput("col", col, columns, case.sensitive = TRUE)
    col <- list(col)
  }

  method.map <- list(two.sided = 1, one.sided.min = 2,
                     one.sided.max = 3, iter.two.sided = 4)
  method <- validateInput("method", method, method.map)
  alpha <- validateInput("alpha", alpha, "double")

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context

  selected <- append(list(key), col)
  data <- data$Select(selected)

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_GRUBBS_TEST_PARAM_TBL_%s", unique.id)
  outlier.tbl <- sprintf("#PAL_GRUBBS_TEST_OUTLIER_TBL_%s", unique.id)
  stat.tbl <- sprintf("#PAL_GRUBBS_TEST_STAT_TBL_%s", unique.id)

  in.tables <- list(data, param.tbl)
  out.tables <- list(outlier.tbl, stat.tbl)
  tables <- c(param.tbl, out.tables)

  param.array <- list(tuple("METHOD", map.null(method, method.map), NULL, NULL),
                      tuple("ALPHA", NULL, alpha, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_GRUBBS_TEST",
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(lapply(out.tables, conn$table))
}

#' @title Kaplan-Meier Survival Analysis
#' @name hanaml.kaplan.meier.survival.analysis
#' @description hanaml.kaplan.meier.survival.analysis is a R wrapper
#' for SAP HANA PAL kaplan.meier.survival.analysis.
#' @details
#' Kaplan Meier is one of the best options to perform non-parametric estimation
#' of the survival function when considering a long term study, where a
#' series of possibly censored failure times are observed. It is often used
#' to measure the time-to-death of patients after treatment or time-to-failure
#' of machine parts
#' @param data \code{DataFrame}\cr
#' DataFrame containting the sampled data points structured as follows:
#' \itemize{
#'   \item{Follow-up time : \code{INTEGER or DOUBLE}}\cr
#'   \item{Status indicator: \code{INTEGER}}\cr
#'   \item{Occurrence number of events at the follow-up time.
#'   (multiple rows for one follow-up time possible) : \code{INTEGER}}\cr
#'   \item{Group : \code{INTEGER or VARCHAR}}\cr
#'  }
#' @param     event.indicator \code{integer, optional}\cr
#'            Specifies one value to indicate an event has occurred.
#'            Defaults to 1.
#' @param     confidence.level \code{double, optional}\cr
#'            specifies the confidence level for a two-sided confidence interval
#'            on the survival estimate.\cr
#'            Defaults to 0.95.
#'
#' @return
#' Returns a list of DataFrames.\cr
#' \itemize{
#'   \item{\code{DataFrame 1}}\cr
#'    Estimation results after every event occurrence, structured as follows:
#'    \itemize{
#'      \item{GROUP}: Group
#'      \item{Time}: Event occurrence time.
#'      \item{RISK_NUMBER}: total number of each group before the event occurrences.
#'      \item{EVENT_NUMBER}: Number of event occurrences.
#'      \item{PROBABILITY}: Probability of surviving beyond event occurrence time.
#'      \item{SE}: Standard error
#'      \item{CI_LOWER}: Lower bound of confidence interval
#'      \item{CI_UPPER}: upper bound of confidence interval
#'   }
#'   \item{\code{DataFrame 2}}\cr
#'    Log rank survival statistics of each group. Only valid for
#'    multiple groups
#'    \itemize{
#'      \item{GROUP}: group\cr
#'      \item{TOTAL_RISK}: All individuals in the lifetime study \cr
#'      \item{OBSERVED}: number of observed events.\cr
#'      \item{LOGRANK_STAT}: log rank test statistics.
#'    }
#'    \item{ \code{DataFrame 3}}\cr
#'    Further statistics. Only valid for multiple groups
#'    \itemize{
#'      \item{STAT_NAME} : Statistics name e.g. Chi-square, df, p-value.
#'      \item{STAT_VALUE} : Statistics value
#'       }
#'    }
#' @section Examples:
#' Input DataFrame data:
#'\preformatted{
#' > data$Head(5)$Collect()
#'   TIME STATUS OCCURRENCES GROUP
#' 1    9      1           1     2
#' 2   10      1           1     1
#' 3    1      1           2     0
#' 4   31      0           1     1
#' 5    2      1           1     0
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.kaplan.meier.survival.analysis(data=data)
#' }
#' Results:
#' \preformatted{
#' > result[[3]]$Collect()
#'   STAT_NAME STAT_VALUE
#' 1    chiSqr  0.3279707
#' 2        df  2.0000000
#' 3   p-value  0.8487545
#' }
#' @keywords Statistics
#' @export
hanaml.kaplan.meier.survival.analysis <- function(data = NULL,
                                                  event.indicator = NULL,
                                                  confidence.level = NULL) {
  col.num <- data$columns
  if (length(col.num) != 4) {
    msg <- "Please check if the components of input data are complete and correct."
    flog.error(msg)
    stop(msg)
  }

  event.indicator <- validateInput("event.indicator", event.indicator, "integer")
  confidence.level <- validateInput("confidence.level", confidence.level, "double")

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_KMSURV_PARAM_TBL_%s", unique.id)
  surv.est.tbl <- sprintf("#PAL_KMSURV_EST_TBL_%s", unique.id)
  stat1.tbl <- sprintf("#PAL_KMSURV_STAT1_TBL_%s", unique.id)
  stat2.tbl <- sprintf("#PAL_KMSURV_STAT2_TBL_%s", unique.id)

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context

  in.tables <- list(data, param.tbl)
  out.tables <- list(surv.est.tbl, stat1.tbl, stat2.tbl)
  tables <- c(param.tbl, out.tables)

  param.array <- list(tuple("EVENT_INDICATOR", event.indicator, NULL, NULL),
                      tuple("CONF_LEVEL", NULL, confidence.level, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_KMSURV",
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(lapply(out.tables, conn$table))
}

#' @title Computes covariance matrix
#' @name hanaml.CovarianceMatrix
#' @description hanaml.CovarianceMatrix is a R wrapper for PAL Multivariate Analysis.
#' @details Computes Covriance matrix  between any two data samples (columns).
#' @keywords Statistics
#' @template args-data
#' @param    cols \code{list of characters, optional}\cr
#'           Name of the columns to analyze.\cr
#'           If it is not given, it defaults to all columns.
#'
#' @return
#' \code{Dataframe}\cr
#' covariance.matrix: Dataframe containing the covariance between any two data samples(columns).
#' structured as follows:
#' \itemize{
#' \item{\code{ID:} type NVARCHAR. The values of this column are the column names
#'            from \emph{cols}.}
#' \item{\code{Covariance columns:} type DOUBLE, named after the columns in \emph{cols}.
#'            The covariance between variables X and Y is in column X, in the
#'            row with ID value Y.}
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    X    Y    Z
#' 1  1  2.4  5.1
#' 2  5  3.5  6.2
#' 3  3  8.9  8.3
#' 4 10 -1.4  9.4
#' 5 -4 -3.5 11.5
#' 6 11 32.8 12.6
#' }
#' Call the function and obtain the result:
#' \preformatted{
#' > hanaml.CovarianceMatrix(data)
#'   ID        X         Y      Z
#' 1  X 31.86667  44.47333  3.500
#' 2  Y 44.47333 176.67767 17.957
#' 3  Z  3.50000  17.95700  8.555
#'
#' OR:
#' > hanaml.CovarianceMatrix(data = data, cols = list('X', 'Y'))
#'   ID        X         Y
#' 1  X 31.86667  44.47333
#' 2  Y 44.47333 176.67767
#'
#' }
#' @export
hanaml.CovarianceMatrix <- function(data, cols = NULL) {

  all.cols <- data$columns
  cols <- validateInput("cols", cols, all.cols, case.sensitive = TRUE)
  if (is.null(cols)) {
    cols <- all.cols
  }
  data <- data$Select(cols)
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_MULTIVARIATE_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_MULTIVARIATE_RESULT_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables <- list(param.tbl, result.tbl)
  param.rows <- list(tuple("RESULT_TYPE", 0, NULL, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_MULTIVARIATE_ANALYSIS",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(result.tbl))
}


#' @title  Computes correlation matrix using Pearsonr
#' @name hanaml.PearsonrMatrix
#' @description hanaml.PearsonrMatrix is a R wrapper for SAP HANA PAL Multivariate Analysis.
#' @details Computes a correlation matrix using Pearson's correlation coefficient.
#' @template args-data
#' @param  cols \code{list of characters, optional}\cr
#'         Name of the columns to analyze.\cr
#'         If not given, it defaults to all columns.
#'
#' @return
#' \code{Dataframe}\cr
#' Pearsonr.matrix: Pearson's correlation coefficient between any two data samples(columns),
#' structured as follows:
#' \itemize{
#'  \item{\code{ID:} type NVARCHAR. The values of this column are the column names
#'             from \emph{cols}.}
#'  \item{\code{Covariance columns:}, type DOUBLE, named after
#'            the columns in \emph{cols}.\cr
#'            The covariance between variables X and Y is in column X, in the
#'            row with ID value Y.}
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    X    Y    Z
#' 1  1  2.4  5.1
#' 2  5  3.5  6.2
#' 3  3  8.9  8.3
#' 4 10 -1.4  9.4
#' 5 -4 -3.5 11.5
#' 6 11 32.8 12.6
#' }
#' Call the function and obtain the result:
#' \preformatted{
#' > hanaml.PearsonrMatrix(df)
#'   ID         X         Y         Z
#' 1  X 1.0000000 0.5927077 0.2119775
#' 2  Y 0.5927077 1.0000000 0.4618840
#' 3  Z 0.2119775 0.4618840 1.0000000
#'
#' }
#' @keywords Statistics
#' @export
hanaml.PearsonrMatrix <- function(data, cols = NULL) {

  all.cols <- data$columns
  cols <- validateInput("cols", cols, all.cols, case.sensitive = TRUE)
  if (is.null(cols)) {
    cols <- all.cols
  }
  data <- data$Select(cols)

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_MULTIVARIATE_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_MULTIVARIATE_RESULT_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables <- list(param.tbl, result.tbl)
  param.rows <- list(tuple("RESULT_TYPE", 1, NULL, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_MULTIVARIATE_ANALYSIS",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(result.tbl))
}

#' @title One-Sample Median Test
#' @name hanaml.median.test.1samp
#' @description hanaml.median.test.1samp is a R wrapper
#' for SAP HANA PAL One-Sample Median Test.
#' @details This algorithm performs a one-sample nonparametric test to check
#' whether the median of the data is different from the user-specified one.
#' @template args-data
#' @param     col \code{character, optional}\cr
#'            Name of the data column that needs to be tested.\cr
#'            If it is not given, the input dataframe must only have one column.
#' @param     mu \code{double, optional}\cr
#'            Hypothesized median of the population underlying the sample.\cr
#'            Defaults to 0.
#' @param     test.type \code{character, optional}\cr
#'            The alternative hypothesis type.
#'            \itemize{
#'                \item{'two.sides'}
#'                \item{'less'}
#'                \item{'greater'}
#'            }
#'            Defaults to 'two.sides'.
#' @param     confidence.interval \code{double, optional}\cr
#'            Confidence level for alternative hypothesis confidence interval.\cr
#'            Defaults to 0.95.
#' @template args-threadratio
#' @return
#' \code{Dataframe}\cr
#' Dataframe containing the statistics results from the one-sample test.
#' @section Examples:
#'  Input DataFrame data:
#' \preformatted{
#'  > data$Collect()
#'     X1
#'  1  85
#'  2  65
#'  3  20
#'  ...
#'  18 40
#'  19 64
#'  20  8
#'  }
#'  Call the function:
#' \preformatted{
#'  > result <- hanaml.median.test.1samp(data)
#'  }
#'  Output:
#' \preformatted{
#'  > result$Collect()
#'                               STAT_NAME   STAT_VALUE
#'  1                         total number 2.000000e+01
#'  2               number smaller than m0 0.000000e+00
#'  3                number larger than m0 2.000000e+01
#'  4                     estimated median 6.150000e+01
#'  5 CI for estimated median, lower bound 2.700000e+01
#'  6 CI for estimated median, upper bound 8.300000e+01
#'  7                    sign test p-value 2.151786e-05
#' }
#' @keywords Statistics
#' @export
hanaml.median.test.1samp <- function(data,
                                     col = NULL,
                                     mu = NULL,
                                     test.type = NULL,
                                     confidence.interval = NULL,
                                     thread.ratio = NULL) {

  col.num <- length(data$columns)
  if (is.null(col)) {
    if (col.num != 1) {
      msg <- "If 'col' is not specified, the input dataframe must only have one column."
      flog.error(msg)
      stop(msg)
    } else {
      col <- data$columns
    }
  } else {
    col <- validateInput("col", col, data$columns, case.sensitive = TRUE)
    col <- list(col)
  }

  if (!is.null(thread.ratio)) {
    thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
    if (thread.ratio < 0 || thread.ratio > 1) {
      msg <- "The thread.ratio value range is from 0 to 1!"
      flog.error(msg)
      stop(msg)
    }
  }

  test.type.map <- list(two.sides = 0, less = 1, greater = 2)
  test.type <- validateInput("test.type", test.type, test.type.map)
  mu <- validateInput("mu", mu, "double")
  confidence.interval <- validateInput("confidence.interval", confidence.interval, "double")

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context
  data <- data$Select(col)
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_SIGNTEST_PARAM_TBL_%s", unique.id)
  stat.tbl <- sprintf("#PAL_SIGNTEST_STAT_TBL_%s", unique.id)
  param.array <- list(tuple("TEST_TYPE", map.null(test.type, test.type.map), NULL, NULL),
                      tuple("M0", NULL, mu, NULL),
                      tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
                      tuple("CONFIDENCE_INTERVAL", NULL, confidence.interval, NULL))
  in.tables <- list(data, param.tbl)
  out.tables <- list(stat.tbl)
  tables <- list(param.tbl, stat.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_SIGN_TEST",
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(list(conn$table(stat.tbl)))
}

TTest <- function(data,
                  mu = NULL,
                  test.type = NULL,
                  paired = NULL,
                  var.equal = NULL,
                  conf.level = NULL) {
  test.type.map <- list(two_sides = 0,
                        less = 1,
                        greater = 2)
  test.type <- validateInput("test.type", test.type, test.type.map)
  mu <- validateInput("mu", mu, "numeric")
  paired <- validateInput("paired", paired, "logical")
  var.equal <- validateInput("var.equal", var.equal, "logical")
  conf.level <- validateInput("conf.level", conf.level, "numeric")

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#TTEST_PARAM_TBL_%s", unique.id)
  stat.tbl <- sprintf("#TTEST_STAT_TBL_%s", unique.id)
  param.array <- list(tuple("TEST_TYPE", map.null(test.type, test.type.map),
                            NULL, NULL),
                      tuple("MU", NULL, mu, NULL),
                      tuple("PAIRED", to.integer(paired), NULL, NULL),
                      tuple("VAR_EQUAL", to.integer(var.equal), NULL, NULL),
                      tuple("CONF_LEVEL", NULL, conf.level, NULL))

  in.tables <- list(data, param.tbl)
  out.tables <- list(stat.tbl)
  tables <- list(param.tbl, stat.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_T_TEST",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(stat.tbl))
}

#' @title One Sample T-Test
#' @name hanaml.TTest1Samp
#' @description hanaml.TTest1Samp is a R wrapper
#' for SAP HANA PAL T Test.
#' @details It is a statistical procedure used to determine whether a sample
#' of observations could have been generated by a process with a specific mean.
#' @template args-data
#' @param     col \code{character, optional}\cr
#'            Names of column for T-test.\cr
#'            No default value.
#' @param     mu \code{double, optional}\cr
#'            Hypothesized mean of the population underlying the sample.\cr
#'            Defaults to 0.
#' @param     test.type \code{character, optional}\cr
#'            The alternative hypothesis type.
#'            \itemize{
#'                \item{'two_sides'}
#'                \item{'less'}
#'                \item{'greater'}
#'            }
#'            Defaults to 'two_sides'.
#' @param     conf.level \code{double, optional}\cr
#'            Confidence level for alternative hypothesis confidence interval.\cr
#'            Defaults to 0.95.
#'
#' @return
#' \code{Dataframe}\cr
#' Dataframe containing the statistics results from the t-test.
#'
#' @section Examples:
#'  Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'   X1 X2
#' 1  1 10
#' 2  2 12
#' 3  4 11
#' 4  7 15
#' 5  3 10
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.TTest1Samp(data)
#' }
#' Output:
#' \preformatted{
#' > result$Collect()
#'                STAT_NAME    STAT_VALUE
#' 1                t-value -1.406288e+01
#' 2      degree of freedom  4.000000e+00
#' 3                p-value  1.483726e-04
#' 4 _PAL_MEAN_DIFFERENCES_ -8.200000e+00
#' 5       confidence level  9.500000e-01
#' 6             lowerLimit -9.818932e+00
#' 7             upperLimit -6.581068e+00
#' }
#' @keywords Statistics
#' @export
hanaml.TTest1Samp <- function(data,
                              col = NULL,
                              mu = NULL,
                              test.type = NULL,
                              conf.level = NULL) {
  cols <- data$columns
  col <-  validateInput("col", col, cols, case.sensitive = TRUE)
  if (is.null(col)) {
    if (length(cols) > 1 ) {
      msg <- "If col is not given, the input DataFrame must only have one column."
      flog.error(msg)
      stop(msg)
    } else {
      col <- cols[[1]]
    }
  }
  data <- data$Select(col)
  return(TTest(data = data,
               mu = mu,
               test.type = test.type,
               conf.level = conf.level))
}

#' @title Independent sample TTest
#' @name hanaml.TTestInd
#' @description hanaml.TTestInd is a R wrapper
#' for SAP HANA PAL T Test.
#' @details It is a statistic procedure used to determine whether the mean
#' difference between two unrelated groups is equal to a given value.
#' @template args-data
#' @param  cols \code{character, optional}\cr
#'         Names of the two columns for independent T-test.\cr
#'         No default value.\cr
#'         If not specified, then \emph{data} must only have
#'         two columns, otherwise an error shall be issued.
#' @param  mu \code{double, optional}\cr
#'         Hypothesized mean of the population underlying the sample.\cr
#'         Defaults to 0.
#' @param  test.type \code{character, optional}\cr
#'         The alternative hypothesis type.
#'         \itemize{
#'             \item{'two_sides'}
#'             \item{'less'}
#'             \item{'greater'}}
#'         Defaults to 'two_sides'.
#' @param  var.equal \code{logical, optional}\cr
#'         Controls whether to assume that the two samples have equal variance.\cr
#'         Defaults to FALSE.
#' @param  conf.level \code{double, optional}\cr
#'         Confidence level for alternative hypothesis confidence interval.\cr
#'         Defaults to 0.95.
#'
#' @return
#' \code{Dataframe}\cr
#' Statistics of the independent sample T-test.
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#'  > data$Collect()
#'    X1 X2
#'  1  1 10
#'  2  2 12
#'  3  4 11
#'  4  7 15
#'  5 NA 10
#' }
#'  Call the function:
#' \preformatted{
#'  > result <- hanaml.TTestInd(data)
#'  }
#'  Output:
#' \preformatted{
#'  > result$Collect()
#'            STAT_NAME   STAT_VALUE
#'  1           t-value  -5.01377413
#'  2 degree of freedom   5.64975672
#'  3           p-value   0.00287491
#'  4     _PAL_MEAN_X1_   3.50000000
#'  5     _PAL_MEAN_X2_  11.60000000
#'  6  confidence level   0.95000000
#'  7        lowerLimit -12.11327798
#'  8        upperLimit  -4.08672202
#' }
#' @keywords Statistics
#' @export
hanaml.TTestInd <- function(data,
                            cols = NULL,
                            mu = NULL,
                            test.type = NULL,
                            var.equal = NULL,
                            conf.level = NULL) {
  data.cols <- data$columns
  cols <- validateInput("cols", cols, data.cols, case.sensitive = TRUE)
  if (length(cols) == 0 && length(data.cols) != 2) {
    msg <- paste("If cols is not given,",
                 "the input DataFrame must only have two columns.")
    flog.error(msg)
    stop(msg)
  }
  if (!is.null(cols) && cols[[1]] == cols[[2]]){
    msg <- paste("The two columns specified for",
                 "independent sample T-test must be different.")
    flog.error(msg)
    stop(msg)
  }
  col.list <- list()
  col.list <- append(col.list, cols)
  if (!is.null(cols)){
    data <- data$Select(col.list)
  }
  return(TTest(data = data,
               mu = mu,
               test.type = test.type,
               paired = FALSE,
               var.equal = var.equal,
               conf.level = conf.level))
}

#' @title Paired sample TTest
#' @name hanaml.TTestPaired
#' @description hanaml.TTestPaired is a R wrapper for SAP HANA PAL T-Test.
#' @details It is a statistic procedure used to determine whether the mean
#' difference between two sets of paired observations is equal to a given value.
#' @template args-data
#' @param  cols \code{character, optional}\cr
#'         Names of the two columns for paired samples.\cr
#'         No default value.
#'         If not specified, then \emph{data} must only have
#'         two columns, otherwise an error shall be issued.
#' @param  mu \code{double, optional}\cr
#'         Hypothesized mean of the population underlying the sample.\cr
#'         Defaults to '0'.
#' @param  test.type \code{character, optional}\cr
#'         The alternative hypothesis type.
#'         \itemize{
#'             \item{'two_sides'}
#'             \item{'less'}
#'             \item{'greater'}}
#'         Defaults to 'two_sides'.
#' @param  var.equal \code{logical, optional}\cr
#'         Controls whether to assume that the two samples have equal variance.\cr
#'         Defaults to FALSE.
#' @param  conf.level \code{double, optional}\cr
#'         Confidence level for alternative hypothesis confidence interval.\cr
#'         Defaults to 0.95.
#' @return
#'\code{Dataframe}\cr
#' Statistics of the paired sample T-test.
#' @section Examples:
#'  Input DataFrame data:
#' \preformatted{
#'  > data$Collect()
#'    X1 X2
#'  1  1 10
#'  2  2 12
#'  3  4 11
#'  4  7 15
#'  5  3 10
#' }
#'  Call the function:
#' \preformatted{
#'  > output <- hanaml.TTestPaired(data)
#'  }
#'  Output:
#' \preformatted{
#'  > output$stats.output$Collect()
#'                 STAT_NAME    STAT_VALUE
#'  1                t-value -1.406288e+01
#'  2      degree of freedom  4.000000e+00
#'  3                p-value  1.483726e-04
#'  4 _PAL_MEAN_DIFFERENCES_ -8.200000e+00
#'  5       confidence level  9.500000e-01
#'  6             lowerLimit -9.818932e+00
#'  7             upperLimit -6.581068e+00
#' }
#'
#' @keywords Statistics
#' @export
hanaml.TTestPaired <- function(data,
                               cols = NULL,
                               mu = NULL,
                               test.type = NULL,
                               var.equal = NULL,
                               conf.level = NULL) {
  data.cols <- data$columns
  if (is.null(cols) && length(data.cols) != 2){
    msg <- paste("If cols is not given,",
                 "the input DataFrame must only have two columns.")
    flog.error(msg)
    stop(msg)
  } else if (!is.null(cols) && cols[[1]] == cols[[2]]){
    msg <- paste("The two columns specified for paired",
                 "sample T-test must be different.")
    flog.error(msg)
    stop(msg)
  }
  cols <- validateInput("cols", cols, data.cols, case.sensitive = TRUE)
  col.list <- list()
  col.list <- append(col.list, cols)
  if (!is.null(cols)){
    data <- data$Select(col.list)
  }
  return(TTest(data = data,
               mu = mu,
               test.type = test.type,
               paired = TRUE,
               var.equal = var.equal,
               conf.level = conf.level))
}

#' @title Univariate Analysis
#' @name hanaml.UnivariateAnalysis
#' @description hanaml.UnivariateAnalysis is a R wrapper
#'  for SAP HANA PAL Univariate Analysis.
#' @details
#' Provides an overview of the dataset. For continuous columns, it provides
#' the count of valid observations, min, lower quartile, median, upper
#' quartile, max, mean, confidence interval for the mean (lower and upper
#' bound), trimmed mean, variance, standard deviation, skewness, and kurtosis.
#' For discrete columns, it provides the number of occurrences and the
#' percentage of the total data in each category.
#' @template args-data
#' @template args-key-optional
#' @param  cols  \code{list of characters, optional}\cr
#'         List of column names to analyze.\cr
#'         If not provided, it defaults to all non-ID columns.
#' @template args-cate-var
#' @param  significance.level  \code{double, optional}\cr
#'         The significance level when the function calculates the confidence
#'         interval of the sample mean.\cr
#'         Values must be greater than 0 and less than 1.\cr
#'         Defaults to 0.05.
#' @param  trimmed.percentage \code{double, optional}\cr
#'         The ratio of data at both head and tail that will be dropped in the
#'         process of calculating the trimmed mean.\cr
#'         Value range is from 0 to 0.5.\cr
#'         Defaults to 0.05.
#' @return
#' Return a list of two DataFrame:
#' \itemize{
#'    \item{\code{DataFrame 1}}\cr
#'         Continuous result: statistics for continuous variables.
#'    \item{\code{DataFrame 2}}\cr
#'         Categorical result: statistics for categorical variables.
#'}
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'      X1 X2 X3 X4
#' 1   1.2 NA  1  A
#' 2   2.5 NA  2  C
#' 3   5.2 NA  3  A
#' 4 -10.2 NA  2  A
#' 5   8.5 NA  2  C
#' 6 100.0 NA  3  B
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.UnivariateAnalysis(data,
#'                                       categorical.variable='X3',
#'                                       significance.level=0.05,
#'                                       trimmed.percentage=0.2)
#' }
#' Ouput:
#' \preformatted{
#' > result[[1]]
#'    VARIABLE_NAME     CATEGORY      STAT_NAME  STAT_VALUE
#' 1             X3 __PAL_NULL__          count     0.00000
#' 2             X3 __PAL_NULL__  percentage(\%)     0.00000
#' 3             X3            1          count     1.00000
#' 4             X3            1  percentage(\%)    16.66667
#' 5             X3            2          count     3.00000
#' 6             X3            2  percentage(\%)    50.00000
#' 7             X3            3          count     2.00000
#' 8             X3            3  percentage(\%)    33.33333
#' 9             X4 __PAL_NULL__          count     0.00000
#' 10            X4 __PAL_NULL__  percentage(\%)     0.00000
#' 11            X4            A          count     3.00000
#' 12            X4            A  percentage(\%)    50.00000
#' 13            X4            B          count     1.00000
#' 14            X4            B  percentage(\%)    16.66667
#' 15            X4            C          count     2.00000
#' 16            X4            C  percentage(\%)    33.33333
#'
#' > result[[2]]
#'    VARIABLE_NAME                STAT_NAME  STAT_VALUE
#' 1             X1       valid observations    6.000000
#' 2             X1                      min  -10.200000
#' 3             X1           lower quartile    1.200000
#' 4             X1                   median    3.850000
#' 5             X1           upper quartile    8.500000
#' 6             X1                      max  100.000000
#' 7             X1                     mean   17.866667
#' 8             X1 CI for mean, lower bound  -24.879549
#' 9             X1 CI for mean, upper bound   60.612883
#' 10            X1             trimmed mean    4.350000
#' 11            X1                 variance 1659.142667
#' 12            X1       standard deviation   40.732575
#' 13            X1                 skewness    1.688495
#' 14            X1                 kurtosis    1.036148
#' 15            X2       valid observations    0.000000
#' }
#' @keywords Statistics
#' @export
hanaml.UnivariateAnalysis <- function(data,
                                      key = NULL,
                                      cols = NULL,
                                      categorical.variable = NULL,
                                      significance.level = NULL,
                                      trimmed.percentage = NULL) {
  significance.level <-
    validateInput("significance.level", significance.level, "double")
  if (!is.null(significance.level)){
    if ((significance.level <= 0 ) || (significance.level >= 1)){#nolint
      msg <- "significance.level value range is larger than 0 and smaller than 1!"
      flog.error(msg)
      stop(msg)
    }
  }
  categorical.variable <- validateInput("categorical.variable",
                                        categorical.variable,
                                        data$columns,
                                        case.sensitive = TRUE)
  trimmed.percentage <-
    validateInput("trimmed.percentage", trimmed.percentage, "double")
  if (!is.null(trimmed.percentage)){
    if ((trimmed.percentage < 0 ) || (trimmed.percentage >= 0.5)) {#nolint
      msg <- "trimmed.percentage value range is no less than 0 and smaller than 0.5!"
      flog.error(msg)
      stop(msg)
    }
  }

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context

  all.cols <- data$columns
  key <- validateInput("key", key, all.cols, case.sensitive = TRUE)
  if (!is.null(key)){
    id.col <- list(key)
  } else {
    id.col <- list()
  }
  all.cols <- all.cols[!all.cols %in% key]
  cols <- validateInput("cols", cols, all.cols, case.sensitive = TRUE)
  if (is.null(cols)) {
    cols <- all.cols
  }

  data <- data$Select(c(id.col, cols))

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_UNIVARIATE_PARAM_TBL_%s", unique.id)
  continuous.tbl <- sprintf("#PAL_UNIVARIATE_CONTINUOUS_TBL_%s", unique.id)
  categorical.tbl <- sprintf("#PAL_UNIVARIATE_CATEGORICAL_TBL_%s", unique.id)
  param.rows <- list(
    tuple("SIGNIFICANCE_LEVEL", NULL, significance.level, NULL),
    tuple("TRIMMED_PERCENTAGE", NULL, trimmed.percentage, NULL),
    tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL))
  if (!is.null(categorical.variable)) {
    for (each in categorical.variable) {
      temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
      param.rows <- append(param.rows, tuple(temp.list))
    }
  }

  in.tables <- list(data, param.tbl)
  out.tables <- list(continuous.tbl, categorical.tbl)
  tables <- list(param.tbl, continuous.tbl, categorical.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_UNIVARIATE_ANALYSIS",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(list(conn$table(continuous.tbl),
              conn$table(categorical.tbl)))
}

#' @title Wilcoxon Signed Rank Test
#' @name hanaml.Wilcoxon
#' @description hanaml.Wilcoxon is a R wrapper for SAP HANA PAL Wilcox Signed Rank Test.
#' @details
#' Wilcoxon signed rank test is a non-parametric procedure which tests the
#' sample median against a hypothetical median.
#' The Wilcoxon signed rank test should be used if the sample data come from
#' a symmetrical distribution, otherwise it is recommended to use the one-sample-median test.
#' @template args-data
#' @param     test.type \code{{'two.sides', 'less','greater'},optional}\cr
#'            Specifies the type of the hypothesis for the test. The types are
#'            given as follows:
#'            \itemize{
#'                \item{\code{'two.sides'}:The true median is different from mu.}
#'                \item{\code{'less'}:The true median is less than mu.}
#'                \item{\code{'greater'}:The true median is greater than mu.}
#'            }
#'            Defaults to 'two.sides'.
#' @param     mu \code{double, optional}\cr
#'            Specifies the hypothetical value of median.\cr
#'            Defalut to 0.
#' @param     correction \code{logical, optional}\cr
#'            Specifies whether or not to include the continuity correction
#'            for the p value calculation.\cr
#'            Defaults to TRUE.
#' @param     col \code{character, optional}\cr
#'            Name of the data column that needs to be tested.
#'            If not given, the input dataframe must only have one column.\cr
#'            Defaults to NULL.
#' @return
#' \itemize{
#'   \item{\code{DataFrame}}\cr
#'    Statistical information of the test,e.g. p-value
#'    \itemize{
#'      \item{STAT_NAME} : Statistics name.
#'      \item{STAT_VALUE} : Statistics value.}
#' }
#' @section Examples:
#' Input DataFrame data of one-sample example:
#' \preformatted{
#' > data$Head(5)$Collect()
#'    X
#' 1 85
#' 2 65
#' 3 20
#' 4 56
#' 5 30
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Wilcoxon(data = data, test.type = 'two.sides',
#'                           mu = 40, correction = TRUE )
#' }
#' Results:
#' \preformatted{
#' > result$Collect()
#'   STAT_NAME   STAT_VALUE
#' 1 statistic 158.50000000
#' 2   p-value   0.01122824
#' }
#'
#' Input DataFrame data of paired two-sample example:
#' \preformatted{
#' > data$Head(5)$Collect()
#'   X1 X2
#' 1 85 60
#' 2 65 68
#' 3 20 20
#' 4 56 89
#' 5 30  7
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Wilcoxon(data = data, test.type = 'two.sides' ,
#'                             correction = TRUE)
#' }
#' Results:
#' \preformatted{
#' > result$Collect()
#'   STAT_NAME  STAT_VALUE
#' 1 statistic 118.5000000
#' 2   p-value   0.3546207
#' }
#' @keywords Statistics
#' @export
hanaml.Wilcoxon <- function(data,
                            col = NULL,
                            mu = NULL,
                            test.type = NULL,
                            correction = NULL) {
  col <- validateInput("col", col, data$columns, case.sensitive = TRUE)
  if (is.null(col)) {
    col <- data$columns
    if (length(col) > 2) {
      msg <- "If 'col' is not specified, the input dataframe must only have one or two columns."
      flog.error(msg)
      stop(msg)
    }
  } else {
    if (length(col) > 2) {
      msg <- "'col' can only specify one or two columns of data to be tested."
      flog.error(msg)
      stop(msg)
    } }

  mu <- validateInput("mu", mu, "numeric")
  test.type.map <- list(two.sides = 0, less = 1, greater = 2)
  test.type <- validateInput("test.type", test.type, test.type.map, case.sensitive = TRUE)
  correction <- validateInput("correction", correction, "logical")

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context
  data <- data$Select(col)

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_WILCOX_TEST_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_WILCOX_TEST_RESULT_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables <- c(param.tbl, out.tables)

  param.array <- list(tuple("TES_TYPE", map.null(test.type, test.type.map), NULL, NULL),
                      tuple("MU", NULL, mu, NULL),
                      tuple("CORRECTION", to.integer(correction), NULL, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_WILCOX_TEST",
                                          in.tables,
                                          out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(result.tbl))
}
