#' @title Inter-Quartile Range
#' @name hanaml.IQR
#' @description hanaml.IQR is a R wrapper for SAP HANA PAL Inter-Quartile Range.
#' @details
#' Given a series of numeric data, the inter-quartile range (IQR) is
#' the difference between the third quartile (Q3) and the first quartile (Q1) of the data.
#' @template args-data
#' @template args-key
#' @param col \code{character, optional}\cr
#' Data that needs to be tested.\cr
#' Defaults to the first non-ID column if not provided.
#' @param multiplier \code{double, optional}\cr
#' The multiplier used in the IQR test.\cr
#' Defaults to 1.5.
#' @return
#' Returns a list of DataFrame:
#' \itemize{
#'   \item{DataFrame 1}\cr
#' Test results, structured as follows:
#' \itemize{
#'   \item{}ID column, with same name and type as \code{data}'s ID column.
#'   \item{}IS_OUT_OF_RANGE column, type INTEGER, containing the test results from
#' the IQR test that determine whether each data sample is in the
#' range or not: 0 indicates a value is in the range and 1 indicates a value is out of range.
#' }
#'    \item{DataFrame 2}\cr
#'    Including Upper-bound and Lower-bound from the IQR test, structured
#'    as follows:
#'    \itemize{
#'      \item{}STAT_NAME, type NVARCHAR(256), statistics name.
#'      \item{}STAT_VALUE, type DOUBLE, statistics value.
#'    }
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'      ID VAL
#'  1   P1  10
#'  2   P2  11
#'  3   P3  10
#'  ...
#'  12 P12  11
#'  13 P13  12
#'  14 P14  13
#'  15 P15  12
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.IQR(data, key="ID", multiplier = 1.5)
#' }
#' Output:
#' \preformatted{
#' > result[[1]]$Collect()
#'      ID    IS_OUT_OF_RANGE
#'  1   P1        0
#'  2   P2        0
#'  3   P3        0
#'  ......
#'  12 P12        0
#'  13 P13        0
#'  14 P14        0
#'  15 P15        0
#'  }
#' @keywords Preprocessing
#' @export
hanaml.IQR <- function(data,
                       key,
                       col = NULL,
                       multiplier = NULL) {
  multiplier <- validateInput("multiplier", multiplier, "double")
  if (!is.null(multiplier)) {
    if (multiplier < 0) {
      msg <- "Parameter multiplier should be greater than or equal to 0."
      flog.error(msg)
      stop(msg)
    }
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)

  cols <- data$columns
  key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
  cols <- cols[!cols %in% key]
  col <- validateInput("col", col, cols, case.sensitive = TRUE)
  if (is.null(col)){
    col <- cols[[1]]
  }
  data <- data$Select(list(key, col))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_IQR_PARAMETER_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_IQR_RESULT_TBL_%s", unique.id)
  statistic.tbl <- sprintf("#PAL_IQR_STATISTIC_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl, statistic.tbl)
  tables <- list(param.tbl, result.tbl, statistic.tbl)
  param.array <- list(tuple("MULTIPLIER", NULL, multiplier, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_IQR",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(list(conn$table(result.tbl),
              conn$table(statistic.tbl)))
}
