ConnectionContext <- R6Class(
  "ConnectionContext",
  public = list(
    dsn = NULL,
    username = NULL,
    connection = NULL,
    odbc = NULL,
    rodbc = NULL,
    autocommit = NULL,
    last.pal.call = NULL,
    initialize = function(dsn = ""
                          , username = ""
                          , password = ""
                          , odbc = TRUE
                          , jdbcDriverPath = NULL
                          , rodbc = FALSE
                          , encrypt = NULL
                          , validateCertificate = NULL
                          , autocommit = FALSE
                          , ...) {
      self$dsn <- dsn
      self$username <- username
      self$odbc <- odbc
      self$rodbc <- rodbc
      self$autocommit <- autocommit
      if (!is.null(jdbcDriverPath)) {
        if (odbc) {
          flog.warn("Since jdbcDriverPath has been set, odbc is disabled.")
        }
        odbc <- FALSE
      }
      tryCatch({
        self$connection <- private$connect(dsn,
                                           username,
                                           password,
                                           odbc,
                                           jdbcDriverPath,
                                           rodbc,
                                           encrypt,
                                           validateCertificate,
                                           autocommit, ...)
        private$version.afl.check()
      },
      warning = function(war) {
        flog.warn(sprintf("Failed: %s", war))
      },
      error = function(err) {
        flog.error(sprintf("Error: %s", err))
        stop()
      })},
    close = function() {
       tryCatch({
         if (grepl("JDBC", toString(class(self$connection)), fixed = TRUE) ||
             grepl("HDB", toString(class(self$connection)), fixed = TRUE)) {
           dbDisconnect(self$connection)
         } else{
           RODBC::odbcClose(self$connection)
         }
      },
      error = function(err) {
        if (grepl("JDBC", toString(class(self$connection)), fixed = TRUE)) {
          stop("RJDBC channel is closed.")
        }
        else if (repl("HDB", toString(class(self$connection)), fixed = TRUE)) {
          stop("ODBC channel is closed.")
        }
        else {
          stop("RODBC channel is closed.")
        }
      })
    },
    commit = function() {
      if (self$autocommit == FALSE) {
        if (grepl("JDBC", toString(class(self$connection)), fixed = TRUE)){
          RJDBC::dbCommit(self$connection)
        }
        if (grepl("HDB", toString(class(self$connection)), fixed = TRUE)){
          odbc::dbCommit(self$connection)
        }
      }
    },

    GetCurrentSchema = function() {
      select.sql <- "SELECT CURRENT_SCHEMA from Dummy"
      return (sqlQueryMix(self$connection, select.sql))
    },

    table = function(table, schema = NULL) {
      if (!is.character(table)){
        msg <- "Table should be a string"
        flog.error(msg)
        stop(msg)
      }
      if (is.null(schema))
        select <- sprintf("SELECT * FROM %s",
                          QuoteName(table))
      else
        select <- sprintf("SELECT * FROM %s.%s",
                          QuoteName(schema),
                          QuoteName(table))
      return (hanaml.DataFrame(self, select, table))
    },

    tbl = function(table, schema = NULL){
      if ("dplyr" %in% rownames(installed.packages()) == FALSE) {
        install.packages("dplyr")
        library("dplyr")
      } else {
        library("dplyr")
      }
      if ("dbplyr" %in% rownames(installed.packages()) == FALSE) {
        install.packages("dbplyr")
        library("dbplyr")
      } else {
        library("dbplyr")
      }
      if (is.null(schema)){
        return(dplyr::tbl(self$connection, table))
      }
      else{
        return(dplyr::tbl(self$connection, dbplyr::in_schema(table, schema)))
      }
    },
    sql = function(sql){
      return (hanaml.DataFrame(self, sql))
    },
    hana.version = function(getMajor = FALSE, ...){
      val <- sqlQueryMix(self$connection, "SELECT version,
      substr_before (version, '.') as major FROM m_database")
      version <- as.character(val[[1]])
      major <- as.integer(val[[2]])
      if (getMajor == TRUE){
        return (major)
      } else {
        return (version)
      }
    },
    create.table = function(table,
                            table.structure,
                            schema = NULL,
                            table.type = "COLUMN",
                            prop = "",
                            data.lake = FALSE,
                            data.lake.container = "SYSRDL#CG") {
      table.ref <- NULL
      if (is.null(schema)) {
        table.ref <- QuoteName(table)
      } else {
        table.ref <- sprintf("%s.%s", QuoteName(schema), QuoteName(table))
      }
      if (startsWith(table, "#")) {
        table.type <- " LOCAL TEMPORARY "
      } else {
        if (data.lake) {
          table.type <- " "
        }
        else {
          table.type <- paste(" ", table.type, " ")
        }
      }
      query <- sprintf("CREATE%sTABLE %s (", table.type, table.ref)
      for (item in 1:length(table.structure)) {
        query <- sprintf("%s%s %s, ",
                         query,
                         QuoteName(names(table.structure)[item]),
                         table.structure[item])
      }
      query <- substr(query, 1, nchar(query) - 2)
      query <- sprintf("%s) %s", query, prop)
      if (data.lake) {
        query <- sprintf("CALL %s.REMOTE_EXECUTE ('%s')", data.lake.container, query)
      }
      ExecuteLogged(self$connection, query)
      self$commit()
    },
    create.virtual.table = function(table, data.lake.table, schema = NULL, data.lake.container = "SYSRDL#CG") {
      table.ref <- NULL
      if (is.null(schema)) {
        table.ref <- QuoteName(table)
      } else {
        table.ref <- sprintf("%s.%s", QuoteName(schema), QuoteName(table))
      }
      query <- sprintf("CREATE VIRTUAL TABLE %s AT \"%s_SOURCE\".\"NULL\".\"%s\".%s",
                      table.ref,
                      data.lake.container,
                      data.lake.container,
                      QuoteName(data.lake.table))
      ExecuteLogged(self$connection, query)
      self$commit()
    },
    copy.to.data.lake = function(data, virtual.table, data.lake.table, schema = NULL, append = FALSE,
                                 data.lake.container = "SYSRDL#CG") {
      if (!append) {
        table.structure <- data$GetTableStructure()
        for (key in names(table.structure)) {
          if (table.structure[[key]] == "NCLOB") {
            table.structure[[key]] <- "CLOB"
          }
          if (table.structure[[key]] == "NBLOB") {
            table.structure[[key]] <- "BLOB"
          }
          if (grepl("NVARCHAR", table.structure[[key]], fixed = TRUE)) {
            table.structure[[key]] <- gsub("NVARCHAR", "VARCHAR", table.structure[[key]])
          }
        }
        self$create.table(table = data.lake.table,
                          table.structure = table.structure,
                          schema = schema,
                          data.lake = TRUE,
                          data.lake.container = data.lake.container)
        self$create.virtual.table(virtual.table, data.lake.table, schema, data.lake.container)
      }
      table.ref <- NULL
      if (is.null(schema)) {
        table.ref <- QuoteName(virtual.table)
      } else {
        table.ref <- sprintf("%s.%s", QuoteName(schema), QuoteName(virtual.table))
      }
      query <- sprintf("INSERT INTO %s %s", table.ref, data$select.statement)
      ExecuteLogged(self$connection, query)
      self$commit()
    },
    drop.table = function(table, schema = NULL, data.lake = FALSE, data.lake.container = "SYSRDL#CG") {
      if (is.null(schema)) {
        schema <- self$GetCurrentSchema()
      }
      query <- sprintf("DROP TABLE %s.%s", QuoteName(schema), QuoteName(table))
      if (data.lake) {
        query <- sprintf("DROP TABLE %s", QuoteName(table))
        query <- sprintf("CALL %s.REMOTE_EXECUTE ('%s')", data.lake.container, query)
      }
      ExecuteLogged(self$connection, query)
      self$commit()
    }
   ),
  private = list(
    connect = function(dsn, username, password, odbc, jdbcDriverPath, rodbc,
                       encrypt, validateCertificate, autocommit, ...) {
      if (rodbc == TRUE) {
        if ("RODBC" %in% rownames(installed.packages()) == FALSE) {
          install.packages("RODBC")
          library("RODBC")
        } else {
          library("RODBC")
        }
        if (dsn == "" || is.null(dsn)) {
          return (...)
        }
        else {
          msg <- "RODBC is not recommended to use. To set RODBC=FALSE and use odbc lib instead."
          flog.warn(msg)
          return (odbcConnect(dsn, uid = username, pwd = password, ...))
        }
      }
      else if (odbc == TRUE && rodbc == FALSE){
        if ("odbc" %in% rownames(installed.packages()) == FALSE) {
          install.packages("odbc")
          library("odbc")
        } else {
          library("odbc")
        }
        return (dbConnect(odbc::odbc(), dsn, uid = username, pwd = password, ...))
      }
      else {
        if ("RJDBC" %in% rownames(installed.packages()) == FALSE) {
          install.packages("RJDBC")
          library("RJDBC")
        } else {
          library("RJDBC")
        }
        if (is.null(jdbcDriverPath)) {
            jdbcDriverPath <- Sys.getenv("JDBC_DRIVER_PATH")
        }
        jdbcDriver <- JDBC(driverClass = "com.sap.db.jdbc.Driver"
        , classPath = jdbcDriverPath, ...)
        option <- list(paste0("autocommit=",
                              tolower(as.character(autocommit))))
        if (!is.null(encrypt)) {
          option <- c(option, paste0("encrypt=",
                              tolower(as.character(encrypt))))
        }
        if (!is.null(validateCertificate)) {
          option <- c(option, paste0("validateCertificate=",
                              tolower(as.character(validateCertificate))))
        }
        if (grepl("[?]", dsn)){
          return (dbConnect(jdbcDriver
                            , paste0(sprintf("jdbc:sap://%s", dsn),
                                     "&",#nolint
                                     paste0(option, collapse = "&"))
                            , username
                            , password
                            , ...))
        }
        return (dbConnect(jdbcDriver
                        , paste0(sprintf("jdbc:sap://%s", dsn),
                                 "/?",#nolint
                                 paste0(option, collapse = "&"))
                        , username
                        , password
                        , ...))
      }
   },

    version.afl.check = function(){
    val <- ExecuteLogged(self$connection, "select version,
    substr_before (version, '.') as major,
    substr_before (substr_after (version, '.'), '.') as minor,
    substr_before (substr_after (substr_after (version, '.'), '.') , '.') as patch
    from m_database")
    version <- as.character(val[[1]])
    major <- as.integer(val[[2]])
    minor <- as.integer(val[[3]])
    patch <- as.integer(val[[4]])
    Afl_avail <- ExecuteLogged(self$connection, "SELECT count(*) FROM \"SYS\".\"AFL_PACKAGES\" WHERE AREA_NAME = 'AFLPAL'")#nolint
    if ( (isTRUE(major >= 2) && isTRUE(patch >= 030) ) || (isTRUE(major >= 2) && isTRUE(minor >= 50) ) || (isTRUE(major >= 4) ) ) {#nolint
       if (Afl_avail <= 0){
       msg1 <- sprintf("The HANA version is %s which is valid, however PAL libraries are not available. Please reinstall and try again.", version)#nolint
       flog.error(msg1)
       }
    } else {
       msg2 <- "The hanaml R libraries require HANA version2 SP03 or above. Please install an approriate version and try again."#nolint
       flog.error(msg2)
    }
    valid.roles <- ExecuteLogged(self$connection, "SELECT count(*) FROM SYS.EFFECTIVE_ROLES
    WHERE USER_NAME=CURRENT_USER AND ROLE_SCHEMA_NAME IS NULL AND ROLE_NAME IN
    ('AFL__SYS_AFL_AFLPAL_EXECUTE','AFL__SYS_AFL_AFLPAL_EXECUTE_WITH_GRANT_OPTION')")
    if (valid.roles <= 0) {
    msg3 <- "Missing required roles. To execute PAL procedures you should have AFL__SYS_AFL_AFLPAL_EXECUTE and AFL__SYS_AFL_AFLPAL_EXECUTE_WITH_GRANT_OPTION roles"#nolint
    flog.error(msg3)
    }
    msg <- sprintf("The HANA version is %s and note that some classes, functions and their parameters are different between HANA versions and please refer to the documentation of the specific function and class!", version)#nolint
    flog.warn(msg)
  }
 )
)
#' @title ConnectionContext
#' @name hanaml.ConnectionContext
#' @details Represents a connection to a SAP HANA system.
#' ConnectionContext includes methods for creating DataFrames from data
#' on SAP HANA. DataFrames are tied to a ConnectionContext, and are unusable
#' once their ConnectionContext is closed.
#' @param dsn \code{character}\cr A registered data source name for ODBC or <host>:<port> for JDBC.
#' @param username \code{character}\cr User name.
#' @param password \code{character}\cr Password.
#' @param odbc \code{logical, optional}\cr Whether to use ODBC or JDBC database connectivity.
#'        For ODBC connectivity, hana.ml.r supports two library 'odbc'(recommended) and 'RODBC'.\cr Defaults to TRUE.
#' @param jdbcDriver \code{character, optional}\cr Path to the JDBC driver. Only valid for JDBC.
#' @param rodbc \code{logical, optional}\cr Whether to use library 'RODBC' for ODBC database connectivity. If TRUE, use RODBC. Else, use odbc.
#'        This parameter is only valid for using ODBC connectivity.\cr Defaults to FALSE.
#' @param encrypt \code{logical, optional}\cr
#'        Whether or not to encrypt the connection.\cr
#'        Valid only for JDBC.\cr
#' @param validateCertificate \code{logical, optional}\cr
#'        Whehter or not to validate certifcate when connection to the server.\cr
#'        Valid only for JDBC.\cr
#' @param autocommit \code{logical, optional}\cr
#'        Whether or not setting a JDBC connection to autocommit mode.\cr
#'        Valid only for JDBC.\cr
#'        Defaults to FALSE.
#' @param ... \code{}\cr
#' @return Object of \code{\link{R6Class}} with methods for ConnectionContext.
#' @section Methods:
#' \describe{
#'   \item{\code{close()}}{
#'    Closes the existing connection.\cr
#'    \emph{Usage:}
#'    \code{conn$close()}
#'     }
#'
#'   \item{\code{sql(sql)}}{
#'    Returns a DataFrame representing a query.\cr
#'
#'    \emph{Usage:}
#'    \code{df <- conn$sql('SELECT T.A, T2.B FROM T, T2 WHERE T.C=T2.C')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{sql, character}: Sql Query.}}
#'    \emph{Returns:}
#'    \code{DataFrame}
#'    Dataframe for the query.}
#'
#'    \item{\code{GetCurrentSchema()}}{
#'    Returns the name of current working schema in the database.\cr
#'
#'    \emph{Usage: } \code{ conn$GetCurrentSchema()} \cr
#'    \emph{Returns: }
#'    \code{character} Current schema name.}
#'
#'    \item{\code{hana.version(getMajor=FALSE, ...)}}{
#'    Returns the version or major version of SAP HANA.\cr
#'
#'    \emph{Usage: } \code{ conn$hana.version()} \cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{getMajor, logical}: if TRUE, return the major nubmer of SAP HANA version. Defaults to FALSE. }}
#'    \emph{Returns: }
#'    \code{character or integer}\cr The version of SAP HANA or major version if getMajor is TRUE.}
#'
#'   \item{\code{table(table, schema = NULL)}}{
#'    Returns a DataFrame representing a table.\cr
#'
#'    \emph{Usage:}
#'    \code{df1 <- conn$table('MY_TABLE')}\cr
#'    \code{df2 <- conn$table('MY_OTHER_TABLE', schema='MY_SCHEMA')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{table, character}:   Table Name(without schema). }
#'     \item{\code{schema, character, optional}:  Schema name.
#'     Defaults to the ConnectionContext's current schema if not provided. }
#'     }
#'    \emph{Returns:}
#'    \code{DataFrame}
#'    DataFrame selecting data from that table.
#'    }
#'  }
#' @export
hanaml.ConnectionContext <- function(dsn = "", username = "", password = "", odbc = TRUE,
                                     jdbcDriver = NULL, rodbc = FALSE, encrypt = NULL,
                                     validateCertificate = NULL, autocommit = FALSE, ...){
  ConnectionContext$new(dsn, username, password, odbc, jdbcDriver,
                        rodbc, encrypt, validateCertificate, autocommit,
                        ...)
}


DataFrame <- R6Class(
  "DataFrame",
  ## list of methods and fields.
  public = list(
    select.statement = NULL,
    current.schema = NULL,
    columns.df = NULL,
    nrows.df = NULL,
    name.df = NULL,
    quoted.name.df = NULL,
    connection.context = NULL,
    initialize = function(connection.context = NULL,
                          select.statement = NULL,
                          name = NULL){
      if (is.null(connection.context) || is.null(select.statement))
        stop("Please provide value for connection.Context/Select.Statement")
      if (!(inherits(connection.context, "R6")))
        stop("Connection.Context type mismatch!")
      self$connection.context <- connection.context
      self$select.statement <- select.statement
      if (is.null(name)){
        self$name.df <- sprintf("DT_%s", self$GetDfCounter())
        self$quoted.name.df <- QuoteName(self$name.df)
        private$shared_env$df.count <- self$GetDfCounter() + 1
      } else {
        self$name.df <- name
        self$quoted.name.df <- QuoteName(self$name.df)
      }
    },

    AddId = function(id){
      if (!id %in% self$columns) {
        select.statement <- sprintf("SELECT CAST(ROW_NUMBER() OVER() AS INTEGER)
                                    AS %s, * FROM (%s)",
                                    id,
                                    self$select.statement)
        return (self$GetDf(select.statement))
      }
      return (self)
    },

    Alias = function(aliasName){
      return (self$GetDf(self$select.statement, aliasName))
    },

    cast = function(cols, new.type){
      d <- intersect(self$columns, cols)
      new.list <- list()
      for (colName in self$columns.df){
        if (colName %in% d){
          new.list <- append(new.list, sprintf("CAST(%s AS %s) AS %s",#nolint
                             QuoteName(colName), new.type, QuoteName(colName)))#nolint
        } else {
          new.list <- append(new.list, QuoteName(colName))
        }
      }
      select.statement <- sprintf("SELECT %s FROM (%s) AS %s", paste(new.list, collapse = ", "),
                                  self$select.statement, self$quoted.name)
      return (self$GetDf(select.statement))
    },

    Collect = function(){
      results <- self$RunQuery(self$select.statement)
      if (isTRUE(length(results) == 1 && results == "No Data")) {
        col.types <- self$dtypes()
        for (col.info in col.types) {
          if ("ST_GEOMETRY" %in% col.info) {
            temp.df <- self$cast(col.info[[1]], "CLOB")
            break
          }
        }
        results <- temp.df$RunQuery(temp.df$select.statement)
      }
      data.frame.result <- as.data.frame(results)
      return (data.frame.result)
    },

    Count = function() {
      new.select.statement <- sprintf("select count(*) from (%s)", self$select.statement)
      result <- ExecuteLogged(self$connection.context$connection, new.select.statement)  # call from sqlinterface
      return (result)
    },

    Describe = function(cols=NULL) {
      #count , mean, stddev, min, max
      dtypes <- self$dtypes()
      if (!is.null(cols)){
        dtypes <- self$dtypes(cols)
      }
      numerics <- list()
      non.numerics <- list()
      for (col in dtypes){
        if (col[[2]] == "INT" ||
            col[[2]] == "TINYINT" ||
            col[[2]] == "BIGINT" ||
            col[[2]] == "INTEGER" ||
            col[[2]] == "DOUBLE" ||
            col[[2]] == "DECIMAL" ||
            col[[2]] == "FLOAT")
          numerics <- append(numerics, col[[1]])
        else if (col[[2]] == "NCHAR" ||
                 col[[2]] == "NVARCHAR" ||
                 col[[2]] == "CHAR" ||
                 col[[2]] == "VARCHAR" ||
                 col[[2]] == "STRING")
          non.numerics <- append(non.numerics, col[[1]])
      }
      sql.numerics <- NULL
      sql.non.numerics <- NULL
      min.max <- 'MIN(%s) as "min", MAX(%s) as "max", '
      if (length(numerics)){
        sql.for.numerics1 <- paste0("select %s as \"column\", COUNT(%s) as \"count\",",
                                    "COUNT(DISTINCT %s) as \"unique\", SUM(CASE WHEN %s is ",
                                    "NULL THEN 1 ELSE 0 END) as \"nulls\" , AVG(%s) as \"mean\"",
                                    ", STDDEV(%s) as \"std\",", min.max, "MEDIAN(%s) as \"median\"",
                                    "FROM (%s) AS %s")

        union <- list()
        for (col in numerics){
          temp.query <- sprintf(sql.for.numerics1, private$colNameFormatting(col), QuoteName(col), QuoteName(col),
                                QuoteName(col), QuoteName(col), QuoteName(col), QuoteName(col), QuoteName(col),
                                QuoteName(col), self$select.statement, self$quoted.name)
          union <- append(union, temp.query)
        }

        sql.simple.stats <- paste(union, collapse = " UNION ALL ")
        percentiles <- paste0("SELECT %s as \"column\", * FROM (SELECT ",
                              "percentile_cont(0.25) WITHIN GROUP (ORDER BY %s) ",
                              "AS \"25_percent_cont\", ",
                              "percentile_disc(0.25) WITHIN GROUP (ORDER BY %s) ",
                              "AS \"25_percent_disc\", ",
                              "percentile_cont(0.50) WITHIN GROUP (ORDER BY %s) ",
                              "AS \"50_percent_cont\", ",
                              "percentile_disc(0.50) WITHIN GROUP (ORDER BY %s) ",
                              "AS \"50_percent_disc\", ",
                              "percentile_cont(0.75) WITHIN GROUP (ORDER BY %s) ",
                              "AS \"75_percent_cont\", ",
                              "percentile_disc(0.75) WITHIN GROUP (ORDER BY %s) ",
                              "AS \"75_percent_disc\" ",
                              "FROM (%s) AS %s)")
        union <- list()
        for (col in numerics){
          temp.query <-  sprintf(percentiles, private$colNameFormatting(col),
                                 QuoteName(col), QuoteName(col), QuoteName(col),
                                 QuoteName(col), QuoteName(col), QuoteName(col),
                                 self$select.statement, self$quoted.name)
          union <- append(union, temp.query)
        }

        sql.percentiles <- paste(union, collapse = " UNION ALL ")
        sql.numerics1 <- "SELECT \"SimpleStats\".*,"
        temp.sql <- ""
        for (x in list(25, 50, 75)){
          temp <- sprintf('%s."%s_percent_cont", %s."%s_percent_disc",', '"Percentiles"', x, '"Percentiles"', x)
          temp.sql <- paste(temp.sql, temp)
        }
        sql.numerics2 <- substr(temp.sql, 1, nchar(temp.sql) - 1)
        sql.numerics3 <- sprintf(paste0(" FROM (%s) AS \"SimpleStats\", (%s)",
                                        "AS \"Percentiles\" WHERE \"SimpleStats\".\"column\"",
                                        "= \"Percentiles\".\"column\""), sql.simple.stats, sql.percentiles)
        sql.numerics <- paste0(sql.numerics1, sql.numerics2, sql.numerics3)
        min.max <- "CAST(NULL AS DOUBLE) AS \"min\", CAST(NULL AS DOUBLE) AS \"max\", "
      }
      if (length(non.numerics)){
        sql.for.non.numerics <- paste0("select %s as \"column\", COUNT(%s) ",
                                       "as \"count\", COUNT(DISTINCT %s) as \"unique\", ",
                                       "SUM(CASE WHEN %s IS NULL THEN 1 ELSE 0 END) as \"nulls\", ",
                                       "CAST(NULL as DOUBLE) AS \"mean\", CAST(NULL as double) as ",
                                       "\"std\", ", min.max, " CAST(NULL as DOUBLE) AS \"median\", ",
                                       "CAST(NULL AS DOUBLE) AS \"25_percent_cont\", ",
                                       "CAST(NULL AS DOUBLE) AS \"25_percent_disc\", ",
                                       "CAST(NULL AS DOUBLE) AS \"50_percent_cont\", ",
                                       "CAST(NULL AS DOUBLE) AS \"50_percent_disc\", ",
                                       "CAST(NULL AS DOUBLE) AS \"75_percent_cont\", ",
                                       "CAST(NULL AS DOUBLE) AS \"75_percent_disc\" ",
                                       "FROM (%s) AS %s")
        union <- list()
        for (col in non.numerics){
          temp.query <- sprintf(sql.for.non.numerics,
                                private$colNameFormatting(col),
                                QuoteName(col),
                                QuoteName(col),
                                QuoteName(col),
                                self$select.statement,
                                self$quoted.name)
          union <- append(temp.query, union)
        }
        sql.non.numerics <- paste(union, collapse = " UNION ALL ")
        sql.non.numerics
      }
      if (is.null(sql.numerics) && is.null(sql.non.numerics)){
        flog.error(sprintf("Error: %s", err))
        stop()
      }

      if (!is.null(sql.numerics) && !is.null(sql.non.numerics)){
        sql.statement <- paste0("SELECT * FROM (%s) AS %s UNION ALL SELECT * FROM ",
                                "(%s) AS %s")
        sql.statement <- sprintf(sql.statement,
                                 sql.numerics,
                                 "\"Numerics\"",
                                 sql.non.numerics,
                                 "\"NonNumerics\"")
        return (self$GetDf(sql.statement))
      }
      if (!is.null(sql.numerics)){
        return (self$GetDf(sql.numerics))
      }
      return (self$GetDf(sql.non.numerics))
    },

    distinct = function(cols=NULL) {
      if (!is.null(cols)) {
        for (col in cols)
          if (!col %in% self$columns){
            msg <- sprintf("Dataframe does not have column %s", col)
            flog.error(msg)
            stop()
          }
      } else {
        cols <- self$columns
      }
      select.statement <- "SELECT DISTINCT %s FROM (%s) AS %s"
      colnames <- paste(QuoteName(cols), collapse = ", ")
      select.statement <- sprintf(select.statement, colnames,
                                  self$select.statement,
                                  self$quoted.name)
      return (self$GetDf(select.statement))
    },

    Drop = function(cols) {
      if (!inherits(cols, "list") && !is.character(cols))   # expects a list of columns
        stop("cols should be of type list or of type character")
      if (is.character(cols)) {
        cols <- list(cols)
      }
      for (each.column in cols) {
        if (!each.column %in% self$columns) {
          stop(sprintf("Can't drop nonexistent column", each.column))
        }
      }
      flag <- TRUE
      cols.kept <- setdiff(self$columns.df, cols)
      cols.template <- ""
      for (each.column in cols.kept) {
        if (!is.null(each.column)) {
          if (flag) {
            each.order.by <- sprintf("%s", QuoteName(each.column))
            flag <- FALSE
          } else {
            each.order.by <- sprintf(",%s", QuoteName(each.column))
          }
          cols.template <- paste(cols.template, each.order.by, sep = " ")
        }
      }
      new.select.statement <- sprintf("SELECT %s FROM (%s) as %s", cols.template,
                                      self$select.statement, self$quoted.name)
      return (self$GetDf(new.select.statement))

    },

    DropDuplicates = function(subset.df=NULL){
      if (is.null(subset.df)){
        select.statement <- sprintf("SELECT DISTINCT * FROM (%s) AS %s",
                                    self$select.statement, self$quoted.name)
        return (self$GetDf(select.statement))
      }
      if (!inherits(subset.df, "list"))   # expects a list of columns
        stop("subset.df should be of type list")
      if (length(subset.df) < 1){
        stop("drop.duplicates requires at least one column in subset")
      }

      keep.columns <- paste(QuoteName(self$columns), collapse = ", ")
      partition.by <- paste(QuoteName(subset.df), collapse = ", ")
      seqnum.col <- self$GenerateColname("SEQNUM")
      select.with.seqnum <- sprintf("SELECT *, ROW_NUMBER() OVER (PARTITION BY %s) AS %s FROM (%s)",
                                    partition.by, seqnum.col, self$select.statement)
      new.select.statement <- sprintf("SELECT %s FROM (%s) WHERE %s = 1",
                                      keep.columns, select.with.seqnum, seqnum.col)
      return (self$GetDf(new.select.statement));
    },

    DropNa = function(how=NULL, thresh=NULL, subset=NULL){
      if (!is.null(how) && !is.null(thresh)){
        stop ("Cannot provide both how and thresh")
      }
      if (!is.null(subset)){
        cols <- QuoteName(subset)
      } else {
        cols <- QuoteName(self$columns)
      }
      cols <- sapply(cols, function(x) toString(x))
      if (is.null(thresh)){
        if (identical(how, "any") || identical(how, NA) )
          and.or <- " OR "
        else if ( identical(how, "all") ){
          and.or <- " AND "
        } else {
          stop (sprintf("Invalid value of how:%s", how))
        }
        drop.if <- ""
        flag <- 1
        for (each.column in cols) {
          each.order.by <- sprintf("%s IS NULL", each.column)
          if (flag < length(cols)){
            add.and.or <- sprintf("%s", and.or)
            each.order.by <- paste(each.order.by, add.and.or, collapse = "")
            flag <- flag + 1
          }
          drop.if <- paste(drop.if, each.order.by, collapse = "")
        }
        keep.if <- sprintf("NOT (%s)", drop.if)
        return (self$Filter(keep.if))
      } #if thresh loop
      count.expression <- ""
      flag <- 1
      for (each.Column in cols) {
        case.statement <- sprintf("'(CASE WHEN %s IS NULL THEN 0 ELSE 1 END)", each.Column)
        if (flag < length(cols)){
          join.str <- sprintf("%s", "+")
          case.statement <- paste(case.statement, join.str, collapse = "")
          flag <- flag + 1
        }
        count.expression <- paste(count.expression, case.statement, collapse = "")
      }
      count.colname <- self$GenerateColname("CT")
      select.with.count <- sprintf("SELECT *, (%s) AS %s FROM (%s) %s", count.expression,
                                   count.colname, self$select.statement, self$quoted.name)
      projection <- paste(QuoteName(self$columns.df), collapse = ", ")
      new.select.statement <- sprintf("SELECT %s FROM (%s) WHERE %s >= %s", projection,
                                      select.with.count, count.colname, thresh)
      return(self$GetDf(new.select.statement))
    },

    dtypes = function(subset.col = NULL){
      #expects list as input
      unique.id <-
        toupper(gsub("-", "_", UUIDgenerate()))
      dtypes.all <- list()
      temp.table.name <- sprintf("#TRYTHISTABLE_%s", unique.id)
      temp.table.statement <- sprintf("CREATE LOCAL TEMPORARY COLUMN TABLE %s AS (%s)",
                                      temp.table.name, self$select.statement)
      temp.table.result <- ExecuteLogged(self$connection.context$connection, temp.table.statement)
      if (length(temp.table.result) != 0){
        if (temp.table.result == -1L)
          stop("Please check if the SQL statement is correct.")
        temp.table.drop <- sprintf("DROP TABLE %s", temp.table.name)
        ExecuteLogged(self$connection.context$connection, temp.table.drop)
        temp.table.result <- ExecuteLogged(self$connection.context$connection, temp.table.statement)
      }
      temp.table.desc.query <- sprintf(paste0("SELECT COLUMN_NAME, DATA_TYPE_NAME,LENGTH FROM ",
                                              "M_TEMPORARY_TABLE_COLUMNS WHERE TABLE_NAME = '%s'
                                              AND COLUMN_NAME != '$rowid$'",
                                              "ORDER BY POSITION"), temp.table.name)
      temp.table.result <- ExecuteLogged(self$connection.context$connection, temp.table.desc.query)
      flag <- TRUE
      if (!is.null(subset.col) && length(subset.col) > 0)  {
        temp.data.frame <- temp.table.result[temp.table.result$COLUMN_NAME %in% subset.col, ]
      } else{
        temp.data.frame <- temp.table.result
      }
      for (row in 1:nrow(temp.data.frame)){
        local.list <- list()
        for (cols in 1:ncol(temp.data.frame)){
          if (cols == 3)
            local.list <- append(local.list, temp.data.frame[row, cols])
          else
            local.list <- append(local.list, as.character(temp.data.frame[row, cols]))
        }
        dtypes.all[[row]] <- local.list
      }
      #delete the temporary table
      temp.table.desc.query <- sprintf("DROP TABLE %s", temp.table.name)
      temp.table.result <- ExecuteLogged(self$connection.context$connection, temp.table.desc.query)
      dtypes.all
    },

    FillNa = function(value, subset.df=NULL){
      if (!inherits(subset.df, "list"))   # expects a list of columns
        stop("subset.df should be of type list")
      if (!is.null(subset.df))
        filled.set <- unique(subset.df)
      else
        filled.set <- unique(self$columns)
      if (!identical(class(value), "numeric") && !identical(class(value), "integer")) {
        stop("Fill values currently must be ints or floats.")
      }
      select.values <- list()
      for (col in self$columns){
        quoted.col <- QuoteName(col)
        if (col %in% filled.set){
          select.values <- append(select.values, sprintf("COALESCE(%s, %s) AS %s",
                                                         quoted.col, value, quoted.col))
        } else {
          select.values <- append(select.values, quoted.col)
        }
      }
      cols <- paste(select.values, collapse = ", ")
      new.select.statement <- sprintf("SELECT %s FROM (%s) dt",
                                      QuoteName(cols),
                                      self$select.statement)
      return(self$GetDf(new.select.statement))
    },

    Filter = function(condition){
      new.select.statement <- sprintf("SELECT * FROM (%s) AS %s WHERE %s",
                                      self$select.statement,
                                      self$quoted.name, condition)
      return(self$GetDf(new.select.statement))
    },

    GenerateColname = function(prefix = "GEN_COL") {
      if (!prefix %in% self$columns)
        return (prefix)

      for (i in 1:length(self$columns.df)) {
        gen_col <- sprintf("%s_%s", prefix, i)
        if (!gen_col %in% self$columns.df)
          return (gen_col)
      }
      stop ("This shouldn\'t be reachable.")
    },

    GetDf = function(new.select.statement, name=NULL) {
      return (hanaml.DataFrame(self$connection.context, new.select.statement, name))
    },

    GetDfCounter = function(){
      df.count <- private$shared_env$df.count
      if (is.null(df.count))
        df.count <-  0
      return(df.count)
    },

    GetTableStructure = function() {
      table.structure <- list()
      for (item in self$dtypes()){
        if (grepl("VARCHAR", toupper(item[[2]]), fixed = TRUE)) {
          table.structure[[item[[1]]]] <- sprintf("%s(%s)",
                                                  item[[2]],
                                                  item[[3]])
        } else if (grepl("DECIMAL", toupper(item[[2]]), fixed = TRUE)) {
          table.structure[[item[[1]]]] <- sprintf("DOUBLE")
        } else {
          table.structure[[item[[1]]]] <- item[[2]]
        }
      }
      return (table.structure)
    },

    GetNRows = function() {
      if (!is.null(self$nrows.df)) {
        row.cnt <- self$nrows.df
      } else {
        row.cnt <- self$Count()
      }
      self$nrows.df <- row.cnt[[1]]
    },

    Has = function(col){
      if (col %in% self$columns)
        return (TRUE)
      else
        return (FALSE)
    },

    Head = function(n=1){
      new.select.statement <- sprintf("SELECT TOP %s * FROM (%s) dt", n,
                                      self$select.statement)
      return (self$GetDf(new.select.statement))
    },

    Join = function(other, on.expression=NULL, how="inner"){
      typeof.join <- c("inner", "outer", "left", "right")
      join.type.map <- list(inner = "INNER", left = "LEFT OUTER",
                            right = "RIGHT OUTER", outer = "FULL OUTER")
      if (!how %in% typeof.join)
        stop (sprintf("Invalid value for 'how' argument: %s", how))

      on.clause <- ""
      if (is.null(on.expression))
        stop("Invalid on.expression.  It must be specified")
      on.clause <- sprintf("ON %s", on.expression)
      join.type <- join.type.map[[how]]
      new.select.statement <- sprintf("SELECT * FROM (%s) AS %s %s JOIN (%s) AS %s %s",
                                      self$select.statement, self$quoted.name, join.type,
                                      other$select.statement, other$quoted.name, on.clause)
      return (self$GetDf(new.select.statement))
    },

    rename.columns = function(new.col.names){
      if (!inherits(new.col.names, "list")){
        stop("Please provide a list for column rename")
      }
      if (is.null(names(new.col.names))){
        if (length(new.col.names) != length(self$columns)){
          if (length(new.col.names) > length(self$columns))
            msg <- "Too many"
          else
            msg <- "Not enough"
          stop(sprintf("%s columns in rename.columns list.", msg))
        }
        temp.list <- list()
        for (count in 1:length(self$columns)){
          temp.list[[self$columns[[count]]]] <- new.col.names[[count]]
        }
        new.col.names <- temp.list
      } else{
        if (!all(names(new.col.names) %in% self$columns)){
          col.diff <- setdiff(as.list(names(new.col.names)), self$columns)
          if (length(col.diff) > 0){
            col.diff <- paste(col.diff, collapse = ", ")
            stop(sprintf("Column(s) not in DataFrame: %s", col.diff))
          }
        }
      }
      result <- list()
      for (count in 1:length(new.col.names)){
        result <- append(result, list(tuple(names(new.col.names)[count],
                                            new.col.names[[count]])))
      }
      Filter(length, result)
      return (self$Select(result))
    },

    RunQuery = function(Query) {
      result <- ExecuteLogged(self$connection.context$connection, Query) # call from sqlinterface
      return (result)
    },

    save = function(table,
                    table.type = NULL,
                    force = FALSE,
                    schema = NULL,
                    append = FALSE,
                    data.lake = FALSE,
                    data.lake.container = "SYSRDL#CG"){
      if (data.lake) {
        if (force) {
          self$connection.context$drop.table(table = table, data.lake = TRUE)
          self$connection.context$drop.table(table = table, schema = schema)
        }
        self$connection.context$copy.to.data.lake(data = self,
                                                  virtual.table = table,
                                                  data.lake.table = table,
                                                  schema = schema,
                                                  append = append,
                                                  data.lake.container = data.lake.container)
      } else {
        if (is.null(table.type)){
          if (startsWith(table, "#")){
            table.type <- "LOCAL TEMPORARY COLUMN"
          } else {
            table.type <- "COLUMN"
          }
        }
        table.types <- c("ROW", "COLUMN", "HISTORY COLUMN", "GLOBAL TEMPORARY",
                         "GLOBAL TEMPORARY COLUMN", "LOCAL TEMPORARY",
                         "LOCAL TEMPORARY COLUMN")
        if (!toupper(table.type) %in% table.types){
          stop(sprintf("%s is not a valid value of table_type", table.type))   #raise error
        }
        if (is.null(schema)){
          where.string <- QuoteName(table)
        } else {
          where.string <- sprintf("%s.%s", QuoteName(schema), QuoteName(table))
        }
        #running the query, need to change with the sqlinterface
        if (force == TRUE) {
          if (!append) {
            dropCmd <- sprintf("DROP TABLE %s", where.string)
            ExecuteLogged(self$connection.context$connection, dropCmd)
          }
        }
        if (append) {
          insertCmd <- sprintf("INSERT INTO %s %s", where.string, self$select.statement)
          ExecuteLogged(self$connection.context$connection, insertCmd)
        } else {
          ExecuteLogged(self$connection.context$connection, sprintf("CREATE %s TABLE %s AS (%s)",
                                                                    table.type, where.string, self$select.statement))
        }
      }
    },

    Select = function(cols){
      # Expects a tuple, package 'sets' need to be installed and tuples can be
      # created using 'col.list <- list('*','select'); cols <- sets::as.tuple(x = col.list)'
      select.cols <- list()
      for (col in cols){
        if (inherits(col, "tuple")){
          select.cols <- append(select.cols, tuple(col))
        } else if (identical(col, "*")){
          select.cols <- append(select.cols, self$columns)
        } else {
          select.cols <- append(select.cols, col)
        }
      }
      select.cols <- select.cols[lapply(select.cols, length) > 0]
      valid.set <- unique(self$columns)
      check.name <- list()
      for (col in select.cols){
        if (inherits(col, "character")){
          check.name <- append(check.name, col)
        }
      }
      invalid_names <- setdiff(check.name, valid.set)
      if (length(invalid_names) > 0){
        stop(sprintf("Column(s) not in DataFrame: %s", invalid_names))
      }
      projection <- list()
      for (col in select.cols){
        if (inherits(col, "character")){
          projection <- append(projection, QuoteName(col))
        } else {
          expr <- col[1]
          name <- col[2]
          projection <- append(projection, sprintf("%s AS %s", QuoteName(expr), QuoteName(name)))
        }
      }
      collpase.projection <-  paste(projection, collapse = ", ")
      new.select.statement <- sprintf("SELECT %s FROM (%s) %s", collpase.projection,
                                      self$select.statement, self$quoted.name)
      newdf <- self$GetDf(new.select.statement)
      temp.columns <- list()
      for (col in select.cols){
        if (inherits(col, "character")){
          temp.columns <- append(temp.columns, col)
        } else {
          temp.columns <- append(temp.columns, col[[2]])
        }
      }
      newdf$columns.df <- temp.columns
      return (newdf)
    },

    Sort = function(cols, desc = FALSE) {
      if (!inherits(cols, "list") && !is.character(cols))   # expects a list of columns
        stop("cols should be of type list or of type character")
      if (is.character(cols)) {
        cols <- list(cols)
      }
      if (length(cols) == 0)
        stop("Can't sort by 0 columns")
      flag <- TRUE
      order.by <- "ORDER BY"
      cols.template <- paste(QuoteName(cols), collapse = ", ")
      order.by <- paste(order.by, cols.template, sep = " ")
      if (desc) {
        order.by <- paste(order.by, "DESC", sep = " ")
      } else {
        order.by <- paste(order.by, "ASC", sep = " ")
      }
      new.select.statement <- sprintf("SELECT * FROM (%s)dt %s", self$select.statement, order.by)
      return (self$GetDf(new.select.statement))
    },

    WithColumnRenamed = function(original, newName){
      columns <- self$columns
      index <- match(original, columns)
      if (is.na(index)){
        stop(sprintf("DataFrame has no column %s", original))
      }
      for (i in 1:length(columns)){
        columns[i] <- columns[i]
      }
      columns[index] <- paste(columns[index], sprintf("AS %s", QuoteName(newName)))
      columns <- paste(columns, collapse = ", ")
      select <- sprintf("SELECT %s FROM (%s) %s", columns, self$select.statement, self$quoted.name)
      return(self$GetDf(select))
    }
    ),
  active = list(
    nrows = function() {
      if (is.null(self$nrows.df)) {
        RowCnt <- self$Count()
        self$nrows.df <- RowCnt[[1]]
      }
      return (self$nrows.df)
    },
    columns = function(message=FALSE, warning=FALSE) {
      if (length(self$columns.df) == 0 && is.null(self$columns.df) == TRUE){
        dtypes.temp <- self$dtypes()
        cols <- lapply(dtypes.temp, `[[`, 1)
        self$columns.df <- cols
      }
      return (self$columns.df)
    },
    name = function() {
      return (self$name.df)
    },
    quoted.name = function() {
      return (self$quoted.name.df)
    },
    len = function() {
      return (self$nrows)
    }
  ),
  private = list(shared_env = new.env(),
                 colNameFormatting = function(name){
                   name <- gsub("\'", "\'\'", name)
                   quoted.name.temp <- sprintf("\'%s\'", name)
                   quoted.name.temp

                   },
                 describeSummary = function(cols=NULL) {
                   #count , mean, stddev, min, max
                   if (!is.null(cols)){
                     msg <- "Parameter cols must be string or a list of strings."
                     # method to check the cols type
                   } else {
                     cols <- self$columns
                   }
                   dtypes <- self$dtypes(cols)
                   numerics <- list()
                   non.numerics <- list()
                   for (col in dtypes){
                     if (col[[2]] == "INT" ||
                         col[[2]] == "TINYINT" ||
                         col[[2]] == "BIGINT" ||
                         col[[2]] == "INTEGER" ||
                         col[[2]] == "DOUBLE" ||
                         col[[2]] == "DECIMAL" ||
                         col[[2]] == "FLOAT")
                       numerics <- append(numerics, col[[1]])
                     else if (col[[2]] == "NCHAR" ||
                              col[[2]] == "NVARCHAR" ||
                              col[[2]] == "CHAR" ||
                              col[[2]] == "VARCHAR" ||
                              col[[2]] == "STRING")
                       non.numerics <- append(non.numerics, col[[1]])
                   }
                   sql.numerics <- NULL
                   sql.non.numerics <- NULL
                   min.max <- 'MIN(%s) as "min", MAX(%s) as "max", '
                   if (length(numerics)){
                     sql.for.numerics1 <- paste0("select %s as \"column\", COUNT(%s) as \"count\",",
                                                 "COUNT(DISTINCT %s) as \"unique\", SUM(CASE WHEN %s is ",
                                                 "NULL THEN 1 ELSE 0 END) as \"nulls\" , AVG(%s) as \"mean\"",
                                                 ", STDDEV(%s) as \"std\",", min.max, "MEDIAN(%s) as \"median\"",
                                                 "FROM (%s) AS %s")

                     union <- list()
                     for (col in numerics){
                       temp.query <- sprintf(sql.for.numerics1, private$colNameFormatting(col), QuoteName(col), QuoteName(col),#nolint
                                             QuoteName(col), QuoteName(col), QuoteName(col), QuoteName(col), QuoteName(col),#nolint
                                             QuoteName(col), self$select.statement, self$quoted.name)
                       union <- append(union, temp.query)
                     }
                     sql.simple.stats <- paste(union, collapse = " UNION ALL ")
                     sql.numerics <- sql.simple.stats
                     min.max <- "CAST(NULL AS DOUBLE) AS \"min\", CAST(NULL AS DOUBLE) AS \"max\", "
                   }
                   if (length(non.numerics)){
                     sql.for.non.numerics <- paste0("select %s as \"column\", COUNT(%s) ",
                                                    "as \"count\", COUNT(DISTINCT %s) as \"unique\", ",
                                                    "SUM(CASE WHEN %s IS NULL THEN 1 ELSE 0 END) as \"nulls\", ",
                                                    "CAST(NULL as DOUBLE) AS \"mean\", CAST(NULL as double) as ",
                                                    "\"std\", ", min.max, " CAST(NULL as DOUBLE) AS \"median\" ",
                                                    " FROM (%s) AS %s")
                     union <- list()
                     for (col in non.numerics){
                       temp.query <- sprintf(sql.for.non.numerics, private$colNameFormatting(col), QuoteName(col), QuoteName(col),#nolint
                                             QuoteName(col), self$select.statement, self$quoted.name)
                       union <- append(temp.query, union)
                     }
                     sql.non.numerics <- paste(union, collapse = " UNION ALL ")
                     sql.non.numerics
                   }

                   if (is.null(sql.numerics) && is.null(sql.non.numerics)){
                     flog.error(sprintf("Error: %s", err))
                     stop()
                   }
                   if (!is.null(sql.numerics) && !is.null(sql.non.numerics)){
                     sql.statement <- paste0("SELECT * FROM (%s) AS %s UNION ALL SELECT * FROM ",
                                             "(%s) AS %s")
                     sql.statement <- sprintf(sql.statement, sql.numerics, "\"Numerics\"", sql.non.numerics, "\"NonNumerics\"")#nolint
                     return (self$GetDf(sql.statement))
                   }
                   if (!is.null(sql.numerics)){
                     return (self$GetDf(sql.numerics))
                   }
                   return (self$GetDf(sql.non.numerics))
                 }
                 )
)

#' @title hanaml DataFrame
#' @name hanaml.DataFrame
#' @description This module represents a database query as a DataFrame.
#' Most operations are designed to never bring data back from the database
#' unless explicitly asked for.
#' @return Object of \code{\link{R6Class}} with methods for DataFrame that is
#'         backed by a database sql statement.
#'
#' @template args-conn
#' @param select.statement \code{character, optional}\cr
#' The sql query for the DataFrame.
#' @param name \code{character, optional}\cr
#' Name of the DataFrame.
#' @section Methods:
#' \describe{
#'    \item{\code{AddId(id)}}{
#'    Adds an ID column based on ROW_NUMBER() as the first column. \cr
#'
#'    \emph{Usage: }\code{dataframe$AddId(id = "NEW_ID")}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'       \item{\code{id: character}, name of the added ID column.}}
#'    \emph{Returns: }  \code{DataFrame} with an ID column based on ROW_NUMBER() built-in.}
#'
#'    \item{\code{Alias(aliasName)}}{
#'    Returns a new DataFrame with an alias set.\cr
#'
#'    \emph{Usage: }\code{NewDf <- dataframe$Alias('TABLE1')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'       \item{\code{aliasName: character}, alias name of the DataFrame.}}
#'    \emph{Returns: }\code{DataFrame} with an alias set.}
#'
#'    \item{\code{cast(cols, new.type)}}{
#'    Converts columns from one datatype to another specified datatype.\cr
#'
#'    \emph{Usage: }\code{dataframe$cast("ID", new.type = "DOUBLE")}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'       \item{\code{cols: list of characters}, the columns to be converted.}
#'       \item{\code{new.type: character}, the datatype to convert expression to.}}
#'    \emph{Returns: }\code{DataFrame} with new datatype.}
#'
#'    \item{\code{Collect()}}{
#'    Copies this DataFrame to an R DataFrame.\cr
#'
#'    \emph{Usage: }\code{dataframe$Collect()}\cr
#'    \emph{Returns: } \code{R DataFrame} containing this DataFrame's data. }
#'
#'    \item{\code{Count()}}{
#'    Computes the number of rows in a DataFrame.\cr
#'
#'    \emph{Usage: } \code{dataframe$Count()}\cr
#'    \emph{Returns: } \code{integer}, number of rows in the DataFrame.}
#'
#'    \item{\code{Describe(cols=NULL)}}{
#'    Generate descriptive statistics that summarize the central tendency, \cr
#'    ispersion and shape of a dataset’s distribution.\cr
#'
#'    \emph{Usage: }\code{dataframe$Describe()}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'       \item{\code{cols: list of characters, optional}, the columns to be summarized.
#'       Defaults to summmarize all columns.}}
#'    \emph{Returns: }\code{DataFrame} with descriptive statistics.}
#'
#'    \item{\code{distinct(cols=NULL)}}{
#'    Return distinct values.\cr
#'
#'    \emph{Usage: }\code{dataframe$distinct()}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'       \item{\code{cols: list of characters, optional}, name of columns which return distinct values.}}
#'    \emph{Returns: }\code{DataFrame} with distinct values.}
#'
#'    \item{\code{Drop(cols)}}{
#'    Returns a new DataFrame after removing specified columns.\cr
#'
#'    \emph{Usage: }\code{dataframe$Drop('colList')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{cols: list of characters}, list of column names to drop.}}
#'    \emph{Returns: } \code{DataFrame},
#'    new DataFrame retaining only columns not in \emph{cols}.}
#'
#'    \item{\code{DropDuplicates(subset.dataframe=NULL)}}{
#'    Returns DataFrame with duplicate rows removed.\cr
#'
#'    \emph{Usage: }\code{dataframe$DropDuplicates('subsetList')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{subset.dataframe: list of characters, optional}, \cr
#'     List of columns to consider when deciding whether rows are duplicates
#'     of each other. Defaults to all columns.}}
#'    \emph{Returns: }\code{DataFrame} with only one copy of duplicate rows. }
#'
#'    \item{\code{DropNa(how = NULL, thresh = NULL, subset = NULL)}}{
#'    Returns a new DataFrame with NULLs removed.\cr
#'
#'    \emph{Usage: }
#'    \code{dataframe$DropNa(how = 'any',thresh = 1,subset = 'subsetone')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{how : ('any', 'all'), optional}, if provided,
#'     'any' eliminates rows with any NULLs, and 'all' eliminates rows
#'     that are entirely NULLs. If neither \emph{how} nor \emph{thresh} are provided,
#'     \emph{how} defaults to 'any'.}
#'     \item{\code{thresh: integer ,optional}, if provided, keep
#'     rows with at least \emph{thresh} non-NULL values and drop rows with less.
#'     \emph{how} and \emph{thresh} cannot both be provided.}
#'     \item{\code{subset}: \code{list of characters, optional}, columns to
#'     consider when looking for NULLs. Values in other columns will be
#'     ignored, NULL or not. Defaults to all columns in the DataFrame.}}
#'    \emph{Returns: }\code{DataFrame} with a select statement that removes NULLs.}
#'
#'    \item{\code{dtypes(subset.col = NULL)}}{
#'    Return column names and their data types as a list.\cr
#'
#'    \emph{Usage: }\code{dataframe$dtypes()}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'       \item{\code{subset.col: list of characters}, selected columns to show datatype.}}
#'    \emph{Returns: }\code{list} of column names and their data types .}
#'
#'    \item{\code{FillNa(value, subset.dataframe = NULL)}}{
#'    Returns a DataFrame with NULLs replaced with the fill value. Only
#'    supports filling numeric columns.\cr
#'
#'    \emph{Usage: }\code{dataframe$FillNa(0, 'col1')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{value: integer or double}, value to replace NULLs with.
#'     \emph{value} should have type appropriate for the selected columns.}
#'     \item{\code{subset: character, Optional}, list of columns in which
#'     to replace NULLs. Defaults to all columns.}}
#'    \emph{Returns: }\code{DataFrame}, new DataFrame with NULLs filled. }
#'
#'    \item{\code{Filter(condition)}}{
#'    Selects rows matching the given condition. The condition string is not
#'    sanity-checked in any way. Do not take condition strings from untrusted
#'    input, as this can easily be used for SQL injection.\cr
#'
#'    \emph{Usage: }
#'    \code{dataframe$Filter("select * from test where col1 = 'A'")}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{condition: character}, condition to filter on. This
#'     should be in the format of a SQL WHERE clause test (not including the word "WHERE").}}
#'    \emph{Returns: } \code{DataFrame} with only rows matching the given condition.}
#'
#'    \item{\code{GenerateColname(prefix = 'GEN_COL')}}{
#'    Generates a new column name for the DataFrame.\cr
#'
#'    \emph{Usage: } \code{dataframe$GenerateColname('COL1')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{prefix: character, optional}, name of the column. If no name if provided, it
#'     creates a default column named 'GEN_COL'. }}
#'    \emph{Returns: } \code{character}, newly generated column name.}
#'
#'    \item{\code{GetDf(select.statement, name = NULL)}}{
#'    Creates a new DataFrame.\cr
#'
#'    \emph{Usage: }
#'    \code{dataframe$GetDf('SELECT * FROM TEMP;', NAME = 'DF1')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{select.statement: character}, Dataframe sql query }
#'     \item{\code{name: character, optional}, Dataframe name }}
#'    \emph{Returns: } \code{DataFrame}}
#'
#'    \item{\code{GetDfCounter()}}{
#'    Returns the number of DataFrame.\cr
#'    \emph{Usage: }\code{dataframe$GetDfCounter()}\cr
#'
#'    \emph{Returns: }\code{integer}.}
#'
#'    \item{\code{GetNRows()}}{
#'    Sets the value of DataFrame's nrows.df.\cr
#'
#'    \emph{Usage: }\code{dataframe$GetNRows()}\cr
#'    \emph{Returns: } No return value.}
#'
#'    \item{\code{Has(col)}}{
#'    Returns TRUE if a column is in the DataFrame.\cr
#'
#'    \emph{Usage: } \code{dataframe$has('col1')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{col}: \code{character} Name of column to search in the
#'     projection list of this DataFrame.}}
#'    \emph{Returns: }
#'    \code{logical}\, TRUE if the column exists in the DataFrame's projection list.}
#'
#'    \item{\code{Join(other, on.expression, how = 'inner')}}{
#'    Returns a new DataFrame that is a join of this DataFrame with another DataFrame.\cr
#'
#'    \emph{Usage: }
#'    \code{dataframe$Drop(other = DF1, on.expression = 'col', how = 'outer')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{other}: \code{DataFrame} The DataFrame to join with.}
#'     \item{\code{on.expression}: \code{character} Join expression}
#'     \item{\code{how}: \code{('inner', 'left', 'right', 'outer'), Optional}
#'      Type of join. Defaults to 'inner'.}}
#'    \emph{Returns: }
#'    \code{DataFrame},
#'    new DataFrame object that joins the current DataFrame with another DataFrame.}
#'
#'    \item{\code{rename.columns(new.col.names)}}{
#'    Updates the column name.\cr
#'
#'    \emph{Usage: }\code{dataframe$rename.columns(list("A", "C"))}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'       \item{\code{new.col.names}:\code{list of characters} List of new columns' name.}}
#'    \emph{Returns: }\code{DataFrame} with rename columns.}
#'
#'    \item{\code{RunQuery(Query)}}{
#'    Performs the query.\cr
#'    \emph{Usage: }\code{b <- dataframe$RunQuery('select "target" from IRIS')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'       \item{\code{Query: character}: sql statement.}}
#'    \emph{Returns: }\code{DataFrame}, new DataFrame generated by sql Query.}
#'
#'
#'    \item{\code{save(table, table.type = NULL, force = TRUE, schema = NULL)}}{
#'    Creates a table holding this DataFrame's data.\cr
#'
#'    \emph{Usage: }\code{Save('TAB1','ROW')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{table}: \code{character}
#'     Table name. save() will fail if a
#'     conflicting table already exists.}
#'     \item{\code{table.type: character, optional},  what kind of table
#'     to create. Case-insensitive. Can be one of "ROW", "COLUMN", "HISTORY COLUMN",
#'      "GLOBAL TEMPORARY", "GLOBAL TEMPORARY COLUMN", "LOCAL TEMPORARY", or
#'      "LOCAL TEMPORARY COLUMN".Defaults to "LOCAL TEMPORARY COLUMN" if `where` starts
#'      with "#" and "COLUMN" otherwise.}
#'     \item{\code{force: logical, optional},
#'     if TRUE, the existed table will be replaced. Defaults to TRUE.}
#'     \item{\code{schema: character, optional},
#'     schema name. save() will fail if a conflicting table already exists.}}
#'    \emph{Returns: }\code{DataFrame} representing the new table.}
#'
#'    \item{\code{Select(cols)}}{
#'    Returns a new DataFrame with columns derived from the current DataFrame.\cr
#'
#'    \emph{Usage: }\code{dataframe$Select('col1')} OR\cr \code{col.list <- list('*','select')} \cr
#'    \code{cols <- sets::as.tuple(x = col.list)}\cr
#'    \code{dataframe$Select(cols)}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{cols}: \code{character or (character, character) tuple}
#'     Columns of the new DataFrame. A string is treated as the name of a
#'     column to select; a (character, character) tuple is treated as
#'     (SQL expression, alias). As a special case, '*' is expanded to
#'     all columns of the original DataFrame.} }
#'    \emph{Returns: } \code{DataFrame},
#'    new DataFrame object with the specified columns projected.}
#'
#'    \item{\code{Sort(cols, desc = FALSE)}}{
#'    Returns a new DataFrame sorted by the specified columns.\cr
#'
#'    \emph{Usage: } \code{dataframe$Sort('COL1')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{cols: list of characters}, list of columns to
#'     sort by. Must be a list, even for sorting by one column.}
#'     \item{\code{desc: logical, Optional}, TRUE to sort in
#'     descending order, FALSE for ascending order. Defaults to FALSE.}}
#'    \emph{Returns: } \code{DataFrame},
#'    new DataFrame object with rows in sorted order.}
#'
#'   \item{\code{WithColumnRenamed(original, newName)}}{
#'    Returns a DataFrame with a new name for one column.\cr
#'
#'    \emph{Usage: }\code{dataframe$WithColumnRenamed('col1','colnew')}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{original: character}, original column name.}
#'     \item{\code{newName: character}, new column name.}}
#'    \emph{Returns: }\code{DataFrame},
#'    the same data as this DataFrame, with one changed column name.}
#'
#'   }
#' @export
hanaml.DataFrame <- function(connection.context = NULL, select.statement = NULL, name = NULL){
  DataFrame$new(connection.context, select.statement, name)
}


#' @title QuoteName
#' @name QuoteName
#' @description
#'    Escape a schema, table, or column name for use in SQL. hana_ml functions
#'    and methods that take schema, table, or column names
#'    already escape their input by default, but those that take SQL don't
#'    (and can't) perform escaping automatically.\cr
#' @param name \code{charater}
#' Name of the \emph{table/column} to be quoted.
#' @param has.schema \code{logical, optional}
#' \itemize{
#'   \item{TRUE}: the name contains schema name.
#'   \item{FALSE}: the name dod not have schema name.}
#' Defaults to FALSE.
#' @return
#' \code{character}\cr
#' Escaped name. The string is surrounded in quotation marks and existing
#' quotation marks are escaped by doubling them.
#' @export
QuoteName <- function(name, has.schema = FALSE) {
  QuoteNameSingle <- function(name0, has.schema) {
    if (grepl("[.]", name0) && (has.schema == TRUE)) {
      split.str <- strsplit(name0, "[.]")[[1]]
      schema <- split.str[1]
      table <- split.str[2]
      schema <- gsub("\'", "\'\'", schema)
      table <- gsub("\'", "\'\'", table)
      quoted.name.temp <- sprintf('"%s"."%s"', schema, table)
      return (quoted.name.temp)
    }
    name0 <- gsub("\'", "\'\'", name0)
    quoted.name.temp <- sprintf('"%s"', name0)
    return (quoted.name.temp)
  }
  if (typeof(name) == "list") {
    return (lapply(name, QuoteNameSingle, has.schema))
  }
  return (QuoteNameSingle(name, has.schema))
}

#' @title GetColumns
#' @name GetColumns
#' @description
#'  Returns the list of column names.
#' @template args-conn
#' @param table \code{character}\cr
#' The HANA table to store the data from R data.frame.
#' @param schema \code{character, optional}\cr
#' The database schema.\cr
#' Defaults to the schema of connection.context.
#' @return \code{list} \cr The list of column names
#' @export
GetColumns <- function(connection.context,
                       table,
                       schema) {
  if (is.null(schema)) {
    schema <- connection.context$GetCurrentSchema()
  }
  sql.cols <- sprintf(
    paste("SELECT COLUMN_NAME FROM TABLE_COLUMNS",
          "WHERE SCHEMA_NAME='%s' AND TABLE_NAME='%s'",
          "ORDER BY POSITION"),
          schema,
          table)
  return(ExecuteLogged(connection.context$connection, sql.cols)$COLUMN_NAME)
}

#' @title ConvertToHANADataFrame
#' @name ConvertToHANADataFrame
#' @description ConvertToHANADataFrame is to convert the R data.frame into a HANA DataFrame.
#' @template args-conn
#' @param data \code{R data.frame}\cr
#' The R data.frame.
#' @param table \code{character}\cr
#' The name of SAP HANA table (does not contain schema name) to store the data from R data.frame.
#' @param schema \code{character, optional}\cr
#' The name of database schema.\cr
#' Defaults to the schema of connection.context.
#' @param force \code{logical, optional}
#' If the table with same name exists:
#' \itemize{
#'   \item{TRUE}: the existing table will be replaced.
#'   \item{FALSE}: error message pops up.}
#' Defaults to FALSE.
#' @param native {logical, optional}
#' \itemize{
#'   \item{TRUE}: use JDBC/ODBC methods to write the table.
#'   \item{FALSE}: insert the table row by row.}
#' Defaults to FALSE.
#' @param col.types {named vector of character, optional}\cr
#' Specifies what types should be stored for the set of columns in \code{data}
#' after transferring into HANA database.\cr
#' If not specified for a column, the corresponding type will be inferred directly
#' from the original type in R.\cr
#' Defaults to NULL, i.e. stored types of all columns should be inferred.
#' @param ... \code{}\cr
#' @return \code{DataFrame} \cr
#' Returns a HANA Dataframe including data from the R data.frame.
#' @export
ConvertToHANADataFrame <- function(connection.context,
                                   data,
                                   table,
                                   schema = NULL,
                                   force = FALSE,
                                   native = TRUE,
                                   col.types = NULL,
                                   ...) {
  is.jdbc <- grepl("JDBC", toString(class(connection.context$connection)), fixed = TRUE)
  columns <- as.list(names(data))
  data.types <- lapply(data, class)
  char.names <- data.types[data.types %in% c("factor", "character")]
  max.leng.vec <- c()
  max.leng.names <- c()
  for (name in names(char.names)){
    max.leng.vec <- c(max.leng.vec,
                      max(nchar(as.character(data[[name]]))))
    max.leng.names <- c(max.leng.names, name)
  }
  names(max.leng.vec) <- max.leng.names
  tab <- QuoteName(table)
  current.schema <- connection.context$GetCurrentSchema()[[1]]
  if (is.null(schema)) {
    schema <- current.schema
  }
  tab <- sprintf("%s.%s", QuoteName(schema), tab)
  if (force == TRUE) {
    delete.sql <- sprintf("DROP TABLE %s", tab)
    ExecuteLogged(connection.context$connection, delete.sql)
  }
  add.single.quote <- function(ch) {
    return (sprintf("'%s'", ch))
  }
  validateInput("Names of col.types",  names(col.types),
                columns,
                case.sensitive = TRUE)
  native.flag  <- isTRUE(length(col.types) > 0 || any(max.leng.vec > 255))
  if (native.flag == TRUE && native == TRUE){
    msg <- paste("Current R data.frame cannot be converted",
                 "when 'native' is TRUE,",
                 "the parameter setting is thus reversed.")
    flog.warn(msg)
    native <- FALSE
  }
  if (native == TRUE) {
    if (is.jdbc) {
      RJDBC::dbWriteTable(connection.context$connection, tab, data,
                          overwrite = force, field.types = col.types,
                          row.names = FALSE, ...)
    } else if (connection.context$odbc == TRUE && connection.context$rodbc == FALSE)  {
      odbc::dbWriteTable(connection.context$connection, DBI::SQL(tab),
                         data, overwrite = force,
                         field.types = col.types,
                         row.names = FALSE, ...)
    } else {
      if (grepl("\\.", table)) {
        msg <- "Cannot create table with dot(.) in table name."
        stop(msg)
      }
      if (is.null(col.types)) {
        sqlSave(connection.context$connection, data,
                paste0(schema, ".", table),
                rownames = FALSE,
                colname = FALSE,
                safer = ! force, ...)
      } else {
        sqlSave(connection.context$connection, data,
                paste0(schema, ".", table),
                varTypes = col.types,
                rownames = FALSE,
                colname = FALSE,
                safer = ! force, ...)
      }
    }
  } else {
    types.list <- list()
    for (name in names(data.types)){
      if (isTRUE(name %in% names(col.types))){
        types.list <- c(types.list,
                        sprintf("%s %s",
                                QuoteName(name),
                                col.types[[name]]))
      } else {
        if (data.types[[name]] == "numeric"){
          types.list <- c(types.list, sprintf("%s DOUBLE", QuoteName(name)))
        } else if (data.types[[name]] %in% c("character", "factor")) {
          char.max <- max.leng.vec[[name]]
          char.max <- max(char.max, 255)
          char.max <- ifelse(char.max > 255,
                             2 ** ceiling(log2(char.max)),
                             char.max)
          s.type <- ifelse(char.max <= 5000,
                           sprintf("VARCHAR(%s)", char.max), "NCLOB")
          types.list <- c(types.list, sprintf("%s %s", QuoteName(name),
                                              s.type))
        } else if (data.types[[name]] %in% c("integer", "logical")) {
          types.list <- c(types.list, sprintf("%s INTEGER", QuoteName(name)))
        } else {
          stop("Dataframe may contain invalid data types for HANA.")
        }
      }
    }
    createT.sql <- sprintf("CREATE TABLE %s (%s);", tab, paste(types.list, collapse = ","))
    ExecuteLogged(connection.context$connection, createT.sql)
    if (is.jdbc) {
      if (length(data[[1]])) {
        inss <- paste("INSERT INTO ", tab, " VALUES(", paste(rep("?", length(data)), collapse = ","), ")", sep = "")
        list <- lapply(data, function(o) if (!is.numeric(o)) as.character(o) else o)
        RJDBC::dbSendUpdate(connection.context$connection, inss, list = list)
      }
      if (connection.context$autocommit == FALSE) RJDBC::dbCommit(connection.context$connection)
    } else if (connection.context$odbc == TRUE && connection.context$rodbc == FALSE) {
      if (length(data[[1]])) {
        inss <- paste("INSERT INTO ", tab, " VALUES(", paste(rep("?", length(data)), collapse = ","), ")", sep = "")
        insert <- odbc::dbSendQuery(connection.context$connection, inss)
        list <- lapply(data, function(o) if (!is.numeric(o)) as.character(o) else o)
        odbc::dbBind(insert, list)
        odbc::dbClearResult(insert)
      }
    } else {
      data.list <- split(data, seq(nrow(data)))
      for (tab.data in data.list) {
        cols <- sapply(tab.data, is.logical)
        tab.data[, cols] <- lapply(tab.data[, cols], as.numeric)
        cols <- sapply(tab.data, is.factor)
        tab.data[, cols] <- lapply(tab.data[, cols], as.character)
        cols <- sapply(tab.data, is.character)
        tab.data[, cols] <- lapply(tab.data[, cols], add.single.quote)
        tab.data <- rapply(tab.data,
                           f = function(x) ifelse(is.na(x), "NULL", x),
                           how = "replace")
        ExecuteLogged(
          connection.context$connection,
          sprintf("INSERT INTO %s VALUES (%s)", tab, paste(tab.data, collapse = ", ")))
      }
    }
  }
  if (isTRUE(schema == current.schema)) {
    schema <- NULL
  }
  new.df <- connection.context$table(table, schema)
  if (native == TRUE) {
    new.df.cols <- GetColumns(connection.context, table, schema)
    for (i in c(1:length(columns))) {
        if (columns[[i]] != new.df.cols[[i]]){
        rename.sql <- sprintf("RENAME COLUMN %s.%s TO %s", tab,
                            QuoteName(new.df.cols[[i]]),
                            QuoteName(columns[[i]]))
        ExecuteLogged(connection.context$connection, rename.sql)
        }
    }
  }
  return (new.df)
}

#' @title DataManipulation
#' @name DataManipulation
#' @details Data load/unload from SAP HANA memory.
#' @template args-conn
#' @param table \code{character}\cr
#' The name of SAP HANA table.
#' @param schema \code{character, optional}\cr
#' The name of database schema.\cr
#' Defaults to the schema of connection.context.
#' @param unload \code{logical, optional}
#' \itemize{
#'   \item{TRUE}: unload table from memory.
#'   \item{FALSE}: no action.}
#' Defaults to TRUE.
#' @export
DataManipulation <- function(connection.context, table, schema = NULL, unload = TRUE) {
  tab <- QuoteName(table)
  if (!is.null(schema)) {
    tab <- sprintf("%s.%s", QuoteName(schema), tab)
  }
  load.sql <- sprintf("LOAD %s all", tab)
  if (unload) {
    load.sql <- sprintf("UNLOAD %s", tab)
  }
  ExecuteLogged(connection.context$connection, load.sql)
}

#' @export
print.DataFrame <- function(x, ...){
  print(x$Collect())
}
