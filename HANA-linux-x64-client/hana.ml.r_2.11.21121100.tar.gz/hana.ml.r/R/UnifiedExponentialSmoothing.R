check.accuracy.measure <- function(func, input.list){
  if (!is.null(input.list[["accuracy.measure"]])) {
    acc <- input.list[["accuracy.measure"]]
    if (is.character(acc)) {
      acc <- as.list(acc)
    }
    acc <- lapply(acc, tolower)
    if (func == "aesm") {
      if (length(acc) != 1) {
        msg <- "Please input only one type of accuracy.measure from 'mse' or 'mape'!"
        flog.error(msg)
        stop(msg)
      }
      validateInput("accuracy.measure", acc, list("mse", "mape"))
    }
    acc.list <- list("mpe", "mse", "rmse", "et", "mad", "mase", "wmape", "smape", "mape")
    if (func != "aesm") {
      for (i in c(1:length(acc))){
        validateInput("accuracy.measure", acc[[i]], acc.list)
      }
    }
    }}

check.season.start <- function(input.list){
  if (!is.null(input.list[["season.start"]])){
    validateInput("season.start", input.list[["season.start"]], "list")
    ss <- input.list[["season.start"]]
    if (!is.null(ss)) {
      for (i in c(1:length(ss))) {
        if (length(ss[[i]]) != 2) {
          msg <- "The length of each tuple of season.start should be 2!"
          flog.error(msg)
          stop(msg)
        } else {
          ss[[i]][[1]] <- validateInput("Cycle ID in season.start",
                                        ss[[i]][[1]],
                                        "integer")
          ss[[i]][[2]] <- validateInput("Initial value in season.start",
                                        ss[[i]][[2]],
                                        "numeric")
        }
  }}}}

check.delta <- function(input.list){
  if (!is.null(input.list[["delta"]]) && (!isTRUE(input.list[["adaptive.method"]]))){
    msg <- "delta is only valid when adaptive.method is TRUE!"
    flog.error(msg)
    stop(msg)
  }
}

check.other.params <- function (input.list, func.map, func) {
  valid.names <- names(func.map)
  param.names <- names(input.list)
  update.pal.params <- list()

  if (length(input.list) > 0) {
    for (i in c(1:length(input.list))) {
      par.name <- param.names[i]
      if (par.name %in% c("func", "accuracy.measure", "season.start")) {
        next
      }
      if (!par.name %in% valid.names) {
        msg <- sprintf("Unrecognized parameter name: %s in function %s!",
                       par.name,
                       func)
        flog.error(msg)
        stop(msg)
      }

      map.value <- func.map[[par.name]]
      constr <- map.value[[2]]
      par.val <- input.list[[i]]
      if ( (map.value[[2]] == "list") && (typeof(input.list[[i]]) %in% c("numeric", "integer", "character"))) {
        par.val <- as.list(par.val)
      }
      par.val <- validateInput(par.name, par.val, constr)
      if (!is.null(par.val)){
        update.pal.params[[map.value[[1]]]] <- list(par.val, map.value[[2]])
      }
    }
  }
  return (update.pal.params)
}

UnifiedExponentialSmoothing <- R6Class(
  "UnifiedExponentialSmoothing",
  inherit = MlBase,
  public = list(
    params = NULL,
    func = NULL,
    massive = FALSE,
    forecast = NULL,
    stats = NULL,
    error.msg = NULL,
    initialize = function(data = NULL,
                          func = NULL,
                          key = NULL,
                          endog = NULL,
                          massive = FALSE,
                          group.key = NULL,
                          group.params = NULL,
                          ...) {

      super$initialize()
      if (!is.null(data)) {
        func <- tolower(func)
        self$func <- validateInput("func", func, private$func.list, required = TRUE)
        self$massive <- validateInput("massive", massive, "logical")

        validateInput("group.params", group.params, "list")
        func.map <- private$map.list[[private$func.list[[self$func]]]]

        if (isTRUE(massive)) {
          expected.len <- 3
        } else {
          expected.len <- 2
        }

        if (length(data$columns) < expected.len) {
          msg <- "Input data should contain at least 2 (non-massive) OR 3 columns (massive mode)!"
          flog.error(msg)
        }

        if (!isTRUE(massive)){
          private$pal.params <- list()
          self$params <- list(func = self$func)
          self$params <- append(self$params, list(...))
          var.names <- names(self$params)

          check.accuracy.measure(self$func, self$params)
          check.season.start(self$params)
          check.delta(self$params)
          pal.params <- check.other.params(self$params, func.map, self$func)

          acc.pal.params <- list()
          if ("accuracy.measure" %in% var.names){
            acc <- list()
            acc <- self$params[["accuracy.measure"]]
            if (is.character(acc)) {
              acc <- as.list(acc)
            }
            acc <- lapply(acc, tolower)
            acc.pal.params[["MEASURE_NAME"]] <- list(acc, "list")
            acc.pal.params[["ACCURACY_MEASURE"]] <- list(acc, "list")
          }

          ss.pal.params <- list()
          if ("season.start" %in% var.names){
            ss <- list()
            ss <- self$params[["season.start"]]
            ss.pal.params[["SEASON_START"]] <- list(ss, "list")
          }

          private$pal.params <- c(pal.params, acc.pal.params, ss.pal.params)

          cols <- data$columns
          key <- validateInput("key", key, cols, case.sensitive = TRUE)
          if (is.null(key)) {
            key <- cols[[1]]
          }
          cols <- cols[! cols %in% key]
          endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
          if (is.null(endog)) {
            endog <- cols[[1]]
          }

          input.df <- data$Select(c(key, endog))

          param.rows <- list(tuple("FUNCTION", NULL, NULL, private$func.list[[self$func]]))
          pal.names <- names(private$pal.params)
          for (i in seq_len(length(private$pal.params))) {
            var.name <- pal.names[i]
            var.info <- private$pal.params[[var.name]]
            if (var.info[[2]] == "integer") {
              param.rows <- append(param.rows,
                                   list(tuple(var.name,
                                              var.info[[1]],
                                              NULL, NULL)))
            } else if (var.info[[2]] == "logical") {
              param.rows <- append(param.rows,
                                   list(tuple(var.name,
                                              to.integer(var.info[[1]]),
                                              NULL, NULL)))
            } else if (var.info[[2]] == "numeric") {
              param.rows <- append(param.rows,
                                   list(tuple(var.name,
                                              NULL,
                                              var.info[[1]],
                                              NULL)))
            } else if (var.info[[2]] == "character") {
              param.rows <- append(param.rows,
                                   list(tuple(var.name,
                                              NULL, NULL,
                                              var.info[[1]])))
            }else if (var.name %in% c("MEASURE_NAME", "ACCURACY_MEASURE")) {
              for (k in 1:length(var.info[[1]])){
                param.rows <- append(param.rows,
                                     list(tuple(var.name,
                                                NULL, NULL,
                                                var.info[[1]][[k]])))
              }
            } else if (var.name == "SEASON_START") {
              for (k in 1:length(var.info[[1]])){
                param.rows <- append(param.rows,
                                     list(tuple(var.name,
                                                var.info[[1]][[k]][[1]],
                                                var.info[[1]][[k]][[2]],
                                                NULL)))
              }
            }
          }
        }
        else {
          private$real.func <- paste("M", private$func.list[[self$func]], sep = "")
          param.rows <- list(tuple(NULL, "FUNCTION", NULL, NULL, private$real.func))

          if (!is.null(group.params)){
            private$pal.params <- list()
            self$params <- group.params
            group.names <- names(group.params)
            for (i in 1:length(group.names)) {
              group.name <- group.names[[i]]
              private$pal.params[[group.name]] <- list()

              check.accuracy.measure(self$func, self$params[[i]])
              check.season.start(self$params[[i]])
              check.delta(self$params[[i]])

              pal.params <- check.other.params(self$params[[i]], func.map, self$func)
              group.var.names <- names(self$params[[group.name]])

              acc.pal.params <- list()
              if ("accuracy.measure" %in% group.var.names){
                acc <- list()
                acc <- self$params[[group.name]][["accuracy.measure"]]
                if (!is.null(acc)){
                  if (is.character(acc)){
                    acc <- as.list(acc)
                  }
                  acc <- lapply(acc, tolower)
                  acc.pal.params[["MEASURE_NAME"]] <- list(acc, "list")
                  acc.pal.params[["ACCURACY_MEASURE"]] <- list(acc, "list")
                }
              }

              ss.pal.params <- list()
              if ("season.start" %in% group.var.names){
                ss <- list()
                ss <- self$params[[group.name]][["season.start"]]
                if (!is.null(ss)){
                  ss.pal.params[["SEASON_START"]] <- list(ss, "list")
                }
              }
              private$pal.params[[group.name]] <- c(pal.params, acc.pal.params, ss.pal.params)

            }
            # generate PAL PARAMETERTABLE content
            for (i in 1:length(group.names)) {
              group.name <- group.names[[i]]
              each.group <- private$pal.params[[group.name]]
              if (length(each.group) > 0) {
                each.group.names <- names(each.group)
                for (j in 1:length(each.group.names)){
                  var.name <- each.group.names[[j]]
                  var.info <- each.group[[var.name]]
                  if (var.info[[2]] == "integer") {
                    param.rows <- append(param.rows,
                                         list(tuple(group.name,
                                                    var.name,
                                                    var.info[[1]],
                                                    NULL, NULL)))
                  } else if (var.info[[2]] == "logical") {
                    param.rows <- append(param.rows,
                                         list(tuple(group.name,
                                                    var.name,
                                                    to.integer(var.info[[1]]),
                                                    NULL, NULL)))
                  } else if (var.info[[2]] == "numeric") {
                    param.rows <- append(param.rows,
                                         list(tuple(group.name,
                                                    var.name,
                                                    NULL,
                                                    var.info[[1]],
                                                    NULL)))
                  } else if (var.info[[2]] == "character") {
                    param.rows <- append(param.rows,
                                         list(tuple(group.name,
                                                    var.name,
                                                    NULL, NULL,
                                                    var.info[[1]])))
                  } else if (var.name %in% c("MEASURE_NAME", "ACCURACY_MEASURE")) {
                    for (k in 1:length(var.info[[1]])){
                      param.rows <- append(param.rows,
                                           list(tuple(group.name,
                                                      var.name,
                                                      NULL, NULL,
                                                      var.info[[1]][[k]])))
                    }
                  } else if (var.name == "SEASON_START") {
                    for (k in 1:length(var.info[[1]])){
                      param.rows <- append(param.rows,
                                           list(tuple(group.name,
                                                      var.name,
                                                      var.info[[1]][[k]][[1]],
                                                      var.info[[1]][[k]][[2]],
                                                      NULL)))
                    }
                  }
                }
              }
            }
          }# end of group.params is null
        }# end of massive mode

        if (!inherits(data, "DataFrame")) {
          msg <- "Data for Unified Exponential Smoothing must be a DataFrame."
          flog.error(msg)
          stop(msg)
        }

        CheckConnection(data)
        conn.context <- data$connection.context

        if (!isTRUE(massive)){
          cols <- data$columns
          key <- validateInput("key", key, cols, case.sensitive = TRUE)
          if (is.null(key)) {
            key <- cols[[1]]
          }
          cols <- cols[! cols %in% key]
          endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
          if (is.null(endog)) {
            endog <- cols[[1]]
          }
          input.df <- data$Select(c(key, endog))
        } else {
          cols <- data$columns
          group.key <- validateInput("group.key", group.key, cols,
                                     required = TRUE,
                                     case.sensitive = TRUE)
          cols <- cols[! cols %in% group.key]
          key <- validateInput("key", key, cols, case.sensitive = TRUE)
          if (is.null(key)) {
            key <- cols[[1]]
          }
          cols <- cols[! cols %in% key]
          endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
          if (is.null(endog)) {
            endog <- cols[[1]]
          }
          input.df <- data$Select(c(group.key, key, endog))

          col.types <- input.df$dtypes()
          if (!col.types[[1]][[2]] %in% c("INTEGER", "NVARCHAR", "VARCHAR")){
            msg <- "Type of group.key column must be INTEGER or NVARCHAR!"
            flog.error(msg)
            stop(msg)
          }

          if (col.types[[1]][[2]] == "INTEGER") {
            group.id.type <- "INTEGER"
          } else {
            group.id.type <- "NVARCHAR(5000)"
          }

          parameterTableSpec <- list(
            tuple("GROUP_ID", group.id.type),
            tuple("PARAM_NAME", "NVARCHAR(5000)"),
            tuple("INT_VALUE", INTEGER),
            tuple("DOUBLE_VALUE", DOUBLE),
            tuple("STRING_VALUE", "NVARCHAR(5000)")
          )
        }

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#UNIFIED_EXPONENTIALSMOOTHING_PARAM_%s_%s",
                             self$id, unique.id)
        forecast.tbl <- sprintf("#UNIFIED_EXPONENTIALSMOOTHING_FORECAST_%s_%s",
                                self$id, unique.id)
        stats.tbl <- sprintf("#UNIFIED_EXPONENTIALSMOOTHING_STATS_%s_%s",
                             self$id, unique.id)
        error.msg.tbl <- sprintf("#UNIFIED_EXPONENTIALSMOOTHING_ERROR_%s_%s",
                                 self$id, unique.id)
        ph.tbl.1 <- sprintf("#UNIFIED_EXPONENTIALSMOOTHING_PLACE_HOLDER1_%s_%s",
                            self$id, unique.id)
        ph.tbl.2 <- sprintf("#UNIFIED_EXPONENTIALSMOOTHING_PLACE_HOLDER2_%s_%s",
                            self$id, unique.id)
        out.tables <- list(forecast.tbl, stats.tbl, error.msg.tbl, ph.tbl.1, ph.tbl.2)
        in.tables <- list(input.df, param.tbl)
        tables <- c(param.tbl, out.tables)
        tryCatch({
          if (isTRUE(massive)){
            errorhelper(CreateTWithConnection(conn.context,
                                              (Table$new(param.tbl, parameterTableSpec))$WithData(param.rows)))
          } else {
            errorhelper(CreateTWithConnection(conn.context,
                                             (ParameterTable$new(param.tbl))$WithData(param.rows)))
          }
          errorhelper(CallPalAutoWithConnection(conn.context,
                                                "PAL_UNIFIED_EXPONENTIALSMOOTHING",
                                                in.tables,
                                                out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err$message)
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })

        self$forecast <- conn.context$table(forecast.tbl)
        self$stats <- conn.context$table(stats.tbl)
        self$error.msg <- conn.context$table(error.msg.tbl)
        if (nrow(self$error.msg$Collect()) != 0){
          msg <- "Please refer to attribute error.msg for error messages!"
          flog.warn(msg)
        }
      }
    }),
  private = list(
    real.func = NULL,
    pal.params = list(),
    func.list = list(sesm = "SESM",
                     desm = "DESM",
                     tesm = "TESM",
                     aesm = "AESM",
                     besm = "BESM"),
    map.list = list(
      "SESM" = list( "alpha" = list("ALPHA", "numeric"),
                     "delta" = list("BETA", "numeric"),
                     "forecast.num" = list("FORECAST_NUM", "integer"),
                     "accuracy.measure" = list("ACCURACY_MEASURE", "character"),
                     "adaptive.method" = list("ADAPTIVE_METHOD", "logical"),
                     "ignore.zero" = list("IGNORE_ZERO", "logical"),
                     "expost.flag" = list("EXPOST_FLAG", "logical"),
                     "prediction.confidence.1" = list("PREDICTION_CONFIDENCE_1", "numeric"),
                     "prediction.confidence.2" = list("PREDICTION_CONFIDENCE_2", "numeric")
                     ),
      "DESM" = list( "alpha" = list("ALPHA", "numeric"),
                     "beta" = list("BETA", "numeric"),
                     "forecast.num" = list("FORECAST_NUM", "integer"),
                     "accuracy.measure" = list("ACCURACY_MEASURE", "character"),
                     "phi" = list("PHI", "numeric"),
                     "damped" = list("DAMPED", "logical"),
                     "ignore.zero" = list("IGNORE_ZERO", "logical"),
                     "expost.flag" = list("EXPOST_FLAG", "logical"),
                     "prediction.confidence.1" = list("PREDICTION.CONFIDENCE_1", "numeric"),
                     "prediction.confidence.2" = list("PREDICTION_CONFIDENCE_2", "numeric")
                     ),
      "TESM" = list( "alpha" = list("ALPHA", "numeric"),
                     "beta" = list("BETA", "numeric"),
                     "gamma" = list("GAMMA", "numeric"),
                     "seasonal.period" = list("CYCLE", "integer"),
                     "forecast.num" = list("FORECAST_NUM", "integer"),
                     "accuracy.measure" = list("ACCURACY_MEASURE", "character"),
                     "seasonal" = list("SEASONAL", "integer"),
                     "initial.method" = list("INITIAL_METHOD", "integer"),
                     "phi" = list("PHI", "numeric"),
                     "damped" = list("DAMPED", "logical"),
                     "ignore.zero" = list("IGNORE_ZERO", "logical"),
                     "expost.flag" = list("EXPOST_FLAG", "logical"),
                     "level.start" = list("LEVEL_START", "numeric"),
                     "trend.start" = list("TREND_START", "numeric"),
                     "season.start" = list("SEASON_START", "list"),
                     "prediction.confidence.1" = list("PREDICTION_CONFIDENCE_1", "numeric"),
                     "prediction.confidence.2" = list("PREDICTION_CONFIDENCE_2", "numeric")
                     ),
      "AESM" = list( "model.selection" = list("MODELSELECTION", "logical"),
                     "forecast.model.name" = list("FORECAST_MODEL_NAME", "character"),
                     "optimizer.time.budget" = list("OPTIMIZER_TIME_BUDGET", "integer"),
                     "max.iter" = list("MAX_ITERATION", "integer"),
                     "optimizer.random.seed" = list("OPTIMIZER_RANDOM_SEED", "integer"),
                     "thread.ratio" = list("THREAD_RATIO", "numeric"),
                     "alpha" = list("ALPHA", "numeric"),
                     "beta" = list("BETA", "numeric"),
                     "gamma" = list("GAMMA", "numeric"),
                     "phi" = list("PHI", "numeric"),
                     "forecast.num" = list("FORECAST_NUM", "integer"),
                     "accuracy.measure" = list("ACCURACY_MEASURE", "character"),
                     "seasonal.period" = list("CYCLE", "integer"),
                     "seasonal" = list("SEASONAL", "integer"),
                     "initial.method" = list("INITIAL_METHOD", "integer"),
                     "training.ratio" = list("TRAINING_RATIO", "numeric"),
                     "damped" = list("DAMPED", "logical"),
                     "seasonality.criterion" = list("SEASONALITY_CRITERION", "numeric"),
                     "trend.test.method" = list("TREND_TEST_METHOD", "integer"),
                     "trend.test.alpha" = list("TREND_TEST_ALPHA", "numeric"),
                     "alpha.min" = list("ALPHA_MIN", "numeric"),
                     "beta.min" = list("BETA_MIN", "numeric"),
                     "gamma.min" = list("GAMMA_MIN", "numeric"),
                     "phi.min" = list("PHI_MIN", "numeric"),
                     "alpha.max" = list("ALPHA_MAX", "numeric"),
                     "beta.max" = list("BETA_MAX", "numeric"),
                     "gamma.max" = list("GAMMA_MAX", "numeric"),
                     "phi.max" = list("PHI_MAX", "numeric"),
                     "prediction.confidence.1" = list("PREDICTION_CONFIDENCE_1", "numeric"),
                     "prediction.confidence.2" = list("PREDICTION_CONFIDENCE_2", "numeric"),
                     "level.start" = list("LEVEL_START", "numeric"),
                     "trend.start" = list("TREND_START", "numeric"),
                     "season.start" = list("SEASON_START", "list")
                     ),
      "BESM" = list( "alpha" = list("ALPHA", "numeric"),
                     "delta" = list("BETA", "numeric"),
                     "forecast.num" = list("FORECAST_NUM", "integer"),
                     "accuracy.measure" = list("ACCURACY_MEASURE", "character"),
                     "adaptive.method" = list("ADAPTIVE_METHOD", "logical"),
                     "ignore.zero" = list("IGNORE_ZERO", "logical"),
                     "expost.flag" = list("EXPOST_FLAG", "logical"),
                     "prediction.confidence.1" = list("PREDICTION_CONFIDENCE_1", "numeric"),
                     "prediction.confidence.2" = list("PREDICTION_CONFIDENCE_2", "numeric"))
  )))

#' @title Unified Exponential Smoothing
#' @name hanaml.UnifiedExponentialSmoothing
#' @description hanaml.UnifiedExponentialSmoothing is an R wrapper for SAP HANA PAL Unified Exponential Smoothing.
#' @template args-data
#' @param func \code{character}\cr
#'   The name of a specified exponential smoothing algorithm.\cr
#'   Valid values are as follows:\cr
#'   \itemize{
#'     \item{"SESM" (Single Exponential Smoothing).}
#'     \item{"DESM" (Double Exponential Smoothing).}
#'     \item{"TESM" (Triple Exponential Smoothing).}
#'     \item{"BESM" (Brown Exponential Smoothing).}
#'     \item{"AESM" (Auto Exponential Smoothing).}}
#' @template args-key
#' @template args-endog
#' @param  massive \code{"logical", optional}\cr
#'   Specifies whether or not to use massive mode of exponential smoothing.\cr
#'   Defaults to FALSE.
#' @param  group.key \code{"character", optional}\cr
#'   Specifies the group.key column.\cr
#'   Valid only when \emph{massive} is TRUE. Defaults to NULL.
#' @param  group.params \code{list, optional}\cr
#'   If massive mode is activated (massive = TRUE), the input data for exponential smoothing shall be divided into different
#'   groups with different exponential smoothing parameters applied. \emph{group.params} specifies the parameter
#'   values of the chosen exponential smoothing algorithm \emph{func} w.r.t. different groups in a list format,
#'   where names of list corresponding to group.key while values should be a list for exponential smoothing algorithm
#'   parameter value assignments.\cr
#'   For example, 'Hello1' and 'Hello2' are group.key:
#'   \preformatted{
#'   msesm <- hanaml.UnifiedExponentialSmoothing(func = 'SESM',
#'                                               data = data,
#'                                               massive = TRUE,
#'                                               group.key = 'GROUP_ID',
#'                                               key = 'ID',
#'                                               endog = 'RAWDATA',
#'                                               group.params = list(
#'                                                 'Hello1'=list(
#'                                                   'adaptive.method'=FALSE,
#'                                                   'accuracy.measure'=list("mse", "MApe"),
#'                                                   'alpha'=0.1,
#'                                                   'forecast.num'=12,
#'                                                   'expost.flag'=TRUE),
#'                                                 'Hello2'=list(
#'                                                   'adaptive.method'=TRUE,
#'                                                   'accuracy.measure'='MApe',
#'                                                   'alpha'=0.5,
#'                                                   'forecast.num'=12,
#'                                                   'expost.flag'=FALSE)))
#'   }
#'   Valid only when \emph{massive} is TRUE. Defaults to NULL.
#' @param ... \cr
#'   Specifies other parameters for a specific exponential smoothing function (not in massive mode).\cr
#'   Please see the documentation of corresponding functions for more details.\cr
#'   \code{\link{hanaml.SingleExponentialSmoothing},\cr
#'         \link{hanaml.DoubleExponentialSmoothing},\cr
#'         \link{hanaml.TripleExponentialSmoothing},\cr
#'         \link{hanaml.AutoExponentialSmoothing},\cr
#'         \link{hanaml.BrownExponentialSmoothing}\cr
#'         }
#' @return
#' Returns a "hanaml.UnifiedExponentialSmoothing" object with the following attributes:\cr
#' \itemize{
#' \item{forecas \code{DataFrame}}\cr
#'     Forecast values.
#' \item{stats \code{DataFrame}}\cr
#'     Statistics analysis content.
#' \item{error.msg \code{DataFrame}}\cr
#'     Error messages in the massive mode.
#' }
#'
#' @section Examples:
#' Case 1: hanaml.UnifiedExponentialSmoothing without massive mode:\cr
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'     ID RAWDATA
#'  1   1   200.0
#'  2   2   135.0
#'  3   3   195.0
#'  4   4   197.5
#'  5   5   310.0
#'  6   6   175.0
#'  7   7   155.0
#'  8   8   130.0
#'  9   9   220.0
#'  10 10   277.5
#'  11 11   235.0
#' }
#' Create a "hanaml.UnifiedExponentialSmoothing" object sesm:
#'
#' \preformatted{
#' sesm <- hanaml.UnifiedExponentialSmoothing(func = 'SESM',
#'                                            data = data,
#'                                            key = 'ID',
#'                                            endog = "RAWDATA",
#'                                            accuracy.measure = list('mse','mpe'),
#'                                            alpha = 0.1,
#'                                            delta = NULL,
#'                                            adaptive.method=NULL,
#'                                            forecast.num = 12,
#'                                            expost.flag = TRUE,
#'                                            ignore.zero = NULL,
#'                                            prediction.confidence.1 = 0.8,
#'                                            prediction.confidence.2 = 0.95)
#' }
#' Output:
#' \preformatted{
#' > sesm[[2]]$Collect()
#'   STAT_NAME    STAT_VALUE
#' 1       MPE   -0.05117142
#' 2       MSE 3438.33212531
#' }
#' Case 2: hanaml.UnifiedExponentialSmoothing with massive mode:\cr
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    GROUP_ID ID RAWDATA RAWDATA2
#' 1    Hello1  0   200.0     -111
#' 2    Hello1  1   135.0     -111
#' 3    Hello1  2   195.0     -111
#' 4    Hello1  3   197.5     -111
#' 5    Hello1  4   310.0     -111
#' 6    Hello1  5   175.0     -111
#' 7    Hello1  6   155.0     -111
#' 8    Hello1  7   130.0     -111
#' 9    Hello1  8   220.0     -111
#' 10   Hello1  9   277.5     -111
#' 11   Hello1 10   235.0     -111
#' 12   Hello2  1     0.0     -111
#' 13   Hello2  2     0.0     -111
#' 14   Hello2  3     0.0     -111
#' 15   Hello2  4     0.0     -111
#' 16   Hello2  5     0.0     -111
#' 17   Hello2  6     0.0     -111
#' 18   Hello2  7     0.0     -111
#' 19   Hello2  8     0.0     -111
#' 20   Hello2  9     0.0     -111
#' 21   Hello2 10     0.0     -111
#' 22   Hello2 11     0.0     -111
#' }
#' Create a "hanaml.UnifiedExponentialSmoothing" object msesm:
#'
#' \preformatted{
#' msesm <- hanaml.UnifiedExponentialSmoothing(func = 'SESM',
#'                                             data = data,
#'                                             massive = TRUE,
#'                                             group.key = 'GROUP_ID',
#'                                             key = 'ID',
#'                                             endog = 'RAWDATA',
#'                                             group.params = list('Hello1'=list(
#'                                               'adaptive.method'=FALSE,
#'                                               'accuracy.measure'=list('mse', 'MApe'),
#'                                               'alpha'=0.1,
#'                                               'forecast.num'=12,
#'                                               'expost.flag'=TRUE),
#'                                               'Hello2'=list(
#'                                                 'adaptive.method'=TRUE,
#'                                                 'accuracy.measure'='MApe',
#'                                                 'alpha'=0.5,
#'                                                 'forecast.num'=12,
#'                                                 'expost.flag'=FALSE)))
#' }
#' Output:
#' \preformatted{
#' > msesm$stats$Collect()
#'   GROUP_ID STAT_NAME         STAT_VALUE
#' 1   Hello2      MAPE                  0
#' 2   Hello1      MAPE 0.2458362309905091
#' 3   Hello1       MSE 3438.3321253085405
#'
#' > msesm$forecast$Collect()
#'    GROUP_ID TIMESTAMP    VALUE PI1_LOWER PI1_UPPER PI2_LOWER PI2_UPPER REASON
#' 1    Hello2        12   0.0000    0.0000    0.0000   0.00000    0.0000   <NA>
#' 2    Hello2        13   0.0000    0.0000    0.0000   0.00000    0.0000   <NA>
#' 3    Hello2        14   0.0000    0.0000    0.0000   0.00000    0.0000   <NA>
#' 4    Hello2        15   0.0000    0.0000    0.0000   0.00000    0.0000   <NA>
#' ......
#' 33   Hello1        22 205.5561  122.8521  288.2602  79.07124  332.0410   <NA>
#' 34   Hello1        23 205.5561  122.4770  288.6352  78.49761  332.6147   <NA>
#' }
#' @keywords Unified Interface
#' @export
hanaml.UnifiedExponentialSmoothing <- function(data = NULL,
                                               func = NULL,
                                               key = NULL,
                                               endog = NULL,
                                               massive = FALSE,
                                               group.key = NULL,
                                               group.params = NULL,
                                               ...) {

  UnifiedExponentialSmoothing$new(data = data,
                                  func = func,
                                  key = key,
                                  endog = endog,
                                  massive = massive,
                                  group.key = group.key,
                                  group.params = group.params,
                                  ...)
}
