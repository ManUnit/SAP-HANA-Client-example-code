KDE <- R6Class(
  "KDE",
  inherit = MlBase,
  public = list(
    kernel.map = list(
      gaussian = 0, tophat = 1, epanechnikov = 2,
      exponential = 3, linear = 4, cosine = 5),
    algorithm.map = list("brute-force" = 0, "kd-tree" = 1, "ball-tree" = 2),
    distance.level.map = list(
      manhattan = 1, euclidean = 2, minkowski = 3, chebyshev = 4),
    range.name.map = list(bandwidth = "BANDWIDTH_RANGE"),
    values.name.map = list(bandwidth = "BANDWIDTH_VALUES"),
    thread.ratio = NULL,
    leaf.size = NULL,
    kernel = NULL,
    algorithm = NULL,
    bandwidth = NULL,
    distance.level = NULL,
    minkowski.power = NULL,
    abs.res.tol = NULL,
    rel.res.tol = NULL,
    resampling.method = NULL,
    evaluation.metric = NULL,
    repeat.times = NULL,
    param.search.strategy = NULL,
    random.state = NULL,
    progress.indicator.id = NULL,
    parameter.range = NULL,
    parameter.values = NULL,
    model = NULL,
    optim.param = NULL,
    cv.stat = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          thread.ratio = NULL,
                          leaf.size = NULL,
                          kernel = NULL,
                          algorithm = NULL,
                          bandwidth = NULL,
                          distance.level = NULL,
                          minkowski.power = NULL,
                          abs.res.tol = NULL,
                          rel.res.tol = NULL,
                          resampling.method = NULL,
                          evaluation.metric = NULL,
                          repeat.times = NULL,
                          param.search.strategy = NULL,
                          random.state = NULL,
                          progress.indicator.id = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL) {
        super$initialize()
        if (!is.null(data)) {
            cols <- data$columns
            if (is.null(key)) {
                key <- cols[[1]]
            } else {
                key <- validateInput("key", key, cols, case.sensitive = TRUE)
            }
            cols <- cols[!cols %in% key]

            if (is.null(features)) {
                features <- cols
            } else {
                features <- validateInput(
                  "features", features, cols, case.sensitive = TRUE)
            }
            self$kernel <- validateInput("kernel", kernel, self$kernel.map)
            self$algorithm <- validateInput("algorithm", algorithm, self$algorithm.map)
            if (!is.null(leaf.size)) {
                if (all(self$algorithm != c("kd-tree", " ball-tree"))) {
                  error.msg <- "leaf.size will only be valid if algorithm is kd-tree or ball-tree!"
                  flog.error(error.msg)
                  stop(error.msg)
                }
                self$leaf.size <- validateInput("leaf.size", leaf.size, "integer")

                if (leaf.size == 0) {
                  error.msg <- "leaf.size should be greater than 0"
                  flog.error(error.msg)
                  stop(error.msg)
                }
            }
            self$bandwidth <- validateInput("bandwidth", bandwidth, "double")
            self$distance.level <- validateInput(
              "distance.level", distance.level, self$distance.level.map)

            if (!is.null(minkowski.power) && !is.null(distance.level)) {
                if (self$distance.level != "minkowski") {
                  error.msg <- "minkowski.power will only be valid if distance.level is Minkowski."
                  flog.error(error.msg)
                  stop(error.msg)
                }
                self$minkowski.power <- validateInput("minkowski.power", minkowski.power, "double")
            }
            self$abs.res.tol <- validateInput("abs.res.tol", abs.res.tol, "double")
            self$rel.res.tol <- validateInput("rel.res.tol", rel.res.tol, "double")

            param.array <- list(
              tuple("BUCKET_SIZE", self$leaf.size, NULL, NULL),
              tuple("KERNEL", map.null(self$kernel, self$kernel.map), NULL, NULL),
              tuple("METHOD", map.null(self$algorithm, self$algorithm.map), NULL, NULL),
              tuple("BANDWIDTH", NULL, self$bandwidth, NULL),
              tuple("DISTANCE_LEVEL", map.null(distance.level, self$distance.level.map), NULL, NULL),
              tuple("MINKOWSKI_POWER", NULL, self$minkowski.power, NULL),
              tuple("ABSOLUTE_RESULT_TOLERANCE", NULL, self$abs.res.tol, NULL),
              tuple("RELATIVE_RESULT_TOLERANCE", NULL, self$rel.res.tol, NULL))

            if (!inherits(data, "DataFrame")) {
              msg <- "data must be given as a DataFrame"
              flog.error(msg)
              stop(msg)
            }
            CheckConnection(data)
            conn <- data$connection.context

            unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
            temp <- list(key)
            temp <- append(temp, features)
            data <- data$Select(temp)

            if (!(is.null(resampling.method) || is.null(evaluation.metric))) {
                if (!is.null(thread.ratio)) {
                  self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
                  if (thread.ratio < 0 || thread.ratio > 1) {
                    msg <- "The thread.ratio value range is from 0 to 1!"
                    flog.error(msg)
                    stop(msg)
                  }
                }
                resampling.list <- list(loocv = "loocv")
                resampling.method <- validateInput(
                  "resampling.method", resampling.method, resampling.list)
                metric.list <- list(NLL = "NLL")
                evaluation.metric <- validateInput(
                  "evaluation.metric", evaluation.metric, metric.list, case.sensitive = TRUE)
                repeat.times <- validateInput("repeat.times", repeat.times, "integer")
                search.strategy.list <- list(grid = "grid", random = "random")
                param.search.strategy <- validateInput(
                  "param.search.strategy", param.search.strategy, search.strategy.list)
                repeat.times <- validateInput("repeat.times", repeat.times, "integer")
                random.state <- validateInput("random.state", random.state, "integer")
                progress.indicator.id <- validateInput("progress.indicator.id",
                                                       progress.indicator.id, "character")
                ps.param.array <- list(
                  tuple("HAS_ID", 1, NULL, NULL),
                  tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
                  tuple("RESAMPLING_METHOD", NULL, NULL,
                        map.null(resampling.method, resampling.list)),
                  tuple("EVALUATION_METRIC", NULL, NULL,
                        map.null(evaluation.metric, metric.list)),
                  tuple("REPEAT_TIMES", repeat.times, NULL, NULL),
                  tuple("PARAM_SEARCH_STRATEGY", NULL, NULL,
                       map.null(param.search.strategy, search.strategy.list)),
                  tuple("SEED", random.state, NULL, NULL),
                  tuple("PROGRESS_INDICATOR_ID", NULL, NULL, progress.indicator.id))

                param.search.list <- list("bandwidth")
                ps.param.array <- append(ps.param.array, param.array)
                if (length(parameter.values) != 0) {
                  validateInput(
                    "Parameters for values specification",
                    names(parameter.values), param.search.list, case.sensitive = TRUE)
                  str.values <- lapply(parameter.values, function(X) paste0(X, collapse = ","))
                  values <- lapply(
                    X = str.values, a = "{", b = "}",
                    function(X, a, b) paste0(a, X, b))
                  values.name <- self$values.name.map[names(parameter.values)]

                  temp <- list()
                  for (i in seq_len(length(values))) {
                    if (length(values.name) == 1) {
                      j <- i %% length(values) + 1
                    } else {
                      j <- i
                    }
                    temp <- append(
                      temp, list(tuple(values.name[[j]], NULL, NULL, as.character(values[i]))))
                  }
                  ps.param.array <- append(ps.param.array, temp)
                }
                if (length(parameter.range) != 0) {
                  validateInput(
                    "Parameters for range specification", names(parameter.range),
                    param.search.list, case.sensitive = TRUE)
                  ranges.length <- lapply(parameter.range, FUN = length)
                  invalid.range <- parameter.range[!(ranges.length == 2 | ranges.length == 3)]
                  if (length(invalid.range) != 0) {
                    msg <- sprintf("%are invalid.", paste(names(invalid.range), collapse = ", "))
                    flog.error(msg)
                    stop(msg)
                  }
                  str.range <- lapply(
                    parameter.range,
                    function(X) paste0(X, collapse = ifelse(length(X) == 2, ",,", ",")))
                  ranges <- lapply(
                    X = str.range, a = "[", b = "]", function(X, a, b) paste0(a, X, b))
                  range.name <- self$range.name.map[names(parameter.range)]

                  temp <- list()
                  for (i in seq_len(length(ranges))) {
                    if (length(range.name) == 1) {
                      j <- i %% length(range.name) + 1
                    } else {
                      j <- i
                    }
                    temp <- append(
                      temp, list(tuple(range.name[[j]], NULL, NULL, as.character(ranges[i]))))
                  }
                  ps.param.array <- append(ps.param.array, temp)
                }

                ps.param.tbl <- sprintf("#PAL_KDE_CV_PARAMETER_TBL_%s_%s", self$id, unique.id)
                optim.param.tbl <- sprintf("#PAL_KDE_CV_RESULT_TBL_%s_%s", self$id, unique.id)
                cv.stat.tbl <- sprintf("#PAL_KDE_CV_STAT_TBL_%s_%s", self$id, unique.id)

                in.tables <- list(data, ps.param.tbl)
                out.tables <- list(cv.stat.tbl, optim.param.tbl)
                tables <- c(ps.param.tbl, out.tables)

                tryCatch({
                  errorhelper(CreateTWithConnection(
                    conn,  ParameterTable$new(ps.param.tbl)$WithData(ps.param.array)))
                  errorhelper(CallPalAutoWithConnection(
                    conn, "PAL_KDE_CV",  in.tables, out.tables))
                }, error = function(err) {
                  msg <- paste("Error:", err[["message"]])
                  flog.error(msg)
                  TryDropWithConnection(conn, tables)
                  stop(msg)
                })
                self$cv.stat <- conn$table(cv.stat.tbl)
                if (!is.null(param.search.strategy)) {
                  self$optim.param <- conn$table(optim.param.tbl)
                }
            }
            param.tbl <- sprintf("#PAL_KDE_PARAMETER_TBL_%s_%s", self$id, unique.id)
            tryCatch({
              errorhelper(CreateTWithConnection(
                conn,  ParameterTable$new(param.tbl)$WithData(param.array)))
            }, error = function(err) {
                msg <- paste("Error:", err[["message"]])
                flog.error(msg)
                TryDropWithConnection(conn, param.tbl)
                stop(msg)
            })
            if (!is.null(self$optim.param)){
              param.string <- "PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE"
              ExecuteLogged(conn$connection,
                          sprintf("INSERT INTO %s (%s) SELECT %s FROM %s",
                                  param.tbl, param.string, param.string,
                                  self$optim.param$name))
            }
            param.df <- conn$table(param.tbl)
            self$model <- list(data, param.df)
        }
    }, predict = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          thread.ratio = NULL,
                          stat.info = NULL) {
        train.data <- self$model[[1]]
        param.df <- self$model[[2]]
        if (is.null(train.data)) {
            msg <- "Model for prediction is NULL!"
            flog.error(msg)
            stop(msg)
        }
        if (is.null(data)) {
            msg <- "data is NULL!"
            flog.error(msg)
            stop(msg)
        }
        if (!inherits(data, "DataFrame")) {
            msg <- paste("data is not of type DataFrame,",
                         "please provide DataFrame to proceed")
            flog.error(msg)
            stop(msg)
        }
        CheckConnection(data)
        conn <- data$connection.context
        cols <- data$columns
        if (is.null(key)) {
            key <- cols[[1]]
        } else {
            key <- validateInput("key", key, cols, case.sensitive = TRUE)
        }
        cols <- cols[!cols %in% key]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        if (is.null(features)) {
            features <- cols
        }
        temp <- c(key, unlist(features))
        data <- data$Select(temp)
        if (length(train.data$columns) != length(data$columns)) {
            msg <- paste("The dimension of data must be the same",
                         "for both training sampling and evaluation data.")
            flog.error(msg)
            stop(msg)
        }
        stat.info <- validateInput("stat.info", stat.info, "logical")
        if (!is.null(thread.ratio)) {
          thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
          if (thread.ratio < 0 || thread.ratio > 1) {
            msg <- "The thread.ratio value range is from 0 to 1!"
            flog.error(msg)
            stop(msg)
          }
        }
        param.array <- list(tuple("STAT_INFO", to.integer(stat.info), NULL, NULL),
                            tuple("THREAD_RATIO", NULL, thread.ratio, NULL))
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_KDE_PARAMETER_%s", unique.id)
        result.tbl <- sprintf("#PAL_EVAL_RESULT_TBL_%s", unique.id)
        stats.tbl <- sprintf("#PAL_STAT_TBL_%s", unique.id)
        in.tables <- list(train.data, data, param.tbl)
        out.tables <- list(result.tbl, stats.tbl)
        tables <- c(param.tbl, out.tables)
        tryCatch({
          errorhelper(CreateTWithConnection(
            conn, ParameterTable$new(param.tbl)$WithData(param.array)))
          param.string <- "PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE"
          ExecuteLogged(conn$connection,
                      sprintf("INSERT INTO %s (%s) SELECT %s FROM %s",
                              param.tbl, param.string, param.string,
                              param.df$name))
          errorhelper(CallPalAutoWithConnection(conn,
                                                "PAL_KDE",
                                                in.tables, out.tables))
        }, error = function(err) {
            msg <- paste("Error:", err[["message"]])
            flog.error(msg)
            TryDropWithConnection(conn, tables)
            stop(msg)
        })

        return(list(conn$table(result.tbl), conn$table(stats.tbl)))
    }))
#' @title Kernel Density Estimation
#' @name hanaml.KDE
#' @description hanaml.KDE is a R wrapper
#' for SAP HANA PAL Kernel Density Estimation.
#' @seealso \code{\link{predict.KDE}}
#' @details Kernel Density Estimation is a nonparametric approach to
#' obtain a continuous probability density estimation of a random
#' variable based on the sampled data points.\cr
#' It is a quite popular technique in unsupervised learning,
#' feature engineering, and data modeling.
#' @template args-data
#' @template args-key-first
#' @template args-feature-clustering
#' @template args-threadratio
#' @param  leaf.size \code{integer, optional}\cr
#'   only valid when using kd-tree or ball-tree searching
#'   specifies the number of samples in tree lead node.\cr
#'   Defaults to 30.
#' @param  kernel \code{{'gaussian', 'tophat', 'epanechnikov',
#' 'exponential', 'linear', 'cosine'}, optional}\cr
#'   Specifies kernel function used for KDE.
#'   \itemize{
#'    \item{\code{'gaussian'} }
#'    \item{\code{'tophat'}}
#'    \item{\code{'epanechnikov'}}
#'    \item{\code{'exponential'}}
#'    \item{\code{'linear'}}
#'    \item{\code{'cosine'}}
#'   }
#'   Defaults to 'gaussian'
#' @param  algorithm \code{{'brute-force', 'kd-tree', 'ball-tree'}}\cr
#'   Specifies data structure used to speed up the calculation
#'   process.
#'   \itemize{
#'    \item{\code{'brute-force'} use brute force searching.}
#'    \item{\code{'kd-tree'} use KD-tree searching.}
#'    \item{\code{'ball-tree'} use Ball-tree searching.}
#'   }
#'   Defaults to 'none'.
#' @param  bandwidth \code{double, optional}\cr
#'   Specifies the bandwidth. \cr
#'   bandwidth = 0 means that the bandwidth will be provided by the
#'   optimizer inside.\cr
#'   Defaults to 0.
#' @param  distance.level \code{{'manhattan', 'euclidean',
#' 'minkowski', 'chebyshev'}, optional}\cr
#'   Specifies the norm used to compute distance between the
#'   train data and evaluation data.
#'   \itemize{
#'    \item{\code{'manhattan'} manhattan norm (l1 norm).}
#'    \item{\code{'euclidean'} euclidean norm (l2 norm).}
#'    \item{\code{'minkowski'} minkowski norm (p-norm).}
#'    \item{\code{'chebyshev'} chebyshev norm (maximum norm).}
#'   }
#'   Defaults to 'euclidean'.
#' @param  minkowski.power \code{double, optional}\cr
#'   When you use the Minkowski distance, this parameter controls the value of power.
#'   Only valid when \emph{distance.level} is 'minkowski'.\cr
#'   Defaults to 3.0.
#' @param  abs.res.tol \code{double, optional}\cr
#'   Spezifies the desired absolute tolerance.
#'   It enable us to trade off computation time for accuracy.\cr
#'   Defaults to 0.
#' @param  rel.res.tol \code{double, optional}\cr
#'   Specifies the desired relative tolerance.
#'   It enable us to trade off computation time for accuracy.\cr
#'   Defaults to 0.
#' @param resampling.method \code{{'loocv'}, optional}\cr
#'   specifies the resampling values to perform model evaluation and
#'   parameter selection only loocv is supported.\cr
#'   If no value is specified for this parameter, neither model
#'   evaluation nor parameter selection is activated.
#' @param evaluation.metric \code{{'NLL'}, optional}\cr
#'   Specifies the evaluation metric for model evaluation or parameter
#'   selection, only NLL is supported.\cr
#'   If not specified, neither model evaluation
#'   nor parameter selection is activated.\cr
#' @param repeat.times \code{numeric, optional}\cr
#'   Specifies the number of repeat times for resampling.\cr
#'   Defaults to 1.
#' @param param.search.strategy \code{{'grid', 'random'}, optional}\cr
#'   Specifies the method to activate parameter selection.
#'   If not specified, parameter selection shall not be triggered.
#' @param  random.state \code{double, optional}\cr
#'   Specifies the seed for random number generation, where 0 means
#'   current system time
#'   is used as seed, and other values are simply real seed values.\cr
#'   Defaults to 0.
#' @param progress.indicator.id  \code{character, optional}\cr
#'   Sets an ID of progress indicator for model evaluation or
#'   parameter selection.\cr
#'   No progress indicator is active if no value is provided.
#' @param parameter.values \code{list/vector, optional}\cr
#'   Specifies values of the bandwidth parameters for parameter
#'   selection:\cr
#' @param parameter.range \code{list/vector, optional}\cr
#'   Specifies range of the bandwidth parameters for parameter
#'   selection:\cr
#'   Parameter range should be specified by 3 numbers in the form of
#'   c(start, step, end).\cr
#' @return
#' A 'KDE' object with the following attributes:\cr
#' \itemize{
#' \item{\code{statistics: DataFrame}}\cr
#'  Statistics for model-evaluation/parameter-selection.\cr
#'  Available only when model-evaluation/parameter selection is enabled.
#' \item{\code{optim.param: DataFrame}}\cr
#'  Optimal parameters selected.\cr
#'  Available only when parameter-selection is enabled.
#' }
#'
#' @section Examples:
#' Input DataFrame data.df.fit:
#' \preformatted{
#' > data.df.fit$Collect()
#'  ID         X1          X2
#' 1 0 -0.4257698 -1.39613035
#' 2 1 0.8841004   1.38149350
#' 3 2 0.1341262  -0.03222389
#' 4 3 0.8455036   2.86792078
#' 5 4 0.2884408   1.51333705
#' 6 5 -0.6667847  1.24498042
#' 7 6 -2.1029683 -1.42832694
#' 8 7 0.7699024  -0.47300711
#' 9 8 0.2102913   0.32843074
#' 10 9 0.4823225 -0.43796174
#' }
#' Call the function:
#' \preformatted{
#' estimation <- hanaml.KDE(
#'   data = data.df.fit, leaf.size = 10,
#'   algorithm = 'kd-tree', distance.level = 'euclidean',
#'   kernel = 'gaussian',
#'   parameter.values = list(bandwidth = c(0.68129, 1.0, 3.0, 5.0)),
#'   resampling.method = 'loocv', evaluation.metric = 'NLL',
#'   repeat.times = 2, param.search.strategy = 'grid',
#'   random.state = 1, progress.indicator.id = 'TEST')
#' }
#' Output:
#' \preformatted{
#' > estimation$optim.param$Collect()
#'  PARAM_NAME INT_VALUE DOUBLE_VALUE STRING_VALUE
#' 1 BANDWIDTH        NA            1         <NA>
#' }
#' @keywords Statistics
#' @export
hanaml.KDE <- function(data = NULL,
                       key = NULL,
                       features = NULL,
                       thread.ratio = NULL,
                       leaf.size = NULL,
                       kernel = NULL,
                       algorithm = NULL,
                       bandwidth = NULL,
                       distance.level = NULL,
                       minkowski.power = NULL,
                       abs.res.tol = NULL,
                       rel.res.tol = NULL,
                       resampling.method = NULL,
                       evaluation.metric = NULL,
                       repeat.times = NULL,
                       param.search.strategy = NULL,
                       random.state = NULL,
                       progress.indicator.id = NULL,
                       parameter.range = NULL,
                       parameter.values = NULL) {
    KDE$new(data = data,
            key = key,
            features = features,
            thread.ratio = thread.ratio,
            leaf.size = leaf.size,
            kernel = kernel,
            algorithm = algorithm,
            bandwidth = bandwidth,
            distance.level = distance.level,
            minkowski.power = minkowski.power,
            abs.res.tol = abs.res.tol,
            rel.res.tol = rel.res.tol,
            resampling.method = resampling.method,
            evaluation.metric = evaluation.metric,
            repeat.times = repeat.times,
            param.search.strategy = param.search.strategy,
            random.state = random.state,
            progress.indicator.id = progress.indicator.id,
            parameter.range = parameter.range,
            parameter.values = parameter.values)
}

#' @title apply Kernel Density Estimation analysis
#' @name predict.KDE
#' @seealso \code{\link{hanaml.KDE}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr A 'KDE' object.
#' @param data \code{DataFrame}\cr
#' DataFrame containting the data points whose density value need
#' to be evaluated.
#' @template args-key-first
#' @template args-feature-clustering
#' @template args-threadratio
#' @param  stat.info \code{logical, optional}\cr
#' If TRUE, return a DataFrame with statistics information.\cr
#' Defaults to FALSE.
#' @return
#' Returns a list of DataFrame.\cr
#' \itemize{
#' \item{\code{DataFrame 1}}\cr
#' Evaluated log density value of the data points, structured as
#' follows:
#' \itemize{
#'   \item{ID}: id.
#'   \item{DENSITY_VALUE}: log Density value.
#' }
#' }
#' \itemize{
#' \item{\code{DataFrame 2}}\cr
#' Statistics information, structured as follows:\cr
#' \item{COMMUNALITIES : \code{DataFrame}}
#'   \itemize{
#'     \item{TEST_ID}: ID of evaluated test data point.
#'     \item{FITTING_IDS}: Fitting IDs.
#'   }
#' }
#' @section Examples:
#' Input DataFrame data.df.fit and data.eval.df.fit:
#' \preformatted{
#' > data.df.fit$Collect()
#'  ID        X1          X2
#' 1 0 -2.1029683 -1.4283269
#' 2 1 -2.1029683  0.7197969
#' 3 2 -2.1029683  2.8679208
#' 4 3 -0.6094340 -1.4283269
#' 5 4 -0.6094340  0.7197969
#' 6 5 -0.6094340  2.8679208
#' 7 6  0.8841004 -1.4283269
#' 8 7  0.8841004  0.7197969
#' 9 8  0.8841004  2.8679208
#' > data.eval.df.fit$Collect()
#'  ID         X1          X2
#' 1 0 -0.4257698 -1.39613035
#' 2 1  0.8841004  1.38149350
#' 3 2  0.1341262 -0.03222389
#' 4 3  0.8455036  2.86792078
#' 5 4  0.2884408  1.51333705
#' 6 5 -0.6667847  1.24498042
#' 7 6 -2.1029683 -1.42832694
#' 8 7  0.7699024 -0.47300711
#' 9 8  0.2102913  0.32843074
#' 10 9 0.4823225 -0.43796174
#' }
#' Call the function:
#' \preformatted{
#' estimation <- hanaml.KDE(data = data.df.fit,
#'                          leaf.size = 10,
#'                          algorithm = 'kd-tree',
#'                          bandwidth = 0.68129,
#'                          distance.level = 'euclidean',
#'                          kernel = 'gaussian')
#'
#' eval.result <- predict(estimation,
#'                        data = data.eval.df.fit,
#'                        stat.info = TRUE)
#' }
#' Output:
#' \preformatted{
#' > eval.result[[1]]$Collect()
#'   ID DENSITY_VALUE
#'  1 0     -3.852755
#'  2 1     -4.586453
#'  3 2     -6.110158
#'  4 3     -3.275507
#'  5 4     -2.888267
#'  6 5     -4.107246
#'  7 6     -3.387239
#'  8 7     -2.732173
#'  9 8     -3.554738
#'}
#' @keywords Statistics
#' @export
predict.KDE <- function(model, data = NULL, key = NULL, features = NULL,
                        thread.ratio = NULL, stat.info = NULL) {
    model$predict(
      data = data, key = key, features = features,
      thread.ratio = thread.ratio, stat.info = stat.info)
}
