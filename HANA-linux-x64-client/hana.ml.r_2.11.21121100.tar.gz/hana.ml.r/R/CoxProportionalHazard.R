CoxProportionalHazard <- R6Class(
  "CoxProportionalHazard",
  inherit = MlBase,
  public = list(
    tie.method = NULL,
    max.iter = NULL,
    tol = NULL,
    significance.level = NULL,
    calculate.hazard = NULL,
    output.fitted = NULL,
    statistics = NULL,
    coefficients = NULL,
    covariance = NULL,
    hazard = NULL,
    fitted = NULL,
    model = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          label = NULL,
                          status = NULL,
                          features = NULL,
                          formula = NULL,
                          tie.method = NULL,
                          max.iter = NULL,
                          tol = NULL,
                          significance.level = NULL,
                          calculate.hazard = NULL,
                          output.fitted = NULL){
      super$initialize()
      if (!is.null(data)){
        self$tie.method <- validateInput("tie.method", tie.method,
                                         private$tie.method.map)
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        self$tol <- validateInput("tol", tol, "numeric")
        self$significance.level <- validateInput("significance.level",
                                                 significance.level,
                                                 "numeric")
        self$calculate.hazard <- validateInput("calculate.hazard",
                                               calculate.hazard,
                                               "logical")
        self$output.fitted <- validateInput("output.fitted",
                                            output.fitted,
                                            "logical")
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        if (length(key) == 0){
          key <- cols[[1]]
        }
        cols <- cols[! cols %in% key]
        if (inherits(formula, "formula")){
          parseformula <- ParseFormula(data, formula)
          label <- parseformula[[1]]
          features <- parseformula[[2]]
          features <- features[! features %in% c(key, status)]
        }
        label <- validateInput("label", label, cols, case.sensitive = TRUE)
        if (length(label) == 0){
          label <- cols[[1]]
        }
        cols <- cols[! cols %in% label]
        status <- validateInput("status", status, cols,
                                case.sensitive = TRUE)
        cols <- cols[! cols %in% status]
        features <- validateInput("features", features, cols,
                                  case.sensitive = TRUE)
        if (length(features) == 0){
          features <- cols
        }
        if (!inherits(data, "DataFrame")){
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn <- data$connection.context
        selected <- as.list(c(key, label, status, features))
        data <- data$Select(selected)

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_CPH_PARAM_TBL_%s_%s", self$id, unique.id)
        stat.tbl <- sprintf("#PAL_CPH_STAT_TBL_%s_%s", self$id, unique.id)
        coef.tbl <- sprintf("#PAL_CPH_COEFF_TBL_%s_%s", self$id, unique.id)
        cov.tbl <- sprintf("#PAL_CPH_COV_TBL_%s_%s", self$id, unique.id)
        hazard.tbl <- sprintf("#PAL_CPH_HAZARD_TBL_%s_%s", self$id, unique.id)
        fitted.tbl <- sprintf("#PAL_CPH_FITTED_TBL_%s_%s", self$id, unique.id)
        param.rows <- list(
          tuple("TIE_METHOD", NULL, NULL, map.null(self$tie.method,
                                                   private$tie.method.map)),
          tuple("STATUS_COL", as.integer(!is.null(status)), NULL, NULL),
          tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
          tuple("CONVERGENCE_CRITERION", NULL, self$tol, NULL),
          tuple("SIGNIFICANCE_LEVEL", NULL, self$significance.level, NULL),
          tuple("CALCULATE_HAZARD", to.integer(self$calculate.hazard),
                NULL, NULL),
          tuple("OUTPUT_FITTED", to.integer(self$output.fitted),
                NULL, NULL)
        )
        in.tables <- list(data, param.tbl)
        out.tables <- list(stat.tbl, coef.tbl, cov.tbl,
                           hazard.tbl, fitted.tbl)
        tables <- c(param.tbl, out.tables)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
            ParameterTable$new(param.tbl)$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn,
                                                "PAL_COXPH",
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err$message)
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        self$statistics <- conn$table(stat.tbl)
        self$coefficients <- conn$table(coef.tbl)
        self$covariance <- conn$table(cov.tbl)
        self$hazard <- conn$table(hazard.tbl)
        self$fitted <- conn$table(fitted.tbl)
        self$model <- list(self$statistics, self$coefficients,
                           self$covariance)
      }
    }),
  private = list(
    tie.method.map = list(breslow = "breslow", efron = "efron")
  ))

#' @title  Cox Proportional Hazard Model
#' @name hanaml.CoxProportionalHazard
#' @description hanaml.CoxProportionalHazard is an R wrapper
#' for SAP HANA PAL Cox proportional hazard model.
#' @details Cox proportional hazard model is a special generalized linear model.
#'          It is a well-known realization-of-survival model that demonstrates failure or
#'          death at a certain time
#' @seealso \code{\link{predict.CoxProportionalHazard}}
#' @template args-data
#' @template args-key-first
#' @param label \code{character, optional}\cr
#' Name of the regression target column of Cox proportional hazard model,
#' which specifies the time before a failure/death event occurs or data
#' is right censored.\cr
#' If not provided, it defaults to the 1st non-ID column of \emph{data}.
#' @param status \code{character, optional}\cr
#' Name of the status column that indicates if the individual is an event
#' or right-censored data.\cr
#' If not specified, then \emph{data} is assumed to have no status column,
#' and all timestamps in \emph{label} column are thus assumed to be
#' associated with death/failure.
#' @param features \code{list/vector of character, optional}\cr
#' Names of the covariate columns.\cr
#' Defaults to all non-ID, non-label, non-status columns if not specified.
#' @template args-formula
#' @param tie.method \code{("breslow", "efron"), optional}\cr
#' Specifies the method for dealing with tied events.\cr
#' Defaults to "efron".
#' @param max.iter \code{integer, optional}\cr
#' Maximum number of iterations for numeric optimization in maximum
#' log-likelihood estimation.\cr
#' Defaults to 100.
#' @param tol \code{numeric, optional}\cr
#' Convergence(stopping) criterion for numeric optimization.\cr
#' Defaults to 1e-8.
#' @param significance.level \code{numeric, optional}\cr
#' Significance level for the confidence interval of estimated coefficients.\cr
#' Defaults to 0.05.
#' @param calculate.hazard \code{logical, optional}
#' Specifies whether or not to calculate hazard function as well as survival function.\cr
#' Defaults to TRUE.
#' @param output.fitted \code{logical, optional}\cr
#' Specifies whether or not to output the fitted response.\cr
#' Defaults to FALSE.
#' @return
#' Return a "CoxProportionalHazard" object with following values:
#' \itemize{
#' \item{statistics: \code{DataFrame}}\cr
#'       Regression-related statistics, like mean square error, F-statistics, etc.
#' \item{coefficients: \code{DataFrame}}\cr
#'       Fitted regression coefficients for the Cox PH model.
#' \item{covariance: \code{DataFrame}}\cr
#'       Covariance values between features.
#' \item{hazard: \code{DataFrame}}\cr
#'       Calculated cumulative baseline hazard function and survival function.
#' \item{fitted: \code{DataFrame}}\cr
#'       Predicted linear predictors and exponential responses in risk space.
#' }
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'   ID TIME STATUS X1 X2
#' 1  1    4      1  0  0
#' 2  2    3      1  2  0
#' 3  3    1      1  1  0
#' 4  4    1      0  1  0
#' 5  5    2      1  1  1
#' 6  6    2      1  0  1
#' 7  7    3      0  0  1
#' }
#' Call the function:
#' \preformatted{
#' cph <-  hanaml.CoxProportionalHazard(data = data,
#'                                      key = "ID",
#'                                      label = "TIME",
#'                                      status = "STATUS",
#'                                      tie.method = "efron",
#'                                      calculate.hazard = TRUE,
#'                                      output.fitted = TRUE)
#' }
#' Output:
#' \preformatted{
#'> cph$coefficients
#'   VARIABLE_NAME      MEAN COEFFICIENT        SE     SCORE PROBABILITY   CI_LOWER CI_UPPER
#' 1            X1 0.7142857   0.7811819 0.7975689 0.9794538   0.3273558 -0.7820244 2.344388
#' 2            X2 0.4285714   0.9337832 1.4081100 0.6631465   0.5072367 -1.8260617 3.693628
#' }
#' @keywords Regression
#' @export
hanaml.CoxProportionalHazard <- function(data = NULL,
                                         key = NULL,
                                         label = NULL,
                                         status = NULL,
                                         features = NULL,
                                         formula = NULL,
                                         tie.method = NULL,
                                         max.iter = NULL,
                                         tol = NULL,
                                         significance.level = NULL,
                                         calculate.hazard = NULL,
                                         output.fitted = NULL){
  CoxProportionalHazard$new(data,
                            key,
                            label,
                            status,
                            features,
                            formula,
                            tie.method,
                            max.iter,
                            tol,
                            significance.level,
                            calculate.hazard,
                            output.fitted)
}

#' @title Make Predictions from a "CoxProportionalHazard" Object
#' @name predict.CoxProportionalHazard
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "CoxProportionalHazard" object.
#' @seealso \code{\link{hanaml.CoxProportionalHazard}}
#' @format     \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#' A "CoxProportionalHazard" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param response.type \code{("risk", "linear"), optional}\cr
#' Specifies the response type of the predicted values.
#' \itemize{
#' \item{"risk": Response in risk space, i.e. exponential value of linear response.}
#' \item{"linear": Linear response.}
#' }
#' Defaults to "risk".
#' @param significance.level \code{numeric, optional}\cr
#' Significance level for the confidence interval and prediction interval.\cr
#' Defaults to 0.05.
#'
#' @return
#'Predicted values are returned as a DataFrame, structured as follows.
#'\itemize{
#'   \item{ID: with same name and type as \emph{data}'s ID column.}
#'   \item{PREDICTION: type DOUBLE, representing predicted values.}
#'   \item{SE: standard error.}
#'   \item{CI_LOWER: lower bound of the confidence interval.}
#'   \item{CI_UPPER: upper bound of the confidence interval.}
#'}
#'
#' @section Examples:
#' DataFrame data2 for prediction:
#' \preformatted{
#' > data2$Collect()
#'   ID X1 X2
#' 1  1  0  0
#' 2  2  2  0
#' 3  3  1  0
#' 4  4  1  0
#' 5  5  1  1
#' 6  6  0  1
#' 7  7  0  1
#' }
#' Perform prediction based on a "LogarithmicRegression" Object cph:
#' \preformatted{
#' > predict(cph, data2, key = "ID", significance.level = 0.05,
#'           response.type = "risk")
#'
#'   ID PREDICTION        SE   CI_LOWER  CI_UPPER
#' 1  1  0.3835904 0.4125263 0.04660757  3.157032
#' 2  2  1.8297584 1.3858338 0.41467272  8.073876
#' 3  3  0.8377815 0.4008941 0.32795551  2.140162
#' 4  4  0.8377815 0.4008941 0.32795551  2.140162
#' 5  5  2.1314132 2.0762107 0.31587249 14.382140
#' 6  6  0.9758985 0.5758764 0.30698117  3.102398
#' 7  7  0.9758985 0.5758764 0.30698117  3.102398
#' }
#' @keywords Regression
#' @export

predict.CoxProportionalHazard <- function(model,
                                          data,
                                          key,
                                          features = NULL,
                                          response.type = NULL,
                                          significance.level = NULL){
  if (is.null(model$model)){
    msg <- "Model is empty!"
    flog.error(msg)
    stop(msg)
  }
  response.type.map <- list(risk = "risk",
                            linear = "lp")
  response.type <- validateInput("response.type", response.type,
                                 response.type.map)
  significance.level <- validateInput("significance.level",
                                      significance.level,
                                      "numeric")
  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE,
                       case.sensitive = TRUE)
  cols <- cols[! cols %in% key]
  features <- validateInput("features", features, cols, case.sensitive = TRUE)
  if (is.null(features)){
    features <- cols
  }
  selected <- c(key, features)
  if (!inherits(data, "DataFrame")){
    msg <- "Data for prediction must be a DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context
  df <- data$Select(selected)
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#COXPHM_PARAMS_TBL_%s_%s", model$id, unique.id)
  result.tbl <- sprintf("#COXPHM_RESULT_TBL_%s_%s", model$id, unique.id)
  tables <- list(param.tbl, result.tbl)
  in.tables <- list(df,
                    model$model[[1]]$name,
                    model$model[[2]]$name,
                    model$model[[3]]$name,
                    param.tbl)
  out.tables <- list(result.tbl)
  param.data <- list(
    tuple("TYPE", NULL, NULL, map.null(response.type,
                                       response.type.map)),
    tuple("SIGNIFICANCE_LEVEL", NULL, significance.level,
          NULL)
  )
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
      ParameterTable$new(param.tbl)$WithData(param.data)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_COXPH_PREDICT",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(result.tbl))
}


#' @export
print.CoxProportionalHazard <- function(x, ...){
  writeLines("\n")
  writeLines("CoxProportionalHazard attributes:")
  writeLines("\n")
  cat(sprintf("tie.method : %s", to.null(x$tie.method)))
  writeLines("\n")
  cat(sprintf("max.iter : %s", to.null(x$max.iter)))
  writeLines("\n")
  cat(sprintf("tol : %s", to.null(x$tol)))
  writeLines("\n")
  cat(sprintf("significance.level : %s",
              to.null(x$significance.level)))
  writeLines("\n")
  cat(sprintf("calculate.hazard : %s",
              to.null(x$calculate.hazard)))
  writeLines("\n")
  cat(sprintf("output.fitted : %s",
              to.null(x$output.fitted)))
  writeLines("\n")
}

#' @export
summary.CoxProportionalHazard <- function(object, ...){
  if (is.null(object$model)){
    writeLines("Summary is empty since model is empty.\n")

  } else {
    writeLines("CoxProportionalHazard coefficients DataFrame:")
    print(object$coefficients$Collect())
    writeLines("\n")
    writeLines("CoxProportionalHazard fitted DataFrame:")
    print(object$fitted$Collect())
    writeLines("\n")
    writeLines("CoxProportionalHazard covariance DataFrame:")
    print(object$covariance$Collect())
    writeLines("\n")
    writeLines("CoxProportionalHazard statistics DataFrame:")
    print(object$statistics$Collect())
    writeLines("\n")
    writeLines("CoxProportionalHazard hazard DataFrame:")
    print(object$hazard$Collect())
    writeLines("\n")
  }
}
