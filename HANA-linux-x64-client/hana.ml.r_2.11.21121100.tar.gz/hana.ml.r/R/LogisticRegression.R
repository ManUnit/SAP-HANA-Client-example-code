LogisticRegression <- R6Class(
  "LogisticRegression",
  inherit = MlBase,
  public = list(
    enet.alpha = NULL,
    enet.lambda = NULL,
    tol = NULL,
    epsilon = NULL,
    solver = NULL,
    max.iter = NULL,
    thread.ratio = NULL,
    standardize = TRUE,
    max.pass.number = NULL,
    lbfgs.m = NULL,
    pmml.export = NULL,
    stat.inf = NULL,
    categorical.variable = NULL,
    class.map0 = NULL,
    class.map1 = NULL,
    model.type = NULL,
    coef = NULL,
    saved.model = NULL,
    result.info = NULL,
    pmml.info = NULL,
    statistic.info = NULL,
    sgd.batch.number = NULL,
    precompute = NULL,
    handle.missing = NULL,
    resampling.method = NULL,
    evaluation.metric = NULL,
    fold.num = NULL,
    repeat.times = NULL,
    param.search.strategy = NULL,
    random.search.times = NULL,
    random.state = NULL,
    timeout = NULL,
    progress.indicator.id = NULL,
    parameter.range = NULL,
    parameter.values = NULL,
    multi.class = FALSE,
    optimal.param = NULL,
    solver.map = list(
      "auto" = -1,
      "newton" = 0,
      "cyclical" = 2,
      "lbfgs" = 3,
      "stochastic" = 4,
      "proximal" = 6
    ),
    multi.solver.map = list(
      "lbfgs" = 0,
      "cyclical" = 1
    ),
    pmml.map.multi = list(
      "no" = 0,
      "multi-row" = 1
    ),
    pmml.map.binary = list(
      "no" = 0,
      "single-row" = 1,
      "multi-row" = 2
    ),
    initialize = function(data,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          enet.alpha = NULL,
                          enet.lambda = NULL,
                          tol = NULL,
                          epsilon = NULL,
                          solver = NULL,
                          max.iter = NULL,
                          thread.ratio = NULL,
                          standardize = TRUE,
                          max.pass.number = NULL,
                          lbfgs.m = NULL,
                          pmml.export = NULL,
                          stat.inf = NULL,
                          categorical.variable = NULL,
                          class.map0 = NULL,
                          class.map1 = NULL,
                          multi.class = FALSE,
                          sgd.batch.number = NULL,
                          precompute = NULL,
                          handle.missing = NULL,
                          resampling.method = NULL,
                          evaluation.metric = NULL,
                          fold.num = NULL, repeat.times = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          random.state = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL){
      super$initialize()
      if (!is.null(data)){
        self$multi.class <- validateInput("multi.class", multi.class, "logical")
        if (isTRUE(self$multi.class)) {
          pmml.map <- self$pmml.map.multi
          solver.map <- self$multi.solver.map
        } else {
          pmml.map <- self$pmml.map.binary
          solver.map <- self$solver.map
        }
        if (is.null(pmml.export)) {
          self$pmml.export <- "no"
        } else {
          self$pmml.export <- pmml.export
        }
        if (!isTRUE(self$multi.class)) {
          msg2 <- "multi.class is set to FALSE and only valid values for pmml.export are 'no', 'single-row' and 'multi-row'." #nolint
        } else {
          msg2 <- "multi.class is set to TRUE and only valid values for pmml.export are 'no' and 'multi-row'."
        }
        if (!self$pmml.export %in% names(pmml.map)) {
          msg <- "Value of pmml_export is invalid."
          flog.error(msg)
          flog.error(msg2)
          stop(msg)
        }
        if (is.null(solver)) {
          if (!isTRUE(self$multi.class)){
            solver <- "auto"
          } else {
            solver <- "lbfgs"
          }
        } else {
          if (!is.character(solver)) {
            msg <- self$errorMsg("Method name should be a character ",
                                 solver.map)
            flog.error(msg)
            stop(msg)
          }
        }
        solver.lower <- sapply(solver, tolower)
        if (length(solver.lower) == 0){
          solver.lower <- NA#Do not change NA to NULL here
        }
        value_solver <- is.null(solver.map[[solver.lower]])
        if (isTRUE(value_solver)) {
          msg <- self$errorMsg("name for solver", solver.map)
          flog.error(msg)
          stop(msg)
        } else {
          self$solver <- solver.lower
        }
        if (!isTRUE(self$multi.class)) {
          if (!(self$solver %in% c("auto",
                                   "newton",
                                   "cyclical",
                                   "lbfgs",
                                   "proximal")) &&
              (!is.null(enet.lambda) && enet.lambda > 0)) {
            msg <- paste("Parameter enet.lambda can be nonzero only when",
                         "solver is Auto, Newton, Cyclical, LBFGS",
                         "or Proximal.")#nolint
            flog.error(msg)
            stop(msg)
          }
          if (!(self$solver %in% c("auto",
                                   "newton",
                                   "cyclical",
                                   "lbfgs",
                                   "proximal")) &&
              !(is.null(enet.alpha))) {
            msg <- paste("Parameter enet.alpha is only valid when",
                         "solver is Auto, Newton, Cyclical, LBFGS",
                         "or Proximal.")#nolint
            flog.error(msg)
            stop(msg)
          }
        } else {
          if ((self$solver == "lbfgs") && (!is.null(enet.lambda) && enet.lambda > 0)) {#nolint
            msg <-
              "Parameter enet.lambda can be nonzero only when solver is Cyclical."
            flog.error(msg)
            stop(msg)
          }
          if (!(self$solver == "cyclical") &&
              !(is.null(enet.alpha))) {
            msg <- paste("Parameter enet.alpha is only valid when",
                         "solver is Cyclical.")#nolint
            flog.error(msg)
            stop(msg)
          }
        }
        self$thread.ratio <-
          validateInput("thread.ratio", thread.ratio, "numeric")
        self$enet.alpha <- validateInput("enet.alpha", enet.alpha, "double")
        self$enet.lambda <- validateInput("enet.lambda", enet.lambda, "double")
        self$max.iter <-
          validateInput("max.iter", max.iter, "integer")
        self$standardize <- validateInput("standardize", standardize, "logical")
        self$tol <- validateInput("tol", tol, "double")
        self$epsilon <- validateInput("epsilon", epsilon, "double")
        if ((sapply(solver, tolower) != "lbfgs") && (!is.null(lbfgs.m))) {#nolint
          msg <-
            "Parameter lbfgs.m will only be available if the method is lbfgs, and it will be ignored otherwise."
          flog.info(msg)
        }
        self$stat.inf <- validateInput("stat.inf", stat.inf,
                                       "logical")
        if (!isTRUE(self$multi.class)){
          if ((self$solver != "stochastic") && !(is.null(max.pass.number))) {#nolint
            msg <-
              "Parameter max.pass.number only applicable when solver is stochastic"
            flog.error(msg)
            stop(msg)
          }
          self$max.pass.number <- validateInput("max.pass.number",
                                                max.pass.number,
                                                "integer")
          if ((self$solver != "stochastic") && !(is.null(sgd.batch.number))) {#nolint
            msg <-
              "Parameter sgd.batch.number only applicable when solver is stochastic"
            flog.error(msg)
            stop(msg)
          }
          self$sgd.batch.number <- validateInput("sgd.batch.number",
                                                 sgd.batch.number,
                                                 "integer")
          if ((self$solver != "lbfgs") && !(is.null(lbfgs.m))) {#nolint
            msg <- "Parameter lbfgs.m only applicable when method is lbfgs"
            flog.error(msg)
            stop(msg)
          }
          self$lbfgs.m <- validateInput("lbfgs.m", lbfgs.m,
                                        "integer")
          catvartype <- typeof(unlist(categorical.variable))
          if (!is.null(categorical.variable) &&
              catvartype == "character")  {
            categorical.variable <- as.list(categorical.variable)
            catvartypenew <- typeof(categorical.variable)
          }
          self$categorical.variable <- validateInput("categorical.variable",
                                                     categorical.variable,
                                                     data$columns,
                                                     case.sensitive = TRUE)
          self$class.map0 <- validateInput("class.map0", class.map0,
                                           "character")
          self$class.map1 <- validateInput("class.map1", class.map1,
                                           "character")
          self$precompute <- validateInput("precompute", precompute,
                                           "logical")
          self$handle.missing <- validateInput("handle.missing", handle.missing,
                                               "logical")
        }
        binary.params <- list(
          "epsilon" = epsilon,
          "thread.ratio" = thread.ratio,
          "max.pass.number" = max.pass.number,
          "sgd.batch.number" = sgd.batch.number,
          "lbfgs.m" = lbfgs.m,
          "class.map0" = class.map0,
          "class.map1" = class.map1,
          "precompute" = precompute,
          "handle.missing" = handle.missing)
        for (x in names(binary.params)) {
          if (!is.null(binary.params[[x]]) && isTRUE(self$multi.class)) {
            msg <- paste("Parameter", x,
                         "is only applicable for binary classification")
            flog.error(msg)
            stop(msg)
          }
        }
        self$resampling.method <-
          validateInput("resampling.method",
                        resampling.method,
                        list(cv = "cv",
                             stratified_cv = "stratified_cv",
                             bootstrap = "bootstrap",
                             stratified_bootstrap = "stratified_bootstrap"
                             ))
        self$evaluation.metric <-
          validateInput("evaluation.metric",
                        evaluation.metric,
                        list(accuracy = "ACCURACY",
                             f1_score = "F1_SCORE",
                             auc = "AUC",
                             nll = "NLL"))
        self$repeat.times <- validateInput("repeat.times",
                                           repeat.times,
                                           "integer")
        self$fold.num <-
          validateInput("fold.num", fold.num, "integer",
                        required = isTRUE(self$resampling.method %in%
                                          c("cv", "stratified_cv")))
        self$param.search.strategy <-
          validateInput("param.search.strategy",
                        param.search.strategy,
                        list(grid = "grid",
                             random = "random"))
        self$random.search.times <-
          validateInput("random.search.times", random.search.times, "integer",
            required = isTRUE(self$param.search.strategy == "random"))
        self$random.state <- validateInput("random.state",
                                           random.state,
                                           "integer")
        self$timeout <- validateInput("timeout", timeout, "integer")
        self$progress.indicator.id <- validateInput("progress.indicator.id",
                                                    progress.indicator.id,
                                                    "character")
        if (length(parameter.values) != 0){
          validateInput("Parameters for value specification",
                        names(parameter.values),
                        list("enet.lambda", "enet.alpha"),
                        case.sensitive = TRUE)
        }
        for (name in names(parameter.values)){
          if (!is.null(self[[name]])){
            msg <- paste(sprintf("Parameter '%s' cannot be specified", name),
                         "both inside and outside parameter.values")
            flog.error(msg)
            stop(msg)
          }
        }
        if (length(parameter.range) != 0){
          validateInput("Parameters for range specification",
                        names(parameter.range),
                        list("enet.lambda", "enet.alpha"),
                        case.sensitive = TRUE)
        }
        for (name in names(parameter.range)){
          if (!(is.null(self[[name]]) && is.null(parameter.values[[name]]))){
            msg <- paste(sprintf("Parameter '%s' cannot be specified", name),
                         "both inside and outside parameter.range")
            flog.error(msg)
            stop(msg)
          }
        }
        self$parameter.range <- parameter.range
        self$parameter.values <- parameter.values
        self$model.type <- "LOGISTICR"
        input.df <- data
        cols <- data$columns
        key <- validateInput("key", key, cols,
                             case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        if (is.null(formula)) {
          label <- validateInput("label", label, cols,
                                 case.sensitive = TRUE)
          if (is.null(label)){
            label <- cols[[length(cols)]]
          }
          cols <- cols[! cols %in% label]
          features <- validateInput("features", features, cols,
                                    case.sensitive = TRUE)
          if (is.null(features))
            features <- cols
        } else {
          FeatureLabels <- ParseFormula(input.df, formula)
          label <- FeatureLabels[[1]]
          label <- validateInput("label", label, cols,
                                 case.sensitive = TRUE)
          cols <- cols[! cols %in% label]
          features <- FeatureLabels[[2]]
          features <- features[! features %in% key]
          features <- validateInput("features", features, cols,
                                    case.sensitive = TRUE)
        }
        if (!isTRUE(self$multi.class)) {
          label.sql.type <- data$dtypes(list(label))[[1]][[2]]
          var1 <- startsWith(label.sql.type, "NVARCHAR")
          var2 <- startsWith(label.sql.type, "VARCHAR")
          if (isTRUE(var1)  || isTRUE(var2)) {
            if (is.null(class.map1) || is.null(class.map0)) {
              msg <- paste("class_map0 and class_map1 are mandatory",
                           "when label is of type NVARCHAR or VARCHAR")
              flog.error(msg)
              stop(msg)
            }
          }
        }
        collist <- c(key, features, label)
        used.cols <- list()
        for (col in collist){
          if (!is.null(col))
            used.cols <- append(used.cols, col)
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "data must be given as a DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn <- data$connection.context
        training.data <- input.df$Select(used.cols)


        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <-
          sprintf("#LR_PARAMETER_TBL_%s_%s", self$id, unique.id)
        result.tbl <-
          sprintf("#PAL_LOGISTICR_RESULT_TBL_%s_%s", self$id, unique.id)
        pmml.tbl <-
          sprintf("#PAL_LOGISTICR_PMMLMODEL_TBL_%s_%s", self$id, unique.id)
        stat.tbl <-
          sprintf("#PAL_STATISTIC_TBL_%s_%s", self$id, unique.id)
        pl.tbl <-
          sprintf("#PAL_PLACEHOLDER_TBL_%s_%s", self$id, unique.id)
        pmml.export.lower <- sapply(self$pmml.export, tolower)
        if (length(pmml.export.lower) == 0){
          pmml.export.lower <- NA#do not change NA to NULL
        }
        param.array <- list(
          tuple("METHOD",
                map.null(self$solver, solver.map),
                NULL, NULL),
          tuple("ENET_ALPHA", NULL, self$enet.alpha, NULL),
          tuple("ENET_LAMBDA", NULL, self$enet.lambda, NULL),
          tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
          tuple("PMML_EXPORT", pmml.map[[pmml.export.lower]], NULL, NULL),
          tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL),#nolint
          tuple("EXIT_THRESHOLD", NULL, self$tol, NULL),
          tuple("STANDARDIZE", to.integer(self$standardize),
                NULL, NULL),
          tuple("STAT_INF", to.integer(self$stat.inf),
                NULL, NULL),
          tuple("RESAMPLING_METHOD", NULL, NULL, self$resampling.method),
          tuple("PARAM_SEARCH_STRATEGY", NULL, NULL,
                self$param.search.strategy),
          tuple("FOLD_NUM", self$fold.num, NULL, NULL),
          tuple("REPEAT_TIMES", self$repeat.times, NULL, NULL),
          tuple("TIMEOUT", self$timeout, NULL, NULL),
          tuple("RANDOM_SEARCH_TIMES", self$random.search.times, NULL, NULL),
          tuple("SEED", self$random.state, NULL, NULL),
          tuple("PROGRESS_INDICATOR_ID", NULL, NULL,
                self$progress.indicator.id)
        )
        if (!is.null(self$evaluation.metric)){
          tup <- tuple("EVALUATION_METRIC", NULL, NULL,
                       toupper(self$evaluation.metric))
          param.array <- append(param.array, list(tup))
        }
        if (!is.null(self$categorical.variable)) {
          for (each in self$categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
            param.array <-
              append(param.array, list(temp.list))
          }
        }

        if (isTRUE(self$multi.class)) {
          proc.name <- "PAL_MULTICLASS_LOGISTIC_REGRESSION"
        } else {
          proc.name <- "PAL_LOGISTIC_REGRESSION"
          param.rest <- list(
            tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
            tuple("EPSILON", NULL, self$epsilon, NULL),
            tuple("MAX_PASS_NUMBER", self$max.pass.number, NULL, NULL),
            tuple("LBFGS_M", self$lbfgs.m, NULL, NULL),
            tuple("CLASS_MAP0", NULL, NULL, self$class.map0),
            tuple("CLASS_MAP1", NULL, NULL, self$class.map1),
            tuple("SGD_BATCH_NUMBER", self$sgd.batch.number,
                  NULL, NULL),
            tuple("PRECOMPUTE", to.integer(self$precompute),
                  NULL, NULL),
            tuple("HANDLE_MISSING", to.integer(self$handle.missing),
                  NULL, NULL))
          param.array <- append(param.array, param.rest)
        }
        if (length(self$parameter.values) > 0){
          for (i in 1:length(self$parameter.values)){
            param.name <- gsub("\\.", "_",
                               toupper(names(self$parameter.values[i])))
            str.values <- paste("{",
                                paste0(self$parameter.values[[i]],
                                       collapse = ","),
                                "}", sep = "")
            temp.tup <- tuple(paste0(param.name, "_VALUES"),
                              NULL, NULL, str.values)
            param.array <-
              append(param.array,  list(temp.tup))
          }
        }
        if (length(self$parameter.range) > 0){
          for (i in 1:length(self$parameter.range)){
            param.name <- gsub("\\.", "_",
                               toupper(names(self$parameter.range[i])))
            range.temp <- self$parameter.range[[i]]
            cps <- ifelse(length(range.temp) == 2, ",,", ",")
            str.range <- paste("[",
                               paste0(range.temp,
                                      collapse = cps),
                               "]", sep = "")
            temp.tup <- tuple(paste0(param.name, "_RANGE"),
                              NULL, NULL, str.range)
            param.array <-
              append(param.array, list(temp.tup))
          }
        }
        in.tables <- list(training.data, param.tbl)
        out.tables <- list(result.tbl, pmml.tbl, stat.tbl, pl.tbl)
        tables <- c(param.tbl, out.tables)

        tryCatch({
          errorhelper(CreateTWithConnection(conn,
                      ParameterTable$new(param.tbl)$WithData(param.array)))
          errorhelper(CallPalAutoWithConnection(conn,
                                                proc.name,
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })

        self$result.info <- conn$table(result.tbl)
        self$model <- self$result.info
        if (pmml.map[[sapply(self$pmml.export, tolower)]] > 0){
          self$pmml.info <- conn$table(pmml.tbl)
          self$model <- self$pmml.info
        }
        self$statistic.info <- conn$table(stat.tbl)
        self$optimal.param <- conn$table(pl.tbl)
        self$saved.model <- self$model
      }
    },
    predict = function(data,
                       key,
                       features = NULL,
                       verbose = FALSE,
                       thread.ratio = NULL,
                       multi.class = TRUE,
                       class.map0 = NULL,
                       class.map1 = NULL,
                       categorical.variable = NULL) {
      self$saved.model <- self$model

      if (length(self$saved.model) == 0 &&
          is.null(self$saved.model) == TRUE) {
        msg <- "Model not initialized. Please perform generate the model first."
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")) {
        msg <- "data must be given as a DataFrame"
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      conn <- data$connection.context

      verbose <- validateInput("verbose", verbose, "logical")
      thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
      multi.class <- validateInput("multi.class", multi.class,
                                   "logical")
      class.map0 <- validateInput("class.map0", class.map0,
                                  "character")
      class.map1 <- validateInput("class.map1", class.map1,
                                  "character")
      cols.left <- data$columns
      key <- validateInput("key", key, cols.left,
                           case.sensitive = TRUE)
      if (!is.null(key)){
        cols.left <- cols.left[! cols.left %in% key]
      }
      features <- validateInput("features", features, cols.left,
                                case.sensitive = TRUE)
      if (is.null(features))
        features <- cols.left
      features.id <- list()
      features.id <- append(key, features)
      input.df <-  data$Select(features.id)

      if (is.null(multi.class)) {
        multi.class <- self$multi.class
      }
      if (isTRUE(multi.class)) {
        proc.name <- "PAL_MULTICLASS_LOGISTIC_REGRESSION_PREDICT"
        param.array <-
          list(tuple("VERBOSE_OUTPUT", to.integer(verbose), NULL, NULL),
               tuple("THREAD_RATIO", NULL, thread.ratio, NULL))

      } else {
        proc.name <- "PAL_LOGISTIC_REGRESSION_PREDICT"
        param.array <- list(tuple("THREAD_RATIO", NULL, thread.ratio, NULL))
        categorical.variable <- validateInput("categorical.variable",
                                              categorical.variable,
                                              features,
                                              case.sensitive = TRUE)
        if (is.null(categorical.variable)){
          categorical.variable <- self$categorical.variable
        }
        if (!is.null(categorical.variable)) {
          for (each in categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
            param.array <-
              append(param.array, tuple(temp.list))
          }
        }
        if (is.null(c(class.map0, class.map1))) {
          class.map0 <- self$class.map0
          class.map1 <- self$class.map1
        }
        if (!is.null(c(class.map0, class.map1))) {
          temp2.list <- list(tuple("CLASS_MAP0", NULL, NULL, class.map0),
                             tuple("CLASS_MAP1", NULL, NULL, class.map1))
          param.array <- c(param.array, temp2.list)
        }
      }
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#LR_PREDICT_PARAM_TBL_%s_%s", self$id, unique.id)
      result.tbl <- sprintf("#LR_PREDICT_RESULT_TBL_%s_%s", self$id, unique.id)
      in.tables <- list(input.df, self$saved.model$name, param.tbl)
      out.tables <- list(result.tbl)
      tables <- c(param.tbl, out.tables)
      tryCatch({
        errorhelper(CreateTWithConnection(conn,
                    ParameterTable$new(param.tbl)$WithData(param.array)))
        errorhelper(CallPalAutoWithConnection(conn,
                                              proc.name,
                                              in.tables,
                                              out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn, tables)
        stop(msg)
      })
      return(conn$table(result.tbl))
    },
    score = function(data,
                     key,
                     features = NULL,
                     label = NULL,
                     multi.class = NULL,
                     class.map0 = NULL,
                     class.map1 = NULL,
                     categorical.variable = NULL) {

      if (!inherits(data, "DataFrame")) {
        msg <- "data must be given as a DataFrame"
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      conn <- data$connection.context

      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      class.map0 <- validateInput("class.map0", class.map0, "character")
      class.map1 <- validateInput("class.map1", class.map1, "character")
      if (is.null(c(class.map0, class.map1))) {
        class.map0 <- self$class.map0
        class.map1 <- self$class.map1
      }
      if (is.null(label))
        label <- cols[[length(cols)]]
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features)){
        features <- cols
      }
      categorical.variable <- validateInput("categorical.variable",
                                            categorical.variable,
                                            features,
                                            case.sensitive = TRUE)
      if (is.null(categorical.variable)) {
        categorical.variable <- self$categorical.variable
      }

      if (!isTRUE(multi.class)) {
        label.sql.type <- data$dtypes(list(label))[[1]][[2]]
        var1 <- startsWith(label.sql.type, "NVARCHAR")
        var2 <- startsWith(label.sql.type, "VARCHAR")
        if (isTRUE(var1)  || isTRUE(var2)) {
          if (length(c(class.map1, class.map0)) < 2) {
            msg <- "class.map0 and class.map1 are mandatory when label is of type NVARCHAR or VARCHAR"
            flog.error(msg)
            stop(msg)
          }
        }
      }
      l <- list(key, label)
      label.df <- data$Select(l)
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      predict.res <- self$predict(data=data,
                                  key=key,
                                  features=features,
                                  verbose=FALSE,
                                  thread.ratio=-1,
                                  multi.class=multi.class,
                                  class.map0=class.map0,
                                  class.map1=class.map1,
                                  categorical.variable=categorical.variable)

      tryCatch({
        val1 <- predict.res$select.statement
        val2 <- label.df$select.statement
        val3 <- QuoteName(data$columns[[1]])
        val4 <- QuoteName(label)
        res.sql <-
          sprintf(
            'SELECT COUNT(*) FROM (%s) res, (%s) ori WHERE res.%s = ori.%s AND ori.%s = res."CLASS";',
            val1,
            val2,
            val3,
            val3,
            val4
          )

        reslt1 <- ExecuteLogged(conn$connection, res.sql)
        Val.score <- reslt1[[1]] / data$nrows
        return(Val.score)
      },
      error = function(err) {
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        stop()
      })
    },
    errorMsg = function(type.name, type.map) {
      error.msg <-
        sprintf("Invalid %s, valid %ss include %s",
                type.name,
                type.name,
                paste(names(type.map), collapse = ", "))
      return(error.msg)
    }
  )
)

#' @title Logistic Regression
#' @name hanaml.LogisticRegression
#' @description hanaml.LogisticRegression is a R wrapper for
#'  SAP HANA PAL Logistic Regression.
#' @seealso \code{\link{predict.LogisticRegression}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @param enet.alpha \code{double, optional}\cr
#' Elastic net mixing parameter.
#' Only valid when \code{solver} is 'cyclical' or 'proximal'.\cr
#' Defaults to 1.0 .
#' @param enet.lambda \code{double, optional}\cr
#' Penalized weight.
#' Only valid when \code{solver} is 'cyclical' or 'proximal'.
#' @param tol \code{double, optional}\cr
#' Convergence threshold for exiting iterations.\cr
#' Defaults to 1.0e-7 when \code{solver} is 'cyclical',
#' otherwise it defaults to '1.0e-6'.
#' @param epsilon \code{double, optional}\cr
#' The parameter determines the accuracy with which the solution is to be found.
#' Defaults to 1.0e-6 when \code{solver} is 'newton', or '1.0e-5' when \code{solver} is 'lbfgs'.
#' @param solver \code{character, optional}\cr
#' Optimization algorithm. \cr
#' Possible values include:
#' \itemize{
#' \item{\code{'auto'}: Automatically determined from data and other parameters.}
#' \item{\code{'newton'}: Newton iteration method.}
#' \item{\code{'cyclical'} - Cyclical coordinate descent method to
#' fit elastic net regularized Logistic Regression.}
#' \item{\code{'lbfgs'} - LBFGS method. Recommended when having
#' many independent variables.}
#' \item{\code{'stochastic'} - Stochastic gradient descent method.
#' Recommended when dealing with very large dataset.}
#' \item{\code{'proximal'} - Proximal gradientdescent method to fit
#' elastic net regularized logistic regression.}
#' }
#' All values are available when \code{multi.class} is FALSE,
#' otherwise only 'lbfgs' and 'cyclical' are available.\cr
#' Defaults to 'auto' when \code{multi.class} is FALSE,
#' and 'lbfgs' when \code{multi.class} is TRUE.
#' @param max.iter \code{integer, optional}\cr
#' Maximum number of iterations taken for the solvers to converge.
#' If convergence is not reached after this number, an error will be generated.
#' For multi.class, the default value is 100.\cr
#' For binary.class, the default value is 100000 when \code{solver} is 'cyclical',
#' '1000' when \code{solver} is 'proximal', or otherwise is '100'.
#' @param   thread.ratio \code{double, optional}\cr
#' Specifies the ratio of total number of threads that can be used by this function.
#' The value range is from 0 to 1, where 0 indicates a single thread,
#' and 1 indicates all the currently available threads.
#' Values outside this range tell PAL to heuristically determine
#' the number of threads to use.
#' Only valid when multi.class is FALSE.
#' Defaults to 1.0 for Logistic regression.
#' @param   standardize \code{logical, optional}\cr
#' Controls whether to standardize the data to have zero mean and unit variance.\cr
#' FALSE - indicates no zero mean and unit variance.\cr
#' TRUE - standarize the data with zero mean and unit variance.\cr
#' Defaults to TRUE.
#' @param   max.pass.number \code{integer, optional}\cr
#' The maximum number of passes over the data.
#' Warning: only valid when solver is stochastic and multi.class is FALSE.
#' Defaults to 1. (Only valid when \code{solver} is 'stochastic')
#' @param lbfgs.m \code{integer}\cr
#' Number of past updates to be kept.
#' Only available when \code{solver} is 'lbfgs'.
#' Defaults to 6.
#' @param pmml.export \code{'no', 'single-row', 'multi-row'}\cr
#' Controls whether to output a PMML representation of the model and how to format
#' the PMML. \cr
#' For multi.class, valid options are:
#' \itemize{
#'     \item{\code{'no'} - No PMML model.}
#'     \item{\code{'multi-row'} - Exports a PMML model, splitting it
#'     across multiple rows if it doesn't fit in one.}}
#' For binary.class:
#' \itemize{
#'     \item{\code{'no'} - No PMML model.}
#'     \item{\code{'single'} - Exports a PMML model in a maximum of
#'                  one row. Fails if the model doesn't fit in one row.}
#'     \item{\code{'multi-row'} - Exports a PMML model, splitting it
#'     across multiple rows if it doesn't fit in one.}}
#' Defaults to 'no'.
#' @param stat.inf \code{logical, optional}\cr
#' Indicates whether or not to a calculate stastical inferences
#' from the given data.
#' \itemize{
#'     \item{\code{FALSE} - Does not calculate statistical inference.}
#'     \item{\code{TRUE} - Calculates statistical inference.}
#' }
#' Defaults to FALSE.
#' @template args-cate-var
#' @param class.map0 \code{character, optional}\cr
#' Categorical label to map to 0.
#' Only valid when \code{multi.class} is 'FALSE'.
#' class.map0 is mandatory when label column type is VARCHAR or
#' NVARCHAR during binary class fit and score.
#' @param class.map1 \code{character, optional}\cr
#' Categorical label to map to 1.
#' Only valid when \code{multi.class} is 'FALSE'.
#' class.map1 is mandatory when label column type is VARCHAR or
#' NVARCHAR during binary class fit and score.
#' @param   multi.class \code{logical, optional}\cr
#' If set to TRUE, a multi-class classification is performed.
#' Otherwise, there must be only two classes.\cr
#' Defaults to FALSE.
#' @param sgd.batch.number \code{integer, optional}\cr
#' The batch number of stochastic gradient method.
#' Valid only when \code{multi.class} is FALSE and \code{method} is 'stochastic'.
#' Defaults to 1.
#' @param precompute \code{logical, optional}\cr
#' Whether or not to precompute the Gram matrix for cyclical coordinate descent method.
#' Valid only when \code{method} is 'cyclical'.
#' Defaults to TRUE.
#' @param handle.missing \code{logical, optional}\cr
#' Whether or not to impute the missing values of the input training data.
#' Defaults to TRUE.
#' @param  resampling.method   \code{character, optional}\cr
#' Specifies the resampling values form below list.\cr
#' valid options are listed as follows:\cr
#' "cv", "stratified_cv", "bootstrap", "stratified_bootstrap".\cr
#' If no value is specifier, neither model evaluation
#' nor parameter selection is activated.
#' @param  evaluation.metric   \code{character, optional}\cr
#' Specifies the evaluation metric for model evaluation or parameter selection.\cr
#' Currently valid options are: "accuracy", "f1_score", "auc", "nll".
#' @param  fold.num \code{integer, optional}\cr
#' Specifies the fold number for the cross-validation(cv).
#' Mandatory and valid only when \code{resampling.method} is 'cv' or 'stratified_cv'.
#' @template args-crossvalidation-group
#' @param parameter.range   \code{list, optional}\cr
#' Specifies range of the following parameters for parameter selection:\cr
#' \code{enet.lambda, enet.alpha}.\cr
#' Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#' Examples:\cr
#' parameter.range <- list(enet.lambda = c(0.01, 0.01, 0.1)), which means taking
#' \code{enet.lambda} values from 0.01 to 0.1 with 0.01 being the step size, i.e.
#' 0.01, 0.02, 0.03, ..., 0.09, 0.1.\cr
#' If \code{param.search.strategy} is 'random', then the middle term,
#' i.e. step has no effect and thus can be omitted.
#' @param parameter.values   \code{list, optional}\cr
#' Specifies values of the following parameters for parameter selection:\cr
#' \code{enet.lambda, enet.alpha}.\cr
#' Example: parameter.values <- list(enet.lambda = c(0.001, 0.003, 0.007, 0.01))
#' @return
#' A "LogisticRegression" object with the following attributes:
#' \itemize{
#' \item{result: \code{DataFrame}}\cr
#' Coefficient values for logisitic regression model(together with z-scores and p-values).
#' \item{pmml: \code{DataFrame}}\cr
#' LogisticRegression model in PMML format.
#' \item{statistic.info: \code{DataFrame}}\cr
#' Related statistics for the logistic regression model and its solving process, including
#' AIC, objective-value, log-likelihood, number of iterations used, solution status, etc.
#' \item{optimal.param: \code{DataFrame}}\cr
#' Optimal model parameters selected. Reserved for model selection using cross-validation.
#' }
#' @section Examples:
#' Call the function:
#' \preformatted{
#' > lr <- hanaml.LogisticRegression(data = df1)
#' OR
#' > lr <- hanaml.LogisticRegression(data = df1,
#'                                   formula = CATEGORY~V1+V2+V3,
#'                                   solver='newton',thread.ratio=0.1, max.iter=1000,
#'                                   categorical.variable='V3', pmml.export='single-row',
#'                                   stat.inf=TRUE, tol=0.000001)
#' }
#'
#' @keywords Classification
#' @export
hanaml.LogisticRegression <- function(data = NULL,
                                      key = NULL,
                                      features = NULL,
                                      label = NULL,
                                      formula = NULL,
                                      enet.alpha = NULL,
                                      enet.lambda = NULL,
                                      tol = NULL,
                                      epsilon = NULL,
                                      solver = NULL,
                                      max.iter = NULL,
                                      thread.ratio = NULL,
                                      standardize = NULL,
                                      max.pass.number = NULL,
                                      lbfgs.m = NULL,
                                      pmml.export = NULL,
                                      stat.inf = NULL,
                                      categorical.variable = NULL,
                                      class.map0 = NULL,
                                      class.map1 = NULL,
                                      multi.class = FALSE,
                                      sgd.batch.number = NULL,
                                      precompute = NULL,
                                      handle.missing = NULL,
                                      resampling.method = NULL,
                                      evaluation.metric = NULL,
                                      fold.num = NULL,
                                      repeat.times = NULL,
                                      param.search.strategy = NULL,
                                      random.search.times = NULL,
                                      random.state = NULL,
                                      timeout = NULL,
                                      progress.indicator.id = NULL,
                                      parameter.range = NULL,
                                      parameter.values = NULL) {
  LogisticRegression$new(data, key, features, label,
                         formula, enet.alpha, enet.lambda, tol,
                         epsilon, solver, max.iter,
                         thread.ratio, standardize,
                         max.pass.number, lbfgs.m,
                         pmml.export, stat.inf,
                         categorical.variable,
                         class.map0, class.map1,
                         multi.class, sgd.batch.number,
                         precompute, handle.missing,
                         resampling.method,
                         evaluation.metric,
                         fold.num, repeat.times,
                         param.search.strategy,
                         random.search.times,
                         random.state,
                         timeout, progress.indicator.id,
                         parameter.range,
                         parameter.values)
}


#' @title Make Predictions from a "LogisticRegression" Object
#' @name predict.LogisticRegression
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "LogisticRegression" object.
#' @seealso \code{\link{hanaml.LogisticRegression}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A "LogisticRegression" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-verbose
#' @template args-threadratio
#' @param multi.class \code{logical, optional}\cr
#' If the value is TRUE, prediction for multi-class classification is performed.\cr
#' Otherwise prediction for binary classification is performed.\cr
#' Defaults to \code{model$multi.class}.
#' @param class.map0 \code{character, optional}\cr
#' Categorical label to map to 0.\cr
#' Only valid when \code{multi.class} or \code{model$multi.class} is FALSE.
#' class.map0 is mandatory when label column type is VARCHAR or
#' NVARCHAR during binary class fit and score.\cr
#' Defaults to \code{model$class.map0}.
#' @param class.map1 \code{character, optional}\cr
#' Categorical label to map to 1.\cr
#' Only valid when \code{multi.class} or \code{model$multi.class} is FALSE.
#' class.map1 is mandatory when label column type is VARCHAR or
#' NVARCHAR during binary class fit and score.\cr
#' Defaults to \code{model$class.map1}.
#' @template args-cate-var
#' @return
#' Returns a \code{Dataframe}\cr containing predicted values, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as `data`'s ID column.}
#'   \item{CLASS, type NVARCHAR, predicted class name.}
#'   \item{PROBABILITY, type DOUBLE.}
#' }
#'@note{ predict() will pass the \emph{pmml} table to PAL as the model
#'   representation if there is a \emph{pmml} table, or the \code{coefficients}
#'   table otherwise.}
#' @section Examples:
#' lr is a "LogisticRegression" object.\cr
#' Call the function:
#' \preformatted{
#' > predict(lr, data2, key = 'ID', features = list('V1', 'V2', 'V3'))
#' }
#' @keywords Classification
#' @export
predict.LogisticRegression <- function(model,
                                       key,
                                       data,
                                       features = NULL,
                                       verbose = FALSE,
                                       thread.ratio = NULL,
                                       multi.class = NULL,
                                       class.map0 = NULL,
                                       class.map1 = NULL,
                                       categorical.variable = NULL){
    features <- validateInput("features", features, "ListOfStrings")
    verbose <- validateInput("verbose", verbose, "logical")
    model$predict(data = data,
                  key = key,
                  features = features,
                  verbose = verbose,
                  thread.ratio = thread.ratio,
                  multi.class = multi.class,
                  class.map0 = class.map0,
                  class.map1 = class.map1,
                  categorical.variable = categorical.variable)
  }

#' @export
summary.LogisticRegression <- function(object, ...) {
  writeLines("Model Attributes for Logistic regression: Results and statistics ")
  cat("\n")
  writeLines("RESULT:")
  print(object$saved.model)
  cat("\n")
  writeLines("STATISTICS:")
  print(object$statistic.info)
  cat("\n")
  writeLines("GENERAL SUMMARY OF THE MODEL:")
  print(object$saved.model$.__enclos_env__$private$describeSummary())

}

#' @export
print.LogisticRegression <- function(x, ...) {

  solver.statm <- list(newton = "Newton iteration method.",
                       cyclical = paste("Cyclical coordinate",
                                        "descent method to fit",
                                        "elastic net regularized",
                                        "logistic regression."),
                       lbfgs = "LBFGS method.",
                       stochastic = "Stochastic gradient descent method.",
                       proximal = paste("Proximal gradient descent",
                                        "method to fit elastic net",
                                        "regularized logistic regression"))
  solver_text <- solver.statm[[ifelse(is.null(x$solver), NA, x$solver)]]
  solver_text2 <-
    sprintf("Method used is         : %s", solver_text)
  tr <- sprintf("Thread ratio is        : %s", to.null(x$thread.ratio))
  mp <- sprintf("MAX_PASS_NUMBER is     : %s", to.null(x$max.pass.number))
  lam <- sprintf("ENET_LAMBDA is         : %s", to.null(x$enet.lambda))
  alp <- sprintf("ENET_ALPHA is          : %s", to.null(x$enet.alpha))
  iter <- sprintf("MAX_ITERATION is       : %s", to.null(x$max.iter))
  stnd <- sprintf("STANDARDIZE is         : %s", to.null(x$standardize))
  pm_exp <- sprintf("PMML_EXPORT is         : %s", to.null(x$pmml.export))
  stat_i <- sprintf("STAT_INF is            : %s", to.null(x$stat.inf))
  cvar <-
    sprintf("CATEGORICAL VARIABLE is: %s", to.null(x$categorical.variable))
  lbfgs <-
    sprintf("LBFGS_M (no.of past updates) is: %s", to.null(x$lbfgs.m))
  writeLines("Logistic Regression (with Elastic Net Regularization)")
  cat("\n")
  writeLines("Model result is:")
  print(x$saved.model)
  cat("\n")
  writeLines("Optional parameters used for this model:")
  writeLines("(NULL indicates none provided by user and internal defaults are used)")
  cat("\n")
  writeLines(solver_text2)
  writeLines(tr)
  writeLines(mp)
  writeLines(lam)
  writeLines(alp)
  writeLines(iter)
  writeLines(stnd)
  writeLines(pm_exp)
  writeLines(stat_i)
  writeLines(cvar)
  writeLines(lbfgs)
}
