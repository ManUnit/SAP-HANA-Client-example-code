#Wrap up two popular algorithms for social network analysis in PAL library: link prediction and pagerank.
#' @title Link Prediction
#' @name hanaml.LinkPredict
#' @description hanaml.LinkPredict is an R wrapper
#'  for SAP HANA PAL link prediction algorithm.
#' @details Predicting potential missing links between different nodes is
#'         a common task in social network analysis. Link prediction
#'         algorithms compute the distance of any two nodes using existing
#'         links in a social network, and make prediction on the missing links
#'         based on these distances..
#' @param     data \code{DataFrame}\cr
#'            DataFrame containing links among all nodes in a social network.
#' @param     used.cols \code{list of character, optional}\cr
#'            This parameter specifies the two columns for the two node information
#'            of all those links in \code{data}. In the settings here,
#'            one node is named "node1", and another node named "node2".
#'            Defaults to the 1st and 2nd column of \code{data} if not provided.
#' @param     method \code{("common.neighbors", "jaccard", "adamic.adar", "katz")}\cr
#'            Method for predicting potential missings links between nodes.
#' @param     katz.beta \code{double, optional}\cr
#'            The beta parameter for the 'katz' method.
#'            The value should be between 0 and 1.
#'            Values closer to 0 are ususally prefered.\cr
#'            Only valid when \emph{method} is "katz".\cr
#'            Defaults to 0.005.
#' @param     min.score \code{double, optional}\cr
#'            Links prediction algorithms compute scores for all pair of nodes with missing links.
#'            A link is assumed to exist only if the computed score is above `min.score`, and
#'            the links whose scores are lower than this threshold will be filtered out from
#'            the result table.\cr
#'            Defaults to 0.
#' @return
#'   \itemize{
#'   \item{\code{DataFrame}}\cr
#'    The data frame that contains the computed scores of all missing links in a network.
#'   }
#' @section Examples:
#' Social networks data that contain existing links between nodes:\cr
#' \preformatted{
#' > data$Collect()
#'    NODE1 NODE2
#' 1      1     2
#' 2      1     4
#' 3      2     3
#' 4      3     4
#' 5      5     1
#' 6      6     2
#' 7      7     4
#' 8      7     5
#' 9      6     7
#' 10     5     4
#' }
#' Creating a LinkPredict instance for predicting potential missing links between all nodes:\cr
#' \preformatted{
#' > lp <- hanaml.LinkPredict(data = data,
#'                            used.cols = c(node1 = "NODE1", node2 = "NODE2"),
#'                            method = "common.neighbors")
#' }
#' Output:
#' \preformatted{
#' > lp$result
#'    NODE1 NODE2     SCORE
#' 1      1     3 0.2857143
#' 2      1     6 0.1428571
#' 3      1     7 0.2857143
#' 4      2     4 0.2857143
#' 5      2     5 0.1428571
#' 6      2     7 0.1428571
#' 7      4     6 0.1428571
#' 8      3     5 0.1428571
#' 9      3     6 0.1428571
#' 10     3     7 0.1428571
#' 11     5     6 0.1428571
#'}
#' @keywords Social Network
#' @export
hanaml.LinkPredict <- function(data,
                               used.cols = NULL,
                               method,
                               katz.beta = NULL,
                               min.score = NULL){
  method.map <- list(common.neighbors = 1,
                     jaccard = 2,
                     adamic.adar = 3,
                     katz = 4)
  col.names <- list("node1", "node2")
  katz.beta <- validateInput("katz.beta", katz.beta, "numeric")
  if (!is.null(katz.beta)){
    if (katz.beta < 0 || katz.beta > 1){
      msg <- paste("The value of beta for katz method",
                   "should be between 0 and 1.")
      flog.error(msg)
      stop(msg)
    }
  }
  min.score <- validateInput("min.score", min.score, "numeric")
  method <- validateInput("method",
                          method,
                          method.map,
                          required = TRUE)
  if (!is.null(katz.beta)){
    if (!is.null(method) && method != "katz"){
      msg <- paste("Value of `katz.beta` has no effect since",
                   "it is valid only when `method` is 'katz'.")
      flog.warn(msg)
    }
  }
  cols <- data$columns
  if (length(cols) < 2){
    msg <- "Input data should contain at least 2 columns."
    flog.error(msg)
    stop(msg)
  }
  if (!is.null(used.cols)){
    used.cols <- as.list(used.cols)
    if (length(used.cols) != 2){
      msg <- paste("Exactly two columns need be specified,",
                   "which correspond to",
                   "two nodes of each link.")
      flog.error(msg)
      stop(msg)
    }
    if (!is.null(names(used.cols))){
      validateInput("Used columns",
                    names(used.cols),
                    col.names)
    } else {
      names(used.cols) <- col.names
    }
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "If training data is not omitted, it must be DataFrame."
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)
  if (!is.null(used.cols)){
    data <- data$Select(list(used.cols[["node1"]],
                             used.cols[["node2"]]))
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#LINKPRED_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#LINKPRED_RESULT_TBL_%s", unique.id)
  param.rows <- list(
    tuple("METHOD", map.null(method, method.map), NULL, NULL),
    tuple("BETA", NULL, katz.beta, NULL),
    tuple("MIN_SCORE", NULL, min.score, NULL)
  )
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables <- list(param.tbl, result.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
               ParameterTable$new(param.tbl)$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_LINK_PREDICT",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(result.tbl))
}

#' @title Page Rank
#' @name hanaml.PageRank
#' @description hanaml.PageRank is an R wrapper for SAP HANA PAL page rank algorithm.
#' @details PageRank is an algorithm used by a search engine to measure
#' the importance of website pages. A website page is considered more
#' important if it receives more links from other websites. PageRank
#' represents the likelihood that a visitor will visit a particular page
#' by randomly clicking of other webpages. Higher rank in PageRank means
#' greater probability of the site being reached.
#' @param     data \code{DataFrame}\cr
#'            DataFrame containing links among all nodes in a social network.
#' @param     used.cols \code{list of characters, optional}\cr
#'            This parameter specifies the two columns for source and
#'            sink nodes of all those links in \code{data}. In the settings here,
#'            source node named "source" and sink node named "sink".
#'            Defaults to the 1st and 2nd column of \code{data} if not provided.
#' @param     damping \code{double, optional}\cr
#'            The damping factor for PageRank scores.\cr
#'            Defautls to 0.85.
#' @param     max.iter \code{integer, optional}\cr
#'            The maximum number of iterations of power method for solving
#'            the PageRank problem.\cr
#'            The value 0 means no maximum number of iterations is set,
#'            and the calculation stops when the result converges.\cr
#'            Defaults to 0.
#' @param     tol \code{double, optional}\cr
#'            The stopping criterion for power method.
#'            When the mean improvement value of ranks is less than this value,
#'            the program stops calculation.\cr
#'            Defaults to 1e-6.
#' @return
#'   \itemize{
#'   \item{\code{DataFrame}}\cr
#'    The data frame that contains the ranking scores of all nodes in a network.
#'   }
#' @section Examples:
#' Social networks data that contain existing links between nodes:
#' \preformatted{
#' > data$Collect()
#'   FROM_NODE TO_NODE
#' 1     Node1   Node2
#' 2     Node1   Node3
#' 3     Node1   Node4
#' 4     Node2   Node3
#' 5     Node2   Node4
#' 6     Node3   Node1
#' 7     Node4   Node1
#' 8     Node4   Node3
#' }
#' Call the function for calculating the ranking scores of all nodes in the network:
#' \preformatted{
#' > result <- hanaml.PageRank(data = data,
#'                             used.cols = c(source = "FROM_NODE", sink = "TO_NODE"),
#'                             damping = 0.85)
#'
#' }
#' Output:
#' \preformatted{
#' > result$Collect()
#'    NODE      RANK
#' 1 Node1 0.3681516
#' 2 Node2 0.1418082
#' 3 Node3 0.2879621
#' 4 Node4 0.2020780
#' }
#' @keywords Social Network
#' @export
hanaml.PageRank <- function(data,
                            used.cols = NULL,
                            damping = NULL,
                            max.iter = NULL,
                            tol = NULL){
  col.names <- list("source", "sink")
  damping <- validateInput("damping", damping, "numeric")
  tol <- validateInput("tol", tol, "numeric")
  max.iter <- validateInput("max.iter", max.iter, "integer")
  cols <- data$columns
  if (length(cols) < 2){
    msg <- "Input data should contain at least 2 columns."
    flog.error(msg)
    stop(msg)
  }
  if (!is.null(used.cols)){
    used.cols <- as.list(used.cols)
    if (length(used.cols) != 2){
      msg <- paste("Exactly two columns need be specified:",
                   "one for source and another for sink.")
      flog.error(msg)
      stop(msg)
    }
    if (!is.null(names(used.cols))){
      validateInput("Used columns",
                    names(used.cols),
                    col.names)
    } else {
      names(used.cols) <- col.names
    }
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "If training data is not omitted, it must be DataFrame."
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)

  if (!is.null(used.cols)){
    data <- data$Select(list(used.cols[["source"]],
                             used.cols[["sink"]]))
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAGERANK_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAGERANK_RESULT_TBL_%s", unique.id)
  param.rows <- list(
    tuple("DAMPING", NULL, damping, NULL),
    tuple("MAX_ITERATION", max.iter, NULL, NULL),
    tuple("THRESHOLD", NULL, tol, NULL)
  )
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables <- list(param.tbl, result.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                ParameterTable$new(param.tbl)$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_PAGERANK",
                                          in.tables,
                                          out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(result.tbl))
}
