GeometricRegression <- R6Class(
  "GeometricRegression",
  inherit = RegressionBase,
  public = list(
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          decomposition = NULL,
                          adjusted.r2 = NULL,
                          pmml.export = NULL){
      super$initialize(data,
                       key,
                       features,
                       label,
                       formula,
                       NULL,
                       decomposition,
                       adjusted.r2,
                       pmml.export,
                       "PAL_GEOMETRIC_REGRESSION")
    }))

#' @title  Bi-variate Geometric Regression
#' @name hanaml.GeometricRegression
#' @description hanaml.GeometricRegression is a R wrapper
#'  for SAP HANA PAL Bi-variate GeometricRegression algorithm.
#' @details Geometric regression is an approach used to model the relationship between
#'  a scalar variable y and a variable denoted X. In geometric regression,
#'  data is modeled using geometric functions, and unknown model parameters
#'  are estimated from the data. Such models are called geometric models.
#' @seealso \code{\link{predict.GeometricRegression}}
#' @template args-data
#' @template args-key
#' @template args-feature-one
#' @template args-label
#' @template args-formula
#' @template args-decompostion
#' @template args-adjustedr2
#' @template args-pmmlexport
#' @return
#' Returns a "GeometricRegression" object with following values:
#' \itemize{
#' \item{coefficients: \code{DataFrame}}\cr
#'       Fitted regression coefficients.
#' \item{pmml: \code{DataFrame}}\cr
#'       Regression model content in PMML format.
#'       Set to NULL if no PMML model was requested.
#' \item{model : \code{DataFrame}}\cr
#'     Model is used to save coefficients or PMML model. If PMML model is requested,
#'     model defaults to PMML model. Otherwise, it is coefficients.
#' \item{fitted: \code{DataFrame}}\cr
#'       Predicted dependent variable values for training data.
#'       Set to NULL if the training data has no row IDs.
#' \item{statistics: \code{DataFrame}}\cr
#'      Regression-related statistics, like mean square error, F-statistics, etc.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#'  > data$Collect()
#'     ID     Y X1
#'  1   0   1.1  1
#'  2   1   4.2  2
#'  3   2   8.9  3
#'  4   3  16.3  4
#'  5   4  24.0  5
#'  6   5  36.0  6
#'  7   6  48.0  7
#'  8   7  64.0  8
#'  9   8  80.0  9
#'  10  9 101.0 10
#'  }
#'  Call the function:
#' \preformatted{
#'  > gr <- hanaml.GeometricRegression(data = data, key = 'ID', label = 'Y',
#'                                     pmml.export='multi-row')
#' }
#' Output:
#' \preformatted{
#' > gr$coefficients
#'       VARIABLE_NAME COEFFICIENT_VALUE
#' 1 __PAL_INTERCEPT__          1.072219
#' 2                X1          1.959633
#'
#' }
#' @keywords Regression
#' @export
hanaml.GeometricRegression <- function(data = NULL,
                                       key = NULL,
                                       features = NULL,
                                       label = NULL,
                                       formula = NULL,
                                       decomposition = NULL,
                                       adjusted.r2 = NULL,
                                       pmml.export = NULL){
  GeometricRegression$new(data,
                          key,
                          features,
                          label,
                          formula,
                          decomposition,
                          adjusted.r2,
                          pmml.export)
}


#' @title Make Predictions from a "GeometricRegression" Object
#' @name predict.GeometricRegression
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "GeometricRegression" object.
#' @seealso \code{\link{hanaml.GeometricRegression}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A "GeometricRegression" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict-1
#' @template args-threadratio
#' @template args-modelformat
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'    \item{ID: with same name and type as \emph{data}'s ID column.}
#'    \item{VALUE: type DOUBLE, representing predicted values.}
#' }
#'
#' @section Examples:
#'  DataFrame data2 for prediction:
#' \preformatted{
#'  > data2$Collect()
#'    ID X1
#'  1  0  1
#'  2  1  2
#'  3  2  3
#'  4  3  4
#'  5  4  5
#' }
#'  Fitted values of the prediction data using model gr:
#' \preformatted{
#'  > predict(model = gr, data = data2, key = "ID")
#'    ID     VALUE
#'  1  0  1.072219
#'  2  1  4.170538
#'  3  2  9.231373
#'  4  3 16.221851
#'  5  4 25.119354
#' }
#' @keywords Regression
#' @export
predict.GeometricRegression <- function(model,
                                        data,
                                        key,
                                        features = NULL,
                                        thread.ratio = NULL,
                                        model.format = NULL){
  model$predict(data,
                key,
                features,
                thread.ratio,
                model.format,
                "PAL_GEOMETRIC_REGRESSION_PREDICT")
}

#' @export
print.GeometricRegression <- function(x, ...){
  writeLines("\n")
  writeLines("GeometricRegression attributes:")
  writeLines("\n")
  cat(sprintf("decomposition : %s", to.null(x$decomposition)))
  writeLines("\n")
  cat(sprintf("adjusted.r2 : %s", to.null(x$adjusted.r2)))
  writeLines("\n")
  cat(sprintf("pmml.export : %s", to.null(x$poly.pmml.export)))
  writeLines("\n")
}

#' @export
summary.GeometricRegression <- function(object, ...){
    writeLines("GeometricRegression coefficients DataFrame:")
    print(object$coefficients$Collect())
    writeLines("\n")
    writeLines("GeometricRegression fitted DataFrame:")
    print(object$fitted$Collect())
    writeLines("\n")
    writeLines("GeometricRegression model DataFrame:")
    print(object$model$Collect())
    writeLines("\n")
    writeLines("GeometricRegression statistics DataFrame:")
    print(object$statistics$Collect())
    writeLines("\n")
    writeLines("GeometricRegression pmml DataFrame:")
    print(object$pmml$Collect())
    writeLines("\n")
}
