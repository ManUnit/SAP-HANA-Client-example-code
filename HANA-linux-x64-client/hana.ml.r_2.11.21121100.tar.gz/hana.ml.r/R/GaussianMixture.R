GaussianMixture <- R6Class(
  "GaussianMixture",
  inherit = ClusterAssignmentBase,
  public = list(
    init.param = NULL,
    n.components = NULL,
    init.centers = NULL,
    covariance.type = NULL,
    shared.covariance = NULL,
    thread.ratio = NULL,
    max.iter = NULL,
    categorical.variable = NULL,
    category.weight = NULL,
    error.tol = NULL,
    regularization = NULL,
    random.seed = NULL,
    labels = NULL,
    model = NULL,
    stats = NULL,
    init.param.map = list("farthest.first.traversal" = 0,
                          "manual" = 1,
                          "random.means" = 2,
                          "k.means++" = 3),
    covariance.type.map = list("full" = 0,
                               "diag" = 1,
                               "tied.diag" = 2),
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          n.components = NULL,
                          init.param = NULL,
                          init.centers = NULL,
                          covariance.type = NULL,
                          shared.covariance = NULL,
                          thread.ratio = NULL,
                          max.iter = NULL,
                          category.weight = NULL,
                          categorical.variable = NULL,
                          error.tol = NULL,
                          regularization = NULL,
                          random.seed = NULL){
      super$initialize()
      if (!is.null(data)){
        self$init.param <-
          validateInput("init.param", init.param, self$init.param.map, required = TRUE)
        self$n.components <- validateInput("n.components", n.components, "integer",
                                           required = !grepl("manu", self$init.param))
        self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        self$category.weight <-
          validateInput("category.weights", category.weight, "double")
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   data$columns,
                                                   case.sensitive = TRUE)
        self$error.tol <- validateInput("error.tol", error.tol, "double")
        self$regularization <- validateInput("regularization", regularization, "double")
        self$random.seed <- validateInput("random.seed", random.seed, "integer")
        cols <- data$columns
        key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        if (is.null(features)){
          features <- cols
        }
        id.type <- data$dtypes(key)[[1]][[2]]
        type.str <- ifelse(grepl("INT", id.type), "integer", "character")
        self$init.centers <- validateInput("init.centers", unlist(init.centers), type.str,
                                           required = grepl("manu", self$init.param))
        self$covariance.type <-
          validateInput("covariance.type", covariance.type, self$covariance.type.map)
        self$shared.covariance <-
          validateInput("shared.covariance", shared.covariance, "logical")
        if (!inherits(data, "DataFrame")) {
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        index.name <- key
        index.type <- data$dtypes(key)[[1]][[2]]
        if (grepl("CHAR", index.type)){
          index.type <- paste0(index.type, "(", data$dtypes(key)[[1]][[3]], ")")
        }
        index.type <- ifelse(grepl("manu", self$init.param),
                             index.type,
                             "INTEGER")

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        init.tbl <- sprintf("#PAL_GMM_INIT_TBL_%s_%s", self$id, unique.id)
        init.data <- private$prep.init.Param()
        param.tbl <-  sprintf("#PAL_GMM_PARAM_TBL_%s_%s", self$id, unique.id)
        param.data <- private$prepParam()
        result.tbl <- sprintf("#PAL_GMM_RES_TBL_%s_%s", self$id, unique.id)
        model.tbl <- sprintf("#PAL_GMM_MODEL_TBL_%s_%s", self$id, unique.id)
        stats.tbl <- sprintf("#PAL_GMM_STAT_TBL_%s_%s", self$id, unique.id)
        placeholder.tbl <- sprintf("#PAL_GMM_PLACEHOLDER_TBL_%s_%s", self$id, unique.id)

        selected <- append(key, features)
        data <- data$Select(selected)
        tables <- list(init.tbl, param.tbl, result.tbl,
                       model.tbl, stats.tbl, placeholder.tbl)
        in.tables <- list(data, init.tbl, param.tbl)
        out.tables <-  list(result.tbl,  model.tbl, stats.tbl, placeholder.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            Table$new(init.tbl,
              list(tuple("ID", "INTEGER"),
                   tuple("CLUSTER_NUMBER",
                         index.type)))$WithData(init.data)))
          errorhelper(CreateTWithConnection(conn.context,
            (ParameterTable$new(param.tbl))$WithData(param.data))) #nolint
          errorhelper(CallPalAutoWithConnection(conn.context,
            "PAL_GMM", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$labels <- conn.context$table(result.tbl)
        self$model <- conn.context$table(model.tbl)
        self$stats <- conn.context$table(stats.tbl)
      }
    }),
  private = list(
    prep.init.Param = function(){
      init.param.data <- list()
      if (!grepl("manu", self$init.param)){
        init.param.data <- list(tuple(map.null(self$init.param,
                                               self$init.param.map),
                                      self$n.components))
      } else {
        for (i in 1:length(self$init.centers)){
          init.param.data <- append(init.param.data,
                                    list(tuple(i - 1,
                                               self$init.centers[i])))
        }
      }
      return (init.param.data)
    },
    prepParam = function() {
      param.array <- list(
        tuple("SHARED_COVARIANCE", to.integer(self$shared.covariance), NULL, NULL),
        tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
        tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
        tuple("CATEGORY_WEIGHT", NULL, self$category.weight, NULL),
        tuple("ERROR_TOL", NULL, self$error.tol, NULL),
        tuple("REGULARIZATION", NULL, self$regularization, NULL),
        tuple("SEED", self$random.seed, NULL, NULL),
        tuple("INIT_MODE", map.null(self$init.param, self$init.param.map), NULL, NULL),
        tuple("COVARIANCE_TYPE", map.null(self$covariance.type, self$covariance.type.map), NULL, NULL)
      )

      if (!is.null(self$categorical.variable)) {
        for (each in self$categorical.variable) {
          temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
          param.array <- append(param.array, tuple(temp.list))
        }
      }
      return (param.array)
    }
  )
)

#' @title Gaussian Mixture Model (GMM)
#' @name hanaml.GaussianMixture
#' @description hanaml.GaussianMixture is a R wrapper for
#'  SAP HANA PAL Gaussian Mixture Model (GMM).
#' @seealso \code{\link{predict.GaussianMixture}}
#' @template args-data
#' @template args-key
#' @template args-feature-clustering
#' @param n.components \code{integer, optional}\cr
#' Number of groups.\cr
#' Mandatory when \emph{init.param} is not 'manual'.
#' @param init.param \code{character}\cr
#' Specifies the initialization mode:
#'  \itemize{
#'  \item{\code{'farthest.first.traversal'}:   The initial centers are given by
#'        the farthest-first traversal algorithm.}
#'  \item{\code{'manual'}:   The initial centers are the init.centers given by user.}
#'  \item{\code{'random.means'}:   The initial centers are the means of all the data
#'        that are randomly weighted.}
#'  \item{\code{'k.means++'}: The initial centers are given using the k-means++ approach.}
#'  }
#' @param init.centers \code{vector of integers/characters, optional}\cr
#' Specifies the rows of data to be used as initial centers by providing their values in the ID column.\cr
#' For example, we want to specify rows with ID 1, 5, and 9 as centers, please input init.centers = c(1, 5, 9)\cr
#' Mandatory when \emph{init.param} is 'manual'.
#' @param covariance.type \code{character, optional}\cr
#' Specifies the type of covariance matrices in the model:
#'  \itemize{
#'  \item{\code{'full'}:   use full covariance matrices.}
#'  \item{\code{'diag'}:   use diagonal covariance matrices.}
#'  \item{\code{'tied.diag'}: use diagonal covariance matrices with all equal
#'                          diagonal entries.}
#'  }
#'  Defaults to 'full'.
#' @param shared.covariance \code{logical, optional}\cr
#' All clusters share the same covariance matrix if TRUE.\cr
#' Defaults to FALSE.
#' @template args-threadratio
#' @param max.iter \code{integer, optional}\cr
#' Specifies the maximum number of iterations for the EM algorithm.\cr
#' Defaults to 100.
#' @param category.weight \code{double, optional}\cr
#' Represents the weight of category attributes.\cr
#' Defaults to 0.707.
#' @template args-cate-var
#' @param error.tol \code{double, optional}\cr
#' Convergence threshold for exiting iterations.\cr
#' Defaults to 1.e-5.
#' @param regularization \code{float, optional}\cr
#' Regularization to be added to the diagonal of covariance matrices to ensure positive-definite.\cr
#' Defaults to 1e-6.
#' @param random.seed  \code{integer, optional}\cr
#' Indicates the seed used to initialize the random number generator:
#' \itemize{
#'  \item{\code{0}: Uses the system time.}
#'  \item{\code{Not 0}: The initial centers are the init.centers given by user.}
#'  }
#' Defaults to 0.
#'
#' @return
#' Returns a "GaussianMixture" object with following values:
#' \itemize{
#'   \item{labels : \code{DataFrame}}\cr
#'    Label assigned to each sample.
#'  \item{model : \code{DataFrame}}\cr
#'    Model content.
#'  \item{stats : \code{DataFrame}}\cr
#'    Statistic value.
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#' ID  X1   X2   X3
#' 0  0.10  0.10  1
#' 1  0.11  0.10  1
#' 2  0.10  0.11  1
#' 3  0.11  0.11  1
#' 4  0.12  0.11  1
#' }
#'
#' Call the function:
#' \preformatted{
#' > gmm <- hanaml.GaussianMixture(data = data,
#'                                 key = "ID",
#'                                 n.components = 2,
#'                                 init.param = 'k.means++',
#'                                 covariance.type = 'full',
#'                                 shared.covariance = TRUE,
#'                                 thread.ratio = 0,
#'                                 max.iter = 100,
#'                                 category.weight = 0.707,
#'                                 error.tol = 2.5,
#'                                 regularization = 2.5,
#'                                 random.seed = 5)
#' }
#'
#' Output:
#' \preformatted{
#'  > gmm$labels$Collect()
#'     ID  CLUSTER_ID  PROBABILITY
#'  1   0           0            1
#'  2   1           0            1
#'  3   2           0            0
#'  4   3           0            0
#'  5   4           0            0
#'  6   0           1            0
#'  7   1           1            0
#'  8   2           1            1
#'  9   3           1            1
#'  10  4           1            1
#'}
#' @keywords Clustering
#' @export
hanaml.GaussianMixture <- function(data = NULL, key = NULL,
                                   features = NULL, n.components=NULL,
                                   init.param=NULL, init.centers=NULL,
                                   covariance.type=NULL, shared.covariance=NULL,
                                   thread.ratio=NULL, max.iter=NULL,
                                   category.weight=NULL, categorical.variable=NULL,
                                   error.tol=NULL, regularization=NULL, random.seed=NULL) {
  GaussianMixture$new(data, key, features, n.components,
                      init.param, init.centers, covariance.type,
                      shared.covariance, thread.ratio, max.iter,
                      category.weight, categorical.variable,
                      error.tol, regularization, random.seed)
}

#' @title Make Predictions from a GaussianMixture Object
#' @name predict.GaussianMixture
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted GaussianMixture object.
#' @keywords Clustering
#' @seealso \code{\link{hanaml.GaussianMixture}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A 'GaussianMixture' object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param     ... Reserved parameter.
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data} 's ID column.}
#'   \item{Cluster_ID, type INTEGER, the assigned cluster ID.}
#'   \item{PROBABILITY, type DOUBLE, Probability that the instance belong to a particular cluster.}
#' }
#'
#' @section Examples:
#' Perform the predict on DataFrame data2 using "GaussianMixture" objectc gmm:
#' \preformatted{
#' > data2$Collect()
#' ID  X1   X2   X3
#' 0  0.10  0.10  1
#' 1  0.11  0.10  1
#' 2  0.10  0.11  1
#' 3  0.11  0.11  1
#' 4  0.12  0.11  1
#'
#' > fitted <- predict(model = gmm, data = data2)
#' }
#'
#' Output:
#' \preformatted{
#' > fitted$Collect()
#'      ID  CLUSTER_ID  PROBABILITY
#' 1     0           0            1
#' 2     1           0            1
#' 3     2           0            0
#' 4     3           0            0
#' 5     4           0            0
#' 6     0           1            0
#' 7     1           1            0
#' 8     2           1            1
#' 9     3           1            1
#' 10    4           1            1
#' }
#' @keywords Clustering
#' @export
predict.GaussianMixture <- function(model, data, key, features = NULL, ...) {
  return (model$predict(model = model,
                        data = data,
                        key = key,
                        features = features))
}

#' @export
print.GaussianMixture <- function(x, ...){
    writeLines("\n")
    writeLines("Kmeans attributes:")
    cat(sprintf("shared.covariance : %s", to.null(x$shared.covariance)))
    writeLines("\n")
    cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
    writeLines("\n")
    cat(sprintf("max.iter : %s", to.null(x$max.iter)))
    writeLines("\n")
    cat(sprintf("category.weight : %s", to.null(x$category.weight)))
    writeLines("\n")
    cat(sprintf("error.tol : %s", to.null(x$error.tol)))
    writeLines("\n")
    cat(sprintf("regularization : %s", to.null(x$regularization)))
    writeLines("\n")
    cat(sprintf("random.seed : %s", to.null(x$random.seed)))
    writeLines("\n")
    cat(sprintf("init.param : %s", to.null(x$init.param.map)))
    writeLines("\n")
    cat(sprintf("covariance.type : %s", to.null(x$covariance.type.map)))
    writeLines("\n")
    cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
    writeLines("\n")
}

#' @export
summary.GaussianMixture <- function(object, ...){
    writeLines("Gaussian Mixture result table::")
    print(object$labels$Collect())
    writeLines("\n")
    writeLines("Gaussian Mixture model table::")
    print(object$model$Collect())
    writeLines("\n")
    writeLines("Gaussian Mixture stats table::")
    print(object$stats$Collect())
    writeLines("\n")
}
