PolynomialRegression <- R6Class(
  "PolynomialRegression",
  inherit = MlBase,
  public = list(
    decomposition.map = list(lu = 0, qr = 1, svd = 2, cholesky = 5),
    resample.map = list(cv = "cv", bootstrap = "bootstrap"),
    pmml.export.map = list("no" = 0, "single-row" = 1, "multi-row" = 2),
    model.format.map = list("coefficients" = 0, "pmml" = 1),
    degree = NULL,
    decomposition = NULL,
    adjusted.r2 = NULL,
    pmml.export = NULL,
    coefficients = NULL,
    fitted = NULL,
    model = NULL,
    statistics = NULL,
    pmml = NULL,
    optim.param = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          degree = NULL,
                          decomposition = NULL,
                          adjusted.r2 = NULL,
                          pmml.export = NULL,
                          resampling.method = NULL,
                          evaluation.metric = NULL,
                          fold.num = NULL,
                          repeat.times = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          random.state = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL) {
      super$initialize()
      if (!is.null(data)){
        self$degree <-
          validateInput("degree", degree, "integer",
                        required = is.null(c(parameter.range,
                                             parameter.values)))
        self$adjusted.r2 <- validateInput("adjusted.r2", adjusted.r2, "logical")
        self$pmml.export <- validateInput("pmml.export", pmml.export,
                                          self$pmml.export.map)
        self$decomposition <- validateInput("decomposition", decomposition,
                                            self$decomposition.map)
        resampling.method <-
          validateInput("resampling.method",
                        resampling.method,
                        self$resample.map)
        metric.map <- list(rmse = "RMSE")
        evaluation.metric <-
          validateInput("evaluation.metric",
                        evaluation.metric,
                        metric.map)
        repeat.times <- validateInput("repeat.times",
                                      repeat.times,
                                      "integer")
        fold.num <-
          validateInput("fold.num", fold.num, "integer",
                        required = isTRUE(self$resampling.method == "cv"))
        param.search.strategy <-
          validateInput("param.search.strategy",
                        param.search.strategy,
                        list(grid = "grid",
                             random = "random"))
        random.search.times <-
          validateInput("random.search.times", random.search.times, "integer",
                        required = isTRUE(self$param.search.strategy == "random"))
        random.state <- validateInput("random.state",
                                           random.state,
                                           "integer")
        timeout <- validateInput("timeout", timeout, "integer")
        progress.indicator.id <- validateInput("progress.indicator.id",
                                               progress.indicator.id,
                                               "character")
        parameter.range <- validateInput("parameter.range",
                                         parameter.range,
                                         "list")
        parameter.values <- validateInput("parameter.values",
                                          parameter.values,
                                          "list")
        # key check
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        # formula check
        if (!is.null(formula)) {
          if (inherits(formula, "formula")){
            parseformula <- ParseFormula(data, formula)
            features <- as.character(parseformula[[2]])
            features <- features[! features %in% key]
            if (length(features) != 1) {#nolint
              msg <- sprintf("Please enter only one feature!")
              flog.error(msg)
              stop(msg)
            }
            label <- as.character(parseformula[[1]])
          } else {
            msg <- sprintf("Please enter right format of formula! label~features")
            flog.error(msg)
            stop(msg)
          }
        }
        #label and features check
        cols <- cols[! cols %in% key]
        label <- validateInput("label", label, cols, case.sensitive = TRUE)
        if (is.null(label)){
          label <- cols[[length(cols)]]
        }
        cols <- cols[! cols %in% label]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        if (length(features) != 1) {#nolint
          msg <- sprintf("Please enter only one feature!")
          flog.error(msg)
          stop(msg)
        }
        if (is.null(features)) {
            features <- cols[[1]]
        }
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_POLYN_REGRESSION_PARAM_TBL_%s_%s", self$id, unique.id)
        coef.tbl <- sprintf("#PAL_POLYN_REGRESSION_COEF_TBL_%s_%s", self$id, unique.id)
        pmml.tbl <- sprintf("#PAL_POLYN_REGRESSION_PMML_TBL_%s_%s", self$id, unique.id)
        fitted.tbl <- sprintf("#PAL_POLYN_REGRESSION_FITTED_TBL_%s_%s", self$id, unique.id)
        stat.tbl <- sprintf("#PAL_POLYN_REGRESSION_STATS_TBL_%s_%s", self$id, unique.id)
        # opt.param.tbl is only for polyregression
        opt.param.tbl <-
          sprintf("#PAL_POLYN_REGRESSION_OPTIMAL_PARAM_TBL_%s_%s", self$id, unique.id)
        tables <- list(param.tbl, coef.tbl, pmml.tbl,
                       fitted.tbl, stat.tbl, opt.param.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(coef.tbl, pmml.tbl, fitted.tbl, stat.tbl, opt.param.tbl)
        param.map <- list(degree = "POLYNOMIAL_NUM")
        param.rows <- list(
          tuple("ADJUSTED_R2", to.integer(self$adjusted.r2), NULL, NULL),
          tuple("PMML_EXPORT",
                map.null(self$pmml.export, self$pmml.export.map),#nolint
                NULL, NULL),
          tuple("ALG", map.null(self$decomposition, self$decomposition.map),#nolint
                NULL, NULL),
          tuple("SELECTED_FEATURES", NULL, NULL, paste(features, collapse = ",")),
          tuple("DEPENDENT_VARIABLE", NULL, NULL, label),
          tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL),
          tuple("RESAMPLING_METHOD", NULL, NULL, resampling.method),
          tuple("EVALUATION_METRIC", NULL, NULL,
                map.null(evaluation.metric, metric.map)),
          tuple("FOLD_NUM", fold.num, NULL, NULL),
          tuple("REPEAT_TIMES", repeat.times, NULL, NULL),
          tuple("PARAM_SEARCH_STRATEGY", NULL, NULL,
                param.search.strategy),
          tuple("RANDOM_SEARCH_TIMES", random.search.times, NULL, NULL),
          tuple("SEED", random.state, NULL, NULL),
          tuple("TIMEOUT", timeout, NULL, NULL),
          tuple("PROGRESS_INDICATOR_ID", NULL, NULL,
                progress.indicator.id),
          tuple("POLYNOMIAL_NUM", self$degree, NULL, NULL))
        if (length(parameter.values) > 0){
          if (length(parameter.values) > 1 ||
              isTRUE(names(parameter.values) != "degree")) {
            msg <- paste("'degree' is the only parameter that can",
                         "be specified in parameter.values.")
            flog.error(msg)
            stop(msg)
          }
          if (is.null(names(parameter.values))) {
            names(parameter.values) <- c("degree")
          }
          for (i in seq_len(length(parameter.values))) {
            param.name <- param.map[[names(parameter.values[i])]]
            str.values <- paste0("{",
                                paste0(parameter.values[[1]],
                                       collapse = ", "),
                                "}")
            temp.tup <- tuple(paste0(param.name, "_VALUES"),
                              NULL, NULL, str.values)
            param.rows <-
              append(param.rows, list(temp.tup))
          }
        }
        if (length(parameter.range) > 0){
          if (length(parameter.range) > 1 ||
              isTRUE(names(parameter.range) != "degree")) {
            msg <- paste("'degree' is the only parameter that can",
                         "be specified in parameter.range.")
            flog.error(msg)
            stop(msg)
          }
          for (i in seq_len(length(parameter.range))) {
            param.name <- param.map[[names(parameter.range[i])]]
            range.temp <- parameter.range[[i]]
            cps <- ifelse(length(range.temp) == 2, ",,", ",")
            str.range <- paste("[",
                               paste0(range.temp,
                                      collapse = cps),
                               "]", sep = "")
            temp.tup <- tuple(paste0(param.name, "_RANGE"),
                              NULL, NULL, str.range)
            param.rows <-
              append(param.rows, list(temp.tup))
          }
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        selected <- append(append(key, label), features)
        data <- data$Select(selected)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
                                            (ParameterTable$new(param.tbl))$WithData(param.rows)))#nolint
          errorhelper(CallPalAutoWithConnection(conn.context,
                                                "PAL_POLYNOMIAL_REGRESSION",
                                                in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err$message)
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$coefficients <- conn.context$table(coef.tbl)
        self$model <- self$coefficients
        self$fitted <- conn.context$table(fitted.tbl)
        self$statistics <- conn.context$table(stat.tbl)
        self$pmml <- conn.context$table(pmml.tbl)
        self$optim.param <- conn.context$table(opt.param.tbl)
        if ((isTRUE(grepl("-row", self$pmml.export)))) {
          self$model <- self$pmml
        }
      }
    },
    predict = function(data,
                       key,
                       features = NULL,
                       thread.ratio = NULL,
                       model.format = NULL){
      if (is.null(self$model)){
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")){
        msg <- "Data for prediction must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      conn.context <- data$connection.context
      model.format <- validateInput("model.format", model.format,
                                    self$model.format.map)
      thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
      # assign key and features
      cols <- data$columns
      key <- validateInput("key", key, cols,
                           case.sensitive = TRUE, required = TRUE)
      cols <- cols[!cols %in% key]
      features <- validateInput("features", features,
                                cols, case.sensitive = TRUE)
      if (is.null(features)) {
        features <- cols[[1]]
      } else if (length(features) != 1){
        msg <- sprintf("Please enter only one feature!")
        flog.error(msg)
        stop(msg)
      }
      data <- data$Select(c(key, features))
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#PAL_POLYN_REGRESSION_PRED_PARAM_TBL_%s_%s",
                           self$id, unique.id)#nolint
      fitted.tbl <- sprintf("#PAL_POLYN_REGRESSION_PRED_FITTED_TBL_%s_%s",
                            self$id, unique.id)#nolint
      in.tables <- list(data, self$model$name, param.tbl)
      tables <- list(param.tbl, fitted.tbl)
      out.tables <- list(fitted.tbl)
      param.rows <- list(tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
                         tuple("MODEL_FORMAT", map.null(model.format,
                                                        self$model.format.map),
                               NULL, NULL))

      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
                                          (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
                                              "PAL_POLYNOMIAL_REGRESSION_PREDICT",
                                              in.tables, out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      return (conn.context$table(fitted.tbl))
    },
    score = function(data,
                     key,
                     features = NULL,
                     label = NULL,
                     model.format = NULL){
      model.format <- validateInput("model.format", model.format,
                                    self$model.format.map)
      if (!inherits(data, "DataFrame")) {
        msg <- "If training data is not omitted, it must be DataFrame."
        flog.error(msg)
        stop(msg)
      }

      if (is.null(self$model)) {
        msg <- "model of object is NULL!"
        flog.error(msg)
        stop(msg)
      }

      cols <- data$columns
      key <- validateInput("key", key, cols,
                           required = TRUE, case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      if (is.null(features)) {
        features <- cols[[1]]
      }

      prediction <- predict(data,
                            key,
                            features,
                            model.format)
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      r2.score <- r2.score(self$connection.context,
                           joined,
                           label.true = "ACTUAL",
                           label.pred = "PREDICTION")
      return(r2.score)
    }
  )
)

#' @title  Polynomial Regression
#' @name hanaml.PolynomialRegression
#' @description hanaml.PolynomialRegression is a R wrapper
#'  for SAP HANA PAL Polynomial Regression.
#' @details Polynomial regression is an approach to modeling the relationship
#' between a scalar variable y and a variable denoted X.
#' In polynomial regression, data is modeled using polynomial functions,
#' and unknown model parameters are estimated from the data.
#' Such models are called polynomial models.
#' @seealso \code{\link{predict.PolynomialRegression}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-one
#' @template args-label
#' @template args-formula
#' @param degree \code{integer}\cr Degree of the polynomial model.
#' @template args-decompostion
#' @template args-adjustedr2
#' @template args-pmmlexport
#' @param  resampling.method   \code{character, optional}\cr
#'         specifies the resampling values form below list. Valid options include:\cr
#'         \code{'cv', 'bootstrap'}.\cr
#'         If no value is specified for this parameter, neither model evaluation
#'         nor parameter selection is activated.
#' @param  evaluation.metric   \code{character, optional}\cr
#'         Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'         Currently the only optional values is 'RMSE'.\cr
#'         If not specified, neither model evaluation
#'         nor parameter selection is activated.\cr
#' @param  fold.num \code{integer, optional}\cr
#'         Specifies the fold number for the cross-validation(cv).
#'         Mandatory and valid only when \code{resampling.method} is 'cv'.
#' @param  repeat.times  \code{numeric, optional}\cr
#'         Specifies the number of repeat times for resampling.\cr
#'         Defaults to 1.
#' @param  param.search.strategy   \code{c('grid', 'random'), optional}\cr
#'         Specifies the method to activate parameter selection.
#'         If not specified, model selection shall not be triggered.
#' @param  random.search.times \code{integer, optional}\cr
#'         Specifies the number of times to randomly select candidate parameters for selection.
#'         Mandatory and valid only when \code{param.search.strategy} is 'random'.
#' @param  random.state \code{integer, optional}\cr
#'         Specifies the seed for random number generation, where 0 means current system time
#'         is used as seed, and other values are simply real seed values.
#' @param  timeout \code{integer, optional}\cr
#'         Specifies maximum running time for model evaluation or parameter selection in seconds.
#'         No timeout when 0 is specified.
#' @param  progress.indicator.id     \code{character, optional}\cr
#'         Sets an ID of progress indicator for model evaluation or parameter selection.\cr
#'         No progress indicator is active if no value is provided.
#' @param  parameter.values   \code{named list/vector, optional}\cr
#'         Specifies values of the \code{degree} parameter for parameter selection.
#' @param  parameter.range   \code{named list/vector, optional}\cr
#'         Specifies range of \code{degree} parameter for parameter selection:\cr
#'         Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'         If \code{param.search.strategy} is 'random', then step has no effect
#'         and thus can be omitted.
#' @return
#'\itemize{
#'    \item{coefficients : \code{DataFrame}}\cr
#'    Fitted regression coefficients.
#'    \item{pmml : \code{DataFrame}}\cr
#'    PMML model. Set to NULL if no PMML model is requested.
#'    \item{model : \code{DataFrame}}\cr
#'    Model is used to save coefficients or PMML model. If PMML model is requested,
#'    model defaults to PMML model. Otherwise, it is coefficients.
#'    \item{fitted : \code{DataFrame}}\cr
#'    Predicted dependent variable values for training data.
#'    Set to NULL if the training data has no row IDs.
#'    \item{statistics : \code{DataFrame}}\cr
#'    Regression-related statistics, such as mean squared error.
#'    \item{optim.param : code{DataFrame}}\cr
#'    The selected optimal \code{degree} parameter.
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' >data$Collect()
#'   ID   Y X1
#' 1  0   5  1
#' 2  1  20  2
#' 3  2  43  3
#' 4  3  89  4
#' 5  4 166  5
#' 6  5 247  6
#' 7  6 403  7
#' }
#' Call the function:
#' \preformatted{
#' >pr <- hanaml.PolynomialRegression(data, key = "ID", formula= Y~X1,
#'                                    degree = 3L, pmml.export = "multi-row")
#' }
#' Output:
#' \preformatted{
#' > pr$coefficients$Collect()
#'        VARIABLE_NAME COEFFICIENT_VALUE
#' 1  __PAL_INTERCEPT__        -11.000000
#' 2 X1__PAL_DELIMIT__1         17.250000
#' 3 X1__PAL_DELIMIT__2         -3.416667
#' 4 X1__PAL_DELIMIT__3          1.333333
#' }
#' @keywords Regression
#' @export
hanaml.PolynomialRegression <- function(data = NULL,
                                        key = NULL,
                                        features = NULL,
                                        label = NULL,
                                        formula = NULL,
                                        degree = NULL,
                                        decomposition = NULL,
                                        adjusted.r2 = NULL,
                                        pmml.export = NULL,
                                        resampling.method = NULL,
                                        evaluation.metric = NULL,
                                        fold.num = NULL,
                                        repeat.times = NULL,
                                        param.search.strategy = NULL,
                                        random.search.times = NULL,
                                        random.state = NULL,
                                        timeout = NULL,
                                        progress.indicator.id = NULL,
                                        parameter.range = NULL,
                                        parameter.values = NULL){
  PolynomialRegression$new(data,
                           key,
                           features,
                           label,
                           formula,
                           degree,
                           decomposition,
                           adjusted.r2,
                           pmml.export,
                           resampling.method,
                           evaluation.metric,
                           fold.num,
                           repeat.times,
                           param.search.strategy,
                           random.search.times,
                           random.state,
                           timeout,
                           progress.indicator.id,
                           parameter.range,
                           parameter.values)
}


#' @title Make Predictions from a "PolynomialRegression" Object
#' @name predict.PolynomialRegression
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "PolynomialRegression" object.
#' @seealso \code{\link{hanaml.PolynomialRegression}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A "PolynomialRegression" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict-1
#' @template args-threadratio
#' @template args-modelformat
#' @return
#'Predicted values are returned as a DataFrame, structured as follows.
#'\itemize{
#'   \item{ID: with same name and type as \emph{data}'s ID column.}
#'   \item{VALUE: type DOUBLE, representing predicted values.}
#'}
#' @section Examples:
#' Input DataFrame data2:
#' \preformatted{
#' > data2$Collect()
#'   ID   X1
#' 1  0 0.30
#' 2  1 4.00
#' 3  2 1.60
#' 4  3 0.45
#' 5  4 1.70
#' }
#'
#' Predict with DataFrame data2 and the "PolynomialRegression" Object pr:
#' \preformatted{
#' > predict(pr, data2, key = "ID")
#'    ID      VALUE
#' 0   1   6.157063
#' 1   2   8.401269
#' 2   3  15.668581
#' 3   4  33.928501
#' }
#' @keywords Regression
#' @export
predict.PolynomialRegression <- function(model,
                                         data,
                                         key,
                                         features = NULL,
                                         thread.ratio = NULL,
                                         model.format = NULL){
  model$predict(data,
                key,
                features,
                thread.ratio,
                model.format)
}

#' @export
print.PolynomialRegression <- function(x, ...){
  writeLines("\n")
  writeLines("PolynomialRegression attributes:")
  writeLines("\n")
  cat(sprintf("degree : %s", to.null(x$degree)))
  writeLines("\n")
  cat(sprintf("decomposition : %s", to.null(x$decomposition)))
  writeLines("\n")
  cat(sprintf("adjusted.r2 : %s", to.null(x$adjusted.r2)))
  writeLines("\n")
  cat(sprintf("pmml.export : %s", to.null(x$poly.pmml.export)))
  writeLines("\n")
}

#' @export
summary.PolynomialRegression <- function(object, ...){
    writeLines("PolynomialRegression coefficients DataFrame:")
    print(object$coefficients$Collect())
    writeLines("\n")
    writeLines("PolynomialRegression fitted DataFrame:")
    print(object$fitted$Collect())
    writeLines("\n")
    writeLines("PolynomialRegression model DataFrame:")
    print(object$model$Collect())
    writeLines("\n")
    writeLines("PolynomialRegression statistics DataFrame:")
    print(object$statistics$Collect())
    writeLines("\n")
    writeLines("PolynomialRegression pmml DataFrame:")
    print(object$pmml$Collect())
    writeLines("\n")
    print(object$optim.param$Collect())
    writeLines("\n")
}
