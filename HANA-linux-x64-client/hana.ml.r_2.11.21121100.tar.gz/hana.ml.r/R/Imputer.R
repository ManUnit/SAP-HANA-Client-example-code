Imputer <- R6Class(
  "Imputer",
  inherit = MlBase,
  public = list(
    strategy = NULL,
    strategy.by.col = NULL,
    als.factors = NULL,
    als.lambda = NULL,
    als.maxit = NULL,
    als.randomstate = NULL,
    als.exit.threshold = NULL,
    als.exit.interval = NULL,
    als.linsolver = NULL,
    als.cg.maxit = NULL,
    als.centering = NULL,
    als.scaling = NULL,
    categorical.variable = NULL,
    thread.ratio = NULL,
    result = NULL,
    model = NULL,
    overall.imputation.map = list(non = 0,
                                  most_frequent.mean = 1,
                                  mean = 1,
                                  most_frequent.median = 2,
                                  median = 2,
                                  most_frequent.zero = 3,
                                  zero = 3,
                                  most_frequent.als = 4,
                                  als = 4,
                                  delete = 5),
    column.imputation.map = list(non = 0, delete = 1,
                                 most_frequent = 100,
                                 categorical_const = 101,
                                 mean = 200, median = 201,
                                 numerical_const = 203,
                                 als = 204),
    solver.map = list(cholsky = 0, cholesky = 0, cg = 1),
    initialize = function(data = NULL,
                          key = NULL,
                          strategy = NULL,
                          strategy.by.col = NULL,
                          als.factors = NULL,
                          als.lambda = NULL,
                          als.maxit = NULL,
                          als.randomstate = NULL,
                          als.exit.threshold = NULL,
                          als.exit.interval = NULL,
                          als.linsolver = NULL,
                          als.cg.maxit = NULL,
                          als.centering = NULL,
                          als.scaling = NULL,
                          categorical.variable = NULL,
                          thread.ratio = NULL
                          ) {
      super$initialize()
      if (!is.null(data)) {
        self$strategy <-
          validateInput("strategy", strategy, self$overall.imputation.map)
        self$als.factors <-
          validateInput("als.factors", als.factors, "integer")
        self$als.lambda <-
          validateInput("als.lambda", als.lambda, "double")
        self$als.maxit <-
          validateInput("als.maxit", als.maxit, "integer")
        self$als.randomstate <-
          validateInput("als.randomstate", als.randomstate, "integer")
        self$als.exit.threshold <-
          validateInput("als.exit.threshold", als.exit.threshold, "double")
        self$als.exit.interval <-
          validateInput("als.exit.interval", als.exit.interval, "integer")
        self$thread.ratio <-
          validateInput("thread.ratio", thread.ratio, "double")
        self$als.linsolver <-
          validateInput("als.linsolver", als.linsolver, self$solver.map)
        self$als.cg.maxit <-
          validateInput("als.maxit", als.cg.maxit, "integer")
        self$als.centering <-
          validateInput("als.centering", als.centering, "logical")
        self$als.scaling <-
          validateInput("als.scaling", als.scaling, "logical")
        #########strategy.by.col check
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   cols,
                                                   case.sensitive = TRUE)
        if (length(strategy.by.col) != 0){
          col.names <- names(strategy.by.col)
          if (length(col.names) != length(strategy.by.col)){
            msg <- paste("Each column imputation strategy must be specified",
                         "with column name.")
            flog.error(msg)
            stop(msg)
          }
          validateInput("Name of columns for imputation strategy specification",
                        col.names,
                        cols,
                        case.sensitive = TRUE)
          valid.num.strategy <- c("non", "delete", "mean", "median", "als")
          valid.cat.strategy <- c("non", "delete", "most_frequent")
          col.dtypes <- data$dtypes(col.names)
          for (i in 1:length(strategy.by.col)) {
            col.name <- col.dtypes[[i]][[1]]
            col.type <- col.dtypes[[i]][[2]]
            s.value <- strategy.by.col[[i]]
            validateInput("Valid value types for column strategy specification",
                          typeof(s.value),
                          list("integer", "double", "character"))
            if (col.type == "DOUBLE") {
              if (is.character(s.value) && !s.value %in% valid.num.strategy){
                msg <- paste0("Wrong column strategy ", s.value,
                              " for column ", col.name,
                              ". Valid strategy should be selected from: ",
                              paste(valid.num.strategy, collapse = ", "))
                flog.error(msg)
                stop(msg)
              }
            } else if (col.type %in% c("VARCHAR", "NVARCHAR") ||
                       (col.type == "INT" &&
                        col.name %in% self$categorical.variable)){
              if (is.character(s.value) && s.value %in% c("mean",
                                                          "median",
                                                          "als")){
                msg <- paste0(col.name, " is a categorical column, ",
                              "valid strategy should be selected from: ",
                              paste(valid.cat.strategy, collapse = ", "))
                flog.error(msg)
                stop(msg)
              }
            }
          }
        }
        self$strategy.by.col <- strategy.by.col
        if (!inherits(data, "DataFrame")) {
          msg <- "data must be given as a DataFrame"
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn <- data$connection.context
        param.rows <- list(
          tuple("IMPUTATION_TYPE",
                map.null(self$strategy, self$overall.imputation.map),
                NULL, NULL),
          tuple("ALS_FACTOR_NUMBER", self$als.factors, NULL, NULL),
          tuple("ALS_REGULARIZATION", NULL, self$als.lambda, NULL),
          tuple("ALS_MAX_ITERATION", self$als.maxit, NULL, NULL),
          tuple("ALS_SEED", self$als.randomstate, NULL, NULL),
          tuple("ALS_EXIT_THRESHOLD", NULL, self$als.exit.threshold, NULL),
          tuple("ALS_EXIT_INTERVAL", self$als.exit.interval, NULL, NULL),
          tuple("ALS_LINEAR_SYSTEM_SOLVER",
                map.null(self$als.linsolver, self$solver.map), NULL, NULL),
          tuple("ALS_CG_MAX_ITERATION", self$als.cg.maxit, NULL, NULL),
          tuple("ALS_CENTERING", to.integer(self$als.centering),
                NULL, NULL),
          tuple("ALS_SCALING", to.integer(self$als.scaling),
                NULL, NULL),
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL))
        if (!is.null(self$categorical.variable)) {
          for (vab in self$categorical.variable){
            param.rows <- append(param.rows, list(
              tuple("CATEGORICAL_VARIABLE", NULL, NULL,
                    vab)))
          }
        }
        if (length(self$strategy.by.col) != 0) {
          for (i in 1:length(self$strategy.by.col)) {
            col.name <- col.dtypes[[i]][[1]]
            col.type <- col.dtypes[[i]][[2]]
            s.value <- self$strategy.by.col[[i]]
            if (s.value %in% names(self$column.imputation.map)){
              param.rows <-
                append(param.rows,
                       list(tuple(paste0(col.name, "_IMPUTATION_TYPE"),
                                  map.null(s.value,
                                           self$column.imputation.map),
                                  NULL, NULL)))
            } else if (col.type %in% c("VARCHAR", "NVARCHAR") ||
                       (col.type == "INTEGER" &&
                        col.name %in% self$categorical.variable)){
              msg <- paste0(s.value, " is not an valid column imputation ",
                            "strategy, it will be used to replace all ",
                            "missing values in column ", col.name, "!")
              flog.warn(msg)
              param.rows <-
                append(param.rows,
                       list(tuple(paste0(col.name, "_IMPUTATION_TYPE"),
                                  map.null("categorical_const",
                                           self$column.imputation.map),
                                  NULL, as.character(s.value))))
            } else {
              param.rows <-
                append(param.rows,
                       list(tuple(paste0(col.name, "_IMPUTATION_TYPE"),
                                  map.null("numerical_const",
                                           self$column.imputation.map),
                                  as.numeric(s.value), NULL)))
            }
          }
        }

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_MISSING_VALUE_PARAMETER_TBL_%s_%s", self$id, unique.id)
        result.tbl <- sprintf("#PAL_MISSING_VALUE_RESULT_TBL_%s_%s", self$id, unique.id)
        model.tbl <- sprintf("#PAL_MISSING_VALUE_MODEL_TBL_%s_%s", self$id, unique.id)
        in.tables <- list(data, param.tbl)
        out.tables <- list(result.tbl, model.tbl)
        tables <- c(param.tbl, out.tables)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
            (ParameterTable$new(param.tbl))$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn,
                                                "PAL_MISSING_VALUE_HANDLING",
                                                in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        self$result <- conn$table(result.tbl)
        self$model <- conn$table(model.tbl)
      }
    }
  )
)
#' @title Imputer
#' @name hanaml.Imputer
#' @description hanaml.Imputer is a R wrapper for SAP HANA PAL Missing Value Handling.
#'  Missing value imputation for DataFrame.
#' @seealso \code{\link{transform.Imputer}}
#' @template args-data
#' @template args-key
#' @param strategy \code{character, optional}\cr
#' \itemize{
#' The overall imputation strategy. Choices are mostly for numerical columns. For categorical columns,
#' if missing values are not left untouched or deleted, then they will be replaced by the most frequent values
#' of their columns by default.
#'      \item{\code{"non"}: Does nothing. Leave all columns untouched.}
#'      \item{\code{"most_frequent.mean"}: For numerical columns, filling all missing values by the mean; for
#'      categorical columns, fills all missing values with the most frequent value.}
#'      \item{\code{"most_frequent.median"}: For numerical columns, fills all missing values by the median;
#'       for categorical columns, fills all missing values with the most frequent value.}
#'      \item{\code{"most_frequent.zero"}: For numerical columns, fills all missing values with zeros;
#'           for categorical columns, fills all missing values with the most frequent value.}
#'      \item{\code{"most_frequent.als"}: For numerical columns, fills each missing value by the value imputed by a
#'      matrix completion model trained using alternating least squares method;
#'      for categorical columns, fills all missing values with the most frequent value.}
#'      \item{\code{"delete"}: Deletes all rows with missing values.
#'      The entire row in table will be deleted.}
#'      }
#' Defaults to 'most_frequent.mean'.
#' @param strategy.by.col \code{list, optional}\cr
#' Specifies the imputation strategy for a set of columns, which
#' overrides the overall strategy for data imputation.\cr
#' Elements of this list must be named. The names must be column names,
#' while each value should either be the imputation strategy applied to that column,
#' or the replacement for all missing values within that column.\cr
#' Valid column imputation strategies are listed as follows:\cr
#' "mean", "median", "als", "non", "delete", "most_frequent".\cr
#' The first five strategies are applicable to numerical columns, while the final three
#' strategies are applicable to categorical columns.\cr
#' An illustrative example:\cr
#' stragegy.by.col = list(V1 = 0, V5 = "median"),
#' which mean for column V1, all missing values shall be replaced by constant 0;
#' while for column V5, all missing values shall be by replaced by the median of all
#' available values in that column.
#' @param als.factors \code{integer, optional}\cr
#' Length of factor vectors in the ALS model.
#' It should be less than the number of numerical columns,
#' so that the imputation results would be meaningful.\cr
#' Defaults to 3.
#' @param als.lambda \code{integer, optional}\cr
#' L2 regularization applied to the factors in the ALS model.\cr
#' Should be non-negative.\cr
#' Defaults to 0.01.
#' @param als.maxit \code{integer, optional}\cr
#' Maximum number of iterations for solving the ALS model.\cr
#' Defaults to 20.
#' @param als.randomstate \code{integer, optional}\cr
#' \itemize{
#'  Specifies the seed of the random number generator used in the training of
#'  ALS model:\cr
#'  \item{\code{0}: Uses the current time as the seed}
#'  \item{\code{Others}: Uses the specified value as the seed.}
#'  }
#'  Defaults to 0.
#' @param als.exit.threshold \code{integer, optional}\cr
#' Specify a value for stopping the training of ALS nmodel.
#' If the improvement of the cost function of the ALS model
#' is less than this value between consecutive checks, then
#' the training process will exit.\cr
#' 0 means there is no checking of the objective value when
#' running the algorithms, and it stops till the maximum number of
#' iterations has been reached.\cr
#' Defaults to 0.
#' @param als.exit.interval \code{integer, optional}\cr
#' Specify the number of iterations between consecutive checking of
#' cost functions for the ALS model, so that one can see if the
#' pre-specified exit_threshold is reached.\cr
#' Defaults to 5.
#' @param als.linsolver \code{character, optional}\cr
#' Linear system solver for the ALS model, could be "cholsky" or "cg".\cr
#' "cholsky" is usually much faster.
#' "cg" is recommended when als.factors is large.\cr
#' Defaults to 'cholsky'.
#' @param als.cg.maxit \code{ int, optional}\cr
#' Specifies the maximum number of iterations for cg algorithm.
#' Invoked only when the 'cg' is the chosen linear system solver for ALS.\cr
#' Defaults to 3.
#' @param als.centering \code{logical, optional}\cr
#' Whether to center the data by column before training the ALS model. \cr
#' Defaults to TRUE.
#' @param als.scaling \code{logical, optional}\cr
#' Wheter to scale the data by column before training the ALS model.\cr
#' Defaults to TRUE.
#' @template args-cate-var
#' @template args-threadratio
#' @note{ The parameters having pre-fix 'als' are invoked only when
#' als' is the overall imputation strategy. Those parameters are for setting
#' up the alternating-least-square(ALS) mdoel for data imputation.
#' }
#'
#' @return
#' An "Imputer" object with the following attributes:
#' \itemize{
#'    \item{result : \code{DataFrame}}\cr
#'    The same column structure (number of columns, column names, and column
#'    types) with the table with which the model is trained.
#'    \item{model : \code{DataFrame}}\cr
#'    statistics/model content.
#'}
#' @section Examples:
#'  Input DataFrame data:
#' \preformatted{
#'  > data$Collect()
#'    V0    V1     V2     V3     V4     V5
#' 1  10     0      D     NA    1.4   23.6
#' 2  20     1      A    0.4    1.3   21.8
#' 3  50     1      C     NA    1.6   21.9
#' 4  30    NA      B    0.8    1.7   22.6
#' 5  10     0      A    0.2     NA     NA
#' 6  10     0   <NA>    0.5    1.8   19.7
#' 7  NA     0      C    0.5     NA   17.8
#' 8  10     1      A    0.6    1.6   24.9
#' 9  20    NA      D    0.9    1.7   22.2
#' 10 30     1      D    0.4    1.3     NA
#' 11 50     0   <NA>    0.3    1.2   16.4
#' 12 NA     1      B    0.7    1.2   19.3
#' 13 30     1      A    0.2    1.1   21.7
#' 14 30     0      D    NA     NA      NA
#' 15 NA     1      C    0.5    1.8   18.6
#' 16 20     0      A    0.6    1.4   17.9
#' }
#'  Model training and a "Imputer" object ip is returned:
#' \preformatted{
#'  > ip <- hanaml.Imputer(data,
#'                         strategy = "most_frequent.mean",
#'                         categorical.variable = "V1",
#'                         strategy.by.col = c(V1 = 0))
#' }
#' Output:
#' \preformatted{
#' > ip$result$Collect()
#'     V0  V1 V2     V3               V4                 V5
#' 1   10  0  D  0.5076923076923077  1.4                23.6
#' 2   20  1  A  0.4                 1.3                21.8
#' 3   50  1  C  0.5076923076923077  1.6                21.9
#' 4   30  0  B  0.8                 1.7                22.6
#' 5   10  0  A  0.2                 1.4692307692307693 20.646153846153844
#' 6   10  0  A  0.5                 1.8                19.7
#' 7   24  0  C  0.5                 1.4692307692307693 17.8
#' 8   10  1  A  0.6                 1.6                24.9
#' 9   20  0  D  0.9                 1.7                22.2
#' 10  30  1  D  0.4                 1.3                20.646153846153844
#' 11  50  0  A  0.3                 1.2                16.4
#' 12  24  1  B  0.7                 1.2                19.3
#' 13  30  1  A  0.2                 1.1                21.7
#' 14  30  0  D  0.5076923076923077  1.4692307692307693 20.646153846153844
#' 15  24  1  C  0.5                 1.8                18.6
#' 16  20  0  A  0.6                 1.4                17.9
#' }
#' @keywords Preprocessing
#' @export
hanaml.Imputer <- function(data = NULL,
                           key = NULL,
                           strategy = NULL,
                           strategy.by.col = NULL,
                           als.factors = NULL,
                           als.lambda = NULL,
                           als.maxit = NULL,
                           als.randomstate = NULL,
                           als.exit.threshold = NULL,
                           als.exit.interval = NULL,
                           als.linsolver = NULL,
                           als.cg.maxit = NULL,
                           als.centering = NULL,
                           als.scaling = NULL,
                           categorical.variable = NULL,
                           thread.ratio = NULL){
  Imputer$new(data,
              key,
              strategy,
              strategy.by.col,
              als.factors,
              als.lambda,
              als.maxit,
              als.randomstate,
              als.exit.threshold,
              als.exit.interval,
              als.linsolver,
              als.cg.maxit,
              als.centering,
              als.scaling,
              categorical.variable,
              thread.ratio)
}


#' @title Make Transformation from an "Imputer" Object
#' @name transform.Imputer
#' @description Similar to other transform methods, this function
#' transforms fitted values from a fitted "Imputer" object.
#' @seealso \code{\link{hanaml.Imputer}}
#' @param model \code{R6Class object}\cr
#'  An "Imputer" object for transformation.
#' @template args-data
#' @template args-key-optional
#' @template args-threadratio
#' @return
#' transformed values are returned as a list of two DataFrame, structured as follows.
#' \itemize{
#'   \item{\code{DataFrame 1}}: \cr
#'    Result DataFrame. The same column structure (number of columns, column names, and column
#'    types) with the table with which the model is trained.
#'   \item{\code{DataFrame 2}}: \cr
#'    Statistics DataFrame.
#' }
#'
#' @section Examples:
#' Perform the transform on DataFrame data2 using "imputer" object ip:
#' \preformatted{
#' > data2$Collect()
#'   ID V0   V1   V2    V3    V4    V5
#' 1  0 20    1    B    NA   1.5  21.7
#' 2  1 40    1 <NA>   0.6   1.2  24.3
#' 3  2 NA    0    D    NA   1.8  22.6
#' 4  3 50   NA    C   0.7   1.1    NA
#' 5  4 20    1    A   0.3    NA  20.6
#' }
#' Call the function:
#' \preformatted{
#' > result <- transform(ip, data2)
#' }
#' Output:
#' \preformatted{
#' > result[[1]]$Collect()
#'   ID V0 V1 V2        V3       V4       V5
#' 1  0 20  1  B 0.5076923 1.500000 21.70000
#' 2  1 40  1  A 0.6000000 1.200000 24.30000
#' 3  2 24  0  D 0.5076923 1.800000 22.60000
#' 4  3 50  0  C 0.7000000 1.100000 20.64615
#' 5  4 20  1  A 0.3000000 1.469231 20.60000
#' }
#' @keywords Preprocessing
#' @export
transform.Imputer <- function(model,
                              data,
                              key = NULL,
                              thread.ratio = NULL) {
  if (is.null(model$model) ){
    msg <- "Model is not initialized!"
    flog.error(msg)
    stop(msg)
  }
  if (!inherits(data, "DataFrame")){
    msg <- "Data to be transformed must be DataFrame."
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  cols <- data$columns
  key <- validateInput("key", key, cols, case.sensitive = TRUE)
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s_%s", model$id, unique.id)
  result.tbl <-
    sprintf("#PAL_MISSING_VALUE_HANDLING_WITH_MODEL_RESUTL_TBL_%s_%s",
            model$id, unique.id)
  stats.tbl <-
    sprintf("#PAL_MISSING_VALUE_HANDLING_WITH_MODEL_STATISTICS_%s_%s",
            model$id, unique.id)
  in.tables <- list(
    data,
    model$model$name,
    param.tbl
  )
  out.tables <- list(
    result.tbl,
    stats.tbl
  )
  tables <- c(param.tbl, out.tables)
  param.rows <- list(
    tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL),
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
      (ParameterTable$new(param.tbl))$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_MISSING_VALUE_HANDLING_WITH_MODEL",
                                          in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  result <- conn$table(result.tbl)
  stats <- conn$table(stats.tbl)
  return (list(result, stats))
}
