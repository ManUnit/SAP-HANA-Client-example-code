GLM <- R6Class(
  "GLM",
  inherit = MlBase,
  public = list(
    family.link.values = list(gaussian = list("identity", "log", "reciprocal", "inverse"),
                              poisson = list("identity", "log"),
                              binomial = list("logit", "probit", "comploglog", "log"),
                              gamma = list("identity", "reciprocal", "inverse", "log"),
                              inversegaussian = list("inversesquare", "identity", "reciprocal",
                                                       "inverse", "log"),
                              negativebinomial = list("identity", "log", "sqrt"),
                              ordinal = list("logit", "probit", "comploglog")),
    solvers = list("irls", "nr", "cd"),
    handle.missing.fit.map = list(abort = 0, skip = 1, fill_zero = 2),
    family = NULL,
    link = NULL,
    solver = NULL,
    handle.missing.fit = NULL,
    quasilikelihood = NULL,
    max.iter = NULL,
    tol = NULL,
    significance.level = NULL,
    output.fitted = NULL,
    enet.alpha = NULL,
    enet.lambda = NULL,
    num.lambda = NULL,
    lambda.min.ratio = NULL,
    categorical.variable = NULL,
    ordering = NULL,
    resampling.method = NULL,
    evaluation.metric = NULL,
    fold.num = NULL,
    repeat.times = NULL,
    param.search.strategy = NULL,
    random.search.times = NULL,
    random.state = NULL,
    timeout = NULL,
    progress.indicator.id = NULL,
    parameter.range = NULL,
    parameter.values = NULL,
    coefficients = NULL,
    covariance = NULL,
    fitted = NULL,
    statistics = NULL,
    model = NULL,
    initialize = function(data=NULL,
                          key=NULL,
                          features=NULL,
                          label=NULL,
                          family=NULL,
                          link=NULL,
                          solver=NULL,
                          handle.missing.fit=NULL,
                          quasilikelihood=NULL,
                          max.iter=NULL,
                          tol=NULL,
                          significance.level=NULL,
                          output.fitted=NULL,
                          alpha=NULL,
                          lambda=NULL,
                          num.lambda=NULL,
                          lambda.min.ratio=NULL,
                          categorical.variable=NULL,
                          ordering=NULL,
                          enet.alpha=NULL,
                          enet.lambda=NULL,
                          resampling.method = NULL,
                          evaluation.metric = NULL,
                          fold.num = NULL,
                          repeat.times = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          random.state = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL){
      super$initialize()
      if (!is.null(data)) {
        if (length(data$columns) < 3) {
          msg <- "The data has at least 3 columns"
          flog.error(msg)
          stop(msg)
        }

        if ((length(data$columns) < 4) && (isTRUE(family == "binomial"))) {#nolint
          msg <- "Binomial distribution needs at least 4 columns"
          flog.error(msg)
          stop(msg)
        }

        param.rows <- list()
        self$family <- validateInput("family", family, self$family.link.values)

        if (is.null(family)) {
          links <-  self$family.link.values[["gaussian"]]
        } else {
          links <-  self$family.link.values[[sapply(family, tolower)]]
        }

        self$link <- validateInput("link", link, links)


        self$solver <- validateInput("solver", solver, self$solvers)

        if ((isTRUE(self$solver != "nr")) && (isTRUE(self$family == "ordinal"))#nolint
            || (isTRUE(self$solver == "nr")) && (isTRUE(self$family != "ordinal"))){#nolint
          msg <- "ordinal regression is solved only via Newton-Raphson method!"
          flog.error(msg)
          stop(msg)
        }

        #check handle.missing.fit
        self$handle.missing.fit <- validateInput("handle.missing.fit",
                                                 handle.missing.fit,
                                                 self$handle.missing.fit.map)
        #check quasi
        if (!is.null(quasilikelihood)) {
          self$quasilikelihood <- validateInput("quasilikelihood", quasilikelihood, "logical")
          if (isFALSE(isTRUE(self$family == "poisson") || isTRUE(self$family == "binomial"))){#nolint
            msg <- "Invalid quasilikelihood! Valid only for Poisson and Binomial distribution."
            flog.error(msg)
            stop(msg)
          }
        }

        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        self$tol <- validateInput("tol", tol, "double")

        # check significance.level
        self$significance.level <- validateInput("significance.level",
                                                 significance.level, "numeric")
        if ((!is.null(self$significance.level)) && (isTRUE (self$solver == "cd"))) {#nolint
          msg <- paste("Invalid significance.level! Not for coordinate descent.")
          flog.error(msg)
          stop(msg)
        }
        self$output.fitted <- validateInput("output.fitted",
                                            output.fitted,
                                            "logical")
        # check alpha, lambda, num.lambda, lambda.min.ratio
        self$enet.alpha <- validateInput("alpha", alpha, "double")
        self$enet.lambda <- validateInput("lambda", lambda, "double")
        self$num.lambda <- validateInput("num.lambda", num.lambda, "integer")
        self$lambda.min.ratio <- validateInput("lambda.min.ratio",
                                               lambda.min.ratio,
                                               "double")
        if (isTRUE(self$solver != "cd")){
          if (!is.null(alpha))
            wrong.input <- "alpha"
          else if (!is.null(lambda))
            wrong.input <- "lambda"
          else if (!is.null(num.lambda))
            wrong.input <- "num_lambda"
          else if (!is.null(lambda.min.ratio))
            wrong.input <- "lambda_min_ratio"
          else
            wrong.input <- NULL
          if (!is.null(wrong.input)){
            msg <- sprintf("Parameter %s should not be provided when solver is not 'cd'.",
                           wrong.input)
            flog.error(msg)
            stop(msg)
          }
        }

        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   data$columns,
                                                   case.sensitive = TRUE)
        # check ordering and ordinal
        if ((!is.null(ordering)) && (isTRUE (self$family != "ordinal"))) {#nolint
          msg <- paste("Only ordinal regression supports ordering!")
          flog.error(msg)
          stop(msg)
        }
        ordering <- validateInput("ordering", unlist(ordering), "character")
        if (any(sapply(ordering, grepl, pattern = ","))){
          msg <- paste("Input list of characters for ordering",
                       "contains invalid symbol ','.")
          flog.error(msg)
          stop(msg)
        }
        self$ordering <- paste(ordering, collapse = ", ")
        self$enet.alpha <- validateInput("enet.alpha", enet.alpha, "double")
        self$enet.lambda <- validateInput("enet.lambda", enet.lambda, "double")
        self$resampling.method <- validateInput("resampling.method",
                                                resampling.method,
                                                list(cv = "cv",
                                                     bootstrap = "bootstrap"))
        self$evaluation.metric <-
          validateInput("evaluation.metric",
                        evaluation.metric,
                        list(rmse = "RMSE",
                             mae = "MAE",
                             error_rate = "ERROR_RATE"),
                        required = isTRUE(!is.null(self$resampling.method)))
        self$repeat.times <- validateInput("repeat.times",
                                           repeat.times,
                                           "integer")
        self$fold.num <-
          validateInput("fold.num", fold.num, "integer",
                        required = isTRUE(self$resampling.method == "cv"))
        self$param.search.strategy <-
          validateInput("param.search.strategy",
                        param.search.strategy,
                        list(grid = "grid",
                             random = "random"))
        self$random.search.times <-
          validateInput("random.search.times", random.search.times, "integer",
                        required = isTRUE(self$param.search.strategy == "random"))
        self$random.state <- validateInput("random.state",
                                           random.state,
                                           "integer")
        self$timeout <- validateInput("timeout", timeout, "integer")
        self$progress.indicator.id <- validateInput("progress.indicator.id",
                                                    progress.indicator.id,
                                                    "character")
        if (length(parameter.values) != 0){
          validateInput("Parameters for value specification",
                        names(parameter.values),
                        list("link", "enet.lambda", "enet.alpha"),
                        case.sensitive = TRUE)
        }
        if (length(parameter.range) != 0){
          validateInput("Parameters for range specification",
                        names(parameter.range),
                        list("enet.lambda", "enet.alpha"),
                        case.sensitive = TRUE)
        }
        self$parameter.range <- parameter.range
        self$parameter.values <- parameter.values
        cols <- data$columns
        # obtain key columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        param.rows <- append(param.rows,
                             list(tuple("HAS_ID",
                                        as.integer(!is.null(key)),
                                        NULL, NULL)))

        # obtain features and label
        if (!is.null(label)){
          # check label
          label <- validateInput("label", label, cols,
                                 case.sensitive = TRUE)
          cols <- cols[! cols %in% label]
        }
        # set default value
        if (is.null(label)){
          if (isTRUE(family == "binomial")){
            if (!is.null(key)){
              label <- cols[2:3]
              cols <- cols[! cols %in% label]
            } else {
              label <- cols[1:2]
              cols <- cols[! cols %in% label]
            }
            if (is.null(features)){
              features <- cols
            }
          } else {
            if (!is.null(key)){
              label <- cols[2]
              cols <- cols[! cols %in% label]
            } else {
              label <- cols[1]
              cols <- cols[! cols %in% label]
            }
            if (is.null(features)){
              features <- cols
            }
          }
        } else {
          cols <- cols[! cols %in% label]
          if (is.null(features)){
            features <- cols
          }
        }
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        # check non-binomial and label relationship
        if (isTRUE(self$family != "binomial") && (length(label) != 1)) {
          msg <- paste("When family is not 'binomial',",
                      "there is a single column of label!")
          flog.error(msg)
          stop(msg)
        }

        # check binomial and label relationship
        if (isTRUE(self$family == "binomial") && (length(label) != 2)) {
          msg <- paste("when binomial distribution is used,",
                       "it requres to have two columns of labels!")
          flog.error(msg)
          stop(msg)
        }
        # selected columns to obtain the data to call PAL
        if (!is.null(key)){
          id.col <- list(key)
          selected <- c(c(id.col, label), features)
        } else {
          selected <- c(label, features)
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        data <- data$Select(selected)

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#GLM_PARAM_TBL_%s_%s", self$id, unique.id)
        coef.tbl <- sprintf("#GLM_COEF_TBL_%s_%s", self$id, unique.id)
        fit.tbl <- sprintf("#GLM_FIT_TBL_%s_%s", self$id, unique.id)
        stat.tbl <- sprintf("#GLM_STAT_TBL_%s_%s", self$id, unique.id)
        covmat.tbl <- sprintf("#GLM_COVMAT_TBL_%s_%s", self$id, unique.id)
        tables <-
          list(param.tbl, stat.tbl, coef.tbl, covmat.tbl, fit.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(stat.tbl, coef.tbl,
                           covmat.tbl, fit.tbl)

        if (isTRUE(length(label) == 2)){
          response.value <- 1
        }
        else{
          response.value <- 0
        }

        param.rows.extended <- list(
          tuple("FAMILY", NULL, NULL, self$family),
          tuple("LINK", NULL, NULL, self$link),
          tuple("SOLVER", NULL, NULL, self$solver),
          tuple("HANDLE_MISSING",
                map.null(self$handle.missing.fit, self$handle.missing.fit.map),
                NULL, NULL),
          tuple("GROUP_RESPONSE", response.value, NULL, NULL),
          tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
          tuple("CONVERGENCE_CRITERION", NULL, self$tol, NULL),
          tuple("SIGNIFICANCE_LEVEL", NULL, self$significance.level, NULL),
          tuple("ENET_ALPHA", NULL, self$enet.alpha, NULL),
          tuple("ENET_LAMBDA", NULL, self$enet.lambda, NULL),
          tuple("ENET_NUM_LAMBDA", self$num.lambda, NULL, NULL),
          tuple("LAMBDA_MIN_RATIO", NULL, self$lambda.min.ratio, NULL),
          tuple("ORDERING", NULL, NULL, self$ordering),
          tuple("QUASI", to.integer(self$quasilikelihood), NULL, NULL),
          tuple("OUTPUT_FITTED", to.integer(self$output.fitted), NULL, NULL),
          tuple("RESAMPLING_METHOD", NULL, NULL, self$resampling.method),
          tuple("PARAM_SEARCH_STRATEGY", NULL, NULL, self$param.search.strategy),
          tuple("FOLD_NUM", self$fold.num, NULL, NULL),
          tuple("REPEAT_TIMES", self$repeat.times, NULL, NULL),
          tuple("TIMEOUT", self$timeout, NULL, NULL),
          tuple("RANDOM_SEARCH_TIMES", self$random.search.times, NULL, NULL),
          tuple("SEED", self$random.state, NULL, NULL),
          tuple("PROGRESS_INDICATOR_ID", NULL, NULL, self$progress.indicator.id))

        param.rows <- append(param.rows, param.rows.extended)

        if (!is.null(self$evaluation.metric)){
          temp <- tuple("EVALUATION_METRIC", NULL, NULL,
                        toupper(self$evaluation.metric))
          param.rows <- append(param.rows, list(temp))
        }

        if (!is.null(self$categorical.variable)) {
          for (each in self$categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
            param.rows <- append(param.rows, tuple(temp.list))
          }
        }

        if (isTRUE(self$family != "binomial") || response.value != 1){
          temp <- tuple("DEPENDENT_VARIABLE", NULL, NULL, label)
          param.rows <- append(param.rows, list(temp))
        }
        if (length(self$parameter.values) > 0){
          for (i in 1:length(self$parameter.values)){
            param.name <- gsub("\\.", "_",
                               toupper(names(self$parameter.values[i])))
            par.val <- self$parameter.values[[i]]
            if (param.name == "LINK"){
              validateInput("Link values", par.val, links,
                            case.sensitive = TRUE)
              str.values <- paste("{\"",
                                  paste0(par.val,
                                         collapse = "\",\""),
                                  "\"}", sep = "")
            } else {
              str.values <- paste("{",
                                  paste0(par.val,
                                         collapse = ","),
                                  "}", sep = "")
            }
            temp.tup <- tuple(paste0(param.name, "_VALUES"),
                              NULL, NULL, str.values)
            param.rows <-
              append(param.rows, list(temp.tup))
          }
        }
        if (length(self$parameter.range) > 0){
          for (i in 1:length(self$parameter.range)){
            param.name <- gsub("\\.", "_",
                               toupper(names(self$parameter.range[i])))
            range.temp <- self$parameter.range[[i]]
            cps <- ifelse(length(range.temp) == 2, ",,", ",")
            str.range <- paste("[",
                               paste0(range.temp,
                                      collapse = cps),
                               "]", sep = "")
            temp.tup <- tuple(paste0(param.name, "_RANGE"),
                              NULL, NULL, str.range)
            param.rows <-
              append(param.rows, list(temp.tup))
          }
        }
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
                      ParameterTable$new(param.tbl)$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn.context,
                                                "PAL_GLM",
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$statistics <- conn.context$table(stat.tbl)
        self$coefficients <- conn.context$table(coef.tbl)
        self$covariance <- conn.context$table(covmat.tbl)
        self$fitted <- conn.context$table(fit.tbl)
        self$model <- list(self$statistics,
                           self$coefficients,
                           self$covariance)
      }
    },
    score = function(data, key, features = NULL, label = NULL,
                     prediction.type=NULL, handle.missing=NULL){
      if (isTRUE(self$family == "ordinal")){
        msg <- "Can't compute R2 for ordinal regression."
        flog.error(msg)
        stop(msg)
      }
      #check key, label, features overlap
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      cols <- cols[! cols %in% features]
      label <- validateInput("label", label, cols,
                             case.sensitive = TRUE)
      prediction <- predict(self, data, key = key,
                            features = features,
                            prediction.type = prediction.type,
                            handle.missing = handle.missing)
      result.cols <- prediction$columns
      selected.cols <- list(result.cols[[1]], result.cols[[2]])
      prediction <- prediction$Select(selected.cols)
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      r2.score <- r2.score(data$connection.context,
                           joined,
                           label.true = "ACTUAL",
                           label.pred = "PREDICTION")
      return(r2.score)
    }
  )
)
#' @title  Generalized Linear Model
#' @name hanaml.GLM
#' @description hanaml.GLM is a R wrapper for SAP HANA PAL Generalized Linear Model.
#' @seealso  \code{\link{predict.GLM}}
#' @template args-data
#' @template args-key
#' @template args-feature-multiple
#' @template args-label
#' @param    family \code{character, optional}\cr
#'  The kind of distribution the dependent variable outcomes are
#'  assumed to be drawn from. Must be one of the following:
#'\itemize{
#'   \item{'gaussian'}
#'   \item{'poisson'}
#'   \item{'binomial'}
#'   \item{'gamma'}
#'   \item{'inversegaussian'}
#'   \item{'negativebinomial'}
#'   \item{'ordinal'}
#'}
#'Defaults to 'gaussian'.
#' @param  link \code{character, optional}\cr
#'        GLM link function. Determines the relationship between the linear
#'        predictor and the predicted response. Default and allowed values
#'        depend on \emph{family}. 'inverse' is accepted as a synonym of
#'        reciprocal'.
#'\itemize{
#'   \item{\code{gaussian(family)}, identity(default), {identity, log, reciprocal}
#'        (allowed)}
#'   \item{\code{poisson(family)}, log(default), {identity, log}(allowed)}
#'   \item{\code{binomial(family)}, logit(default), {logit, probit, comploglog, log}
#'        (allowed)}
#'   \item{\code{gamma(family)}, reciprocal(default), {identity, reciprocal, log}(allowed)}
#'   \item{\code{inversegaussian(family)}, inversesquare(default), {inversesquare,
#'         identity, reciprocal, log}(allowed)}
#'   \item{\code{negativebinomial(family)}, log(default), {identity, log, sqrt}(allowed)}
#'   \item{\code{ordinal(family)}, logit(default), {logit, probit, comploglog}(allowed)}}
#' @param     solver \code{("irls","nr","cd"), optional}\cr
#'      The Optimization algorithm.
#'\itemize{
#'   \item{"irls"} Iteratively re-weighted least squares.
#'   \item{"nr"} Newton-Raphson.
#'   \item{"cd"} Coordinate descent. (Picking coordinate descent activates
#' elastic net regularization.)
#' }
#' Defaults to "irls", except when \emph{family} is "ordinal".
#' Ordinal regression requires (and defaults to) "nr", and Newton-Raphson
#' is not supported for other values of \emph{family}.
#' @param      handle.missing.fit \code{("skip", "abort", "fill_zero"), optional}\cr
#'            How to handle data rows with missing independent variable values
#'            during fitting.
#' \itemize{
#'   \item{"skip"} Don't use those rows for fitting
#'   \item{"abort"} Throw an error if missing independent variable values
#'                are found.
#'   \item{"fill_zero"} Replace missing values with 0.
#' }
#'  Defaults to "skip".
#' @param     quasilikelihood \code{logical, optional}\cr
#'            If TRUE, enables the use of quasi-likelihood to estimate overdispersion.
#'            Defaults to FALSE.
#' @param     max.iter \code{integer, optional}\cr
#'            Maximum number of optimization iterations. \cr
#'            Defaults to 100 for IRLS
#'            and Newton-Raphson. Defaults to 100000 for coordinate descent.
#' @param     tol \code{double, optional}\cr
#'            Stopping condition for optimization. \cr
#'            Defaults to 1e-8 for IRLS,
#'            1e-6 for Newton-Raphson, and 1e-7 for coordinate descent.
#' @param     significance.level \code{double, optional}\cr
#'            Significance level for confidence intervals and prediction intervals.\cr
#'            Defaults to 0.05.
#' @param     output.fitted \code{logical, optional}\cr
#'            If TRUE, create the `fitted_` DataFrame of fitted response values
#'            for training data in fit.\cr
#'            Defaults to FALSE.
#' @param     alpha \code{numeric, optional(deprecated)}\cr
#'            Elastic net mixing parameter. Only accepted when using coordinate
#'            descent. Should be between 0 and 1 inclusive. Defaults to 1.0.\cr
#'            Will be replaced by \code{enet.alpha} in future release.
#' @param     lambda \code{numeric, optional(deprecated)}\cr
#'            Coefficient for L1 and L2 regularization.\cr
#'            No default value.
#'            Will be replaced by \code{enet.lambda} in future release.
#' @param      num.lambda \code{integer}\cr
#'            The number of lambda values. Only accepted when using coordinate
#'            descent. \cr
#'            Defaults to 100.
#' @param     lambda.min.ratio \code{double, optional}\cr
#'            The smallest value of lambda, as a fraction of the maximum lambda,
#'            where lambda_max is the smallest value for which all coefficients
#'            are zero. Only accepted when using coordinate descent. \cr
#'            Defaults to 0.01 when the number of observations is smaller than the number
#'            of covariates, and 0.0001 otherwise.
#' @template args-cate-var
#' @param     ordering \code{list of characters, optional}\cr
#'            Specifies the (ascending)order of categories for ordinal regression.\cr
#'            Applicable only when the label column for ordinal regression is string-valued.\cr
#'            By default, numeric order is adopted for integer values and alphabetical order adopted for
#'            strings.
#' @param     enet.alpha \code{numeric, optional}\cr
#'            Elastic net mixing parameter. Only accepted when using coordinate
#'            descent. Should be between 0 and 1 inclusive. \cr
#'            Defaults to 1.0.
#' @param     enet.lambda \code{numeric, optional}\cr
#'            Coefficient for L1 and L2 regularization.\cr
#'            No default value.
#' @param     resampling.method   \code{c("cv", "bootstrap"), optional}\cr
#'            Specifies the resampling values form below list.\cr
#'            If no value is specifier, neither model evaluation
#'            nor parameter selection is activated.
#' @param     evaluation.metric   \code{c("rmse", "mae", "error_rate"), optional}\cr
#'            Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'            Mandatory for activating model evaluation and parameter selection.
#' @param     fold.num \code{integer, optional}\cr
#'            Specifies the fold number for the cross-validation(cv).
#'            Mandatory and valid only when \code{resampling.method} is 'cv'.
#' @template args-crossvalidation-group
#' @param     parameter.range   \code{list, optional}\cr
#'            Specifies range of the following parameters for parameter selection:\cr
#'            \code{enet.lambda, enet.alpha}.\cr
#'            Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'            Examples:\cr
#'            parameter.range <- list(enet.lambda = c(0.01, 0.01, 0.1)), which means taking
#'            \code{enet.lambda} values from 0.01 to 0.1 with 0.01 being the step size, i.e.
#'            0.01, 0.02, 0.03, ..., 0.09, 0.1.\cr
#'            If \code{param.search.strategy} is 'random', then the middle term,
#'            i.e. step has no effect and thus can be omitted.
#' @param     parameter.values   \code{list, optional}\cr
#'            Specifies values of the following parameters for parameter selection:\cr
#'            \code{enet.lambda, enet.alpha}.\cr
#'            Example: parameter.values <- list(enet.lambda = c(0.001, 0.003, 0.007, 0.01))
#'
#' @return
#' A "GLM" object with the following attributes:
#' \itemize{
#'   \item{statistics: \code{DataFrame}}\cr
#'         Training statistics and model information other than the
#'         coefficients and covariance matrix.
#'   \item{coefficients: \code{DataFrame}}\cr
#'         Model coefficients.
#'   \item{covariance: \code{DataFrame}}\cr
#'         Covariance matrix. Set to NULL for coordinate descent.
#'   \item{fitted: \code{DataFrame}}\cr
#'         Predicted values for the training data. Set to NULL if
#'         \emph{output.fitted} is FALSE.
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    ID  X  Y
#' 1   1  0 -1
#' 2   2  0 -1
#' 3   3  1  0
#' 4   4  1  0
#' 5   5  1  0
#' 6   6  1  0
#' 7   7  2  1
#' 8   8  2  1
#' 9   9  2  1
#' }
#' Call the function:
#' \preformatted{
#' > glm <- hanaml.GLM(data = data, key = "ID", label = "Y", features = "X",
#'                     solver = "irls", output.fitted = TRUE,
#'                     family = "poisson", link = "log")
#' }
#'
#' Output:
#' \preformatted{
#' > glm$coefficients$Collect()
#'   VARIABLE_NAME COEFFICIENT        SE      SCORE PROBABILITY    CI_LOWER   CI_UPPER
#' 1 __PAL_INTCP__  -0.2949583 0.4530004 -0.6511215  0.51496806 -1.18282271  0.5929061
#' 2             X   1.0698198 0.5405998  1.9789496  0.04782168  0.01026362  2.1293760
#' }
#' @keywords Regression
#' @export
hanaml.GLM <- function(data=NULL,
                       key=NULL,
                       features=NULL,
                       label=NULL,
                       family=NULL,
                       link=NULL,
                       solver=NULL,
                       handle.missing.fit=NULL,
                       quasilikelihood=NULL,
                       max.iter=NULL,
                       tol=NULL,
                       significance.level=NULL,
                       output.fitted=NULL,
                       alpha=NULL,
                       lambda=NULL,
                       num.lambda=NULL,
                       lambda.min.ratio=NULL,
                       categorical.variable=NULL,
                       ordering=NULL,
                       enet.alpha=NULL,
                       enet.lambda=NULL,
                       resampling.method = NULL,
                       evaluation.metric = NULL,
                       fold.num = NULL,
                       repeat.times = NULL,
                       param.search.strategy = NULL,
                       random.search.times = NULL,
                       random.state = NULL,
                       timeout = NULL,
                       progress.indicator.id = NULL,
                       parameter.range = NULL,
                       parameter.values = NULL){
  GLM$new(data, key, features, label, family, link, solver,
          handle.missing.fit, quasilikelihood, max.iter, tol, significance.level,
          output.fitted, alpha, lambda, num.lambda, lambda.min.ratio,
          categorical.variable, ordering,
          enet.alpha, enet.lambda,
          resampling.method,
          evaluation.metric,
          fold.num,
          repeat.times,
          param.search.strategy,
          random.search.times,
          random.state,
          timeout,
          progress.indicator.id,
          parameter.range,
          parameter.values)
}


#' @title Make Predictions from a "GLM" Object
#' @name predict.GLM
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "GLM" object.
#' @seealso \code{\link{hanaml.GLM}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A "GLM" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param prediction.type \code{character, optional}\cr
#' Specifies whether to output predicted values of the
#' response or the link function. \cr
#' Defaults to 'response'.
#' @param significance.level \code{double, optional}\cr
#' Significance level for confidence intervals and prediction
#' intervals. If specified, overrides the value passed to the
#' GLM constructor.\cr
#' @param handle.missing \code{("remove", "fill_zero"), optional}\cr
#'  How to handle data rows with missing independent variable values.
#'\itemize{
#'   \item{"remove"} Remove missing rows.
#'   \item{"fill_zero"} Replace missing values with 0.
#'}
#'Defaults to "remove".
#'
#' @return Dataframe
#' Predicted values, structured as follows. The following two
#' columns are always populated:
#' \itemize{
#'    \item{ID column, with same name and type as \emph{data}'s ID column.}
#'    \item{PREDICTION, type NVARCHAR(100), representing predicted values.}
#' }
#' The following five columns are only populated for IRLS:
#' \itemize{
#'   \item{SE, type DOUBLE. Standard error, or for ordinal regression,
#'   the probability that the data point belongs to the predicted category.}
#'   \item{CI_LOWER, type DOUBLE. Lower bound of the confidence interval.}
#'   \item{CI_UPPER, type DOUBLE. Upper bound of the confidence interval.}
#'   \item{PI_LOWER, type DOUBLE. Lower bound of the prediction interval.}
#'   \item{PI_UPPER, type DOUBLE. Upper bound of the prediction interval.}
#'}
#' @section Examples:
#' DataFrame data2 for prediction:
#' \preformatted{
#' > data2$Collect()
#'     ID  X
#' 1   1 -1
#' 2   2  0
#' 3   3  1
#' 4   4  2
#' }
#' Call the function and obtain the result:
#' \preformatted{
#' > predict(glm, data2, key="ID")$Collect()
#'     ID          PREDICTION
#' 1   1  0.25543735346197155
#' 2   2    0.744562646538029
#' 3   3   2.1702915689746476
#' 4   4     6.32608352871737
#' }
#' @keywords Regression
#' @export
predict.GLM <- function(model, data, key, features = NULL,
                        prediction.type = NULL,
                        significance.level = NULL,
                        handle.missing = NULL){

  if (is.null(model$model)){
    msg <- "Model of GLM is NULL!"
    flog.error(msg)
    stop(msg)
  }

  type.list <- list ("response", "link")
  if (!is.null(prediction.type)) {
    if (isTRUE(model$family == "ordinal")) {
      msg <- "prediction.type is not for ordinal regression!"
      flog.error(msg)
      stop(msg)
    }
    prediction.type <- validateInput("prediction.type", prediction.type,
                                     type.list)
  }

  handle.missing.map <- list(remove = 1, fill_zero = 2)
  handle.missing <- validateInput("handle.missing", handle.missing,
                                  model$handle.missing.map)

  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE,
                       case.sensitive = TRUE)
  cols <- cols[! cols %in% key]

  if (!is.null(significance.level)){
   significance.level <- validateInput("significance.level",
                                       significance.level,
                                       "double")
  }

  if (!is.null(features)){
    features <- validateInput("features", features, cols,
                              case.sensitive = TRUE)
  } else {
    features <- cols
  }

  selected <- list(key)
  selected <- append(selected, features)
  CheckConnection(data)
  conn.context <- data$connection.context
  data <- data$Select(selected)
  unique.id <-
    toupper(gsub("-", "_", UUIDgenerate()))  #require UUID package
  param.tbl <- sprintf("#PAL_GLM_PREDICT_PARAM_TBL_%s_%s",
                       model$id, unique.id)#nolint
  result.tbl <- sprintf("#PAL_GLM_RESULT_TBL_%s_%s", model$id, unique.id)

  model$statistics <- model$model[[1]]
  model$coefficients <- model$model[[2]]
  model$covariance <- model$model[[3]]

  tables <- list(param.tbl, result.tbl)
  in.tables <- list(data, model$statistics$name, model$coefficients$name,
                    model$covariance$name, param.tbl)
  out.tables <- list(result.tbl)
  param.rows <- list(tuple("TYPE", NULL, NULL, prediction.type),
                     tuple("SIGNIFICANCE_LEVEL", NULL,
                           significance.level, NULL),
                     tuple("HANDLE_MISSING",
                           map.null(handle.missing,
                                    model$handle.missing.map),
                           NULL, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
      (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
    errorhelper(CallPalAutoWithConnection(conn.context,
      "PAL_GLM_PREDICT", in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return (conn.context$table(result.tbl))
}

#' @export
print.GLM <- function(x, ...){
  writeLines(paste("Attributes of the GLM object for model training:"))
  writeLines(paste("(NULL indicates none provided by user",
                   "and internal defaults are used)"))
  writeLines("\n")
  writeLines("GLM attributes:")
  cat(sprintf("family : %s", to.null(x$family)))
  writeLines("\n")
  cat(sprintf("link : %s", to.null(x$link)))
  writeLines("\n")
  cat(sprintf("solver : %s", to.null(x$solver)))
  writeLines("\n")
  cat(sprintf("handle.missing.fit : %s", to.null(x$handle.missing.fit)))
  writeLines("\n")
  cat(sprintf("quasilikelihood : %s", to.null(x$quasilikelihood)))
  writeLines("\n")
  cat(sprintf("max.iter : %s", to.null(x$max.iter)))
  writeLines("\n")
  cat(sprintf("tol : %s", to.null(x$tol)))
  writeLines("\n")
  cat(sprintf("significance.level : %s", to.null(x$significance.level)))
  writeLines("\n")
  cat(sprintf("output.fitted : %s", to.null(x$output.fitted)))
  writeLines("\n")
  cat(sprintf("alpha : %s", to.null(x$alpha)))
  writeLines("\n")
  cat(sprintf("lambda : %s", to.null(x$lambda)))
  writeLines("\n")
  cat(sprintf("num.lambda : %s", to.null(x$num.lambda)))
  writeLines("\n")
  cat(sprintf("lambda.min.ratio : %s", to.null(x$lambda.min.ratio)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("ordering : %s", to.null(x$ordering)))
  writeLines("\n")
}

#' @export
summary.GLM <- function(object, ...){
  writeLines("Model Attributes DataFrame : Coef, covariance Predication, Statistics")
  writeLines("-----------------------")
  writeLines("coefficients DataFrame")
  writeLines("-----------------------")
  cat("\n")
  if (!is.null(object$model)) {
    writeLines("GLM coefficients DataFrame:")
    writeLines("\n")
    print(object$coefficients$Collect())
    writeLines("\n")
    writeLines("GLM covariance DataFrame:")
    print(object$covariance$Collect())
    writeLines("\n")
    writeLines("GLM fitted DataFrame:")
    print(object$fitted$Collect())
    writeLines("\n")
    writeLines("GLM statistics DataFrame:")
    print(object$statistics$Collect())
    writeLines("\n")
  } else {
    print("Please create a GLM object first!")
  }
}
