#' @title Partition
#' @description hanaml.Partition is a R wrapper for SAP HANA PAL Partition algorithm.
#' @name hanaml.Partition
#' @template args-data
#' @template args-key
#' @template args-feature-multiple
#' @param random.state \code{integer, optional}\cr
#' Indicates the seed used to initialize the random number generator.
#' \itemize{
#'   \item{\code{0}}: Uses the system time
#'   \item{\code{Not 0}}: Uses the specified seed
#' }
#' Defaults to 0.
#' @template args-threadratio
#' @param method \code{character, optional}\cr
#' Partition method used for splitting dataset into train, test and validation sets:\cr
#' \itemize{
#'    \item{\code{"random"}}: random partitions
#'    \item{\code{"stratified"}}: stratified partition
#' }
#' Defaults to "random".
#' @param stratified.column \code{character, optional}\cr
#' Indicates which column is used for stratification in the partition process.\cr
#' Required and valid only when \code{method} is set to 'stratified'
#' (stratified partition).\cr
#'  No default value.
#' @param split.ratio \code{list of double, optional}\cr
#' List of 3 numerical numbers that specifies the percent of data used for training, testing
#' and validation respectively.\cr
#' If both \emph{split.ratio} and \emph{split.size} are specified, split.ratio takes precedence.\cr
#' If not provided, defaults to c(0.8, 0.1, 0.1), i.e. 80 percent data used for training,
#' 10 percent data used for testing and 10 percent data used for validation.
#' @param split.size \code{list of integers, optional}\cr
#' List of 3 integers that specifies the number of rows in \emph{data} used for training, testing
#' and validation respectively.\cr
#' If both \emph{split.ratio} and \emph{split.size} are specified, \code{split.ratio} takes precedence.\cr
#' No default value.
#' @return
#' \code{List of DataFrames}\cr
#' DataFrames for training, testing and validation, arranged in the following order:\cr
#' \itemize{
#'   \item{DataFrame 1:} training,
#'   \item{DataFrame 2:} testing,
#'   \item{DataFrame 3:} validation.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$collect()
#'    ID HomeOwner MaritalStatus AnnualIncome DefaultedBorrower
#' 1   0       YES        Single          125                NO
#' 2   1        NO       Married          100                NO
#' 3   2        NO        Single           70                NO
#' 4   3       YES       Married          120                NO
#' 5   4        NO      Divorced           95               YES
#' ...
#' 28 27        NO        Single           85               YES
#' 29 28        NO       Married           75               YES
#' 30 29        NO        Single           90               YES
#' }
#' Call the function:
#' \preformatted{
#' > partition <- hanaml.Partition(data,
#'                                 random.state = 23,
#'                                 method = "random",
#'                                 split.ratio = c(0.6, 0.2, 0.2))
#' }
#' Output:
#' \preformatted{
#' > partition[[1]]$Collect()
#'     ID HomeOwner MaritalStatus AnnualIncome DefaultedBorrower
#'  1   0       YES        Single          125                NO
#'  2   1        NO       Married          100                NO
#'  3   3       YES       Married          120                NO
#'  4   5        NO       Married           60                NO
#'  5   7        NO        Single           85               YES
#'  6  10       YES        Single          125                NO
#'  7  12        NO        Single           70                NO
#'  8  13       YES       Married          120                NO
#'  9  17        NO        Single           85               YES
#'  10 18        NO       Married           75                NO
#'  11 21        NO       Married          100                NO
#'  12 22        NO        Single           70                NO
#'  13 23       YES       Married          120                NO
#'  14 24        NO      Divorced           95               YES
#'  15 25        NO       Married           60                NO
#'  16 27        NO        Single           85               YES
#'  17 28        NO       Married           75               YES
#'  18 29        NO        Single           90               YES
#' }
#' @keywords Preprocessing
#' @export
hanaml.Partition <- function(data,
                             key,
                             features = NULL,
                             random.state = NULL,
                             thread.ratio = NULL,
                             method = NULL,
                             stratified.column = NULL,
                             split.ratio = NULL,
                             split.size = NULL) {
  partition.method.map <- list(random = 0, stratified = 1)
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
  method <- validateInput("method", method, partition.method.map)
  random.state <- validateInput("random.state", random.state, "integer")
  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
  cols <- cols[! cols %in% key]
  stratified.column <-
    validateInput("stratified.column", stratified.column, cols,
                  case.sensitive = TRUE)
  if (isTRUE(!is.null(stratified.column) &&
      (method == "random" || is.null(method)))) {
    msg <- paste("`stratified.column` valid only when partition method is",
                 "set to 'stratified'.")
    flog.error(msg)
    stop(msg)
  }
  features <- validateInput("features", features, cols, case.sensitive = TRUE)
  if (length(features) == 0){
    features <- cols
  }
  if (!is.null(split.ratio)){
    split.ratio <- unlist(split.ratio)
    if (!(is.numeric(split.ratio) && all(split.ratio >= 0) &&
          sum(split.ratio) == 1.0 && length(split.ratio) == 3)){
      msg <- paste("`split.ratio` must be a list of 3 non-negative",
                   "numbers that sum to 1.")
      flog.error(msg)
      stop(msg)
    }
  } else if (is.null(split.ratio) && !is.null(split.size)){
    split.size <- unlist(split.size)
    nsp <- data$nrows
    if (!( (is.numeric(split.size) &&
            all(round(split.size) == split.size) ||
            is.integer(split.size)) && length(split.size) == 3 &&
           all(split.size >= 1) && sum(split.size) == nsp)){
      msg <- paste("`split.size` must be a list of 3 positive integers that",
                   "sum to the number of rows in `data`.")
      flog.error(msg)
      stop(msg)
    }
  }
  cols <- data$columns
  CheckConnection(data)
  conn <- data$connection.context
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }

  data <- data$Select(c(key, features))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_PARTITION_PARAMETER_TBL_%s", unique.id)
  output.tbl <- sprintf("#PAL_PARTITION_OUTPUT_TBL_%s", unique.id)
  tables <- list(param.tbl, output.tbl)
  in.tables <- list(data, param.tbl)
  out.tables <- list(output.tbl)

  param.array <- list(
    tuple("THREAD_RATIO",  NULL, thread.ratio, NULL),
    tuple("PARTITION_METHOD",
          map.null(method, partition.method.map),
          NULL, NULL),
    tuple("RANDOM_SEED", random.state, NULL, NULL),
    tuple("STRATIFIED_COLUMN", NULL, NULL, stratified.column)
  )
  if (length(split.ratio) != 0){
    param.array <- append(param.array,
                          list(tuple("TRAINING_PERCENT",
                                     NULL,
                                     split.ratio[[1]],
                                     NULL),
                               tuple("TESTING_PERCENT",
                                     NULL,
                                     split.ratio[[2]],
                                     NULL),
                               tuple("VALIDATION_PERCENT",
                                     NULL,
                                     split.ratio[[3]],
                                     NULL)))
  } else if (length(split.size) != 0) {
    param.array <- append(param.array,
                          list(tuple("TRAINING_SIZE",
                                     split.size[[1]],
                                     NULL, NULL),
                               tuple("TESTING_SIZE",
                                     split.size[[2]],
                                     NULL, NULL),
                               tuple("VALIDATION_SIZE",
                                     split.size[[3]],
                                     NULL, NULL)))
  }
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
               (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_PARTITION",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return.list <- list()
  for (i in c(1:3)){
    df.string <- paste(sprintf("SELECT * FROM (%s)",
                               data$select.statement),
                       sprintf("WHERE %s IN (SELECT",
                               QuoteName(key)),
                       sprintf("%s FROM %s WHERE PARTITION_TYPE = %s)",
                               QuoteName(key),
                               output.tbl, i))
    return.list <- append(return.list, conn$sql(df.string))
  }
  return(return.list)
}
