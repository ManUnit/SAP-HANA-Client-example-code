DecisionTreeBase <- R6Class(
  "DecisionTreeBase",
  inherit = MlBase,
  public = list(
    algorithm = NULL,
    thread.ratio = NULL,
    allow.missing.dependent = NULL,
    percentage = NULL,
    min.records.of.parent = NULL,
    min.records.of.leaf = NULL,
    max.depth = NULL,
    categorical.variable = NULL,
    split.threshold = NULL,
    use.surrogate = NULL,
    model.format = NULL,
    output.rules = NULL,
    output.confusion.matrix = NULL,
    evaluation.metric = NULL,
    parameter.range = NULL,
    parameter.values = NULL,
    resampling.method = NULL,
    repeat.times = NULL,
    fold.num = NULL,
    param.search.strategy = NULL,
    random.search.times = NULL,
    timeout = NULL,
    progress.indicator.id = NULL,
    priors = NULL,
    model = NULL,
    decision.rules = NULL,
    confusion.matrix = NULL,
    statistics = NULL,
    cv = NULL,
    algorithm.map = list(
      "c45" = 1,
      "chaid" = 2,
      "cart" = 3
    ),
    model.format.map = list("json" = 1,
                            "pmml" = 2),
    discretization.type.map = list(mdlpc = 0,
                                   equal_freq = 1),
    metric.list = list(rmse = "RMSE", mae = "MAE",
                       error_rate = "ERROR_RATE",
                       nll = "NLL", auc = "AUC"),
    search.strategy.list = list("grid", "random"),
    resampling.method.list = list("cv", "stratified_cv",
                                  "bootstrap",
                                  "stratified_bootstrap"),
    initialize = function(algorithm,
                          thread.ratio = NULL,
                          allow.missing.dependent = NULL,
                          percentage = NULL,
                          min.records.of.parent = NULL,
                          min.records.of.leaf = NULL,
                          max.depth = NULL,
                          categorical.variable = NULL,
                          split.threshold = NULL,
                          use.surrogate = NULL,
                          model.format = NULL,
                          output.rules = NULL,
                          output.confusion.matrix = NULL,
                          evaluation.metric = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL,
                          resampling.method = NULL,
                          repeat.times = NULL,
                          fold.num = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL){
      super$initialize()
      if (!is.null(data)){
        if (is.null(algorithm)) {
          msg <-
            sprintf("Algorithm should be provided. The valid values are C45, chaid and CART ")
          flog.error(msg)
          stop(msg)
        } else {
          if (!is.character(algorithm)) {
            msg <-
              sprintf("Algorithm name should be a character. Valid values are C45, chaid and CART")
            flog.error(msg)
            stop(msg)
          }
        }
        algorithm.lower <- sapply(algorithm, tolower)[[1]]
        if (is.null(self$algorithm.map[[algorithm.lower]])) {
          if (self$tree.type == "Classifier"){
            msg <- "Invalid algorithm value provided. Valid algorithms for classification are c45, cart or Chaid"
          } else if (self$tree.type == "Regressor") {
            msg <- "Invalid algorithm value provided. Valid algorithms for regressor is cart"
          }
          flog.error(msg)
          stop(msg)
        } else {
          self$algorithm <- algorithm.lower
        }
        self$thread.ratio <-
          validateInput("thread.ratio", thread.ratio, "numeric", required = FALSE)
        self$allow.missing.dependent <-
          validateInput("allow.missing.dependent",
                        allow.missing.dependent,
                        "logical")
        self$percentage <-
          validateInput("percentage", percentage, "numeric", required = FALSE)
        self$min.records.of.parent <-
          validateInput("min.records.of.parent", min.records.of.parent, "integer")
        self$min.records.of.leaf <-
          validateInput("min.records.of.leaf", min.records.of.leaf, "integer")
        self$max.depth <-
          validateInput("max.depth", max.depth, "integer")
        if (!is.null(categorical.variable) &&
            typeof(categorical.variable) == "character")  {
          categorical.variable <- as.list(categorical.variable)
        }
        self$categorical.variable <-
          validateInput("categorical.variable", categorical.variable, "LISTOFSTRINGS")
        self$split.threshold <-
          validateInput("split.threshold", split.threshold, "double")
        if (!is.null(use.surrogate)) {
          if (self$algorithm != "cart") {
            msg <-
              "use.surrogate parameter is only applicable when algorithm is cart."
            flog.error(msg)
            stop(msg)
          }
          self$use.surrogate <-
            validateInput("use.surrogate", use.surrogate, "logical")
        } else {
          self$use.surrogate <- TRUE
        }
        if (!is.null(model.format)) {
          model.format.lower <- sapply(model.format, tolower)[[1]]
          if (is.null(self$model.format.map[[model.format.lower]])) {
            value <- (self$model.format.map[[model.format.lower]])
            msg <-
              "Invalid model format, valid model formats include pmml and json "
            flog.error(msg)
            stop(msg)
          }
          self$model.format <- model.format.lower
        }
        self$output.rules <-
          validateInput("output.rules", output.rules, "logical")
        self$resampling.method <- validateInput("resampling.method",
                                                resampling.method,
                                                self$resampling.method.list,
                                                case.sensitive = TRUE)
        self$repeat.times <- validateInput("repeat.times",
                                           repeat.times,
                                           "integer")
        self$fold.num <- validateInput("fold.num", fold.num, "integer")
        self$param.search.strategy <-
          validateInput("param.search.strategy",
                        param.search.strategy,
                        self$search.strategy.list,
                        case.sensitive = TRUE)
        self$random.search.times <-
          validateInput("random.search.times",
                        random.search.times,
                        "integer")
        self$timeout <- validateInput("timeout", timeout, "integer")
        self$evaluation.metric <- validateInput("evaluation.metric",
                                                evaluation.metric,
                                                self$metric.list)
        self$progress.indicator.id <- validateInput("progress.indicator.id",
                                                    progress.indicator.id,
                                                    "character")
        if (self$tree.type == "Classifier"){
          range.param <- self$value.param[2:7]
        } else {
          range.param <- self$value.param
        }
        if (length(parameter.values) != 0){
          validateInput("Parameters for value specification",
                        names(parameter.values),
                        self$value.param,
                        case.sensitive = TRUE)
        }
        if (length(parameter.range) != 0){
          validateInput("Parameters for range specification",
                        names(parameter.range),
                        range.param,
                        case.sensitive = TRUE)
        }
        if ("discretization.type" %in% names(parameter.values)){
          parameter.values[["discretization.type"]] <-
            validateInput("Values of discretization.type",
                          parameter.values[["discretization.type"]],
                          self$discretization.type.map)
        }
        self$parameter.range <- parameter.range
        self$parameter.values <- parameter.values
        self$output.confusion.matrix <- FALSE
        self$priors <- NULL
        self$model <- NULL
        self$decision.rules <- NULL
        self$confusion.matrix <- NULL
      }
    },
    fit = function(data,
                   formula = NULL,
                   features = NULL,
                   label = NULL,
                   key = NULL) {
      conn.context <- data$connection.context
      if (!is.null(data)){
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        if (inherits(formula, "formula")){
          parseformula <- ParseFormula(data, formula)
          label <- parseformula[[1]]
          features <- parseformula[[2]]
          features <- features[! features %in% key]
        }
        cols <- cols[! cols %in% key]
        label <- validateInput("label", label, cols, case.sensitive = TRUE)
        if (is.null(label)){
          label <- cols[[length(cols)]]
        }
        cols <- cols[! cols %in% label]
        features <- validateInput("features", features, cols,
                                  case.sensitive = TRUE)
        if (length(features) == 0){
          features <- cols
        }
        id.col <- as.list(key)
        feature.col <- id.col
        feature.col <- c(id.col, features, label)
        label.type <- data$dtypes(label)[[1]][[2]]
        if (self$tree.type == "Classifier"){
          if (label.type %in% c("DECIMAL", "DOUBLE")) {
            msg <- paste("Label variable is of continuous type,",
                         "not suitable for classification.")
            flog.error(msg)
            stop(msg)
          } else if (label.type %in% c("INT", "INTEGER")) {
            self$categorical.variable <- c(self$categorical.variable,
                                           label)
          }
        } else {
          if (label.type %in% c("VARCHAR", "NVARCHAR") ||
              (label.type %in% c("INT", "INTEGER") &&
               label %in% self$categorical.variable)){
            msg <- paste("Label variable is of categorical type,",
                         "not suitable for regression.")
            flog.error(msg)
            stop(msg)
          }
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        data <- data$Select(feature.col)

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <-
          sprintf("#DECISION_TREE_PARAMS_TBL_%s_%s", self$id, unique.id)
        model.tbl <-
          sprintf("#DECISION_TREE_MODEL_TBL_%s_%s", self$id, unique.id)
        rules.tbl <-
          sprintf("#DECISION_TREE_RULESL_TBL_%s_%s", self$id, unique.id)
        cm.tbl <-
          sprintf("#DECISION_TREE_CONFUSION_MATRIX_TBL_%s_%s", self$id, unique.id)
        stats.tbl <- sprintf("#DECISION_TREE_STATS_TBL_%s_%s", self$id, unique.id)
        cv.tbl <- sprintf("#DECISION_TREE_CV_TBL_%s_%s", self$id, unique.id)
        tables <-
          list(param.tbl,
               model.tbl,
               rules.tbl,
               cm.tbl,
               stats.tbl,
               cv.tbl)
        in.tables <-
          list(data,
               param.tbl)
        out.tables <-
          list(model.tbl,
               rules.tbl,
               cm.tbl,
               stats.tbl,
               cv.tbl)
        param.data <- list(
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple(
            "ALLOW_MISSING_DEPENDENT",
            to.integer(self$allow.missing.dependent),
            NULL,
            NULL
          ),
          tuple("PERCENTAGE", NULL, self$percentage, NULL),
          tuple("MIN_RECORDS_OF_PARENT", self$min.records.of.parent, NULL, NULL),
          tuple("MIN_RECORDS_OF_LEAF", self$min.records.of.leaf, NULL, NULL),
          tuple("MAX_DEPTH", self$max.depth, NULL, NULL),
          tuple("SPLIT_THRESHOLD", NULL, self$split.threshold, NULL),
          tuple("MAX_BRANCH", self$max.branch, NULL, NULL),
          tuple("MERGE_THRESHOLD", NULL, self$merge.threshold, NULL),
          tuple("USE_SURROGATE", to.integer(self$use.surrogate), NULL, NULL),
          tuple("IS_OUTPUT_RULES", to.integer(self$output.rules), NULL, NULL),
          tuple("IS_OUTPUT_CONFUSION_MATRIX",
                to.integer(self$output.confusion.matrix),
                NULL, NULL),
          tuple("HAS_ID", to.integer(!is.null(key)), NULL, NULL),
          tuple("RESAMPLING_METHOD", NULL, NULL, self$resampling.method),
          tuple("PARAM_SEARCH_STRATEGY", NULL, NULL, self$param.search.strategy),
          tuple("FOLD_NUM", self$fold.num, NULL, NULL),
          tuple("REPEAT_TIMES", self$repeat.times, NULL, NULL),
          tuple("EVALUATION_METRIC", NULL, NULL,
                map.null(self$evaluation.metric, self$metric.list)),
          tuple("TIMEOUT", self$timeout, NULL, NULL),
          tuple("RANDOM_SEARCH_TIMES", self$random.search.times, NULL, NULL),
          tuple("PROGRESS_INDICATOR_ID", NULL, NULL, self$progress.indicator.id)
        )
        if (!is.null(self$algorithm)){
          param.data <-
            append(param.data,
                   list(tuple("ALGORITHM",
                              self$algorithm.map[[self$algorithm]],
                              NULL, NULL)))
        }
        if (!is.null(self$model.format)){
          param.data <-
            append(param.data,
                   list(tuple("MODEL_FORMAT",
                              self$model.format.map[[self$model.format]],
                              NULL, NULL)))
        }
        if (!is.null(self$discretization.type)){
          para.data <-
            append(param.data,
                   list(tuple("DISCRETIZATION_TYPE",
                              self$discretization.map[[self$discretization.type]],#nolint
                              NULL, NULL)))
        }
        if (!is.null(self$categorical.variable)) {
          for (each in self$categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
            param.data <- append(param.data, tuple(temp.list))
          }
        }
        if (length(self$priors) > 0) {
          for (i in 1:length(self$priors)) {
            class.type <- names(self$priors[i])
            prior.prob <- self$priors[[i]]
            NewClassType <- sprintf("%s_PRIOR_", class.type)
            temppriors.list <- tuple(NewClassType, NULL, prior.prob, NULL)
            param.data <-
              append(param.data, tuple(temppriors.list))
          }
        }
        if (length(self$bins) > 0) {
          for (i in 1:length(self$bins)) {
            col.name <- names(self$bins[i])
            num.bins <- self$bins[[i]]
            NewColName <- sprintf("%s_BIN_", col.name)
            tempbins.list <- tuple(NewColName, num.bins, NULL, NULL)
            param.data <-
              append(param.data, tuple(tempbins.list))
          }
        }
        if (length(self$parameter.values) > 0){
          for (i in 1:length(self$parameter.values)){
            param.name <- gsub("\\.", "_",
                               toupper(names(self$parameter.values[i])))
            value.temp <- self$parameter.values[[i]]
            if (grepl("DISCRETIZATION", param.name)){
              for (i in length(value.temp)){
                value.temp[[i]] <-
                  self$discretization.type.map[[value.temp[[i]]]]
              }
            }
            str.values <- paste("{",
                                paste0(value.temp,
                                       collapse = ","),
                                "}", sep = "")
            temp.tup <- tuple(paste0(param.name, "_VALUES"),
                              NULL, NULL, str.values)
            param.data <-
              append(param.data,  list(temp.tup))
          }
        }
        if (length(self$parameter.range) > 0){
          for (i in 1:length(self$parameter.range)){
            param.name <- gsub("\\.", "_",
                               toupper(names(self$parameter.range[i])))
            range.temp <- self$parameter.range[[i]]
            cps <- ifelse(length(range.temp) == 2, ",,", ",")
            str.range <- paste("[",
                               paste0(range.temp,
                                      collapse = cps),
                               "]", sep = "")
            temp.tup <- tuple(paste0(param.name, "_RANGE"),
                              NULL, NULL, str.range)
            param.data <-
              append(param.data, list(temp.tup))
          }
        }
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            (ParameterTable$new(param.tbl))$WithData(param.data))) #nolint
          errorhelper(CallPalAutoWithConnection(conn.context,
            "PAL_DECISION_TREE", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$model <- conn.context$table(model.tbl)
        self$decision.rules <- conn.context$table(rules.tbl)
        self$confusion.matrix <- conn.context$table(cm.tbl)
        self$statistics <- conn.context$table(stats.tbl)
        self$cv <- conn.context$table(cv.tbl)
      }
    },
    predict = function(data,
                       key,
                       features = NULL,
                       verbose = NULL,
                       thread.ratio = NULL) {
      if (is.null(self$model)){
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }
      conn.context <- data$connection.context
      if (!inherits(data, "DataFrame")){
        msg <- "Data for prediction must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      verbose <- validateInput("verbose", verbose, "logical")
      thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                    "numeric")
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features)){
        features <- cols
      }
      temp <- list(key)
      for (element in features)
        temp <- append(temp, element)
      data <- data$Select(temp)
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#DECISION_TREE_PARAMS_%s_%s", self$id, unique.id)
      result.tbl <- sprintf("#DECISION_TREE_RESULT_TBL_%s_%s", self$id, unique.id)
      tables <- list(param.tbl, result.tbl)
      in.tables <- list(data, self$model$name, param.tbl)
      out.tables <- list(result.tbl)
      param.data <- list(
        tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
        tuple("VERBOSE", to.integer(verbose), NULL, NULL)
      )
      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
          (ParameterTable$new(param.tbl))$WithData(param.data))) #nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
          "PAL_DECISION_TREE_PREDICT", in.tables, out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      result <- conn.context$table(result.tbl)
      return (result)
    }
  )
)


DecisionTreeClassifier <- R6Class(
  "DecisionTreeClassifier",
  inherit = DecisionTreeBase,
  public = list(
    discretization.type = NULL,
    bins = NULL,
    max.branch = NULL,
    merge.threshold = NULL,
    use.surrogate = NULL,
    output.rules = TRUE,
    model.format = NULL,
    priors = NULL,
    confusion.matrix = NULL,
    output.confusion.matrix = TRUE,
    tree.type = "Classifier",
    algorithm.map = list(
      "c45" = 1,
      "chaid" = 2,
      "cart" = 3
    ),
    value.param = list("discretization.type",
                       "min.records.of.leaf",
                       "min.records.of.parent",
                       "max.depth",
                       "split.threshold",
                       "max.branch",
                       "merge.threshold"),
    initialize = function(algorithm,
                          data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          thread.ratio = NULL,
                          allow.missing.dependent = TRUE,
                          percentage = NULL,
                          min.records.of.parent = NULL,
                          min.records.of.leaf = NULL,
                          max.depth = NULL,
                          categorical.variable = NULL,
                          split.threshold = NULL,
                          use.surrogate = NULL,
                          model.format = NULL,
                          discretization.type = NULL,
                          bins = NULL,
                          max.branch = NULL,
                          merge.threshold = NULL,
                          priors = NULL,
                          output.rules = TRUE,
                          output.confusion.matrix = TRUE,
                          evaluation.metric = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL,
                          resampling.method = NULL,
                          repeat.times = NULL,
                          fold.num = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL) {
      super$initialize(
        algorithm,
        thread.ratio,
        allow.missing.dependent,
        percentage,
        min.records.of.parent,
        min.records.of.leaf,
        max.depth,
        categorical.variable,
        split.threshold,
        use.surrogate,
        model.format,
        output.rules,
        output.confusion.matrix,
        evaluation.metric,
        parameter.range,
        parameter.values,
        resampling.method,
        repeat.times,
        fold.num,
        param.search.strategy,
        random.search.times,
        timeout,
        progress.indicator.id)
      if (!is.null(data)){
        if (self$algorithm != "c45") {
          if (self$algorithm != "chaid") {
            if (!is.null(discretization.type)) {
              msg <- paste("discretization.type is not applicable.",
                           "Algorithm is", self$algorithm,
                           "instead of C45 or Chaid.")
              flog.error(msg)
              stop(msg)
            }
          }
        }
        if (!is.null(discretization.type)) {
          discretization.type.lower <- sapply(discretization.type, tolower)[[1]]
          if (is.null(self$discretization.type.map[[discretization.type.lower]])) {
            msg <-
              "Invalid discretization types, valid types include mdlpc and equal_freq "
            flog.error(msg)
            stop(msg)
          }
          self$discretization.type <- discretization.type.lower
        }
        if (length(bins) > 0) {
          if (self$discretization.type != "equal_freq") {
            msg <-
              "bins not applicable. It is valid only when discretization_type is set to equal_freq"
            flog.error(msg)
            stop(msg)
          }
          self$bins <- bins
        }
        if (!is.null(max.branch)) {
          if (self$algorithm != "chaid") {
            msg <-
              "max.branch applicable only when algorithm is set to chaid"
            stop(msg)
          }
          self$max.branch <-
            validateInput("max.branch", max.branch, "integer")
        }
        if (!is.null(merge.threshold)) {
          if (self$algorithm != "chaid") {
            msg <-
              "merge.threshold is applicable only when algorithm is set to chaid"
            stop(msg)
          }
          self$merge.threshold <-
            validateInput("merge.threshold", merge.threshold, "double")
        }
        self$priors <- validateInput("priors", unlist(priors),
                                     "numeric")
        self$output.confusion.matrix <-
          validateInput("output.confusion.matrix",
                        output.confusion.matrix,
                        "logical")
        self$confusion.matrix <- NULL
      }
      super$fit(data = data,
                formula = formula,
                features = features,
                label = label,
                key = key)
      self$confusion.matrix <- self$confusion.matrix
    },
    score = function(data,
                     key,
                     features = NULL,
                     label = NULL) {
      features <- validateInput("features", features, "ListOfStrings")
      key <- validateInput("key", key, "character")
      label <- validateInput("label", label, "character")
      cols <- data$columns
      cols <- cols[! cols %in% key]
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      if (length(features) == 0)
        features <- cols

      prediction <- self$predict(data, key = key, features = features)
      prediction <- prediction$Select(list(key, "SCORE"))
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      acc.score <- accuracy.score(data$connection.context,
                     joined,
                     label.true = "ACTUAL",
                     label.pred = "PREDICTION")
      return(acc.score)
    }
  )
) ## DecisionTreeClassifier ends here.
#' @title Decision Tree Model for Classficiation
#' @name hanaml.DecisionTreeClassifier
#' @description hanaml.DecisionTreeClassifier is a R wrapper for SAP HANA PAL Decision tree.
#' @seealso \code{\link{predict.DecisionTreeClassifier}}
#' @param  algorithm \code{character}\cr
#'         Algorithm used to grow a decision tree.\cr
#'         Valid values are 'c45', 'chaid', and 'cart'.
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @template args-threadratio-1
#' @param  allow.missing.dependent \code{logical, optional}\cr
#'         Specifies if a missing target value is allowed.
#'         FALSE does not allow the missing target value.
#'         An error occurs if a missing target is present.
#'         TRUE allows the missing target value.
#'         The datum with the missing target is removed.\cr
#'         Defaults to TRUE.
#' @param  percentage \code{double, optional}\cr
#'         Specifies the percentage of the input data that will be used to build the tree model.
#'         The rest of the data will be used for pruning.\cr
#'         Defaults to 1.0.
#' @param  min.records.of.parent \code{integer, optional}\cr
#'         Specifies the stop condition. If the number of records in one node is less
#'         than the specified value, the algorithm stops splitting.\cr
#'         Defaults to 2.
#' @param  min.records.of.leaf \code{integer, optional}\cr
#'         Promises the minimum number of records in a leaf.\cr
#'         Defaults to 1.
#' @param  max.depth \code{integer, optional}\cr
#'         The maximum depth of a tree.
#'         By default it is unlimited.
#' @template args-cate-var
#' @param  split.threshold \code{double, optional}\cr
#'         Specifies the stop condition for a node.
#'         \itemize{
#'             \item{\code{C45} - The information gain ratio of
#'             the best split is less than this value.}
#'             \item{\code{CHAID} - The p-value of the best
#'             split is greater than or equal to this value.}
#'             \item{\code{CART} - The reduction of Gini
#'             index or relative MSE of the best split is
#'             less than this value.}
#'         }
#'         The smaller the SPLIT_THRESHOLD value is, the larger
#'         a C45 or CART tree grows.
#'         On the contrary, CHAID will grow a larger tree with a
#'         larger SPLIT_THRESHOLD value.\cr
#'         Defaults to 1e-5 for C45 and CART, and 0.05 for CHAID.
#' @param  discretization.type \code{character, optional}\cr
#'         Specifies the strategy for discretizing continuous attributes.
#'         Valid options are mdlpc and equal_freq.
#'         Valid only for C45 and CHAID.\cr
#'         Defaults to 'mdlpc'.
#' @param  bins \code{list}\cr
#'         Specifies the number of bins for discretization in list.
#'         Each element in the list must be named, with the name being a column name,
#'         and the values be the number of bins for discretizing that column.\cr
#'         Only valid when discretization type is "equal_freq".\cr
#'         Defaults to '10' for each column.
#' @param  max.branch \code{integer, optional}\cr
#'         Specifies the maximum number of branches.
#'         Valid only for CHAID.\cr
#'         Defaults to 10.
#' @param  merge.threshold \code{double, optional}\cr
#'         Specifies the merge condition for CHAID.
#'         If the metric value is greater than
#'         or equal to the specified value, the algorithm will
#'         merge the two branches.
#'         Only valid for CHAID.\cr
#'         Defaults to 0.05.
#' @param  use.surrogate \code{logical, optional}\cr
#'         Indicates whether to use surrogate split when NULL
#'         values are encountered.\cr
#'         FALSE does not use surrogate split.
#'         TRUE will use a surrogate split.
#'         Only valid for CART.\cr
#'         Defaults to TRUE.
#' @param  model.format \code{character, optional}\cr
#'         Specifies the tree model format for store.
#'         Valid options are json and pmml.\cr
#'         Defaults to 'json'.
#' @param  output.rules \code{logical, optional}\cr
#'         Specifies whether to output decision rules or not.
#'         FALSE will not output decision rules.
#'         TRUE will output decision rules.\cr
#'         Defaults to TRUE.
#' @param  priors \code{named list/vector of numerics, optional}\cr
#'         Specifies the priori probability of every class label(in the form of class.label = probability).\cr
#'         The default value is determined from the data.
#' @param  output.confusion.matrix \code{logical, optional}\cr
#'         Specifies whether or not to produce an output confusion matrix.
#'         FALSE will not output a confusion matrix.
#'         TRUE will output confusion matrix.\cr
#'         Defaults to TRUE.
#' @param  resampling.method   \code{character, optional}\cr
#'         specifies the resampling values form below list. Valid options include:\cr
#'         \code{'cv',
#'         'stratified_cv',
#'         'bootstrap',
#'         'stratified_bootstrap'}\cr
#'         If no value is specified for this parameter, neither model evaluation
#'         nor parameter selection is activated.
#' @param  evaluation.metric   \code{c('error_rate', 'nll', 'auc'), optional}\cr
#'         Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'         Defaults to 'error_rate'.
#' @param  fold.num \code{integer, optional}\cr
#'         Specifies the fold number for the cross-validation(cv).
#'         Mandatory and valid only when \code{resampling.method} is 'cv' or 'stratified_cv'.
#' @param  repeat.times  \code{numeric, optional}\cr
#'         Specifies the number of repeat times for resampling.\cr
#'         Defaults to 1.
#' @param  param.search.strategy   \code{c('grid', 'random'), optional}\cr
#'         Specifies the method to activate parameter selection.
#'         If not specified, model selection shall not be triggered.
#' @param  random.search.times \code{integer, optional}\cr
#'         Specifies the number of times to randomly select candidate parameters for selection.
#'         Mandatory and valid only when \code{param.search.strategy} is 'random'.
#' @param  timeout \code{integer, optional}\cr
#'         Specifies maximum running time for model evaluation or parameter selection in seconds.
#'         No timeout when 0 is specified.
#' @param  progress.indicator.id     \code{character, optional}\cr
#'         Sets an ID of progress indicator for model evaluation or parameter selection.\cr
#'         No progress indicator is active if no value is provided.
#' @param  parameter.values   \code{list, optional}\cr
#'         Specifies values of the following parameters for parameter selection:\cr
#'         \code{discretization.type, min.records.of.leaf,
#'             min.records.of.parent, max.depth,
#'             split.threshold, max.branch, merge.threshold}.
#' @param  parameter.range   \code{list, optional}\cr
#'         Specifies range of the following parameters for parameter selection:\cr
#'         \code{min.records.of.leaf, min.records.of.parent, max.depth,
#'               split.threshold, max.branch, merge.threshold}.\cr
#'         Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'         Examples:\cr
#'         parameter.range <- list(max.depth = c(10, 1, 20)).\cr
#'         If \code{param.search.strategy} is 'random', then step has no effect
#'         and thus can be omitted.
#' @return
#' A "DecisionTreeClassifier" object with the following attributes:
#' \itemize{
#' \item{model: \code{DataFrame}}\cr
#'   Trained model content.
#' \item{decision.rules: \code{DataFrame}}\cr
#'   Rules for decision tree to make decisions.
#' \item{confusion.matrix: \code{DataFrame}}\cr
#'   Confusion matrix used to evaluate the performance of classification algorithms.
#' }
#' @section Examples:
#' Input DataFrame for training:
#' \preformatted{
#'  > data$Collect()
#'     OUTLOOK TEMP HUMIDITY WINDY       CLASS
#' 1     Sunny   75       70   Yes        Play
#' 2     Sunny   80       90   Yes Do not Play
#' 3     Sunny   85       85    No Do not Play
#' 4     Sunny   72       95    No Do not Play
#' 5     Sunny   69       70    No        Play
#' 6  Overcast   72       90   Yes        Play
#' 7  Overcast   83       78    No        Play
#' 8  Overcast   64       65   Yes        Play
#' 9  Overcast   81       75    No        Play
#' 10     Rain   71       80   Yes Do not Play
#' 11     Rain   65       70   Yes Do not Play
#' 12     Rain   75       80    No        Play
#' 13     Rain   68       80    No        Play
#' 14     Rain   70       96    No        Play
#' }
#' Call the function:
#' \preformatted{
#' > dtc <- hanaml.DecisionTreeClassifier(algorithm = 'c45', data = data,
#'                                        features = list('TEMP', 'HUMIDITY', 'WINDY'),
#'                                        label = "CLASS", key= NULL
#'                                        min.records.of.parent = 2, min.records.of.leaf = 1,
#'                                        thread.ratio = 0.4, split.threshold = 1e-5,
#'                                        model.format = 'json',  output.rules = TRUE )
#' }
#' OR giving input to create a model as a formula:
#' \preformatted{
#' > dtc <- hanaml.DecisionTreeClassifier(algorithm = 'c45', data = data,
#'                                        formula=CATEGORY~V1+V2+V3, key= "ID"
#'                                        min.records.of.parent = 2, min.records.of.leaf = 1,
#'                                        thread.ratio = 0.4, split.threshold = 1e-5,
#'                                        model.format = 'json', output.rules = TRUE)
#'}
#' Output:
#' \preformatted{
#' > dtc$decision.rules$Collect()
#'    ROW_INDEX                                                    RULES_CONTENT
#' 1          0                                        (TEMP>=84) => Do not Play
#' 2          1                          (TEMP<84) && (OUTLOOK=Overcast) => Play
#' 3          2          (TEMP<84) && (OUTLOOK=Sunny) && (HUMIDITY<82.5) => Play
#' 4          3  (TEMP<84) && (OUTLOOK=Sunny) && (HUMIDITY>=82.5) => Do not Play
#' 5          4        (TEMP<84) && (OUTLOOK=Rain) && (WINDY=Yes) => Do not Play
#' 6          5                (TEMP<84) && (OUTLOOK=Rain) && (WINDY=No) => Play
#' }
#' @keywords Classification
#' @export
hanaml.DecisionTreeClassifier <- function(algorithm,
                                          data = NULL,
                                          key = NULL, features = NULL,
                                          label = NULL, formula = NULL,
                                          thread.ratio = NULL,
                                          allow.missing.dependent = NULL,
                                          percentage = NULL,
                                          min.records.of.parent = NULL,
                                          min.records.of.leaf = NULL,
                                          max.depth = NULL,
                                          categorical.variable = NULL,
                                          split.threshold = NULL,
                                          use.surrogate = NULL,
                                          model.format = NULL,
                                          discretization.type = NULL,
                                          bins = NULL, max.branch = NULL,
                                          merge.threshold = NULL,
                                          priors = NULL, output.rules = NULL,
                                          output.confusion.matrix = NULL,
                                          evaluation.metric = NULL,
                                          parameter.range = NULL,
                                          parameter.values = NULL,
                                          resampling.method = NULL,
                                          repeat.times = NULL,
                                          fold.num = NULL,
                                          param.search.strategy = NULL,
                                          random.search.times = NULL,
                                          timeout = NULL,
                                          progress.indicator.id = NULL){
  DecisionTreeClassifier$new(algorithm, data, key,
                             features, label, formula,
                             thread.ratio,
                             allow.missing.dependent,
                             percentage, min.records.of.parent,
                             min.records.of.leaf,
                             max.depth, categorical.variable,
                             split.threshold,
                             use.surrogate, model.format,
                             discretization.type,
                             bins, max.branch, merge.threshold,
                             priors, output.rules,
                             output.confusion.matrix,
                             evaluation.metric,
                             parameter.range,
                             parameter.values,
                             resampling.method,
                             repeat.times,
                             fold.num,
                             param.search.strategy,
                             random.search.times,
                             timeout,
                             progress.indicator.id)
}

DecisionTreeRegressor <- R6Class(
  "DecisionTreeRegressor",
  inherit = DecisionTreeBase,
  public = list(
    confusion.matrix = NULL,
    tree.type = "Regressor",
    value.param = list("min.records.of.leaf",
                       "min.records.of.parent",
                       "split.threshold"),
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          thread.ratio = NULL,
                          allow.missing.dependent = TRUE,
                          percentage = NULL,
                          min.records.of.parent = NULL,
                          min.records.of.leaf = NULL,
                          max.depth = NULL,
                          categorical.variable = NULL,
                          split.threshold = NULL,
                          use.surrogate = NULL,
                          model.format = NULL,
                          output.rules = TRUE,
                          evaluation.metric = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL,
                          resampling.method = NULL,
                          repeat.times = NULL,
                          fold.num = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL){
      super$initialize(
        "cart",
        thread.ratio,
        allow.missing.dependent,
        percentage,
        min.records.of.parent,
        min.records.of.leaf,
        max.depth,
        categorical.variable,
        split.threshold,
        use.surrogate,
        model.format,
        output.rules,
        FALSE,
        evaluation.metric,
        parameter.range,
        parameter.values,
        resampling.method,
        repeat.times,
        fold.num,
        param.search.strategy,
        random.search.times,
        timeout,
        progress.indicator.id)
      if (!is.null(data)){
        super$fit(data = data,
                  formula = formula,
                  features = features,
                  label = label,
                  key = key)
        }
    },
    score = function(data,
                     key,
                     features = NULL,
                     label = NULL) {
      features <- validateInput("features", features, "ListOfStrings")
      key <- validateInput("key", key, "character", required = TRUE)
      label <- validateInput("label", label, "character")
      cols <- data$columns
      cols <- cols[! cols %in% key]
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      if (is.null(features)){
        features <- cols
      }
      prediction <- self$predict(data, key = key, features = features)#nolint
      original <- data$Select(list(key, label))
      prediction <- prediction$Select(list(key, "SCORE"))

      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      original <- data$Select(list(key, label))
      original <- original$rename.columns(list("ID_A", "ACTUAL"))
      joined <- original$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      r2.score <- r2.score(self$connection.context,
                     joined,
                     label.true = "ACTUAL",
                     label.pred = "PREDICTION")
      return(r2.score)
    }
  )
)

#' @title Make Predictions from a "DecisionTreeClassifier" Object
#' @name predict.DecisionTreeClassifier
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "DecisionTreeClassifier" object.
#' @seealso \code{\link{hanaml.DecisionTreeClassifier}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A "DecisionTreeClassifier" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param verbose \code{logical , optional}\cr
#' Defaults to FALSE. Valid only for Classification.
#' @template args-threadratio-1
#' @return
#' \code{Dataframe}\cr
#' Predicted values, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data}'s ID column.}
#'   \item{SCORE, type NVARCHAR(100), predicted classes.}
#'   \item{CONFIDENCE, type DOUBLE. Representing the confidence of a class}
#'}
#' @section Examples:
#' Input DataFrame data2:
#' \preformatted{
#' > data2$Collect()
#'    ID   OUTLOOK  HUMIDITY  TEMP WINDY
#' 1   0  Overcast      75.0    70   Yes
#' 2   1      Rain      78.0    70   Yes
#' 3   2     Sunny      66.0    70   Yes
#' 4   3     Sunny      69.0    70   Yes
#' 5   4      Rain        NA    70   Yes
#' 6   5      <NA>      70.0    70   Yes
#' 7   6       ***      70.0    70   Yes
#' }
#' Call the function and obtain the result:
#' \preformatted{
#' > result = predict(dtc, data2, verbose=FALSE)
#'    ID        SCORE  CONFIDENCE
#' 1   0         Play    1.000000
#' 2   1  Do not Play    1.000000
#' 3   2         Play    1.000000
#' 4   3         Play    1.000000
#' 5   4  Do not Play    1.000000
#' 6   5         Play    0.692308
#' 7   6         Play    0.692308
#' }
#' @export
predict.DecisionTreeClassifier <-
  function(model,
           data,
           key,
           features = NULL,
           verbose = NULL,
           thread.ratio = NULL) {
    model$predict(data = data,
                  key = key,
                  features = features,
                  verbose = verbose,
                  thread.ratio = thread.ratio)

  }

#' @title Decision Tree Model for Regression
#' @name hanaml.DecisionTreeRegressor
#' @description hanaml.DecisionTreeRegressor is a R wrapper for SAP HANA PAL Decision tree.
#' @seealso \code{\link{predict.DecisionTreeRegressor}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @template args-threadratio-1
#' @param  allow.missing.dependent \code{logical, optional}\cr
#'         Specifies if a missing target value is allowed.
#'         FALSE does not allow the missing target value.
#'         An error occurs if a missing target is present.
#'         TRUE allows the missing target value.
#'         The datum with the missing target is removed.\cr#'
#'         Defaults to TRUE.
#' @param  percentage \code{double, optional}\cr
#'         Specifies the percentage of the input data that will be used to build the tree model.
#'         The rest of the data will be used for pruning.\cr
#'         Defaults to 1.0.
#' @param  min.records.of.parent \code{integer, optional}\cr
#'         Specifies the stop condition. If the number of records in one node is less
#'         than the specified value, the algorithm stops splitting.\cr
#'         Defaults to 2.
#' @param  min.records.of.leaf \code{integer, optional}\cr
#'         Promises the minimum number of records in a leaf.\cr
#'         Defaults to 1.
#' @param  max.depth \code{integer, optional}\cr
#'         The maximum depth of a tree.\cr
#'         By default it is unlimited.
#' @template args-cate-var
#' @param  split.threshold \code{double, optional}\cr
#'         Specifies the stop condition for a node. In this case, it is
#'         the reduction of Gini index or relative MSE of the best split is
#'         less than this value in 'cart' algorithm.
#'         The smaller the value is, the larger a 'cart' tree grows.\cr
#'         Defaults to 1e-5.
#' @param  use.surrogate \code{logical, optional}\cr
#'         Indicates whether to use a surrogate split when NULL values are encountered.
#'         FALSE does not use surrogate split.
#'         TRUE uses a surrogate split.\cr
#'         Defaults to TRUE.
#' @param  model.format \code{character, optional}\cr
#'         Specifies the tree model format for store.
#'         Valid options are json and pmml.\cr
#'         Defaults to 'json'.
#' @param  output.rules \code{logical, optional}\cr
#'         Specifies whether to output decision rules or not.
#'         FALSE does not output decision rules.
#'         TRUE outputs decision rules.\cr
#'         Defaults to TRUE.
#' @param  resampling.method   \code{character, optional}\cr
#'         specifies the resampling values form below list. Valid options include:\cr
#'         \code{'cv',
#'         'stratified_cv',
#'         'bootstrap',
#'         'stratified_bootstrap'}\cr
#'         If no value is specified for this parameter, neither model evaluation
#'         nor parameter selection is activated.
#' @param  evaluation.metric   \code{c('rmse', 'mae'), optional}\cr
#'         Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'         Defaults to 'rmse'.
#' @param  fold.num \code{integer, optional}\cr
#'         Specifies the fold number for the cross-validation(cv).
#'         Mandatory and valid only when \code{resampling.method} is 'cv' or 'stratified_cv'.
#' @param  repeat.times  \code{numeric, optional}\cr
#'         Specifies the number of repeat times for resampling.\cr
#'         Defaults to 1.
#' @param  param.search.strategy   \code{c('grid', 'random'), optional}\cr
#'         Specifies the method to activate parameter selection.
#'         If not specified, model selection shall not be triggered.
#' @param  random.search.times \code{integer, optional}\cr
#'         Specifies the number of times to randomly select candidate parameters for selection.
#'         Mandatory and valid only when \code{param.search.strategy} is 'random'.
#' @param  timeout \code{integer, optional}\cr
#'         Specifies maximum running time for model evaluation or parameter selection in seconds.\cr
#'         No timeout when 0 is specified.
#' @param  progress.indicator.id     \code{character, optional}\cr
#'         Sets an ID of progress indicator for model evaluation or parameter selection.\cr
#'         No progress indicator is active if no value is provided.
#' @param  parameter.values   \code{list, optional}\cr
#'         Specifies values of the following parameters for parameter selection:\cr
#'         \code{min.records.of.leaf, min.records.of.parent, max.depth, split.threshold}.
#' @param  parameter.range   \code{list, optional}\cr
#'         Specifies range of the following parameters for parameter selection:\cr
#'         \code{min.records.of.leaf, min.records.of.parent, max.depth, split.threshold}.\cr
#'         Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'         Examples:\cr
#'         parameter.range <- list(split.threshold = c(1e-5, 2e-5, 1e-4)).\cr
#'         If \code{param.search.strategy} is 'random', then the step has no effect
#'         and thus can be omitted.
#' @return
#' A "DecisionTreeRegressor" object with the following attributes:
#' \itemize{
#' \item{model: \code{DataFrame}}\cr
#'   Trained model content.
#' \item{decision.rules: \code{DataFrame}}\cr
#'   Rules for decision tree to make decisions.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > head(data$Collect(),5)
#'   OUTLOOK TEMP HUMIDITY WINDY CLASS
#' 1   Sunny   75       70   Yes     1
#' 2   Sunny   80       90   Yes     0
#' 3   Sunny   85       85    No     0
#' 4   Sunny   72       95    No     0
#' 5   Sunny   69       70    No     1
#' }
#'
#' Call the function:
#' \preformatted{
#' > dtr <- hanaml.DecisionTreeRegressor(data,
#'                                       features = list("A", "B", "C"),
#'                                       label = "LABEL",
#'                                       key = 'ID',
#'                                       min.records.of.parent = 2,
#'                                       min.records.of.leaf = 1,
#'                                       thread.ratio = 0.4,
#'                                       split.threshold = 1e-5,
#'                                       model.format = 'pmml',
#'                                       output.rules = TRUE )
#' }
#' OR call the function with formula:
#' \preformatted{
#' > dtr <- hanaml.DecisionTreeRegressor(data,
#'                                       formula=LABEL~A+B+C,
#'                                       key = NULL,
#'                                       min.records.of.parent = 2,
#'                                       min.records.of.leaf = 1,
#'                                       thread.ratio = 0.4,
#'                                       split.threshold = 1e-5,
#'                                       model.format = 'pmml',
#'                                       output.rules = TRUE)
#' }
#' @keywords Regression
#' @export
hanaml.DecisionTreeRegressor <- function(data = NULL,
                                         key = NULL,
                                         features = NULL,
                                         label = NULL,
                                         formula = NULL,
                                         thread.ratio = NULL,
                                         allow.missing.dependent = NULL,
                                         percentage = NULL,
                                         min.records.of.parent = NULL,
                                         min.records.of.leaf = NULL,
                                         max.depth = NULL,
                                         categorical.variable = NULL,
                                         split.threshold = NULL,
                                         use.surrogate = NULL,
                                         model.format = NULL,
                                         output.rules = NULL,
                                         evaluation.metric = NULL,
                                         parameter.range = NULL,
                                         parameter.values = NULL,
                                         resampling.method = NULL,
                                         repeat.times = NULL,
                                         fold.num = NULL,
                                         param.search.strategy = NULL,
                                         random.search.times = NULL,
                                         timeout = NULL,
                                         progress.indicator.id = NULL){
  DecisionTreeRegressor$new(data, key,
                            features, label, formula,
                            thread.ratio,
                            allow.missing.dependent,
                            percentage, min.records.of.parent,
                            min.records.of.leaf,
                            max.depth, categorical.variable,
                            split.threshold,
                            use.surrogate, model.format,
                            output.rules,
                            evaluation.metric,
                            parameter.range,
                            parameter.values,
                            resampling.method,
                            repeat.times,
                            fold.num,
                            param.search.strategy,
                            random.search.times,
                            timeout,
                            progress.indicator.id)
}

#' @title Make Predictions from a "DecisionTreeRegressor" Object
#' @name predict.DecisionTreeRegressor
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "DecisionTreeRegressor" object.
#' @seealso \code{\link{hanaml.DecisionTreeRegressor}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A "DecisionTreeRegressor" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-threadratio-1
#' @return
#' \code{Dataframe}\cr
#' Predicted values, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data}'s ID column.}
#'   \item{SCORE, type NVARCHAR, predicted values.}
#'   \item{CONFIDENCE, type DOUBLE. Representing the confidence of a class. All 0s for regression}
#' }
#' @keywords Regression
#' @export
predict.DecisionTreeRegressor <-
  function(model,
           data,
           key,
           features = NULL,
           thread.ratio = NULL) {
    model$predict(data = data,
                  key = key,
                  features = features,
                  thread.ratio = thread.ratio)
  }



## Global functions
Preparedata <-
  function(data,
           formula = NULL,
           features = NULL,
           label = NULL,
           key = NULL) {
    cols.left <- data$columns
    col.number <- length(data$columns)
    if (!is.null(key)) {
      cols.left <- cols.left[!cols.left %in% key]
    }
    col.name <- data$columns[[col.number]]
    if (length(formula) == 0) {
      if (is.null(label)) {
        label <-  col.name
      }
      if (length(features) == 0) {
        cols.left <- cols.left[! cols.left %in% label]
        features <- cols.left
      }
    } else {
      FeatureLabels <- ParseFormula(data, formula)
      label <- FeatureLabels[[1]]
      features <- FeatureLabels[[2]]
      features <- features[! features %in% key]
    }
    if (!all(sapply(features, is.character)) || is.character(label)) {
      msg <- paste("Please make sure Feature is a list of column names",
                   "and Label is of type string")
      flog.error(msg)
      stop(msg)
    }
    featureDT.label <- append(features, label)
    data <- data$Select(featureDT.label)
    RetValues <- list(data = data,
                      features = features,
                      label = label)
    return(RetValues)
  }

#' @export
summary.DecisionTreeClassifier <- function(object, ...) {
  model_type <-
    ifelse(
      object$model.format == "json",
      "1: JSON model",
      ifelse(
        object$model.format == "pmml",
        "2: PMML model"
      )
    )
  writeLines("Model Attributes for Decision tree Classifier: Rules, confusion, statistics and CV")
  cat("\n")
  val_format <- sprintf("MODEL FORMAT is: %s", model_type)
  writeLines(val_format)
  cat("\n")
  writeLines("RULES:")
  print(object$decision.rules)
  cat("\n")
  writeLines("CONFUSION:")
  print(object$confusion.matrix)
  cat("\n")
  writeLines("STATISTICS (stats):")
  print(object$stats_output)
  cat("\n")
  writeLines("CV:")
  print(object$cv_output)
  cat("\n")
  writeLines("GENERAL SUMMARY OF THE MODEL:")
  print(object$model$.__enclos_env__$private$describeSummary())
  if ( (object$algorithm == "chaid") && is.null(object$max.branch)){
    writeLines("Max branches for Chaid algorithm: 10 (default value"  )
  }
  if (is.null(object$min.records.of.parent)){
    writeLines("Minimum records of parent: 2 (default value")
  } else {
    val <- sprintf("Minimum records of parent: %s", object$min.records.of.parent)
  }
  if (is.null(object$min.records.of.leaf)){
    writeLines("Minimum records of leaf: 1 (default value")
  } else {
    val <- sprintf("Minimum records of parent: %s", object$min.records.of.leaf)
  }
  cat("\n")
  ifelse(
   object$algorithm == "c45",
    textA <- "Algorithm used to grow this decision tree: C45",
    ifelse(
     object$algorithm == "chaid",
      textA <- "Algorithm used to grow this decision tree: CHAID",
      ifelse(
       object$algorithm == "cart",
        textA <- "Algorithm used to grow this decision tree: CART",
        textA <- "Unrecognized algorithms to grow decision tree."
      )
    )
  )
  writeLines(textA)
}

#' @export
print.DecisionTreeClassifier <- function(x, ...) {

  model_type <-
    ifelse(
      x$model.format == "json",
      "JSON model",
      ifelse(
        x$model.format == "pmml",
        "PMML model",
        "Unrecognized model format"
      )
    )

  writeLines("Decision tree Classification Algorithm")
  cat("\n")
  val_format <- sprintf("MODEL FORMAT is: %s", model_type)
  writeLines(val_format)
  cat("\n")
  ifelse(
    x$algorithm == "c45",
    textA <- "Algorithm used to grow this decision tree: C45",
    ifelse(
      x$algorithm == "chaid",
      textA <- "Algorithm used to grow this decision tree: CHAID",
      ifelse(
        x$algorithm == "cart",
        textA <- "Algorithm used to grow this decision tree: CART"
      )
    )
  )
  writeLines(textA)
  cat("\n")
  tr <- sprintf("Thread ratio is          : %s", to.null(x$thread.ratio))
  md <- sprintf("MAX_DEPTH is            : %s", to.null(x$max.depth))
  cvar <- sprintf("CATEGORICAL VARIABLE is  : %s",
                  to.null(x$categorical.variable))
  lbfgs <-
  writeLines("Model rule is:")
  print(to.null(x$decision.rules))
  cat("\n")
  writeLines("Optional parameters used for this model:")
  writeLines(paste("(NULL indicates none provided by user",
                   "and internal defaults are used)"))
  cat("\n")
  if ( (x$algorithm == "chaid") && is.null(x$max.branch)){
    writeLines("Max branches for Chaid algorithm: 10 (default value"  )
  }
  if (is.null(x$min.records.of.parent)){
    writeLines("Minimum records of parent: 2 (default value")
  } else {
    val1 <- sprintf("Minimum records of parent: %s",
                    x$min.records.of.parent)
    writeLines(val1)
  }
  if (is.null(x$min.records.of.leaf)){
    writeLines("Minimum records of leaf: 1 (default value")
  } else {
    val2 <- sprintf("Minimum records of leaf  : %s",
                    to.null(x$min.records.of.leaf))
    writeLines(val2)
  }
  writeLines(tr)
  writeLines(cvar)
    if ( (x$algorithm == "c45") && is.null(x$split.threshold)) {
         writeLines("Split threshold default value for algorithm C45 is le-5")
     }
    if ( (x$algorithm == "chaid") && is.null(x$split.threshold)){
         writeLines("Split threshold default value for algorithm CHAID is 0.05")
    }
    if ( (x$algorithm == "cart") && is.null(x$split.threshold)){
          writeLines("Split threshold default value for algorithm CART is le-5")
    }
    if ( (!is.null(x$split.threshold))) {
            valSplt <- sprintf("Split threshold value is : %s",
                               to.null(x$split.threshold))
            writeLines(valSplt)
    }
}

#' @export
summary.DecisionTreeRegressor <- function(object, ...) {
  model_type <-
    ifelse(
     object$model.format == "json",
      "JSON model",
      ifelse(
       object$model.format == "pmml",
        "PMML model",
        "Unrecognized model format"
      )
    )
  writeLines("Model Attributes for Decision tree Regressor: Rules, confusion, statistics and CV")
  cat("\n")
  val_format <- sprintf("MODEL FORMAT is: %s", model_type)
  writeLines(val_format)
  cat("\n")
  writeLines("RULES:")
  print(object$decision.rules)
  cat("\n")
  writeLines("CONFUSION:")
  print(object$confusion.matrix)
  cat("\n")
  writeLines("STATISTICS (stats):")
  print(object$stats_output)
  cat("\n")
  writeLines("CV:")
  print(object$cv_output)
  cat("\n")
  writeLines("GENERAL SUMMARY OF THE MODEL:")
  print(object$model$.__enclos_env__$private$describeSummary())
  if ( (object$algorithm == "chaid") && is.null(object$max.branch)){
    writeLines("Max branches for Chaid algorithm: 10 (default value")
  }
  if (is.null(object$min.records.of.parent)){
    writeLines("Minimum records of parent: 2 (default value\n")
  } else {
    writeLines(sprintf("Minimum records of parent: %s",
                      object$min.records.of.parent))
  }
  if (is.null(object$min.records.of.leaf)){
    writeLines("Minimum records of leaf: 1 (default value")
  } else {
    writeLines(sprintf("Minimum records of parent: %s",
                      object$min.records.of.leaf))
  }
  cat("\n")
  ifelse(
   object$algorithm == 1,
    textA <- "Algorithm used to grow this decision tree: C45",
    ifelse(
      object$algorithm == 2,
      textA <- "Algorithm used to grow this decision tree: CHAID",
      ifelse(
        object$algorithm == 3,
        textA <- "Algorithm used to grow this decision tree: CART",
        textA <- "Unrecognized algorithm to grow decision tree."
      )
    )
  )
  writeLines(textA)

}

#' @export
print.DecisionTreeRegressor <- function(x, ...) {
  model_type <-
    ifelse(
      x$model.format == "json",
      "1: JSON model",
      ifelse(
        x$model.format == "pmml",
        "2: PMML model",
        "Unrecognized model format."
      )
    )
  writeLines("Decision tree Regressor Algorithm")
  cat("\n")
  val_format <- sprintf("MODEL FORMAT is: %s", model_type)
  writeLines(val_format)
  cat("\n")
  ifelse(
    x$algorithm == "c45",
    textA <- "Algorithm used to grow this decision tree: C45",
    ifelse(
      x$algorithm == "chaid",
      textA <- "Algorithm used to grow this decision tree: CHAID",
      ifelse(
        x$algorithm == "cart",
        textA <- "Algorithm used to grow this decision tree: CART",
        textA <- "Unrecognized algorithm to grow decision tree."
      )
    )
  )
  writeLines(textA)
  cat("\n")
  tr <- sprintf("Thread ratio is          : %s", to.null(x$thread.ratio))
  md <- sprintf("MAX_DEPTH is            : %s", to.null(x$max.depth))
  cvar <-
    sprintf("CATEGORICAL VARIABLE is  : %s", to.null(x$categorical.variable))
  lbfgs <-
    writeLines("Model rule is:")
  print(to.null(x$decision.rules))
  cat("\n")
  writeLines("optional parameters used for this model:")
  writeLines(paste("(NULL indicates none provided by user",
                   "and internal defaults are used)"))
  cat("\n")
  if ( (x$algorithm == "chaid") && is.null(x$max.branch)){
    writeLines("Max branches for Chaid algorithm: 10 (default value"  )
  }
  if (is.null(x$min.records.of.parent)){
    writeLines("Minimum records of parent: 2 (default value")
  } else {
    val1 <- sprintf("Minimum records of parent: %s", x$min.records.of.parent)
    writeLines(val1)
  }
  if (is.null(x$min.records.of.leaf)){
    writeLines("Minimum records of leaf: 1 (default value")
  } else {
    val2 <- sprintf("Minimum records of leaf  : %s", x$min.records.of.leaf)
    writeLines(val2)
  }
  writeLines(tr)
  writeLines(cvar)
  if ( (x$algorithm == "c45") && is.null(x$split.threshold)) {
    writeLines("Split threshold default value for algorithm C45 is le-5")
  }
  if ( (x$algorithm == "chaid") && is.null(x$split.threshold)){
    writeLines("Split threshold default value for algorithm CHAID is 0.05")
  }
  if ( (x$algorithm == "cart") && is.null(x$split.threshold)){
    writeLines("Split threshold default value for algorithm CART is le-5")
  }
  if ( (!is.null(x$split.threshold))) {
    valSplt <- sprintf("Split threshold value is : %s",
                       to.null(x$split.threshold))
    writeLines(valSplt)
  }
}
