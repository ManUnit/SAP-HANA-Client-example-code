LSTM <- R6Class(
  "LSTM",
  inherit = MlBase,
  public = list(
    optimizer.map = list(
      sgd = 0,
      rmsprop = 1,
      adam = 2,
      adagrad = 3),
    learning.rate = NULL,
    gru = NULL,
    batch.size = NULL,
    time.dim = NULL,
    hidden.dim = NULL,
    num.layers = NULL,
    max.iter = NULL,
    interval = NULL,
    optimizer = NULL,
    stateful = NULL,
    bidirectional = NULL,
    model = NULL,
    loss = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          endog = NULL,
                          exog = NULL,
                          learning.rate = NULL,
                          gru = NULL,
                          batch.size = NULL,
                          time.dim = NULL,
                          hidden.dim = NULL,
                          num.layers = NULL,
                          max.iter = NULL,
                          interval = NULL,
                          optimizer = NULL,
                          stateful = NULL,
                          bidirectional = NULL) {
      super$initialize()
      if (!is.null(data)) {
        self$learning.rate <- validateInput("learnign.rate", learning.rate, "numeric")
        self$gru <- validateInput("gru", gru, "logical")
        self$batch.size <- validateInput("batch.size", batch.size, "integer")
        self$time.dim <- validateInput("time.dim", time.dim, "integer")
        self$hidden.dim <- validateInput("hidden.dim", hidden.dim, "integer")
        self$num.layers <- validateInput("num.layers", num.layers, "integer")
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        self$interval <- validateInput("interval", interval, "integer")
        self$optimizer <- validateInput("optimizer", optimizer, self$optimizer.map)
        self$stateful <- validateInput("stateful", stateful, "logical")
        self$bidirectional <- validateInput("bidirectional", bidirectional,
                                            "logical")
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        if (is.null(key)) {
          key <- cols[[1]]
        }
        cols <- cols[! cols %in% key]
        endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
        if (is.null(endog)) {
          endog <- cols[[1]]
        }
        cols <- cols[! cols %in% endog]
        exog <- validateInput("exog", exog, cols, case.sensitive = TRUE)
        if (is.null(exog)) {
          exog <- cols
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "data must be given as DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        data <- data$Select(c(key, endog, exog))
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_LSTM_PARAM_TBL_%s_%s",
                             self$id, unique.id)
        model.tbl <- sprintf("#PAL_LSTM_MODEL_TBL_%s_%s",
                             self$id, unique.id)
        loss.tbl <- sprintf("#PAL_LSTM_LOSS_TBL_%s_%s",
                            self$id, unique.id)
        in.tables <- list(data, param.tbl)
        tables <- list(param.tbl, loss.tbl, model.tbl)
        out.tables <- list(loss.tbl, model.tbl)
        param.rows <- list(
          tuple("LEARNING_RATE", NULL, self$learning.rate, NULL),
          tuple("GRU", to.integer(self$gru), NULL, NULL),
          tuple("BATCH_SIZE", self$batch.size, NULL, NULL),
          tuple("TIME_DIM", self$time.dim, NULL, NULL),
          tuple("HIDDEN_DIM", self$hidden.dim, NULL, NULL),
          tuple("NUM_LAYERS", self$num.layers, NULL, NULL),
          tuple("MAX_ITER", self$max.iter, NULL, NULL),
          tuple("INTERVAL", self$interval, NULL, NULL),
          tuple("OPTIMIZER_TYPE", map.null(self$optimizer,
                                           self$optimizer.map),
                NULL, NULL),
          tuple("STATEFUL", to.integer(self$stateful), NULL, NULL),
          tuple("BIDIRECTIONAL", to.integer(self$bidirectional), NULL, NULL)
        )
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            (ParameterTable$new(param.tbl))$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn.context,
                                                "PAL_LSTM_TRAIN",
                                                in.tables,
                                                out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err$message)
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$model <- conn.context$table(model.tbl)
        self$loss <- conn.context$table(loss.tbl)
      }
    }
  )
)

#' @title Long Short-Term Memory
#' @name hanaml.LSTM
#' @description hanaml.LSTM is an R wrapper for PAL Long Short-Term Memory(LSTM).
#' @details Long short-term memory (LSTM) is one of the most famous modules of
#'          Recurrent Neural Networks(RNN). It can not only process single data point,
#'          but also the entire sequences of data, such as speech and stock prices.
#' @seealso \code{\link{predict.LSTM}}
#' @template  args-data
#' @param     key \code{character, optional}\cr
#'            Name of the time stamp column that represents the order of values in
#'            the time-series.\cr
#'            The type of this column should be INTEGER.\cr
#' @template  args-endog
#' @param     exog \code{character or list of character, optional}\cr
#'            An optional array of exogenous variables.\cr
#'            Defaults all other columns in \code{data} exclusive of \code{key} and
#'            \code{endog}.
#' @param     learning.rate \code{float, optional}\cr
#'            Specifies the learning rate for gradient descent.\cr
#'            Defaults to 0.01
#' @param     gru \code{logical, optional}\cr
#'            Specifies whether or not the use gated recurrent units(GRUs) instead of
#'            regular LSTM in recurrent neural network structure.\cr
#'            If not TRUE, only regular LSTM is used.\cr
#'            Defaults to FALSE.
#' @param     batch.size \code{integer, optional}\cr
#'            Number of pieces of data for training in one optimization iteration.\cr
#'            Defaults to 32.
#' @param     time.dim \code{integer, optional}\cr
#'            Specifying how many time steps in a sequence that will be trained
#'            by LSTM/GRU and then for time series prediction.\cr
#'            This value must be smaller than the length of input time series minus 1.\cr
#'            Defaults to 16.
#' @param     hidden.dim \code{integer, optional}\cr
#'            Number of hidden neurons in LSTM/GRU unit.\cr
#'            Defaults to 128.
#' @param     num.layers \code{int, optional}\cr
#'            Number of layers in LSTM/GRU unit.\cr
#'            Defaults to 1.
#' @param     max.iter \code{int, optional}\cr
#'            Maximum number of iterations, equivalent to maximum number of batches of data
#'            by which LSTM/GRU is trained.\cr
#'            Defaults to 1000.
#' @param     interval \code{int, optional}\cr
#'            Output the average loss within every \code{interval} iterations.\cr
#'            Defaults to 100.
#' @param     optimizer \code{c("SGD", "RMSprop", "Adam", "Adagrad"), optional}\cr
#'            Specifying which optimizer is used to train the LSTM/GRU model.\cr
#'            Defaults to "Adam".
#' @param     stateful \code{logical, optional}\cr
#'            If the value is TRUE, it enables stateful LSTM/GRU.
#'            Defaults to True.
#' @param     bidirectional \code{logical, optional}\cr
#'            If the value is TRUE, it uses bidirectional LSTM/GRU.\cr
#'            Otherwise, it uses LSTM/GRU.\cr
#'            Defaults to False.
#' @return
#' Returns an "LSTM" object with the following attributes:
#' \itemize{
#'   \item{loss: \code{DataFrame}}\cr
#'        For storing the the average loss in every \code{interval}
#'        iterations.
#'   \item{model: \code{DataFrame}}\cr
#'        Fitted LSTM/GRU model.
#'  }
#' @section Examples:
#' Input DataFrame df:
#' \preformatted{
#' > df$Head(3)$Collect()
#'    TIMESTAMP  SERIES
#' 1          0    20.7
#' 2          1    17.9
#' 3          2    18.8
#' }
#' Create an LSTM instance:
#' \preformatted{
#' > lstm <- LSTM(data = df,
#'                key = 'TIMESTAMP',
#'                gru=FALSE,
#'                bidirectional=FALSE,
#'                time.dim=16,
#'                max.iter=1000,
#'                learning.rate=0.01,
#'                batch.size=32,
#'                hidden.dim=128,
#'                num.layers=1,
#'                interval=1,
#'                stateful=FALSE,
#'                optimizer='Adam')
#' }
#' Peform predict on the fittd model:
#' \preformatted{
#' > res <- predict(lstm, df.predict)
#' }
#' Expected output:
#' \preformatted{
#' > res$Select(c("ID", "VALUE"))$Head(3)$Collect()
#'    ID      VALUE
#' 1   0  11.673560
#' 2   1  14.057195
#' 3   2  15.119411
#' }
#' @keywords TimeSeries, RNN
#' @export
hanaml.LSTM <- function(data = NULL,
                        key = NULL,
                        endog = NULL,
                        exog = NULL,
                        learning.rate = NULL,
                        gru = NULL,
                        batch.size = NULL,
                        time.dim = NULL,
                        hidden.dim = NULL,
                        num.layers = NULL,
                        max.iter = NULL,
                        interval = NULL,
                        optimizer = NULL,
                        stateful = NULL,
                        bidirectional = NULL) {
  LSTM$new(data,
           key,
           endog,
           exog,
           learning.rate,
           gru,
           batch.size,
           time.dim,
           hidden.dim,
           num.layers,
           max.iter,
           interval,
           optimizer,
           stateful,
           bidirectional)
}

#' @title LSTM Predict
#' @name predict.LSTM
#' @description Predict method for LSTM
#' @details Time-series prediction using LSTM model
#' @seealso \code{\link{hanaml.LSTM}}
#' @param data \code{DataFrame}\cr
#'        Data for prediction.
#'        Every row in the ``data`` should contain one piece of
#'        record data for prediction, i.e. it should be structured as follows:
#'        \itemize{
#'          \item{First column:} Record ID, type INTEGER.
#'          \item{Other columns:} Time-series and external data values,
#'          arranged in time order.}
#'        The number of all columns but the first ID column should be equal to
#'        \code{time.dim} * (M + 1), where M is the number of exogenous variables
#'        of the input data in the training phase.
#' @param top.k.attributions \code{integer, optional}\cr
#'        Specifies the number of features with highest attributions to output.\cr
#'        Defaults to 10.
#' @return
#' DataFrame\cr
#' Forecasted values, structured as follows:
#' \itemize{
#'   \item{ID:} type INTEGER, timestamp.
#'   \item{VALUE:} type DOUBLE, forecast value.
#'   \item{REASON_CODE:} type NCLOB, Sorted SHAP values for test data at each time step.
#' }
#' @keywords TimeSeries, RNN
#' @export
predict.LSTM <- function(model,
                         data,
                         top.k.attributions = NULL,
                         ...) {
  if (is.null(model$model)) {
    msg <- "Model not initialized. Perform a fit first."
    flog.error(msg)
    stop(msg)
  }
  top.k.attributions <- validateInput("top.k.attributions",
                                      top.k.attributions,
                                      "integer")
  conn.context <- data$connection.context
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_LSTM_PREDICT_PARAM_TBL_%s_%s",
                       model$id, unique.id)
  result.tbl <- sprintf("#PAL_LSTM_PREDICT_RESULT_TBL_%s_%s",
                        model$id, unique.id)
  in.tables <- list(data, model$model$name, param.tbl)
  tables <- list(param.tbl, result.tbl)
  out.tables <- list(result.tbl)
  param.rows <- list(tuple("TOP_K_ATTRIBUTIONS",
                           top.k.attributions,
                           NULL, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
      (ParameterTable$new(param.tbl))$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn.context,
                                          "PAL_LSTM_PREDICT",
                                          in.tables,
                                          out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return(conn.context$table(result.tbl))
}

GRUAttention <- R6Class(
  "GRUAttention",
  inherit = MlBase,
  public = list(
    learning.rate = NULL,
    batch.size = NULL,
    time.dim = NULL,
    hidden.dim = NULL,
    num.layers = NULL,
    max.iter = NULL,
    interval = NULL,
    model = NULL,
    loss = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          endog = NULL,
                          exog = NULL,
                          learning.rate = NULL,
                          batch.size = NULL,
                          time.dim = NULL,
                          hidden.dim = NULL,
                          num.layers = NULL,
                          max.iter = NULL,
                          interval = NULL) {
      super$initialize()
      if (!is.null(data)) {
        self$learning.rate <- validateInput("learnign.rate", learning.rate, "numeric")
        self$batch.size <- validateInput("batch.size", batch.size, "integer")
        self$time.dim <- validateInput("time.dim", time.dim, "integer")
        self$hidden.dim <- validateInput("hidden.dim", hidden.dim, "integer")
        self$num.layers <- validateInput("num.layers", num.layers, "integer")
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        self$interval <- validateInput("interval", interval, "integer")
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        if (is.null(key)) {
          key <- cols[[1]]
        }
        cols <- cols[! cols %in% key]
        endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
        if (is.null(endog)) {
          endog <- cols[[1]]
        }
        cols <- cols[! cols %in% endog]
        exog <- validateInput("exog", exog, cols, case.sensitive = TRUE)
        if (is.null(exog)) {
          exog <- cols
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "data must be given as DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        data <- data$Select(c(key, endog, exog))
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_ATTENTION_PARAM_TBL_%s_%s",
                             self$id, unique.id)
        model.tbl <- sprintf("#PAL_ATTENTIION_MODEL_TBL_%s_%s",
                             self$id, unique.id)
        loss.tbl <- sprintf("#PAL_ATTENTION_LOSS_TBL_%s_%s",
                            self$id, unique.id)
        in.tables <- list(data, param.tbl)
        tables <- list(param.tbl, loss.tbl, model.tbl)
        out.tables <- list(loss.tbl, model.tbl)
        param.rows <- list(
          tuple("LEARNING_RATE", NULL, self$learning.rate, NULL),
          tuple("BATCH_SIZE", self$batch.size, NULL, NULL),
          tuple("TIME_DIM", self$time.dim, NULL, NULL),
          tuple("HIDDEN_DIM", self$hidden.dim, NULL, NULL),
          tuple("NUM_LAYERS", self$num.layers, NULL, NULL),
          tuple("MAX_ITER", self$max.iter, NULL, NULL),
          tuple("INTERVAL", self$interval, NULL, NULL)
        )
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            ParameterTable$new(param.tbl)$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn.context,
                                                "PAL_ATTENTION_TRAIN",
                                                in.tables,
                                                out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err$message)
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$model <- conn.context$table(model.tbl)
        self$loss <- conn.context$table(loss.tbl)
      }
    }
  )
)

#' @title Gated Recurrent Units(GRU) based Encoder-Decoder Model with Attention Mechanism
#' @name hanaml.GRUAttention
#' @description hanaml.GRUAttion is an R wrapper for PAL Gated Recurrent Units(GRU) based
#'              Encoder-Decoder Model with Attention Mechanism for time-series prediction.
#' @details Attention allows the recurrent network to focus on the relevant parts of the input
#'          sequence as needed, accessing all the past hidden states of the encoder, instead of
#'          just the last one. At each decoding step, the decoder gets to look at any particular
#'          state of the encoder and can selectively pick out specific elements from that
#'          sequence to produce the output.
#' @seealso \code{\link{predict.GRUAttention}}
#' @template  args-data
#' @param     key \code{character, optional}\cr
#'            Name of the time stamp column that represents the order of values in
#'            the time-series.\cr
#'            The type of this column should be INTEGER.\cr
#' @template  args-endog
#' @param     exog \code{character or list of character, optional}\cr
#'            An optional array of exogenous variables.\cr
#'            Defaults all other columns in \code{data} exclusive of \code{key} and
#'            \code{endog}.
#' @param     learning.rate \code{float, optional}\cr
#'            Specifies the learning rate for gradient descent.\cr
#'            Defaults to 0.005.
#' @param     batch.size \code{integer, optional}\cr
#'            Number of pieces of data for training in one iteration.\cr
#'            Defaults to 32.
#' @param     time.dim \code{integer, optional}\cr
#'            Specifying how many time steps in a sequence that will be trained
#'            by attention and then for time series prediction.\cr
#'            This value must be smaller than the length of input time series minus 1.\cr
#'            Defaults to 16.
#' @param     hidden.dim \code{integer, optional}\cr
#'            Number of hidden neurons in every GRU layer.\cr
#'            Defaults to 64.
#' @param     num.layers \code{int, optional}\cr
#'            Number of layers in GRU unit at encoder part and decoder part.\cr
#'            Defaults to 1.
#' @param     max.iter \code{int, optional}\cr
#'            Maximum number of iterations, equivalent to maximum number of batches of data
#'            by which attention model is trained.\cr
#'            Defaults to 1000.
#' @param     interval \code{int, optional}\cr
#'            Output the average loss within every \code{interval} iterations.\cr
#'            Defaults to 100.
#' @return
#' Returns a "GRUAttention" instance with the following attributes:
#' \itemize{
#'   \item{loss: \code{DataFrame}}\cr
#'        For storing the the average loss in every \code{interval}
#'        iterations.
#'   \item{model: \code{DataFrame}}\cr
#'        Fitted GRU+Attention model.
#'  }
#' @section Examples:
#' Input DataFrame df:
#' \preformatted{
#' > df$Head(3)$Collect()
#'    TIME_STAMP   TARGET
#' 1           0    129.0
#' 2           1    148.0
#' 3           2    159.0
#' }
#' Create an LSTM instance:
#' \preformatted{
#' > att <- GRUAttention(data = df,
#'                       key = 'TIMESTAMP',
#'                       time.dim=6,
#'                       max.iter=1000,
#'                       learning.rate=0.005,
#'                       batch.size=8,
#'                       hidden.dim=64,
#'                       num.layers=2,
#'                       interval=50)
#' }
#' Peform predict on the fittd model:
#' \preformatted{
#' > res <- predict(att, df.predict)
#' }
#' Expected output:
#' \preformatted{
#' > res$Select(c("ID", "VALUE"))$Head(3)$Collect()
#'    ID      VALUE
#' 1   0  11.673560
#' 2   1  14.057195
#' 3   2  15.119411
#' }
#' @keywords TimeSeries, RNN, Attention
#' @export
hanaml.GRUAttention <- function(data = NULL,
                                key = NULL,
                                endog = NULL,
                                exog = NULL,
                                learning.rate = NULL,
                                batch.size = NULL,
                                time.dim = NULL,
                                hidden.dim = NULL,
                                num.layers = NULL,
                                max.iter = NULL,
                                interval = NULL) {
  GRUAttention$new(data,
                   key,
                   endog,
                   exog,
                   learning.rate,
                   batch.size,
                   time.dim,
                   hidden.dim,
                   num.layers,
                   max.iter,
                   interval)
}

#' @title GRU Attention Predict
#' @name predict.GRUAttention
#' @description Predict method for GRUAttention
#' @details Time-series prediction using GRU equipped with Attention Mechanism.
#' @seealso \code{\link{hanaml.GRUAttention}}
#' @param data \code{DataFrame}\cr
#'        Data for prediction.
#'        Every row in the ``data`` should contain one piece of
#'        record data for prediction, i.e. it should be structured as follows:
#'        \itemize{
#'          \item{First column:} Record ID, type INTEGER.
#'          \item{Other columns:} Time-series and external data values,
#'          arranged in time order.}
#'        The number of columns in \code{data} should be equal to
#'        \code{time.dim} * (M + 1) + 1, where M is the number of exogenous variables
#'        of the input data in the training phase.
#' @param top.k.attributions \code{integer, optional}\cr
#'        Specifies the number of features with highest attributions to output.\cr
#'        This value needs to be smaller than the length of time series data for prediction.\cr
#'        Defaults to 10.
#' @return
#' DataFrame\cr
#' Predicted values, structured as follows:
#' \itemize{
#'   \item{ID:} type INTEGER, timestamp.
#'   \item{VALUE:} type DOUBLE, forecast values of data records.
#'   \item{REASON_CODE:} type NCLOB, Sorted SHAP values for test data at each time step.
#' }
#' @keywords TimeSeries, RNN, Attention
#' @export
predict.GRUAttention <- function(model,
                                 data,
                                 top.k.attributions = NULL,
                                 ...) {
  if (is.null(model$model)) {
    msg <- "Model not initialized. Perform a fit first."
    flog.error(msg)
    stop(msg)
  }
  top.k.attributions <- validateInput("top.k.attributions",
                                      top.k.attributions,
                                      "integer")
  conn.context <- data$connection.context
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_ATTENTION_PREDICT_PARAM_TBL_%s_%s",
                       model$id, unique.id)
  result.tbl <- sprintf("#PAL_ATTENTION_PREDICT_RESULT_TBL_%s_%s",
                        model$id, unique.id)
  in.tables <- list(data, model$model$name, param.tbl)
  tables <- list(param.tbl, result.tbl)
  out.tables <- list(result.tbl)
  param.rows <- list(tuple("TOP_K_ATTRIBUTIONS",
                           top.k.attributions,
                           NULL, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
      ParameterTable$new(param.tbl)$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn.context,
                                          "PAL_ATTENTION_PREDICT",
                                          in.tables,
                                          out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return(conn.context$table(result.tbl))
}
