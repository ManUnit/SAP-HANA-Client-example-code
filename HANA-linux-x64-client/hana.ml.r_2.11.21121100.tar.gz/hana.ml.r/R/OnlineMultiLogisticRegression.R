OnlineMultiLogisticRegression <- R6Class(
  "OnlineMultiLogisticRegression",
  inherit = MlBase,
  public = list(
    class.label=NULL,
    init.learning.rate=NULL,
    decay=NULL,
    drop.rate=NULL,
    step.boundaries=NULL,
    constant.values=NULL,
    enet.alpha=NULL,
    enet.lambda=NULL,
    shuffle=NULL,
    shuffle.seed=NULL,
    weight.avg=NULL,
    weight.avg.begin=NULL,
    learning.rate.type=NULL,
    general.learning.rate=NULL,
    stair.case=NULL,
    cycle=NULL,
    epsilon=NULL,
    window.size=NULL,
    thread.ratio=NULL,
    progress.indicator.id=NULL,
    online.result=NULL,
    coef=NULL,
    model=NULL,
    learning.rate.type.map = list ('inverse.time.decay'=0,
                                   'exponential.decay'=1,
                                   'polynomial.decay'=2,
                                   'piecewise.constant.decay'=3,
                                   'adagrad'=4,
                                   'adadelta'=5,
                                   'rmsprop'=6),
    initialize = function(class.label=NULL,
                          init.learning.rate=NULL,
                          decay=NULL,
                          drop.rate=NULL,
                          step.boundaries=NULL,
                          constant.values=NULL,
                          enet.alpha=NULL,
                          enet.lambda=NULL,
                          shuffle=NULL,
                          shuffle.seed=NULL,
                          weight.avg=NULL,
                          weight.avg.begin=NULL,
                          learning.rate.type=NULL,
                          general.learning.rate=NULL,
                          stair.case=NULL,
                          cycle=NULL,
                          epsilon=NULL,
                          window.size=NULL){
        super$initialize()

        self$class.label <- validateInput("class.label", class.label, "list")
        self$init.learning.rate <- validateInput("init.learning.rate", init.learning.rate, "double")
        self$decay <- validateInput("decay", decay, "double")
        self$drop.rate <- validateInput("drop.rate", drop.rate, "integer")
        self$enet.alpha <- validateInput("enet.alpha", enet.alpha, "double")
        self$enet.lambda <- validateInput("enet.lambda", enet.lambda, "double")
        self$shuffle <- validateInput("shuffle", shuffle, "logical")
        self$shuffle.seed <- validateInput("shuffle.seed", shuffle.seed, "double")
        self$weight.avg <- validateInput("weight.avg", weight.avg, "logical")
        self$weight.avg.begin <- validateInput("weight.avg.begin", weight.avg.begin, "integer")

        if (!is.null(learning.rate.type)){
          learning.rate.type <- tolower(learning.rate.type)
        }
        self$learning.rate.type <- validateInput("learning.rate.type",
                                                 learning.rate.type, self$learning.rate.type.map)
        self$general.learning.rate <- validateInput("general.learning.rate", general.learning.rate, "double")
        self$stair.case <- validateInput("stair.case", stair.case, "double")
        self$cycle <- validateInput("cycle", cycle, "double")
        self$epsilon <- validateInput("epsilon", epsilon, "double")
        self$window.size <- validateInput("window.size", window.size, "double")

        if (!is.null(self$learning.rate.type)){
          # when learning.rate.type is 'Inverse.time.decay', 'Exponential.decay', 'Polynomial.decay', decay,
          # init.learning.rate and drop.rate are mandatory
          if (((is.null(decay)) || (is.null(init.learning.rate)) || (is.null(drop.rate)))
              && (self$learning.rate.type %in% c('inverse.time.decay', 'exponential.decay', 'polynomial.decay'))){
            msg <- paste("If learning.rate.type is 'Inverse.time.decay', 'Exponential.decay', 'Polynomial.decay',",
                         "decay, init.learning.rate and drop.rate are mandatory!")
            flog.error(msg)
            stop(msg)
          }

          # when learning.rate.type is 'Piecewise.constant.decay', step.boundaries, constant.values are mandatory.
          if (((is.null(step.boundaries)) || (is.null(constant.values)))
              && (self$learning.rate.type %in% c('piecewise.constant.decay'))){
            msg <- paste("If learning.rate.type is 'Piecewise.constant.decay',",
                         "step.boundaries and constant.values are mandatory!")
            flog.error(msg)
            stop(msg)
          }
        }

        # check step.boundaries
        self$step.boundaries <- validateInput("step.boundaries", step.boundaries, "list")
        if (!is.null(step.boundaries)){
          if (!all(sapply(step.boundaries,
                          inherits,
                          what =  c("numeric",
                                    "integer")))){
            msg <- "Valid values of `step.boundaries` must be a list of numerical values!"
            flog.error(msg)
            stop(msg)
          }
        }
        # check constant.values
        self$constant.values  <-  validateInput("constant.values", constant.values, "list")
        if (!is.null(constant.values)){
          if (!all(sapply(constant.values,
                          inherits,
                          what =  c("numeric",
                                    "integer")))){
            msg <- "Valid values of `constant.values` must be a list of numerical values!"
            flog.error(msg)
            stop(msg)
          }
        }

        self$model = NULL
        self$online.result = NULL
        self$coef = NULL
    },
    fit = function(data,
                   key = NULL,
                   features = NULL,
                   label = NULL,
                   formula = NULL,
                   thread.ratio=NULL,
                   progress.indicator.id = NULL){

      CheckConnection(data)
      conn <- data$connection.context

      self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
      self$progress.indicator.id <- validateInput("progress.indicator.id",
                                                  progress.indicator.id, "double")

      if (is.null(self$model)){

        if (is.null(self$class.label)){
          msg <- "class.label is mandatory!"
          flog.error(msg)
          stop(msg)
        }
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_OMLR_PARAM_TBL_%s_%s", self$id, unique.id)
        result.tbl <- sprintf("#PAL_OMLR_RESULT_TBL_%s_%s", self$id, unique.id)

        param.rows <- list(
          tuple("INITIAL_LEARN_RATE", NULL, self$init.learning.rate, NULL),
          tuple("DECAY", NULL, self$decay, NULL),
          tuple("DROP_RATE", self$drop.rate, NULL, NULL),
          tuple("STEP_BOUNDARIES", NULL, NULL, self$step.boundaries),
          tuple("CONSTANT_VALUES", NULL, NULL, self$constant.values),
          tuple("ENET_LAMBDA", NULL, self$enet.lambda, NULL),
          tuple("ENET_ALPHA", NULL, self$enet.alpha, NULL),
          tuple("NEED_SHUFFLE", to.integer(self$shuffle), NULL, NULL),
          tuple("SHUFFLE_SEED", self$shuffle.seed, NULL, NULL),
          tuple("NEED_WEIGHT_AVERAGE", to.integer(self$weight.avg), NULL, NULL),
          tuple("WEIGHT_AVERAGE_BEGIN", self$weight.avg.begin, NULL, NULL),
          tuple("LEARN_RATE_TYPE", map.null(self$learning.rate.type,
                                            self$learning.rate.type.map), NULL, NULL),
          tuple("GENERAL_LEARN_RATE", NULL, self$general.learning.rate, NULL),
          tuple("STAIR_CASE", self$stair.case, NULL, NULL),
          tuple("CYCLE", self$cycle, NULL, NULL),
          tuple("EPSILON", NULL, self$epsilon, NULL),
          tuple("WINDOW_SIZE", NULL, self$window.size, NULL))

        if (!is.null(self$step.boundaries)) {
          param.rows <- append(param.rows,
                               list(tuple("STEP_BOUNDARIES", NULL, NULL,
                                           paste(self$step.boundaries,
                                                 collapse = ", "))))
        }
        if (!is.null(self$constant.values)) {
          param.rows <- append(param.rows,
                               list(tuple("CONSTANT_VALUES", NULL, NULL,
                                           paste(self$constant.values,
                                                 collapse = ", "))))
        }
        for (each in self$class.label) {
          temp.list <- tuple("CLASS_LABEL", NULL, NULL, each)
          param.rows <- append(param.rows, list(temp.list))
        }

        in.tables <- list(param.tbl)
        out.tables <- list(result.tbl)
        tables <- list(param.tbl, result.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,(ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
          errorhelper(CallPalAutoWithConnection(conn,
                                                "PAL_INIT_ONLINE_MULTICLASS_LOGISTIC_REGRESSION",
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        self$online.result <- conn$table(result.tbl)
      }

      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE)
      cols <- cols[!cols %in% key]
      if (inherits(formula, "formula")){
        parseformula <- ParseFormula(data, formula)
        label <- parseformula[[1]]
        features <- parseformula[[2]]
        features <- features[! features %in% key]
      }
      label <- validateInput("label", label, cols, case.sensitive = TRUE)

      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features)){
        features <- cols
      }
      if (!is.null(key)){
        id.col <- list(key)
        cols <- cols[! cols %in% key]
      } else {
        id.col <- list()
      }

      selected <- append(id.col, label)
      selected <- append(selected, features)

      if (!inherits(data, "DataFrame")) {
        msg <- "data must be given as a DataFrame."
        flog.error(msg)
        stop(msg)
      }

      data <- data$Select(selected)
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#PAL_OMLR_PARAM_TBL_%s_%s", self$id, unique.id)
      input.name.tbl <- sprintf("#PAL_OMLR_INPUT_TBL_%s_%s", self$id, unique.id)
      coef.tbl <- sprintf("#PAL_OMLR_COEF_TBL_%s_%s", self$id, unique.id)
      online.update.tbl <- sprintf("#PAL_OMLR_ONLINE_UPDATE_TBL_%s_%s", self$id, unique.id)

      ExecuteLogged(conn$connection, paste("CREATE LOCAL TEMPORARY COLUMN TABLE",
                                           input.name.tbl,
                                           "(\"SEQUENCE\" INTEGER,",
                                           "\"INTERMEDIATE_MODEL\" NVARCHAR(5000))"))
      tryCatch({
        if (is.null(self$model)){
          ExecuteLogged(conn$connection, sprintf("INSERT INTO %s SELECT * FROM (%s)",
                                                 input.name.tbl,
                                                 self$online.result$select.statement))
        } else {
          ExecuteLogged(conn$connection, sprintf("INSERT INTO %s SELECT * FROM (%s)",
                                                 input.name.tbl,
                                                 self$model[[2]]$select.statement))
        }

      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn, input.name.tbl)
        stop(msg)
      })
      input.tbl <- conn$table(input.name.tbl)
      param.rows <- list(
        tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
        tuple("PROGRESS_INDICATOR_ID", NULL, NULL, self$progress.indicator.id),
        tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL))

      tables <- list(param.tbl, coef.tbl, online.update.tbl)
      in.tables <- list(data, input.tbl, param.tbl)
      out.tables <- list(coef.tbl, online.update.tbl)
      tryCatch({
        errorhelper(CreateTWithConnection(conn,(ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
        errorhelper(CallPalAutoWithConnection(conn,
                                              "PAL_TRAIN_ONLINE_MULTICLASS_LOGISTIC_REGRESSION",
                                              in.tables,
                                              out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn, tables)
        stop(msg)
      })

      self$coef <- conn$table(coef.tbl)
      self$online.result <- conn$table(online.update.tbl)
      self$model <- list(self$coef, self$online.result)

    },
    score = function(data,
                     key,
                     features = NULL,
                     label = NULL) {
      if (is.null(self$model)) {
        msg <- "Model not initialized. Perform a fit first."
        flog.error(msg = msg)
        stop(msg)
      }

      logr <- hanaml.LogisticRegression()
      logr$model <- self$model[[1]]
      score <- logr$score(data,
                          key,
                          features = features,
                          label = label,
                          multi.class = TRUE,
                          class.map0 = NULL,
                          class.map1 = NULL,
                          categorical.variable = NULL)
      return(score)
    }
))

#' @title Online Multi Logistic Regression
#' @name hanaml.OnlineMultiLogisticRegression
#' @description
#' This algorithm is the online version of Multi-Class Logistic Regression,
#' while the Multi-Class Logistic Regression is offline/batch version.
#' The difference is that during training phase, for the offline/batch version algorithm
#' it requires all training data to be fed into the algorithm in one batch,
#' then it tries its best to output one model to best fit the training data.
#' This infers that the computer must have enough memory to store all data,
#' and can obtain all data in one batch. Online version algorithm applies
#' in scenario that either or all these two assumptions are not right.
#' @seealso \code{\link{predict.OnlineMultiLogisticRegression}}
#' @param class.label \code{list of character}\cr
#'        Indicate the class label and should be at least two class labels.
#' @param init.learning.rate \code{float, optional}\cr
#'        The initial learning rate for learning rate schedule. \cr
#'        Value should be larger than 0.
#'        Only valid when \emph{learning.rate.type} is
#'        'Inverse.time.decay', 'Exponential.decay', 'Polynomial.decay'.
#' @param decay \code{float, optional}\cr
#'        Specify the learning rate decay speed for learning rate schedule.
#'        Larger value indicates faster decay.\cr
#'        Value should be larger than 0.
#'        When \emph{learning.rate.type} is 'exponential.decay',
#'        value should be larger than 1.
#'        Only valid when \emph{learning.rate.type}
#'        is 'Inverse.time.decay', 'Exponential.decay', 'Polynomial.decay'.
#' @param drop.rate \code{integer, optional}\cr
#'        Specify the decay frequency.
#'        There are apparent effect when \emph{stair.case} is true.\cr
#'        Value should be larger than 0.
#'        Only valid when \emph{learning.rate.type} is 'Inverse.time.decay',
#'        'Exponential.decay', 'Polynomial.decay'.
#' @param step.boundaries \code{ character, optional}\cr
#'        Specify the step boundaries for regions where step size remains constant.
#'        The format of this parameter is a comma separated unsigned integer value.
#'        The step value start from 0. The values should be in increasing order.
#'        Empty value for this parameter is allowed.\cr
#'        Only valid when \emph{learning.rate.type} is 'Piecewise.constant.decay'.
#' @param constant.values  \code{character, optional}\cr
#'        Specify the constant step size for each region defined by \emph{step.boundaries}.
#'        The format of this parameter is a comma separated double value.
#'        There should always be one more value than \emph{step.boundaries}.
#'        Only valid when \emph{learning.rate.type} is 'Piecewise.constant.decay'.
#' @param enet.alpha  \code{float, optional}\cr
#'        Elastic-Net mixing parameter.
#'        The valid range is [0, 1]. When it is 0, this means Ridge penalty;
#'        When it is 1, it is Lasso penalty.
#'        Only valid when \emph{enet.lambda} is not 0.0.\cr
#'        Defaults to 1.0.
#' @param enet.lambda  \code{float, optional}\cr
#'        Penalized constant. The value should be larger than or equal to 0.0.
#'        The higher the value, the characteronger the regularization.
#'        When it equal to 0.0, there is no regularization.\cr
#'        Defaults to 0.0.
#' @param shuffle \code{logical, optonal}\cr
#'        logical value indicating whether need to shuffle the row order of observation data.
#'        False means keeping original order; True means performing shuffle operation.\cr
#'        Defaults to False.
#' @param shuffle.seed  \code{integer, optonal}\cr
#'        The seed is used to initialize the random generator to perform shuffle operation.
#'        The value of this parameter should be larger than or equal to 0.
#'        If need to reproduce the result when performing shuffle operation,
#'        please set this value to non-zero.\cr
#'        Only valid when \emph{shuffle} is True.
#'        Defaults to 0.
#' @param weight.avg  \code{logical, optonal}\cr
#'        logical value indicating whether need to perform average operator over output model.
#'        False means directly output model;
#'        True means perform average operator over output model.
#'        Currently only support Polyak Ruppert Average.\cr
#'        Defaults to False.
#' @param weight.avg.begin  \code{integer, optonal}\cr
#'        Specify the beginning step counter to perform the average operator over model.
#'        The value should be larger than or equal to 0. When current step counter is less than this parameter,
#'        just directly output model.Only valid when \emph{weight.avg} is True.\cr
#'        Defaults to 0.
#' @param learning.rate.type  \code{character, optonal}\cr
#'        Specify the learning rate type for SGD algorithm.
#'         - 'Inverse.time.decay'
#'         - 'Exponential.decay'
#'         - 'Polynomial.decay'
#'         - 'Piecewise.constant.decay'
#'         - 'AdaGrad'
#'         - 'AdaDelta'
#'         - 'RMSProp'
#'        Defaults to 'RMSProp'.
#' @param general.learning.rate  \code{float, optonal}\cr
#'        Specify the general learning rate used in AdaGrad and RMSProp.
#'        The value should be larger than 0.\cr
#'        Only valid when \emph{learning.rate.type} is 'AdaGrad', 'RMSProp'.
#'        Defaults to 0.001.
#' @param stair.case  \code{logical, optonal}\cr
#'        logical value indicate the drop way of step size. False means drop step size smoothly.
#'        Only valid when \emph{learning.rate.type} is 'Inverse.time.decay', 'Exponential.decay'.
#'        Defaults to False.
#' @param cycle \code{logical, optonal}\cr
#'        indicate whether need to cycle from the start when reaching specified end learning rate.
#'        False means do not cycle from the start; True means cycle from the start.
#'        Only valid when \emph{learning.rate.type} is 'Polynomial.decay'.\cr
#'        Defaults to False.
#' @param epsilon  \code{float, optonal}\cr
#'        This parameter has multiple purposes depending on the learn rate type.
#'        The value should be within (0, 1). When used in learn rate type 0 and 1, it represent the smallest allowable step size.
#'        When step size reach this value, it will no longer change.
#'        When used in \emph{learning.rate.type} 'Polynomial.decay', it represent the end learn rate.
#'        When used in \emph{learning.rate.type} 'AdaGrad', 'AdaDelta', 'RMSProp', it is used to avoid dividing by 0.
#'        Only valid when \emph{learning.rate.type} is not 'Piecewise.constant.decay'.\cr
#'        Defaults to 1E-8.
#' @param window.size \code{float, optonal}\cr
#'        This parameter controls the moving window size of recent steps. The value should be in range (0, 1).
#'        Larger value means more steps are kept in track.
#'        Only valid when \emph{learning.rate.type} is 'AdaDelta', 'RMSProp'.\cr
#'        Defaults to 0.9.
#'
#' @section Methods:
#' \describe{
#'    \code{fit(data = NULL, key = NULL, features = NULL, formula = NULL, thread.ratio = NULL, progress.indicator.id=NULL)}\cr\cr
#'    The fit function of an "OnlineMultiLogisticRegression" object.\cr
#'
#'    \emph{Usage:\cr
#'    OMLR <- hanaml.OnlineMultiLogisticRegression()\cr
#'    OMLR$fit(data, key='ID', features=list('X1','X2'))}\cr
#'
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{data, DataFrame}\cr Input data.}
#'     \item{\code{key, character, optional}\cr Name of the ID column.\cr
#'                 If not provided, the \emph{data} is assumed to have no ID column.\cr
#'                 No default value.}
#'     \item{\code{features, character of list of characters, optional}\cr
#'                 Name of feature columns.\cr
#'                 If not provided, it defaults all non-key, non-label columns of \emph{data}.}
#'     \item{\code{label, character, optional}\cr
#'                 Name of the column which specifies the dependent variable.\cr
#'                 Defaults to the last column of \emph{data} if not provided.}
#'     \item{\code{formula, formula type, optional}\cr
#'                 Formula to be used for model generation.
#'                 format = label ~ <feature_list>
#'                 e.g.: formula = CATEGORY~V1+V2+V3 \cr
#'                 You can either give the formula,
#'                 or a feature and label combination, but do not provide both.\cr
#'                 Defaults to NULL.}
#'     \item{\code{thread.ratio, double, optional}\cr
#'                 Controls the proportion of available threads that can be used by this
#'                 function. \cr
#'                 The value range is from 0 to 1, where 0 indicates a single thread,
#'                 and 1 indicates all available threads. Values between 0 and 1 will use up to
#'                 that percentage of available threads. Values outside this
#'                 range are ignored.\cr
#'                 Defaults to -1. }
#'     \item{\code{progress.indicator.id, character, optional}\cr
#'                 The ID of progress indicator for model evaluation/parameter selection.\cr
#'                 Progress indicator deactivated if no value provided.}
#'  }
#' }
#' @return
#' A "OnlineMultiLogisticRegression" object with the following attributes:
#' \itemize{
#' \item{coef: \code{DataFrame}}\cr
#' Coefficient values for multi logisitic regression model.
#' \item{online.result: \code{DataFrame}}\cr
#' Updated online training result.}
#' @section Examples:
#' First, initialize an online multi logistic regression instance:
#' \preformatted{
#' > omlr <- OnlineMultiLogisticRegression(class.label=list('0','1','2'),
#'                                         enet.lambda=0.01,
#'                                         enet.alpha=0.2, weight.avg=True,
#'                                         weight.avg.begin=8, learning.rate.type = 'rmsprop',
#'                                         general.learning.rate=0.1,
#'                                         window.size=0.9, epsilon = 1e-6)
#'}
#' Four rounds of data:
#' \preformatted{
#' > df.1$Collect()
#'          X1        X2    Y
#' 0  1.160456 -0.079584  0.0
#' 1  1.216722 -1.315348  2.0
#' 2  1.018474 -0.600647  1.0
#' 3  0.884580  1.546115  1.0
#' 4  2.432160  0.425895  1.0
#' 5  1.573506 -0.019852  0.0
#' 6  1.285611 -2.004879  1.0
#' 7  0.478364 -1.791279  2.0
#'
#' > df.2$Collect()
#'          X1        X2    Y
#' 0 -1.799803  1.225313  1.0
#' 1  0.552956 -2.134007  2.0
#' 2  0.750153 -1.332960  2.0
#' 3  2.024223 -1.406925  2.0
#' 4  1.204173 -1.395284  1.0
#' 5  1.745183  0.647891  0.0
#' 6  1.406053  0.180530  0.0
#' 7  1.880983 -1.627834  2.0
#'
#' > df.3$Collect()
#'          X1        X2    Y
#' 0  1.860634 -2.474313  2.0
#' 1  0.710662 -3.317885  2.0
#' 2  1.153588  0.539949  0.0
#' 3  1.297490 -1.811933  2.0
#' 4  2.071784  0.351789  0.0
#' 5  1.552456  0.550787  0.0
#' 6  1.202615 -1.256570  2.0
#' 7 -2.348316  1.384935  1.0
#'
#' > df.4$Collect()
#'          X1        X2    Y
#' 0 -2.132380  1.457749  1.0
#' 1  0.549665  0.174078  1.0
#' 2  1.422629  0.815358  0.0
#' 3  1.318544  0.062472  0.0
#' 4  0.501686 -1.286537  1.0
#' 5  1.541711  0.737517  1.0
#' 6  1.709486 -0.036971  0.0
#' 7  1.708367  0.761572  0.0
#' }
#'
#' Round 1, invoke fit() for training the model with df.1:
#' \preformatted{
#' > omlr$fit(df.1, label='Y', features=list('X1', 'X2'))
#' }
#' Output:
#' \preformatted{
#' > omlr$coef$Collect
#'        VARIABLE_NAME CLASSLABEL  COEFFICIENT
#' 0  __PAL_INTERCEPT__          0    -0.245137
#' 1  __PAL_INTERCEPT__          1     0.112396
#' 2  __PAL_INTERCEPT__          2    -0.236284
#' 3                 X1          0    -0.189930
#' 4                 X1          1     0.218920
#' 5                 X1          2    -0.372500
#' 6                 X2          0     0.279547
#' 7                 X2          1     0.458214
#' 8                 X2          2    -0.185378
#' }
#'
#'
#' Round 2, invoke fit() for training the model with df.2:
#' \preformatted{
#' > omlr$fit(df.2, label='Y', features=list('X1', 'X2'))
#' }
#' Output:
#' \preformatted{
#' > omlr$coef$Collect
#'        VARIABLE_NAME CLASSLABEL  COEFFICIENT
#' 0  __PAL_INTERCEPT__          0    -0.359296
#' 1  __PAL_INTERCEPT__          1     0.163218
#' 2  __PAL_INTERCEPT__          2    -0.182423
#' 3                 X1          0    -0.045149
#' 4                 X1          1    -0.046508
#' 5                 X1          2    -0.122690
#' 6                 X2          0     0.420425
#' 7                 X2          1     0.594954
#' 8                 X2          2    -0.451050
#' }
#'
#' Round 3, invoke fit() for training the model with df.3:
#' \preformatted{
#' > omlr$fit(df.3, label='Y', features=list('X1', 'X2'))
#' }
#' Output:
#' \preformatted{
#' > omlr$coef$Collect
#'        VARIABLE_NAME CLASSLABEL  COEFFICIENT
#' 0  __PAL_INTERCEPT__          0    -0.225687
#' 1  __PAL_INTERCEPT__          1     0.031453
#' 2  __PAL_INTERCEPT__          2    -0.173944
#' 3                 X1          0     0.100580
#' 4                 X1          1    -0.208257
#' 5                 X1          2    -0.097395
#' 6                 X2          0     0.628975
#' 7                 X2          1     0.576544
#' 8                 X2          2    -0.582955
#'  }
#' Round 4, invoke fit() for training the model with df.4:
#' \preformatted{
#' > omlr$fit(df.4, label='Y', features=list('X1', 'X2'))
#' }
#' Output:
#' \preformatted{
#' > omlr.coef$Collect
#'        VARIABLE_NAME CLASSLABEL  COEFFICIENT
#' 0  __PAL_INTERCEPT__          0    -0.204118
#' 1  __PAL_INTERCEPT__          1     0.071965
#' 2  __PAL_INTERCEPT__          2    -0.263698
#' 3                 X1          0     0.239740
#' 4                 X1          1    -0.326290
#' 5                 X1          2    -0.139859
#' 6                 X2          0     0.696389
#' 7                 X2          1     0.590014
#' 8                 X2          2    -0.643752
#' }
#' @keywords Classification
#' @export
hanaml.OnlineMultiLogisticRegression <- function(class.label=NULL,
                                                 init.learning.rate=NULL,
                                                 decay=NULL,
                                                 drop.rate=NULL,
                                                 step.boundaries=NULL,
                                                 constant.values=NULL,
                                                 enet.alpha=NULL,
                                                 enet.lambda=NULL,
                                                 shuffle=NULL,
                                                 shuffle.seed=NULL,
                                                 weight.avg=NULL,
                                                 weight.avg.begin=NULL,
                                                 learning.rate.type=NULL,
                                                 general.learning.rate=NULL,
                                                 stair.case=NULL,
                                                 cycle=NULL,
                                                 epsilon=NULL,
                                                 window.size=NULL) {
  OnlineMultiLogisticRegression$new(class.label,
                                    init.learning.rate,
                                    decay,
                                    drop.rate,
                                    step.boundaries,
                                    constant.values,
                                    enet.alpha,
                                    enet.lambda,
                                    shuffle,
                                    shuffle.seed,
                                    weight.avg,
                                    weight.avg.begin,
                                    learning.rate.type,
                                    general.learning.rate,
                                    stair.case,
                                    cycle,
                                    epsilon,
                                    window.size )
}


#' @title Make Predictions from a "OnlineMultiLogisticRegression" Object
#' @name predict.OnlineMultiLogisticRegression
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "OnlineMultiLogisticRegression" object.
#' @seealso \code{\link{hanaml.OnlineMultiLogisticRegression}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A "OnlineMultiLogisticRegression" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-threadratio
#' @return
#' Returns a \code{Dataframe}\cr containing predicted values, characteructured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as `data`'s ID column.}
#'   \item{CLASS, type NVARCHAR, predicted class name.}
#'   \item{PROBABILITY, type DOUBLE.}
#' }
#' @section Examples:
#' omlr is an "OnlineMultiLogisticRegression" object.\cr
#' Call predict() with df.predict:
#' \preformatted{
#' > df.predict$Collect
#'    ID   X1   X2
#' 0   1  1.2  0.7
#' 1   2  1.0 -2.0
#' }
#' Invoke predict():
#' \preformatted{
#' > fitted <- predict(omlr, df.predict, key='ID', features=list('X1', 'X2'))
#' > fitted$Collect
#'    ID CLASS  PROBABILITY
#' 0   1     0     0.539350
#' 1   2     2     0.830026
#' }
#' @keywords Classification
#' @export
predict.OnlineMultiLogisticRegression <- function(model,
                                                  data,
                                                  key,
                                                  features = NULL,
                                                  thread.ratio = NULL){
  if (is.null(model$model)) {
    msg <- "Model not initialized. Perform a fit first."
    flog.error(msg = msg)
    stop(msg)
  }

  logr <- hanaml.LogisticRegression(multi.class = TRUE)
  logr$model <- model$model[[1]]
  fitted <- predict(model=logr,
                    data=data,
                    key=key,
                    features=features,
                    verbose = FALSE,
                    thread.ratio = thread.ratio,
                    multi.class = TRUE,
                    class.map0 = NULL,
                    class.map1 = NULL,
                    categorical.variable = NULL)
  return(fitted)
  }

