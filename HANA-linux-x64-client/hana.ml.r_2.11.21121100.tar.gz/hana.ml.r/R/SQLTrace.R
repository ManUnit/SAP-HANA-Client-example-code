#' @title hanaml.sqltrace
#' @name hanaml.sqltrace
#' @description
#' Command to start or end logging SQL statement.
#' @param cmd \code{'start', 'stop'}\cr
#'  - 'start': begin to log SQL statement into hanaml_r.log at TRACE level.\cr
#'  - 'stop': stop the logging.
#' @return
#' The logging status.
#' @export
hanaml.sqltrace <- function(cmd = NULL) {
  if (!is.null(cmd)){
    if (cmd == 'start') {
      is.sqltrace <<- TRUE
    }
    if (cmd == 'stop') {
      is.sqltrace <<- FALSE
    }
  }
  if (exists('is.sqltrace')){
    return (is.sqltrace)
  }
  return (FALSE)
}
