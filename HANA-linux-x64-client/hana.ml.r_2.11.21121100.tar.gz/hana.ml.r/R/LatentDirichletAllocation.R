LatentDirichletAllocation <- R6Class(
  "LatentDirichletAllocation",
  inherit = MlBase,
  public = list(
    n.components = NULL, #TOPICS
    doc.topic.prior = NULL, #ALPHA
    topic.word.prior = NULL, #BETA
    burn.in = NULL,
    iteration = NULL,
    thin = NULL,
    seed = NULL,
    max.top.words = NULL,
    threshold.top.words = NULL,
    gibbs.init = NULL,
    delimiters = NULL,
    output.word.assignment = NULL,
    doc.topic.dist = NULL,
    word.topic.assignment = NULL,
    topic.top.words = NULL,
    topic.word.dist = NULL,
    dictionary = NULL,
    statistics = NULL,
    cv.parameter = NULL,
    model = NULL,
    method.map = list("uniform" = 0, "gibbs" = 1),
    initialize = function(data = NULL,
                          key = NULL,
                          document = NULL,
                          n.components = NULL, #TOPICS
                          doc.topic.prior = NULL, #ALPHA
                          topic.word.prior = NULL, #BETA
                          burn.in =NULL,
                          iteration = NULL,
                          thin = NULL,
                          seed = NULL,
                          max.top.words = NULL,
                          threshold.top.words = NULL,
                          gibbs.init = NULL,
                          delimiters = NULL,
                          output.word.assignment = NULL) {
      super$initialize()

      if (!is.null(data)) {
        self$doc.topic.prior <-
          validateInput("doc.topic.prior", doc.topic.prior, "double")
        self$topic.word.prior <-
          validateInput("topic.word.prior", topic.word.prior, "double")
        self$burn.in <-
          validateInput("burn.in", burn.in, "integer")
        self$seed <-
          validateInput("seed", seed, "integer")
        self$thin <- validateInput("thin", thin, "integer")
        self$iteration <- validateInput("iteration", iteration, "integer")
        self$max.top.words <-
          validateInput("max.top.words", max.top.words, "integer")
        self$threshold.top.words <-
          validateInput("threshold.top.words", threshold.top.words, "double")
        if (!is.null(self$max.top.words) && !is.null(self$threshold.top.words)) {
          msg <-
            paste("Parameter max.top.words and threshold.top.words cannot be",
                  "provided together, please choose one of them.")
          flog.error(msg)
          stop(msg)
        }
        self$gibbs.init <- validateInput("gibbs.init", gibbs.init, self$method.map)

        if (!is.null(delimiters)) {
          delimiters <- validateInput("delimiters", delimiters, "LISTOFSTRINGS")
          for (delimiter in delimiters) {
            if (nchar(delimiter) != 1) {
              msg <- "Each delimiter must be one character long."
              flog.error(msg)
              stop(msg)
            }
          }
          self$delimiters <- paste(delimiters, sep = "", collapse = "")
        }

        if (!is.null(document)) {
          if (length(document) != 1) {
            msg <- "LatentDirichletAllocation requires exactly one document column."
            flog.error(msg)
            stop(msg)
          }
        }

        self$output.word.assignment <-
          validateInput("output.word.assignment",
                        output.word.assignment, "logical")
        self$n.components <-
          validateInput("n.components", n.components, "integer", required = TRUE)

        if (!inherits(data, "DataFrame")) {
          msg <- "data must be given as a DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn <- data$connection.context

        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
        cols <- cols[! cols %in% key]
        document <- validateInput("document", document, cols, case.sensitive = TRUE)
        if (is.null(document)){
          document <- cols[[1]]
        }

        data <- data$Select(c(key, document))

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s_%s", self$id, unique.id)
        doc.topic.dist.tbl <- sprintf("#PAL_LDA_DOC_TOPIC_DIST_TBL_%s_%s", self$id, unique.id)
        word.topic.assignment.tbl <- sprintf("#PAL_LDA_WORD_TOPIC_ASSIGNMENT_%s_%s", self$id, unique.id)
        topic.top.words.tbl <- sprintf("#PAL_LDA_TOPIC_TOP_WORDS_TBL_%s_%s", self$id, unique.id)
        topic.word.dist.tbl <- sprintf("#PAL_LDA_TOPIC_WORD_DIST_TBL_%s_%s", self$id, unique.id)
        dictionary.tbl <- sprintf("#PAL_LDA_DICTIONARY_TBL_%s_%s", self$id, unique.id)
        statistics.tbl <- sprintf("#PAL_LDA_STASTISTICS_TBL_%s_%s", self$id, unique.id)
        cv.parameter.tbl <- sprintf("#PAL_LDA_CV_PARAMETER_%s_%s", self$id, unique.id)
        param.rows <- list(
          tuple("TOPICS", self$n.components, NULL, NULL),
          tuple("ALPHA", NULL, self$doc.topic.prior, NULL),
          tuple("BETA", NULL, self$topic.word.prior, NULL),
          tuple("BURNIN", self$burn.in, NULL, NULL),
          tuple("THIN", self$thin, NULL, NULL),
          tuple("ITERATION", self$iteration, NULL, NULL),
          tuple("SEED", self$seed, NULL, NULL),
          tuple("INIT", map.null(self$gibbs.init, self$method.map), NULL, NULL),
          tuple("OUTPUT_WORD_ASSIGNMENT",
                to.integer(self$output.word.assignment), NULL, NULL),
          tuple("MAX_TOP_WORDS", self$max.top.words, NULL, NULL),
          tuple("DELIMIT", NULL, NULL, self$delimiters),
          tuple("THRESHOLD_TOP_WORDS", NULL, self$threshold.top.words, NULL)
        )

        in.tables <- list(data, param.tbl)
        out.tables <- list(
          doc.topic.dist.tbl,
          word.topic.assignment.tbl,
          topic.top.words.tbl,
          topic.word.dist.tbl,
          dictionary.tbl,
          statistics.tbl,
          cv.parameter.tbl
        )
        tables <- c(param.tbl, out.tables)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
                      (ParameterTable$new(param.tbl))$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn,
                                                "PAL_LATENT_DIRICHLET_ALLOCATION",
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })

        self$doc.topic.dist <- conn$table(doc.topic.dist.tbl)
        self$word.topic.assignment <- conn$table(word.topic.assignment.tbl)
        self$topic.top.words <- conn$table(topic.top.words.tbl)
        self$topic.word.dist <- conn$table(topic.word.dist.tbl)
        self$dictionary <- conn$table(dictionary.tbl)
        self$statistics <- conn$table(statistics.tbl)
        self$cv.parameter <- conn$table(cv.parameter.tbl)
        self$model <- list(self$topic.word.dist,
                           self$dictionary,
                           self$cv.parameter)
      }
    }
  )
)

#' @title Latent Dirichlet Allocation
#' @description hanaml.LatentDirichletAllocation is a R wrapper for
#'  SAP HANA PAL Latent Dirichlet Allocation.
#' @name hanaml.LatentDirichletAllocation
#' @details Latent Dirichlet allocation (LDA) is a generative model
#' in which each item (word) of a collection (document) is
#' generated from a finite mixture over several latent groups (topics).
#' @seealso \code{\link{transform.LatentDirichletAllocation}}
#' @template args-data
#' @template args-key
#' @param    document \code{character, optional}\cr
#' Name of the document column.\cr
#' Defaults to the first no-ID column.
#' @param    n.components \code{integer}\cr
#' Expected number of topics in the corpus.
#' @param    doc.topic.prior \code{double, optional}\cr
#' Specifies the prior weight related to document-topic distribution.\cr
#' Defaults to 50/\emph{n_components}.
#' @param    topic.word.prior \code{double, optional}\cr
#' Specifies the prior weight related to topic-word distribution.\cr
#' Defaults to 0.1.
#' @param    burn.in \code{integer, optional}\cr
#' Number of omitted Gibbs iterations at the beginning.\cr
#' Defaults to 0.
#' @param    iteration \code{integer, optional}\cr
#' Number of Gibbs iterations.\cr
#' Defaults to 2000.
#' @param    thin \code{integer, optional}\cr
#' Number of omitted in-between Gibbs iterations.\cr
#' Defaults to 1.
#' @param    seed \code{integer, optional}\cr
#' Indicates the seed used to initialize the random number generator.\cr
#' \itemize{
#'      \item{\code{0}: uses the system time}
#'      \item{\code{Not 0}: uses the specified seed}}
#' Defaults to 0.
#' @param    max.top.words \code{integer, optional}\cr
#' Specifies the maximum number of words to be output for each topic.\cr
#' Only valid when the topic top words output table is provided.
#' It cannot be used together with parameter \emph{threshold.top.words}.\cr
#' Defaults to 0.
#' @param    threshold.top.words \code{double, optional}\cr
#' The algorithm outputs top words for each topic if the probability is
#' larger than this threshold.\cr
#' Only valid when the topic top words output table is provided.
#' It cannot be used together with parameter \emph{max.top.words}.\cr
#' Defaults to 0.
#' @param    gibbs.init \code{character, optional}\cr
#'   Specifies initialization method for Gibbs sampling:\cr
#'   'uniform': Assigns each word in each document a topic by a uniform
#'   distribution. Each topic has the same probability to be assigned for each
#'   word.\cr
#'   'gibbs': Initialization by Gibbs sampling. Assigns each word in each document a
#'   topic by one round of Gibbs sampling using the prior distribution of
#'   document-topic and topic-word given by parameters ALPHA and BETA.\cr
#'   Defaults to 'uniform'.
#' @param    delimiters \code{list of character, optional}\cr
#' Specifies the delimit to separate words in a document.\cr
#' For example, if the words are separated by , or :, then the delimit should
#' be "," or ":".\cr
#' Defaults to ''(single space).
#' @param    output.word.assignment \code{logical, optional}\cr
#' Controls whether to output the word-topic assignment or not.
#' Note that if this parameter is set to TRUE, the procedure would take
#' more time to return to write the \emph{word-topic assignment} table. \cr
#' Defaults to FALSE.
#'
#' @return
#' A "LatentDirecheletAllocation" object with the following attributes:
#' \itemize{
#'  \item{\code{doc.topic.dist: DataFrame}}\cr
#'  Document-topic distribution table, structured as follows:
#'  \itemize{
#'  \item{\code{Document ID column}}: with same name and type as \emph{data}'s
#'  document ID column.
#'  \item{\code{TOPIC_ID}}: type INTEGER, topic ID.
#'  \item{\code{PROBABILITY}}: type DOUBLE, probability of topic given document.
#'  }
#'  \item{\code{word.topic.assignment: DataFrame}}\cr
#'   Word-topic assignment table, structured as follows:
#'   \itemize{
#'   \item{\code{Document ID column}}:with same name and type as \emph{data}'s
#'   document ID column.
#'  \item{\code{WORD_ID}}:type INTEGER, word ID.
#'  \item{\code{TOPIC_ID}}: type INTEGER, topic ID.
#'   }
#'
#' \item{\code{topic.top.words: DataFrame}}\cr
#'  Topic top words table, structured as follows:
#'  \itemize{
#'  \item{\code{TOPIC_ID}}: type INTEGER, topic ID.
#'  \item{\code{WORDS}}: type NVARCHAR(5000), topic top words separated by
#'  spaces.}
#'
#' \item{\code{topic.word.dist: DataFrame}}\cr
#'   topic-word distribution table, structured as follows:
#'  \itemize{
#'    \item{\code{TOPIC_ID}}: type INTEGER, topic ID.
#'    \item{\code{WORD_ID}}: type INTEGER, word ID.
#'    \item{\code{PROBABILITY}}: type DOUBLE, probability of topic given document.
#'  }
#'
#' \item{\code{dictionary: DataFrame}}\cr
#'  Dictionary table, structured as follows:
#'  \itemize{
#'    \item{\code{WORD_ID}}: type INTEGER, word ID.
#'    \item{\code{WORD}}: type NVARCHAR(5000), word text.
#'  }
#'
#' \item{\code{statistics: DataFrame}}\cr
#'  Statistics table, structured as follows:
#'  \itemize{
#'   \item{\code{STAT_NAME}}: type NVARCHAR(256), statistic name.
#'   \item{\code{STAT_VALUE}}:  type NVARCHAR(1000), statistic value.
#'  }
#' }
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'   DOCUMENT_ID      TEXT
#' 1   10       cpu harddisk graphiccard cpu monitor keyboard cpu memory memory
#' 2   20       tires mountainbike wheels valve helmet mountainbike rearfender
#'              tires mountainbike mountainbike
#' 3   30       carseat toy strollers toy toy spoon toy strollers toy carseat
#' 4   40       sweaters sweaters sweaters boots sweaters rings vest vest shoe
#'              sweaters
#' }
#'
#' Call the function:
#' \preformatted{
#' LDA <- hanaml.LatentDirichletAllocation(data, key = "DOCUMENT_ID",
#'                                         document = "TEXT", n.components = 6,
#'                                         doc.topic.prior = 0.1, burn.in = 50,
#'                                         iteration = 100, thin = 10, seed = 1,
#'                                         max.top.words = 5, output.word.assignment = 1)
#' }
#'
#' Output:
#' \preformatted{
#' > LDA$topic.word.dist$Collect()
#'
#'        DOCUMENT_ID TOPIC_ID      PROBABILITY
#' 1               10        0      0.010416667
#' 2               10        1      0.010416667
#' 3               10        2      0.010416667
#' 4               10        3      0.010416667
#' ......
#' 20              40        1      0.009433962
#' 21              40        2      0.952830189
#' 22              40        3      0.009433962
#' 23              40        4      0.009433962
#' 24              40        5      0.009433962
#'}
#' @keywords Clustering
#' @export
hanaml.LatentDirichletAllocation <- function(data = NULL,
                                             key = NULL,
                                             document = NULL,
                                             n.components = NULL,
                                             doc.topic.prior = NULL,
                                             topic.word.prior = NULL,
                                             burn.in =NULL, iteration = NULL,
                                             thin = NULL, seed = NULL,
                                             max.top.words = NULL,
                                             threshold.top.words = NULL,
                                             gibbs.init = NULL,
                                             delimiters = NULL,
                                             output.word.assignment = NULL) {
  LatentDirichletAllocation$new(data, key, document, n.components,
                                doc.topic.prior, topic.word.prior, burn.in, iteration, thin,
                                seed, max.top.words, threshold.top.words, gibbs.init, delimiters,
                                output.word.assignment)
}

#' @title Make Inference from a "LatentDirichletAllocation" Object
#' @name transform.LatentDirichletAllocation
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "LatentDirichletAllocation" object.
#' @export
#' @keywords Clustering
#' @seealso \code{\link{hanaml.LatentDirichletAllocation}}
#' @param model \code{R6Class object}\cr
#' A "LatentDirichletAllocation" object for prediction.
#' @template args-data
#' @template args-key
#' @param   document \code{character, optional}\cr
#'          Names of the document columns.\cr
#'          Defaults to the first non-ID column.
#' @param   burn.in \code{integer, optional}\cr
#'          Number of omitted Gibbs iterations at the beginning.\cr
#'          Defaults to 0.
#' @param   iteration \code{integer, optional}\cr
#'          Number of Gibbs iterations.\cr
#'          Defaults to 2000.
#' @param   thin \code{integer, optional}\cr
#'          Number of omitted in-between Gibbs iterations.\cr
#'          Defaults to 1.
#' @param   seed \code{integer, optional}\cr
#' Indicates the seed used to initialize the random number generator.
#' \itemize{
#'   \item{0}: uses the system time.\cr
#'   \item{Not 0}: uses the specified seed.
#' }
#' Defaults to 0.
#' @param   gibbs.init \code{character, optional}\cr
#' Specifies initialization method for Gibbs sampling.
#' This value takes precedence over the corresponding one in the general information table.
#' \itemize{
#'   \item{'uniform'}: Assigns each word in each document a topic by a uniform
#' distribution. Each topic has the same probability to be assigned for each
#' word.
#'   \item{'gibbs'}: Initialization by Gibbs sampling.
#' }
#' Defaults to 'uniform'.
#' @param   delimiters \code{list of character, optional}\cr
#' Specifies the delimit to separate words in a document.\cr
#' For example, if the words are separated by , and :, then the delimit can be
#' ,:.\cr
#' For example, if the words are separated by , or :, then the delimit should
#' be ',' or ':'.\cr
#' Defaults to ''.
#' @param    output.word.assignment \code{logical, optional}\cr
#' Controls whether to output the word-topic assignment or not.
#' Note that if this parameter is set to TRUE, the procedure would take
#' more time to return to write the WORD_TOPIC_ASSIGNMENT table. \cr
#' Defaults to FALSE.
#' @return
#' Predicted values are returned as a list of DataFrames, structured as follows:\cr
#' \itemize{
#'  DataFrame 1: \cr
#'  Document-topic distribution table, structured as follows:\cr
#'  \item{\code{Document ID column}: with same name and type as \emph{data}'s
#'  document ID column.}
#'  \item{\code{TOPIC_ID}: type INTEGER, topic ID.}
#'  \item{\code{PROBABILITY}: type DOUBLE, probability of topic given document.}
#'  }
#'
#' \itemize{
#'   DataFrame 2: \cr
#'   Word-topic assignment table, structured as follows:
#'  \item{\code{Document ID column}:with same name and type as \emph{data}'s
#'  document ID column.}
#'  \item{\code{WORD_ID}:type INTEGER, word ID.}
#'  \item{\code{TOPIC_ID}: type INTEGER, topic ID.}
#'   }
#'
#' \itemize{
#'  DataFrame 3: \cr
#'  Statistics table, structured as follows:
#'  \item{\code{STAT_NAME}: type NVARCHAR(256), statistic name.}
#'  \item{\code{STAT_VALUE}:  type NVARCHAR(1000), statistic value.}
#'  }
#'
#' @section Examples:
#' Perform the predict on DataFrame data1 using "LatentDirichletAllocation" object LDA:
#' \preformatted{
#' > data1$Collect()
#'    DOCUMENT_ID                   TEXT
#'  1          10      toy toy spoon cpu
#'
#' > result <- transform(LDA, pred.data, key = "DOCUMENT_ID",
#'                       document = "TEXT", burn.in = 2000,
#'                       iteration = 1000, thin = 100,
#'                       seed = 1, output.word.assignment = TRUE)
#' }
#'
#' Output:
#' \preformatted{
#' > result[[1]]$Collect()
#'     DOCUMENT_ID  TOPIC_ID               PROBABILITY
#' 1            10         0       0.23913043478260873
#' 2            10         1       0.4565217391304348
#' 3            10         2       0.02173913043478261
#' 4            10         3       0.02173913043478261
#' 5            10         4       0.23913043478260873
#' 6            10         5       0.02173913043478261
#' }
transform.LatentDirichletAllocation <- function(model,
                                                data,
                                                key,
                                                document = NULL,
                                                burn.in = NULL,
                                                iteration = NULL,
                                                thin = NULL,
                                                seed = NULL,
                                                gibbs.init = NULL,
                                                delimiters = NULL,
                                                output.word.assignment = NULL) {
  if (is.null(model$model)){
    msg <- "Model of LatentDirichletAllocation is NULL!"
    flog.error(msg)
    stop(msg)
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context

  method.map <- list( "uniform" = 0, "gibbs" = 1)
  cols <- data$columns
  key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
  cols <- cols[! cols %in% key]
  document <- validateInput("document", document, cols, case.sensitive = TRUE)
  burn.in <- validateInput("burn.in", burn.in, "integer")
  seed <- validateInput("seed", seed, "integer")
  thin <- validateInput("thin", thin, "integer")
  iteration <- validateInput("iteration", iteration, "integer")
  output.word.assignment <-
    validateInput("output.word.assignment", output.word.assignment, "logical")
  gibbs.init <- validateInput("gibbs.init", gibbs.init, method.map)
  if (!is.null(delimiters)) {
    delimiters <- validateInput("delimiters", delimiters, "LISTOFSTRINGS")
    for (delimiter in delimiters) {
      if (nchar(delimiter) != 1) {
        msg <- "Each delimiter must be one character long."
        flog.error(msg)
        stop(msg)
      }
    }
    delimiters <- paste(delimiters, sep = "", collapse = "")
  }

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s_%s", model$id, unique.id)
  doc.topic.dist.tbl <-
    sprintf("#PAL_LDA_INFERENCE_DOC_TOPIC_DIST_TBL_%s_%s",
            model$id, unique.id)
  word.topic.assignment.tbl <-
    sprintf("#PAL_LDA_INFERENCE_WORD_TOPIC_ASSIGNMENT_%s_%s",
            model$id, unique.id)
  statistics.tbl <-
    sprintf("#PAL_LDA_INFERENCE_STASTISTIC_TBL_%s_%s", model$id, unique.id)

  model$topic.word.dist <- model$model[[1]]
  model$dictionary <- model$model[[2]]
  model$cv.parameter <- model$model[[3]]

  in.tables <- list(
    data,
    model$topic.word.dist$name,
    model$dictionary$name,
    model$cv.parameter$name,
    param.tbl
  )
  out.tables <- list(
    doc.topic.dist.tbl,
    word.topic.assignment.tbl,
    statistics.tbl
  )
  tables <- c(param.tbl, out.tables)
  param.rows <- list(
    tuple("BURNIN", burn.in, NULL, NULL),
    tuple("THIN", thin, NULL, NULL),
    tuple("ITERATION", iteration, NULL, NULL),
    tuple("SEED", seed, NULL, NULL),
    tuple("INIT", map.null(gibbs.init, method.map), NULL, NULL),
    tuple("OUTPUT_WORD_ASSIGNMENT", to.integer(output.word.assignment), NULL, NULL),
    tuple("DELIMIT", NULL, NULL, delimiters)
  )

  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                ParameterTable$new(param.tbl)$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_LATENT_DIRICHLET_ALLOCATION_INFERENCE",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })

  return (list(conn$table(doc.topic.dist.tbl),
               conn$table(word.topic.assignment.tbl),
               conn$table(statistics.tbl)))
}
