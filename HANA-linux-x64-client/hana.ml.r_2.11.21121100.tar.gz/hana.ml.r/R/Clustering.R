ClusterAssignmentBase <- R6Class(
  "ClusterAssignmentBase",
  inherit = MlBase,
  public = list(
    predict = function(model,
                       data,
                       key,
                       features = NULL) {
      if (is.null(model$model)) {
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")) {
        msg <- "data should be a DataFrame!"
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features)) {
        features <-  cols
      }
      selected <- c(key, features)
      data <- data$Select(selected)
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#PAL_CLUASSIGN_PARAM_TBL_%s_%s", self$id,  unique.id)
      assignment.tbl <- sprintf("#PAL_CLUASSIGN_ASSIGNMENT_TBL_%s_%s", self$id,  unique.id)
      tables <- list(param.tbl, assignment.tbl)
      in.tables <- list(data, self$model$name, param.tbl)
      out.tables <- list(assignment.tbl)
      tryCatch({
        errorhelper(CreateTWithConnection(conn,
          ParameterTable$new(param.tbl))) #nolint
        errorhelper(CallPalAutoWithConnection(conn,
          "PAL_CLUSTER_ASSIGNMENT", in.tables, out.tables))
      },
      error = function(err) {
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn, tables)
        stop(msg)
      })
      return(conn$table(assignment.tbl))
    }
  ))


KMeans <- R6Class(
  "KMeans",
  inherit = ClusterAssignmentBase,
  public = list(
    n.clusters = NULL,
    init = NULL,
    n.clusters.max = NULL,
    n.clusters.min = NULL,
    accelerated = NULL,
    use.fast.library = NULL,
    use.float = NULL,
    memory.mode = NULL,
    max.iter = NULL,
    tol = NULL,
    thread.ratio = NULL,
    distance.level = NULL,
    minkowski.power = NULL,
    category.weights = NULL,
    normalization = NULL,
    categorical.variable = NULL,
    labels = NULL,
    cluster.centers = NULL,
    model = NULL,
    statistics = NULL,
    placeholder = NULL,
    distance.map = list(
      manhattan = 1,
      euclidean = 2,
      minkowski = 3,
      chebyshev = 4,
      cosine = 6
    ),
    distance.map.acc = list(
      manhattan = 1,
      euclidean = 2,
      minkowski = 3,
      chebyshev = 4
    ),
    normalization.map = list(no = 0, l1.norm = 1, min.max = 2),
    init.map = list("first.k" = 1, "first_k" = 1, "replace" = 2, "no.replace" = 3, "no_replace" = 3, "patent" = 4),
    mem.mode.map = list(
      auto = 0,
      optimize_speed = 1,
      optimize_space = 2,
      optimize.speed = 1,
      optimize.space = 2
    ),
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          n.clusters = NULL,
                          n.clusters.min = NULL,
                          n.clusters.max = NULL,
                          init = NULL,
                          max.iter = NULL,
                          tol = NULL,
                          thread.ratio = NULL,
                          distance.level = NULL,
                          minkowski.power = NULL,
                          category.weights = NULL,
                          normalization = NULL,
                          categorical.variable = NULL,
                          memory.mode = NULL,
                          accelerated = FALSE,
                          use.fast.library = NULL,
                          use.float = NULL
                          ) {
      super$initialize()
      conn.context <- data$connection.context
      if (!is.null(data)) {
        self$n.clusters <- validateInput("n.clusters", n.clusters, "integer")
        self$n.clusters.min <-
          validateInput("n.clusters.min", n.clusters.min, "integer")
        self$n.clusters.max <-
          validateInput("n.clusters.max", n.clusters.max, "integer")
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        self$tol <- validateInput("tol", tol, "double")
        self$thread.ratio <-
          validateInput("thread.ratio", thread.ratio, "double")
        self$minkowski.power <-
          validateInput("minkowski.power", minkowski.power, "double")
        self$category.weights <-
          validateInput("category.weights", category.weights, "double")
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   data$columns,
                                                   case.sensitive = TRUE)
        self$accelerated <- validateInput("accelerated", accelerated, "logical")
        self$use.fast.library <- validateInput("use.fast.library",
                                               use.fast.library,
                                               "logical")
        self$use.float <- validateInput("use.float", use.float, "logical")
        if (is.null(n.clusters)) {
          if (is.null(n.clusters.max) || is.null(n.clusters.min)) {
            msg <-
              paste("You must specify either an exact value",
                    "or a range for number of clusters.")
            flog.error(msg)
            stop(msg)
          }
        } else {
          if ( (!is.null(n.clusters.min)) || (!is.null(n.clusters.max))) {#nolint
            msg <-
              paste("Both exact value and range ending points are provided for",
                    "number of groups, please choose one or the other.")
            flog.error(msg)
            stop(msg)
          }
        }
        self$init <- validateInput("init", init, self$init.map)
        self$normalization <-
          validateInput("normalization", normalization,
                        self$normalization.map)
        if (accelerated) {
          self$memory.mode <-
            validateInput("memory.mode", memory.mode,
                          self$mem.mode.map)
          distance.map <- self$distance.map.acc
          if (!is.null(tol)) {
            msg <- "tol is only valid when accelerated is FALSE."
            flog.error(msg)
            stop(msg)
          }
        } else {
          distance.map <- self$distance.map
          if (!is.null(memory.mode)) {
            msg <- "memory.mode is only valid when accelerated is TRUE."
            flog.error(msg)
            stop(msg)
          }
        } #accelerated end
        self$distance.level <-
          validateInput("distance.level", distance.level, self$distance.map)
        if ((self$distance.level != "minkowski") && #nolint
             !is.null(minkowski.power)) {
          msg <-
            "Minkowski.power will only be valid if distance.level is Minkowski."
          flog.error(msg)
          stop(msg)
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "data should be a DataFrame!"
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        cols <- data$columns

        key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)

        if (is.null(features)) {
          features <- cols
        }
        selected <- c(key, features)
        training.set <- data$Select(selected)

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_KMEANS_PARAMETER_TBL_%s_%s", self$id, unique.id)
        result.tbl <- sprintf("#PAL_KMEANS_RESULT_TBL_%s_%s", self$id, unique.id)
        centers.tbl <- sprintf("#PAL_KMEANS_CENTERS_TBL_%s_%s", self$id, unique.id)
        all.dtypes <- data$dtypes(features)
        model.tbl <- sprintf("#PAL_KMEANS_MODEL_TBL_%s_%s", self$id, unique.id)
        statistics.tbl <- sprintf("#PAL_KMEANS_STATISTICS_TBL_%s_%s", self$id, unique.id)
        placeholder.tbl <- sprintf("#PAL_KMEANS_PLACEHOLDER_TBL_%s_%s", self$id, unique.id)
        prep.param.value <- private$prepParam()
        proc.name <- prep.param.value[[1]]
        param.array <- prep.param.value[[2]]
        tables <-
          list(
            param.tbl,
            result.tbl,
            centers.tbl,
            model.tbl,
            statistics.tbl,
            placeholder.tbl
          )
        in.tables <- list(training.set, param.tbl)
        out.tables <- list(result.tbl, centers.tbl, model.tbl, statistics.tbl,
                           placeholder.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            (ParameterTable$new(param.tbl))$WithData(param.array))) #nolint
          errorhelper(CallPalAutoWithConnection(conn.context,
            proc.name, in.tables, out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        conn <- conn.context
        self$cluster.centers <- conn$table(centers.tbl)
        self$labels <- conn$table(result.tbl)
        self$model <- conn$table(model.tbl)
        self$statistics <- conn$table(statistics.tbl)
        self$placeholder <- conn$table(placeholder.tbl)
      }
    },
    score = function() {
      if (is.null(self$statistics)) {
        msg <- "Model not initialized. Perform a fit first."
        flog.error(msg)
        stop(msg)
      } else {
        return(self$statistics)
      }
    }
  ),
  private = list(
    prepParam = function() {
      param.array <- list(
        tuple("GROUP_NUMBER", self$n.clusters, NULL, NULL),
        tuple("GROUP_NUMBER_MIN", self$n.clusters.min, NULL, NULL),
        tuple("GROUP_NUMBER_MAX", self$n.clusters.max, NULL, NULL),
        tuple("DISTANCE_LEVEL",
              map.null(self$distance.level, self$distance.map),
              NULL, NULL),
        tuple("MINKOWSKI_POWER", NULL, self$minkowski.power, NULL),
        tuple("CATEGORY_WEIGHTS", NULL, self$category.weights, NULL),
        tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
        tuple("INIT_TYPE",
              map.null(self$init, self$init.map), NULL, NULL),
        tuple("NORMALIZATION",
              map.null(self$normalization, self$normalization.map),
              NULL, NULL),
        tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL)
      )
      if (!is.null(self$categorical.variable)) {
        for (each in self$categorical.variable) {
          temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
          param.array <- append(param.array, tuple(temp.list))
        }
      }
      if (self$accelerated) {
        proc.name <- "PAL_ACCELERATED_KMEANS"
        temp.list <-
          tuple("MEMORY_MODE",
                map.null(self$memory.mode, self$mem.mode.map), NULL, NULL)
        param.array <- append(param.array, tuple(temp.list))
      } else {
        proc.name <- "PAL_KMEANS"
        temp.list <- tuple("EXIT_THRESHOLD", NULL, self$tol, NULL)
        param.array <- append(param.array, tuple(temp.list))
      }
      temp.list <- tuple(proc.name, param.array)
      return(temp.list)
    }
  )
)

#' @title KMeans
#' @name hanaml.KMeans
#' @description hanaml.KMeans is a R wrapper for SAP HANA PAL K-means and
#' accelerated K-Means algorithm.
#' @seealso \code{\link{predict.KMeans}}
#' @template args-data
#' @template args-key
#' @template args-feature-clustering
#' @param n.clusters \code{integer, optional}\cr
#' Number of groups.\cr
#' Note: If this parameter is not specified, you must specify the range of k using
#' \emph{n.clusters.min} and \emph{n.clusters.max}. Then the algorithm will iterate through
#' the range and return the k with the highest slight silhouette.\cr
#' No default value.
#' @param n.clusters.min \code{integer, optional}\cr
#' Lower boundary of the clustering range.\cr
#' Note: You must specify either an exact value or a range for k. If both are specified,
#' the exact value will be used.\cr
#' No default value.
#' @param n.clusters.max \code{integer, optional}\cr
#' Upper boundary of the clustering range.\cr
#' Note: You must specify either an exact value or a range for k. If both are specified,
#' the exact value will be used.\cr
#' No default value.
#' @param init \code{character, optional}\cr
#' Controls how the initial centers are selected:
#'  \itemize{
#'  \item{\code{'first.k'}:   First k observations.}
#'  \item{\code{'replace'}:   Random with replacements.}
#'  \item{\code{'no.replace'}:   Random without replacements.}
#'  \item{\code{'patent'}:Patent of selecting the init center (US 6,882,998 B1).}
#'  }\cr
#'     Defaults to 'patent'.
#' @param max.iter \code{integer, optional}\cr
#' Maximum number of iterations.\cr
#' Defaults to 100.
#' @template args-threadratio
#' @param distance.level \code{character, optional}\cr
#' Specifies how to compute the distance between the item and the cluster center.
#' \itemize{
#' \item{\code{'manhattan'}}
#' \item{\code{'euclidean'}}
#' \item{\code{'minkowski'}}
#' \item{\code{'chebyshev'}}
#' \item{\code{'cosine'} valid only when \emph{accelerated} is FALSE.}
#' }
#' Defaults to 'euclidean'.
#' @param minkowski.power \code{double, optional}\cr
#' When Minkowski distance is used, this parameter controls the value of power.\cr
#' Only valid when \code{distance.level} is 'minkowski'.\cr
#' Defaults to 3.0.
#' @param category.weights \code{double, optional}\cr
#' Represents the weight of category attributes.\cr
#' Defaults to 0.707.
#' @template args-normalization
#' @template args-cate-var
#' @param tol \code{double, optional}\cr
#' Convergence threshold for exiting iterations.
#' Only valid when \emph{accelerated} is FALSE.\cr
#' Defaults to 1.0e-6.
#' @param memory.mode \code{character, optional}\cr
#' Indicates the memory mode the algorithm uses.
#' \itemize{
#' \item{\code{'auto'}: Chosen by the algorithm.}
#' \item{\code{'optimized.speed'}: Priorities speed.}
#' \item{\code{'optimized.space'}: Priorities saving memory.}}
#' Only valid when \emph{accelerated} is TRUE.
#' Defaults to 'auto'.
#' @param accelerated \code{logical, optional}\cr
#' Indicates whether or not to accelerate the calculation process.\cr
#' Defaults to FALSE.
#' @param use.fast.library \code{logical, optional}\cr
#' Use vectorized accelerated operation when it is set to TRUE.\cr
#' Not valid when accelerated is TRUE.\cr
#' Defaults to FALSE.
#' @param use.float \code{logical, optional}\cr
#' If FALSE, use double and if TRUE, use float.\cr
#' Only valid when \code{use.fast.library} is TRUE. Not valid when \code{accelerated} is TRUE.\cr
#' Defaults to TRUE.
#'
#'
#' @return
#' A "KMeans" object with the following attributes:
#' \itemize{
#'   \item{labels : \code{DataFrame}}\cr
#'    Label assigned to each sample.
#'    \item{cluster.centers : \code{DataFrame}}\cr
#'    Coordinates of cluster centers.
#'  \item{model : \code{DataFrame}}\cr
#'    Model content.
#'  \item{statistics : \code{DataFrame}}\cr
#'    Statistic value.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'     ID V000 V001  V002
#'  1   0  0.5    A   0.5
#'  2   1  1.5    A   0.5
#'  3   2  1.5    A   1.5
#'  4   3  0.5    A   1.5
#'  5   4  1.1    B   1.2
#'  6   5  0.5    B  15.5
#'  7   6  1.5    B  15.5
#'  8   7  1.5    B  16.5
#'  9   8  0.5    B  16.5
#'  10  9  1.2    C  16.1
#'  11 10 15.5    C  15.5
#'  12 11 16.5    C  15.5
#'  13 12 16.5    C  16.5
#'  14 13 15.5    C  16.5
#'  15 14 15.6    D  16.2
#'  16 15 15.5    D   0.5
#'  17 16 16.5    D   0.5
#'  18 17 16.5    D   1.5
#'  19 18 15.5    D   1.5
#'  20 19 15.7    A   1.6
#'  }
#'
#' Call the function:
#' \preformatted{
#' > km <- hanaml.KMeans(data = data,
#'                       key = "ID",
#'                       features = NULL,
#'                       n.clusters = 4,
#'                       init = "first.k",
#'                       max.iter = 100,
#'                       tol = 1.0E-6,
#'                       thread.ratio = 0.2,
#'                       distance.level = "euclidean",
#'                       category.weights = 0.5)
#' }
#'
#' Output:
#' \preformatted{
#' > km$labels$Collect()
#'       ID  CLUSTER_ID  DISTANCE  SLIGHT_SILHOUETTE
#' 1      0           0  0.891088           0.944370
#' 2      1           0  0.863917           0.942478
#' 3      2           0  0.806252           0.946288
#' 4      3           0  0.835684           0.944942
#' 5      4           0  0.744571           0.950234
#' 6      5           3  0.891088           0.940733
#' }
#' @keywords Clustering
#' @export
hanaml.KMeans <- function(data = NULL, key = NULL, features = NULL, n.clusters = NULL,
                          n.clusters.min = NULL, n.clusters.max = NULL, init = NULL,
                          max.iter = NULL, tol = NULL, thread.ratio = NULL,
                          distance.level = NULL, minkowski.power = NULL,
                          category.weights = NULL, normalization = NULL,
                          categorical.variable = NULL, memory.mode = NULL,
                          accelerated = FALSE, use.fast.library=NULL, use.float=NULL) {
  KMeans$new(data, key, features, n.clusters, n.clusters.min,
             n.clusters.max, init, max.iter, tol, thread.ratio, distance.level,
             minkowski.power, category.weights, normalization, categorical.variable,
             memory.mode, accelerated, use.fast.library, use.float)
}

#' @export
print.KMeans <- function(x, ...) {
  writeLines("\n")
  writeLines("KMeans attributes:")
  cat(sprintf("n.clusters : %s", to.null(x$n.clusters)))
  writeLines("\n")
  cat(sprintf("n.clusters.min : %s", to.null(x$n.clusters.min)))
  writeLines("\n")
  cat(sprintf("n.clusters.max : %s", to.null(x$n.clusters.max)))
  writeLines("\n")
  cat(sprintf("init : %s", to.null(x$init)))
  writeLines("\n")
  cat(sprintf("max.iter : %s", to.null(x$max.iter)))
  writeLines("\n")
  cat(sprintf("tol : %s", to.null(x$tol)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("distance.level : %s", to.null(x$distance.level)))
  writeLines("\n")
  cat(sprintf("minkowski.power : %s", to.null(x$minkowski.power)))
  writeLines("\n")
  cat(sprintf("category.weights : %s", to.null(x$category.weights)))
  writeLines("\n")
  cat(sprintf("normalization : %s", to.null(x$normalization)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("memory.mode : %s", to.null(x$memory.mode)))
  writeLines("\n")
  cat(sprintf("accelerated : %s", to.null(x$accelerated)))
  writeLines("\n")
}

#' @export
summary.KMeans <- function(object, ...) {
    writeLines("KMeans labels DataFrame:")
    print(object$labels$Collect())
    writeLines("\n")
    writeLines("KMeans cluster.centers DataFrame:")
    print(object$cluster.centers$Collect())
    writeLines("\n")
    writeLines("KMeans object DataFrame:")
    print(object$model$Collect())
    writeLines("\n")
    writeLines("KMeans statistics DataFrame:")
    print(object$statistics$Collect())
    writeLines("\n")
}

#' @title Make Predictions from a "KMeans" Object
#' @name predict.KMeans
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "KMeans" object.
#' @seealso \code{\link{hanaml.KMeans}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A 'KMeans' object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param     ... Reserved parameter.
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column: with same name and type as \emph{data}'s ID column.}
#'   \item{Cluster_ID: type INTEGER, the assigned cluster ID.}
#'   \item{DISTANCE: type DOUBLE, Distance between a given point and the cluster
#'    center.}
#' }
#'
#' @section Examples:
#' Perform the predict on DataFrame data2 using "KMeans" object km:
#' \preformatted{
#' > data2$Collect()
#'    ID  V000 V001  V002
#' 1   0   0.5    A   0.5
#' 2   1   1.5    A   0.5
#' 3   2   1.5    A   1.5
#' 4   3   0.5    A   1.5
#' 5   4   1.1    B   1.2
#' ......
#' 19 18  15.5    D   1.5
#' 20 19  15.7    A   1.6
#'
#' > fitted <- predict(model = km, data = data2, key = 'ID')
#' }
#'
#' Output:
#' \preformatted{
#' > fitted$Collect()
#'     ID   CLUSTER_ID  DISTANCE
#'  1   0        0     0.9496364
#'  2   1        0     0.9224655
#'  3   2        0     0.8648006
#'  4   3        0     0.8942320
#'  5   4        0     0.9787646
#'  ......
#'  19 18        3     0.7813475
#'  20 19        3     1.3365355
#'}
#' @export
#' @keywords Clustering
predict.KMeans <- function(model,
                           data,
                           key,
                           features = NULL, ...) {
  return(model$predict(model = model,
                       data = data,
                       key = key,
                       features = features))
}

KClusteringBase <- R6Class(
  "KClusteringBase",
  inherit = MlBase,
  public = list(
    n.clusters = NULL,
    init = NULL,
    max.iter = NULL,
    tol = NULL,
    thread.ratio = NULL,
    distance.level = NULL,
    minkowski.power = NULL,
    category.weights = NULL,
    normalization = NULL,
    categorical.variable = NULL,
    labels = NULL,
    cluster.centers = NULL,
    proc.name = NULL,
    clustering.type.proc.map = list(KMedians = "PAL_KMEDIANS",
                                    KMedoids = "PAL_KMEDOIDS"),
    distance.map = list(),
    normalization.map = list(no = 0, l1.norm = 1, min.max = 2),
    init.map = list("first.k" = 1, "first_k" = 1, "replace" = 2, "no_replace" = 3, "no.replace" = 3, "patent" = 4),
    initialize = function(data,
                          key,
                          features = NULL,
                          n.clusters,
                          init = NULL,
                          max.iter = NULL,
                          tol = NULL,
                          thread.ratio = NULL,
                          distance.level = NULL,
                          minkowski.power = NULL,
                          category.weights = NULL,
                          normalization = NULL,
                          categorical.variable = NULL) {
      super$initialize()
      conn.context <- data$connection.context
      self$n.clusters <- validateInput("n.clusters", n.clusters, "integer")
      self$max.iter <- validateInput("max.iter", max.iter, "integer")
      self$tol <- validateInput("tol", tol, "double")
      self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
      self$minkowski.power <-
        validateInput("minkowski.power", minkowski.power, "double")
      self$category.weights <-
        validateInput("category.weights", category.weights, "double")
      self$categorical.variable <- validateInput("categorical.variable",
                                                 categorical.variable,
                                                 data$columns,
                                                 case.sensitive = TRUE)
      self$init <- validateInput("init", init, self$init.map)

      if (is.null(self$distance.map) && (length(self$distance.map) < 1)) {
        msg <- "Value for distance.map is NULL"
        flog.error(msg)
        stop(msg)
      }
      self$distance.level <-
        validateInput("distance.level", distance.level, self$distance.map)
      if ( (self$distance.level != "minkowski") && #nolint
           !is.null(minkowski.power)) {
        msg <-
          "Invalid minkowski.power, valid when distance.level is Minkowski
        distance"
        flog.error(msg)
        stop(msg)
      }
      self$normalization <- validateInput("normalization",
                                          normalization,
                                          self$normalization.map)
      self$proc.name <- self$clustering.type.proc.map[[self$CallerClass]]

      if (!inherits(data, "DataFrame")) {#nolint
        msg <- "data should be a DataFrame!"
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)

      if (is.null(features)) {
        features <- cols
      }
      selected <- c(key, features)
      data <- data$Select(selected)
      if (!is.null(self$distance.level) && (self$distance.level == "jaccard")) {
        cols <- ColspecFromDf(data)[-1]
        for (column in cols) {
          col.name <- column[[1]]
          col.type <- column[[2]]
          if (col.type == "DOUBLE" ||
              (col.type == "INT" &&
               !(col.name %in% self$categorical.variable))) {
            msg <- paste("When jaccard distance is used,",
                         "all columns must be categorical.")
            flog.error(msg)
            stop(msg)
          }
        }
      }
      param.data <- private$PrepParam()
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <-  sprintf("#%s_PARAMETER_TBL_%s_%s", self$proc.name, self$id, unique.id)
      result.tbl <- sprintf("#%s_RESULT_TBL_%s_%s", self$proc.name, self$id, unique.id)
      centers.tbl <- sprintf("#%s_CENTERS_TBL_%s_%s", self$proc.name, self$id, unique.id)
      tables <- list(param.tbl, result.tbl, centers.tbl)
      in.tables <- list(data, param.tbl)
      out.tables <- list(result.tbl, centers.tbl)
      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
                                          (ParameterTable$new(param.tbl))$WithData(param.data))) #nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
                                              self$proc.name, in.tables, out.tables))
      },
      error = function(err) {
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      self$cluster.centers <- conn.context$table(centers.tbl)
      self$labels <- conn.context$table(result.tbl)
    }),
  private = list(
    PrepParam = function() {
      param.array <- list(
        tuple("GROUP_NUMBER", self$n.clusters, NULL, NULL),
        tuple("DISTANCE_LEVEL",
              map.null(self$distance.level, self$distance.map), NULL, NULL),
        tuple("MINKOWSKI_POWER", NULL, self$minkowski.power, NULL),
        tuple("CATEGORY_WEIGHTS", NULL, self$category.weights, NULL),
        tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
        tuple("INIT_TYPE", map.null(self$init, self$init.map), NULL, NULL),
        tuple("NORMALIZATION",
              map.null(self$normalization, self$normalization.map),
              NULL, NULL),
        tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
        tuple("EXIT_THRESHOLD", NULL, self$tol, NULL)
      )
      if (!is.null(self$categorical.variable)) {
        for (each in self$categorical.variable) {
          temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
          param.array <- append(param.array, tuple(temp.list))
        }
      }
      return(param.array)
    }
  )
)


KMedoid <- R6Class(
  "KMedoid",
  inherit = KClusteringBase,
  public = list(
    distance.map = list(
      "manhattan" = 1,
      "euclidean" = 2,
      "minkowski" = 3,
      "chebyshev" = 4,
      "jaccard" = 5,
      "cosine" = 6
    ),
    CallerClass = "KMedoids"
  )
)

#' @title K-Medoids
#' @name hanaml.KMedoid
#' @description hanaml.KMedoid is a R wrapper
#' for SAP HANA PAL KMedoids algorithm.
#' @details The K-Medoids clustering algorithm partitions n observations into
#' K clusters according to their nearest cluster center. It uses medoids
#' to calculate cluster centers. The K-Medoids algorithm is more robust
#' in regards to noise and outliers.
#' @template args-data
#' @template args-key
#' @template args-feature-clustering
#' @param n.clusters \code{integer}\cr
#' Number of groups.\cr
#' @param init \code{character, optional}\cr
#' Controls how the initial centers are selected:
#'  \itemize{
#'  \item{\code{'first.k'}:   First k observations.}
#'  \item{\code{'replace'}:   Random with replacements.}
#'  \item{\code{'no.replace'}:   Random without replacements.}
#'  \item{\code{'patent'}:Patent of selecting the init center (US 6,882,998 B1).}
#'  }
#'  Defaults to 'patent'.
#' @param max.iter \code{integer, optional}\cr
#' Maximum number of iterations.\cr
#' Defaults to 100.
#' @param tol \code{double, optional}\cr
#' Threshold for exiting the iteration.\cr
#' Defaults to 1e-6.
#' @template args-threadratio
#' @param distance.level \code{character, optional}\cr
#' Specifies how to compute the distance between the item and the cluster center.
#' \itemize{
#' \item{\code{'manhattan'}}
#' \item{\code{'euclidean'}}
#' \item{\code{'minkowski'}}
#' \item{\code{'chebyshev'}}
#' \item{\code{'cosine'}}
#' }
#' Defaults to 'euclidean'.
#' @param minkowski.power \code{double, optional}\cr
#' When Minkowski distance is used, this parameter controls the value of power.\cr
#' Only valid when \code{distance.level} is 'minkowski'.\cr
#' Defaults to 3.0.
#' @param category.weights \code{double, optional}\cr
#' Represents the weight of category attributes.\cr
#' Defaults to 0.707.
#' @template args-normalization
#' @template args-cate-var
#'
#' @return
#' A "KMedoid" object with the following attributes:
#' \itemize{
#'    \item{labels : \code{DataFrame}}\cr
#'    Label assigned to each sample.
#'    \item{cluster.centers : \code{DataFrame}}\cr
#'    Coordinates of cluster centers.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'      ID  V000 V001  V002
#' 1    0   0.5    A   0.5
#' 2    1   1.5    A   0.5
#' 3    2   1.5    A   1.5
#' 4    3   0.5    A   1.5
#' 5    4   1.1    B   1.2
#' ......
#' 16  15  15.5    D   0.5
#' 17  16  16.5    D   0.5
#' 18  17  16.5    D   1.5
#' 19  18  15.5    D   1.5
#' 20  19  15.7    A   1.6
#' }
#'
#' Call the function:
#' \preformatted{
#' > kmed <- hanaml.KMedoid(data = data,
#'                          key = "ID",
#'                          n.clusters = 4,
#'                          init = 'first_k',
#'                          max.iter = 100,
#'                          tol = 1.0E-6,
#'                          thread.ratio = 0.3,
#'                          distance.level = 'Euclidean',
#'                          category.weights = 0.5)
#' }
#'
#' Output:
#' \preformatted{
#' > kmed$cluster.centers$Collect()
#'    CLUSTER_ID  V000 V001  V002
#' 1           0   1.5    A   1.5
#' 2           1  15.5    D   1.5
#' 3           2  15.5    C  16.5
#' 4           3   1.5    B  16.5
#'
#' >dkmed$labels$Collect()
#'    ID CLUSTER_ID  DISTANCE
#' 1   0          0 1.4142136
#' 2   1          0 1.0000000
#' 3   2          0 0.0000000
#' 4   3          0 1.0000000
#' ......
#' 17 16          1 1.4142136
#' 18 17          1 1.0000000
#' 19 18          1 0.0000000
#' 20 19          1 0.9307136
#' }
#' @keywords Clustering
#' @export
hanaml.KMedoid <- function(data, key, features = NULL, n.clusters,
                           init = NULL, max.iter = NULL, tol = NULL,
                           thread.ratio = NULL, distance.level = NULL,
                           minkowski.power = NULL, category.weights = NULL,
                           normalization = NULL, categorical.variable = NULL) {
  KMedoid$new(data, key, features, n.clusters, init, max.iter, tol,
              thread.ratio, distance.level, minkowski.power, category.weights,
              normalization, categorical.variable)
}

#' @export
print.KMedoid <- function(x, ...) {
  writeLines("\n")
  writeLines("KMedoid attributes:")
  cat(sprintf("n.clusters : %s", to.null(x$n.clusters)))
  writeLines("\n")
  cat(sprintf("init : %s", to.null(x$init)))
  writeLines("\n")
  cat(sprintf("max.iter : %s", to.null(x$max.iter)))
  writeLines("\n")
  cat(sprintf("tol : %s", to.null(x$tol)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("distance.level : %s", to.null(x$distance.level)))
  writeLines("\n")
  cat(sprintf("minkowski.power : %s", to.null(x$minkowski.power)))
  writeLines("\n")
  cat(sprintf("category.weights : %s", to.null(x$category.weights)))
  writeLines("\n")
  cat(sprintf("normalization : %s", to.null(x$normalization)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
}

#' @export
summary.KMedoid <- function(object, ...) {
    writeLines("KMedoid labels DataFrame:")
    print(object$labels$Collect())
    writeLines("\n")
    writeLines("KMedoid cluster.centers DataFrame:")
    print(object$cluster.centers$Collect())
    writeLines("\n")
}


KMedian <- R6Class(
  "KMedian",
  inherit = KClusteringBase,
  public = list(
    distance.map = list(
      "manhattan" = 1,
      "euclidean" = 2,
      "minkowski" = 3,
      "chebyshev" = 4,
      "cosine" = 6
    ),
    CallerClass = "KMedians"
  )
)

#' @title K-Medians
#' @name hanaml.KMedian
#' @description hanaml.KMedian is a R wrapper
#'  for SAP HANA PAL KMedian algorithm.
#' @details The K-Medians clustering algorithm that partitions n observations into
#' K clusters according to their nearest cluster center. It uses medians
#' of each feature to calculate cluster centers.
#' @template args-data
#' @template args-key
#' @template args-feature-clustering
#' @param n.clusters \code{integer}\cr
#' Number of groups.\cr
#' @param init \code{character, optional}\cr
#' Controls how the initial centers are selected:
#'  \itemize{
#'  \item{\code{'first.k'}:   First k observations.}
#'  \item{\code{'replace'}:   Random with replacements.}
#'  \item{\code{'no.replace'}:   Random without replacements.}
#'  \item{\code{'patent'}:Patent of selecting the init center (US 6,882,998 B1).}
#'  }\cr
#'     Defaults to 'patent'.
#' @param max.iter \code{integer, optional}\cr
#' Maximum number of iterations.\cr
#' Defaults to 100.
#' @param tol \code{double, optional}\cr
#' Convergence threshold for exiting iterations.
#' Defaults to 1e-6.
#' @template args-threadratio
#' @param distance.level \code{character, optional}\cr
#' Specifies how to compute the distance between the item and the cluster center.
#' \itemize{
#' \item{\code{'manhattan'}}
#' \item{\code{'euclidean'}}
#' \item{\code{'minkowski'}}
#' \item{\code{'chebyshev'}}
#' \item{\code{'cosine'}}
#' }
#' Defaults to 'euclidean'.
#' @param minkowski.power \code{double, optional}\cr
#' When Minkowski distance is used, this parameter controls the value of power.\cr
#' Only valid when \emph{distance.level} is 'minkowski'.\cr
#' Defaults to 3.0.
#' @param category.weights \code{double, optional}\cr
#' Represents the weight of category attributes.\cr
#' Defaults to 0.707.
#' @template args-normalization
#' @template args-cate-var
#' @return
#' A "KMedian" object with the following attributes:
#'\itemize{
#'    \item{labels : \code{DataFrame}}\cr
#'    Label assigned to each sample.
#'    \item{cluster.centers : \code{DataFrame}}\cr
#'    Coordinates of cluster centers.
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'     ID  V000 V001  V002
#' 1    0   0.5    A   0.5
#' 2    1   1.5    A   0.5
#' 3    2   1.5    A   1.5
#' 4    3   0.5    A   1.5
#' 5    4   1.1    B   1.2
#' ......
#' 17  16  16.5    D   0.5
#' 18  17  16.5    D   1.5
#' 19  18  15.5    D   1.5
#' 20  19  15.7    A   1.6
#' }
#'
#' Call the function:
#' \preformatted{
#' > kmedian <- hanaml.KMedian(data = data,
#'                             key = "ID",
#'                             n.clusters = 4,
#'                             init = 'first_k',
#'                             max.iter = 100,
#'                             tol = 1.0E-6,
#'                             thread.ratio = 0.3,
#'                             distance.level = 'euclidean',
#'                             category.weights = 0.5)
#' }
#'
#' Output:
#' \preformatted{
#' > kmedian$cluster.centers$Collect()
#'     CLUSTER_ID  V000 V001  V002
#' 1           0   1.1    A   1.2
#' 2           1  15.7    D   1.5
#' 3           2  15.6    C  16.2
#' 4           3   1.2    B  16.1
#'
#' > kmedian$labels$Collect()
#'     ID CLUSTER_ID  DISTANCE
#' 1   0          0 0.9219544
#' 2   1          0 0.8062258
#' 3   2          0 0.5000000
#' 4   3          0 0.6708204
#' ......
#' 17 16          1 1.2806248
#' 18 17          1 0.8000000
#' 19 18          1 0.2000000
#' 20 19          1 0.8071068
#' }
#' @keywords Clustering
#' @export
hanaml.KMedian <- function(data, key, features = NULL, n.clusters,
                           init = NULL, max.iter = NULL,
                           tol = NULL, thread.ratio = NULL, distance.level = NULL,
                           minkowski.power = NULL, category.weights = NULL,
                           normalization = NULL, categorical.variable = NULL) {
  KMedian$new(data, key, features, n.clusters, init,
              max.iter, tol, thread.ratio, distance.level,
              minkowski.power, category.weights,
              normalization, categorical.variable)
}

#' @export
print.KMedian <- function(x, ...) {
  writeLines("\n")
  writeLines("KMedian attributes:")
  cat(sprintf("n.clusters : %s", to.null(x$n.clusters)))
  writeLines("\n")
  cat(sprintf("init : %s", to.null(x$init)))
  writeLines("\n")
  cat(sprintf("max.iter : %s", to.null(x$max.iter)))
  writeLines("\n")
  cat(sprintf("tol : %s", to.null(x$tol)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("distance.level : %s", to.null(x$distance.level)))
  writeLines("\n")
  cat(sprintf("minkowski.power : %s", to.null(x$minkowski.power)))
  writeLines("\n")
  cat(sprintf("category.weights : %s", to.null(x$category.weights)))
  writeLines("\n")
  cat(sprintf("normalization : %s", to.null(x$normalization)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
}

#' @export
summary.KMedian <- function(object, ...) {
  if (!is.null(object)) {
    writeLines("KMedian labels DataFrame:")
    print(object$labels$Collect())
    writeLines("\n")
    writeLines("KMedian cluster.centers DataFrame:")
    print(object$cluster.centers$Collect())
    writeLines("\n")
  } else {
    print("Please create a KMedian object first!")
  }
}


AffinityPropagation <- R6Class(
  "AffinityPropagation",
  inherit = MlBase,
  public = list(
    n.clusters = NULL,
    affinity = NULL,
    max.iter = NULL,
    convergence.iter = NULL,
    damping = NULL,
    preference = NULL,
    seed.ratio = NULL,
    times = NULL,
    minkowski.power = NULL,
    thread.ratio = NULL,
    labels = NULL,
    statistics = NULL,
    affinity.map = list(
      manhattan = 1, euclidean = 2, minkowski = 3, chebyshev = 4,
      standardized.euclidean = 5, cosine = 6
    ),
    initialize = function(data,
                          key,
                          features = NULL,
                          affinity,
                          n.clusters,
                          max.iter = NULL,
                          convergence.iter = NULL,
                          damping = NULL,
                          preference = NULL,
                          seed.ratio = NULL,
                          times = NULL,
                          minkowski.power = NULL,
                          thread.ratio = NULL) {
      super$initialize()
      conn.context <- data$connection.context
      if (!is.null(data)) {
      self$n.clusters <-
            validateInput("n.clusters", n.clusters, "integer", required = TRUE)
      self$affinity <-
            validateInput("affinity", affinity, self$affinity.map, required = TRUE)
      self$max.iter <- validateInput("max.iter", max.iter, "integer")
      self$convergence.iter <-
          validateInput("convergence.iter", convergence.iter, "integer")
      self$damping <- validateInput("damping", damping, "double")
      if (!is.null(damping)) {
          if (damping <= 0 || damping >= 1) {
            msg <- "damping value must lager than 0 and less than 1."
            flog.error(msg)
            stop(msg)
          }
      }
      self$preference <- validateInput("preference", preference, "double")
      if (!is.null(preference)) {
          if (preference < 0 || preference > 1) {
            msg <- "preference value must no lager than 1 and no less than 0."
            flog.error(msg)
            stop(msg)
          }
      }
      self$seed.ratio <- validateInput("seed.ratio", seed.ratio, "double")
      if (!is.null(seed.ratio)) {
        if (seed.ratio <= 0 || seed.ratio > 1) {
            msg <- "seed ratio value must no less than 0 and less than 1"
            flog.error(msg)
            stop(msg)
          }
      }
      self$times <- validateInput("times", times, "integer")
      self$minkowski.power <-
        validateInput("minkowski.power", minkowski.power, "double")
      self$thread.ratio <-
        validateInput("thread.ratio", thread.ratio, "double")

      if (!inherits(data, "DataFrame")) {
        msg <- "If training data is not omitted, it must be DataFrame."
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features)) {
        features <- cols
      }
      selected <- c(key, features)
      data <- data$Select(selected)

      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      seed.tbl <- sprintf("#PAL_AP_SEED_TBL_%s_%s", self$id, unique.id)
      param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s_%s", self$id, unique.id)
      result.tbl <- sprintf("#PAL_AP_RESULT_TBL_%s_%s", self$id, unique.id)
      statistics.tbl <- sprintf("#PAL_AP_STATIS_TBL_%s_%s", self$id, unique.id)
      prep.param.value <- private$prepParam()
      proc.name <- prep.param.value[[1]]
      param.array <- prep.param.value[[2]]
      tables <- list(seed.tbl, param.tbl, result.tbl, statistics.tbl)
      in.tables <- list(data, seed.tbl, param.tbl)
      out.tables <- list(result.tbl, statistics.tbl)
      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
          (ParameterTable$new(param.tbl))$WithData(param.array))) #nolint
        errorhelper(CreateTWithConnection(conn.context,
          Table$new(seed.tbl, list(tuple("ID", INTEGER),
                                   tuple("SEED", INTEGER)))))
        errorhelper(CallPalAutoWithConnection(conn.context,
          "PAL_AFFINITY_PROPAGATION", in.tables, out.tables))
      },
        error = function(err) {
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$labels <- conn.context$table(result.tbl)
        self$statistics <- conn.context$table(statistics.tbl)
      }
    },
    score = function() {
      if (is.null(self$statistics)) {
        msg <- "Model is not initialized. Perform a fit first."
        flog.error(msg)
        stop(msg)
      } else {
        return(self$statistics)
      }
    }
  ),
  private = list(
    prepParam = function() {
      param.array <- list(
        tuple("DISTANCE_METHOD",
              map.null(self$affinity, self$affinity.map), NULL, NULL),
        tuple("CLUSTER_NUMBER", self$n.clusters, NULL, NULL),
        tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
        tuple("CON_ITERATION", self$convergence.iter, NULL, NULL),
        tuple("DAMP", NULL, self$damping, NULL),
        tuple("PREFERENCE", NULL, self$preference, NULL),
        tuple("SEED_RATIO", NULL, self$seed.ratio, NULL),
        tuple("TIMES", self$times, NULL, NULL),
        tuple("MINKOW_P", self$minkowski.power, NULL, NULL),
        tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL)
      )
      proc.name <- "PAL_AFFINITY_PROPAGATION"
      temp.list <- tuple(proc.name, param.array)
      return(temp.list)
    }
  )
)
#' @title Affinity Propagation
#' @name hanaml.AffinityPropagation
#' @description hanaml.AffinityPropagation is a R wrapper for SAP HANA PAL
#' Affinity Propagation algorithm.
#' @template args-data
#' @template args-key
#' @template args-feature-clustering
#' @param affinity  \code{character}\cr
#' Ways to compute the distance between two points.\cr
#' \itemize{
#'    \item{\code{'manhattan'}}
#'    \item{\code{'euclidean'}}
#'    \item{\code{'minkowski'}}
#'    \item{\code{'chebyshev'}}
#'    \item{\code{'standardized.euclidean'}}
#'    \item{\code{'cosine'}}
#' }
#'  No default value as it is mandatory.
#' @param n.clusters  \code{integer}\cr
#' \itemize{
#' \item{\code{0}: Does not adjust Affinity Propagation cluster result.}
#' \item{\code{Non-zero integer}: If Affinity Propagation cluster number is bigger
#' than \emph{n.clusters}, PAL will merge the result to make the cluster number
#' be the value specified for \emph{n.clusters}.}
#' }
#' @param max.iter \code{integer, optional}\cr
#' Maximum number of iterations.\cr
#' Defaults to 500.
#' @param convergence.iter  \code{integer, optional}\cr
#' When the clusters keep a steady one for the specified times,
#' the algorithm ends.\cr
#' Defaults to 100.
#' @param damping  \code{double, optional}\cr
#' Controls the updating velocity. Value range: (0, 1).\cr
#' Defaults to 0.9.
#' @param preference  \code{double, optional}\cr
#' Determines the preference. Value range: [0,1].\cr
#' Defaults to 0.5.
#' @param seed.ratio  \code{double, optional}\cr
#' Select a portion of (\code{seed.ratio} * data_number) the
#' input data as seed, where \emph{data_number} is the row-size of the
#' input data. Value range: (0,1]. If \code{seed.ratio} is 1, all the
#' input data will be the seed.\cr
#' Defaults to 1.
#' @param times  \code{integer, optional}\cr
#' The sampling times. Only valid when \code{seed.ratio} is less than 1 and
#' \emph{affinity} is 'minkowski'.\cr
#' Defaults to 3.
#' @param minkowski.power  \code{integer, optional}\cr
#' The sampling times. Only valid when \emph{affinity} is 'minkowski'. \cr
#' Defaults to 1.
#' @template args-threadratio
#' @return
#' An "AffinityPropagation" object with the following attributes:
#'\itemize{
#'   \item{labels : \code{DataFrame}}\cr
#'    Label assigned to each sample,structured as follows:
#'    \itemize{
#'      \item{ID} record ID.\cr
#'      \item{CLUSTER_ID} the range is from 0 to \emph{n.clusters} - 1.
#'      }
#'  \item{statistics : \code{DataFrame}}\cr
#'    Statistic value, structured as follows:
#'    \itemize{
#'      \item{STAT_NAME} Statistic name.
#'      \item{STAT_VALUE} Statistic value.
#'      }
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'     ID     V1     V2
#' 1    1   0.10   0.10
#' 2    2   0.11   0.10
#' 3    3   0.10   0.11
#' 4    4   0.11   0.11
#' 5    5   0.12   0.11
#' 6    6   0.11   0.12
#  ......
#' 21  21  10.13  10.12
#' 22  22  10.13  10.13
#' 23  23  10.13  10.14
#' 24  24  10.14  10.13
#' }
#'
#' Call the function:
#' \preformatted{
#' > ap <- hanaml.AffinityPropagation(data = data,
#'                                    key = "ID",
#'                                    affinity = 'euclidean',
#'                                    n.clusters = 0L,
#'                                    max.iter = 500L,
#'                                    convergence.iter = 100L,
#'                                    damping = 0.9,
#'                                    preference = 0.5,
#'                                    times = 1L,
#'                                    seed.ratio = 1,
#'                                    minkowski.power = 0,
#'                                    thread.ratio = 0)
#' }
#'
#' Output:
#' \preformatted{
#' > ap$labels$collect()
#'     ID  CLUSTER_ID
#' 1    1           0
#' 2    2           0
#' 3    3           0
#' 4    4           0
#' 5    5           0
#' 6    6           0
#' ......
#' 22  22           1
#' 23  23           1
#' 24  24           1
#' }
#' @keywords Clustering
#' @export
hanaml.AffinityPropagation <- function(data, key, features = NULL,
                                       affinity, n.clusters,
                                       max.iter = NULL, convergence.iter = NULL,
                                       damping = NULL, preference = NULL,
                                       seed.ratio = NULL, times = NULL,
                                       minkowski.power = NULL,
                                       thread.ratio = NULL) {
  AffinityPropagation$new(data, key, features, affinity, n.clusters,
                          max.iter, convergence.iter, damping, preference,
                          seed.ratio, times, minkowski.power, thread.ratio)
}

#' @export
print.AffinityPropagation <- function(x, ...) {
  writeLines("\n")
  writeLines("AffinityPropagation attributes:")
  cat(sprintf("affinity : %s", to.null(x$affinity)))
  writeLines("\n")
  cat(sprintf("n.clusters : %s", to.null(x$n.clusters)))
  writeLines("\n")
  cat(sprintf("max.iter : %s", to.null(x$max.iter)))
  writeLines("\n")
  cat(sprintf("convergence.iter : %s", to.null(x$convergence.iter)))
  writeLines("\n")
  cat(sprintf("damping : %s", to.null(x$damping)))
  writeLines("\n")
  cat(sprintf("preference : %s", to.null(x$preference)))
  writeLines("\n")
  cat(sprintf("seed.ratio : %s", to.null(x$seed.ratio)))
  writeLines("\n")
  cat(sprintf("times : %s", to.null(x$times)))
  writeLines("\n")
  cat(sprintf("minkowski.power : %s", to.null(x$minkowski.power)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
}

#' @export
summary.AffinityPropagation <- function(object, ...) {
    writeLines("AffinityPropagation labels DataFrame:")
    print(object$labels)
    writeLines("\n")
    writeLines("AffinityPropagation statistics DataFrame:")
    print(object$statistics)
    writeLines("\n")
}


AgglomerateHierarchical <- R6Class(
  "AgglomerateHierarchical",
  inherit = MlBase,
  public = list(
    n.clusters = NULL,
    affinity = NULL,
    linkage = NULL,
    thread.ratio = NULL,
    distance.dim = NULL,
    normalization = NULL,
    category.weights = NULL,
    categorical.variable = NULL,
    labels = NULL,
    combine.process = NULL,
    affinity.map = list(
      "manhattan" = 1, "euclidean" = 2, "minkowski" = 3, "chebyshev" = 4,
      "cosine" = 6, "pearson.correlation" = 7, "squared.euclidean" = 8,
      "jaccard" = 9, "gower" = 10),
    linkage.map = list(
      "nearest.neighbor" = 1, "furthest.neighbor" = 2, "group.average" = 3,
      "weighted.average" = 4, "centroid.clustering" = 5,
      "median.clustering" = 6, "ward" = 7),
    norm.map = list(no = 0, z.score = 1,
                    symmetric.min.max = 2,
                    min.max = 3),
    initialize = function(data,
                          key = NULL,
                          features = NULL,
                          n.clusters = NULL,
                          affinity = NULL,
                          linkage = NULL,
                          thread.ratio = NULL,
                          distance.dim = NULL,
                          normalization = NULL,
                          category.weights = NULL,
                          categorical.variable = NULL) {
      super$initialize()
      conn.context <- data$connection.context
      self$n.clusters <- validateInput("n.clusters", n.clusters, "integer")
      self$affinity <- validateInput("affinity", affinity, self$affinity.map)
      self$linkage <- validateInput("linkage", linkage, self$linkage.map)
      cluster.method <-
        list("centroid.clustering", "median.clustering", "ward")
      if (!is.null(self$linkage)) {
        if ((self$linkage %in% cluster.method) && #nolint
             self$affinity != "squared.euclidean") {
          msg <- paste("affinity must be set to squared.euclidean if",
                       "linkage is centroid.clustering, median.clustering",
                       "or ward.")
          flog.error(msg)
          stop(msg)
        }
      }
      self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
      if (!is.null(distance.dim)) {
        if (isTRUE(self$affinity != "minkowski")) {
          msg <- "distance.dim only be valid if affinity is minkowski."
          flog.error(msg)
          stop(msg)
        }
      }
      self$distance.dim <- validateInput("distance.dim", distance.dim, "double")
      self$normalization <- validateInput("normalization", normalization,
                                          self$norm.map)
      self$category.weights <-
        validateInput("category.weights", category.weights, "double")
      self$categorical.variable <- validateInput("categorical.variable",
                                                 categorical.variable,
                                                 data$columns,
                                                 case.sensitive = TRUE)
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features)) {
        features <- cols
      }
      selected <- c(key, features)
      data <- data$Select(selected)
      if (!inherits(data, "DataFrame")) {
        msg <- "If training data is not omitted, it must be DataFrame."
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s_%s", self$id, unique.id)
      comb.tbl <- sprintf("#HIERARCHICAL_CLUSTERING_COMBINE_TBL_%s_%s", self$id, unique.id)
      result.tbl <- sprintf("#HIERARCHICAL_CLUSTERING_RESULT_TBL_%s_%s", self$id, unique.id)
      prep.param.value <- private$prepParam()
      proc.name <- prep.param.value[[1]]
      param.array <- prep.param.value[[2]]
      tables <- list(param.tbl, comb.tbl, result.tbl)
      in.tables <- list(data, param.tbl)
      out.tables <- list(comb.tbl, result.tbl)
      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
          (ParameterTable$new(param.tbl))$WithData(param.array)))
        errorhelper(CallPalAutoWithConnection(conn.context,
          proc.name, in.tables, out.tables))
      },
      error = function(err) {
        msg <- paste("Error:", err)
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      self$labels <- conn.context$table(result.tbl)
      self$combine.process <- conn.context$table(comb.tbl)
    }
  ),
  private = list(
    prepParam = function() {
      param.array <- list(
        tuple("CLUSTER_NUM", self$n.clusters, NULL, NULL),
        tuple("DISTANCE_FUNC",
              map.null(self$affinity, self$affinity.map), NULL, NULL),
        tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
        tuple("CLUSTER_METHOD",
              map.null(self$linkage, self$linkage.map), NULL, NULL),
        tuple("NORMALIZE_TYPE",
              map.null(self$normalization, self$norm.map),
              NULL, NULL),
        tuple("CATEGORY_WEIGHTS", NULL, self$category.weights, NULL),
        tuple("DISTANCE_DIMENSION", NULL, self$distance.dim, NULL)
      )
      if (!is.null(self$categorical.variable)) {
        for (each in self$categorical.variable) {
          temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
          param.array <- append(param.array, tuple(temp.list))
        }
      }
      proc.name <- "PAL_HIERARCHICAL_CLUSTERING"
      temp.list <- tuple(proc.name, param.array)
      return(temp.list)
    }
  )
)

#' @title Agglomerate Hierarchical Clustering
#' @name hanaml.AgglomerateHierarchical
#' @description  hanaml.AgglomerateHierarchical is a R wrapper for SAP HANA PAL
#'  Agglomerate Hierarchical Clustering algorithm.
#' @template args-data
#' @template args-key
#' @template args-feature-clustering
#' @param n.clusters  \code{integer, optional}\cr
#' Number of clusters after agglomerate hierarchical clustering algorithm.\cr
#' Value range: between 1 and the initial number of input data.\cr
#' Defaults to 1.
#' @param affinity  \code{character, optional}\cr
#' Ways to compute the distance between two points:
#'\itemize{
#'   \item{\code{'manhattan'}}
#'   \item{\code{'euclidean'}}
#'   \item{\code{'minkowski'}}
#'   \item{\code{'chebyshev'}}
#'   \item{\code{'cosine'}}
#'   \item{\code{'pearson.correlation'}}
#'   \item{\code{'squared.euclidean'}}
#'   \item{\code{'jaccard'}}
#'   \item{\code{'gower'}}
#'   }
#' Note that \cr
#' (1) For "jaccard", non-zero input data will be treated as
#' 1, and zero input data will be treated as 0. \cr
#' jaccard distance = (M01 + M10) / (M11 + M01 + M10)\cr
#' (2) Only "gower" supports category attributes.\cr
#' (3) When \emph{linkage} is 'centroid.clustering', 'median.clustering'
#' 'ward', \emph{affinity} must be set to 'squared.euclidean'\cr
#' Defaults to "centroid clustering".
#' @param linkage  \code{character, optional}\cr
#'  Linkage type between two clusters.\cr
#'  \itemize{
#'      \item{\code{'nearest.neighbor'}}:  single linkage.
#'      \item{\code{'furthest.neighbor'}}:  complete linkage.
#'      \item{\code{'group.average'}}:  UPGMA.
#'      \item{\code{'weighted.average'}}:  WPGMA
#'      \item{\code{'centroid.clustering'}}
#'      \item{\code{'median.clustering'}}
#'      \item{\code{'ward'}}
#' }
#' When \emph{linkage} is 'centroid.clustering', 'median.clustering'
#' 'ward', \emph{affinity} must be set to 'squared.euclidean'\cr
#' Defaults to 'centroid.clustering'.
#' @template args-threadratio
#' @param distance.dimension \code{double, optional}\cr
#' \emph{distance.dimension} can be set if
#' \emph{affinity} is set to 'minkowski'.
#' The value should be no less than 1.\cr
#' Only valid when \emph{affinity} is 'minkowski'.\cr
#' Defaults to 3.
#' @param normalization  \code{character, optional}\cr
#' normalization type\cr
#' \itemize{
#'  \item{\code{"no"}}: does nothing
#'  \item{\code{"z.score"}}: Z score standardize
#'  \item{\code{"symmetric.min.max"}}: transforms to new range: -1 to 1.
#'  \item{\code{"min.max"}}: transforms to new range: 0 to 1
#'  }
#' Defaults to "no".
#' @param  category.weights  \code{double, optional}\cr
#' Represents the weight of category columns.\cr
#' Defaults to 1.
#' @template args-cate-var
#' @return
#' A "AgglomerateHierarchical" object with the following attributes:
#' \itemize{
#'   \item{labels : \code{DataFrame}}\cr
#'    label of each points, structed as follows:
#'    \itemize{
#'      \item{1st column}: ID (in input table) data type, ID, record ID.\cr
#'      \item{2nd column}: int, CLUSTER_ID, the range is from 0 to
#'        \emph{n.clusters} - 1.}
#'    \item{comb.process : \code{DataFrame}}\cr
#'         structed as follows:
#'      \itemize{
#'        \item{1st column}: int, STAGE, cluster stage.
#'        \item{2nd column}: ID (in input table) data type, LEFT_ + ID (in input
#'        table) column name,
#'          One of the clusters that is to be combined in one combine stage,
#'          name as its row number in the input data table.
#'          After the combining, the new cluster is named after the left one.
#'        \item{3rd column}: ID (in input table) data type, RIGHT_ + ID (in input
#'        table) column name,
#'          The other cluster to be combined in the same combine stage, named
#'          as its row number in the input data table.\cr
#'        \item{4th column}: float, DISTANCE. Distance between the two combined
#'        clusters.}
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'  POINT        X1    X2    X3
#' 0    0       0.5   0.5     1
#' 1    1       1.5   0.5     2
#' 2    2       1.5   1.5     2
#' 3    3       0.5   1.5     2
#' 4    4       1.1   1.2     2
#' ......
#' 16   16      16.5  0.5     1
#' 17   17      16.5  1.5     1
#' 18   18      15.5  1.5     1
#' 19   19      15.7  1.6     1
#' }
#'
#' Call the function:
#' \preformatted{
#' > AH <- hanaml.AgglomerateHierarchical(data = data,
#'                                        key = "POINT",
#'                                        n.clusters = 4,
#'                                        affinity = 'squared.euclidean',
#'                                        inkage = 'centroid.clustering',
#'                                        thread.ratio = 0,
#'                                        distance.dimension = 3,
#'                                        normalization = "no",
#'                                        category.weights = 0.1)
#' }
#'
#' Output:
#' \preformatted{
#' > AH$comb.process.tbl$collect()
#'     STAGE  LEFT_POINT RIGHT_POINT  DISTANCE
#' 1       1          18      19        0.0187
#' 2       2          13      14        0.025
#' 3       3          7       9         0.0437
#' 4       4          2       4         0.0438
#' ......
#' 16     16          15      16        0.1085
#' 17     17          0       15        1.0381
#' 18     18          5       10        1.0425
#' 19     19          0        5        1.5146
#'
#' > AH$labels$collect()
#'    POINT    CLUSTER_ID
#' 1      0          1
#' 2      1          1
#' 3      2          1
#' 4      3          1
#' ......
#' 17    16          4
#' 18    17          4
#' 19    18          4
#' 20    19          4
#'}
#' @keywords Clustering
#' @export
hanaml.AgglomerateHierarchical <- function(data, key,
                                           features = NULL, n.clusters = NULL,
                                           affinity = NULL, linkage = NULL,
                                           thread.ratio = NULL,
                                           distance.dimension = NULL,
                                           normalization = NULL,
                                           category.weights = NULL,
                                           categorical.variable = NULL) {
  AgglomerateHierarchical$new(data, key, features, n.clusters,
                              affinity, linkage, thread.ratio,
                              distance.dimension, normalization,
                              category.weights, categorical.variable)
}


#' @export
print.AgglomerateHierarchical <- function(x, ...) {
  writeLines("\n")
  writeLines("AgglomerateHierarchical attributes:")
  cat(sprintf("n.clusters : %s", to.null(x$n.clusters)))
  writeLines("\n")
  cat(sprintf("affinity : %s", to.null(x$affinity)))
  writeLines("\n")
  cat(sprintf("linkage : %s", to.null(x$linkage)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("distance.dimension : %s", to.null(x$distance.dimension)))
  writeLines("\n")
  cat(sprintf("normalization : %s", to.null(x$normalization)))
  writeLines("\n")
  cat(sprintf("category.weights : %s", to.null(x$category.weights)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
}

#' @export
summary.AgglomerateHierarchical <- function(object, ...) {
  writeLines("\n")
  writeLines("AgglomerateHierarchical labels DataFrame:")
  print(object$labels)
  writeLines("\n")
  writeLines("AgglomerateHierarchical combine.process DataFrame:")
  print(object$combine.process)
  writeLines("\n")
}


DBSCAN <- R6Class(
  "DBSCAN",
  inherit = ClusterAssignmentBase,
  public = list(
    auto.param = NULL,
    minpts = NULL,
    eps = NULL,
    thread.ratio = NULL,
    metric = NULL,
    minkowski.power = NULL,
    categorical.variable = NULL,
    category.weights = NULL,
    algorithm = NULL,
    save.model = NULL,
    string.variable = NULL,
    variable.weight = NULL,
    labels = NULL,
    model = NULL,
    param = NULL,
    metric.map = list(
      "manhattan" = 1,
      "euclidean" = 2,
      "minkowski" = 3,
      "chebyshev" = 4,
      "standardized euclidean" = 5,
      "cosine" = 6
    ),
    algorithm.map = list(
      "brute.force" = 0,
      "kd.tree" = 1),
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          minpts = NULL,
                          eps = NULL,
                          thread.ratio = NULL,
                          metric = NULL,
                          minkowski.power = NULL,
                          categorical.variable = NULL,
                          category.weights = NULL,
                          algorithm = NULL,
                          save.model = NULL,
                          string.variable = NULL,
                          variable.weight = NULL) {
      super$initialize()
      conn.context <- data$connection.context
      if (!is.null(data)) {
        if (!is.null(eps) || !is.null(minpts)) {
          self$auto.param <- "false"
        } else {
          self$auto.param <- "true"
        }
        if ((is.null(eps) && !is.null(minpts)) || #nolint
             (is.null(minpts) && !is.null(eps))) {
          msg <- "minpts and eps need to be provided together."
          flog.error(msg)
          stop(msg)
        }
        self$minpts <- validateInput("minpts", minpts, "integer")
        self$eps <- validateInput("eps", eps, "double")
        self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
        self$metric <- validateInput("metric", metric, self$metric.map)
        self$minkowski.power <-
          validateInput("minkowski.power", minkowski.power, "double")
        if (self$metric != "minkowski" && !is.null(self$minkowski.power)) {
          msg <- "minkowski.power will only be applicable if metric is minkowski."
          flog.error(msg)
          stop(msg)
        }
        category.weights <- validateInput("category.weights", category.weights, "double")
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   data$columns,
                                                   case.sensitive = TRUE)
        self$algorithm <- validateInput("algorithm", algorithm, self$algorithm.map)
        save.model <- validateInput("save.model", save.model, "logical")
        self$string.variable <- validateInput("string.variable",
                                              string.variable,
                                              data$columns,
                                              case.sensitive = TRUE)
        if (length(variable.weight) != 0) {
          validateInput("variable.weight",
                        names(variable.weight),
                        data$columns,
                        case.sensitive = TRUE)
          for (i in seq_len(length(variable.weight))) {
            if (!is.numeric(variable.weight[[i]])) {
              msg <- "The value of variable.weight should be numeric!"
              flog.error(msg)
              stop(msg)
            }
          }
          self$variable.weight <- variable.weight
        }

        if (!inherits(data, "DataFrame")) {
          msg <- "data should be a DataFrame!"
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        cols <- data$columns
        key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        if (is.null(features)) {
          features <- cols
        }
        data <- data$Select(c(key, features))

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s_%s", self$id, unique.id)
        result.tbl <- sprintf("#PAL_DBSCAN_RESULT_TBL_%s_%s", self$id, unique.id)
        model.tbl <- sprintf("#PAL_DBSCAN_MODEL_TBL_%s_%s", self$id, unique.id)
        statistics.tbl <- sprintf("#PAL_DSCBAN_STATS_TBL_%s_%s", self$id, unique.id)
        placeholder.tbl <- sprintf("#PAL_DSCBAN_PH_TBL_%s_%s", self$id, unique.id)
        param.array <- list(
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple("AUTO_PARAM", NULL, NULL, self$auto.param),
          tuple("DISTANCE_METHOD",
                map.null(self$metric, self$metric.map), NULL, NULL),
          tuple("MINPTS", self$minpts, NULL, NULL),
          tuple("RADIUS", NULL, self$eps, NULL),
          tuple("MINKOW_P", self$minkowski.power, NULL, NULL),
          tuple("CATEGORY_WEIGHTS", NULL, self$category.weights, NULL),
          tuple("METHOD",
                map.null(self$algorithm, self$algorithm.map), NULL, NULL),
          tuple("SAVE_MODEL", to.integer(self$save.model), NULL, NULL)
        )
        if (!is.null(self$categorical.variable)) {
          for (each in self$categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
            param.array <- append(param.array, tuple(temp.list))
          }
        }
        if (!is.null(self$string.variable)) {
          for (variable in self$string.variable) {
            temp.list <- tuple("STRING_VARIABLE", NULL, NULL, variable)
            param.array <- append(param.array, tuple(temp.list))
          }
        }

        if (!is.null(self$variable.weight)) {
          for (i in seq_len(length(self$variable.weight))) {
            temp.list <- tuple("VARIABLE_WEIGHT", NULL,
                               self$variable.weight[[i]], names(self$variable.weight[i]))
            param.array <- append(param.array, tuple(temp.list))
          }
        }

        tables <- list(param.tbl, result.tbl, model.tbl, statistics.tbl, placeholder.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(result.tbl, model.tbl, statistics.tbl, placeholder.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            (ParameterTable$new(param.tbl))$WithData(param.array)))
          errorhelper(CallPalAutoWithConnection(conn.context,
            "PAL_DBSCAN", in.tables, out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$labels <- conn.context$table(result.tbl)
        self$model <- conn.context$table(model.tbl)
      }
    }
  )
)

#' @title DBSCAN (Density-Based Spatial Clustering of Applications with Noise)
#' @name hanaml.DBSCAN
#' @description hanaml.DBSCAN is a R wrapper for SAP HANA PAL DBSCAN algorithm.
#' @seealso \code{\link{predict.DBSCAN}}
#' @template args-data
#' @template args-key
#' @template args-feature-clustering
#' @param minpts \code{integer, optional}\cr
#' The minimum number of points required to form a cluster\cr
#' Note that\cr
#' \emph{minpts} and \emph{eps} need to be provided together by user or these
#' two parameters are automatically determined.
#' @param eps    \code{double, optional}\cr
#' The scan radius.\cr
#' Note that \emph{minpts} and \emph{eps} need to be provided together
#' by user or these two parameters are automatically determined.
#' @template args-threadratio-1
#' @param metric  \code{character, optional}\cr
#' Ways to compute the distance between two points. Valid metric options include:\cr
#' \itemize{
#'  \item{\code{'manhattan'}}
#'  \item{\code{'euclidean'}}
#'  \item{\code{'minkowski'}}
#'  \item{\code{'chebyshev'}}
#'  \item{\code{'standardized.euclidean'}}
#'  \item{\code{'cosine'}}
#'  }
#'   Defaults to "euclidean".
#' @param minkowski.power  \code{integer, optional}\cr
#' When \emph{minkowski} is choosed for "metric", this parameter
#' controls the value of power.
#' Only applicable when \emph{metric} is 'minkowski'.\cr
#' Defaults to 3.
#' @template args-cate-var
#' @param category.weights \code{double, optional}\cr
#' Represents the weight of category attributes.\cr
#' Defaults to 0.707.
#' @param algorithm  \code{{"brute.force", "kd.tree"}, optional}\cr
#' Ways to search for neighbours.\cr
#' Defaults to "kd.tree".
#' @param save.model \code{logical, optional}\cr
#' If TRUE, the generated model will be saved.
#' \emph{save.model} must be TRUE to call.\cr
#'  Defaults to TRUE.
#' @template args-string-variable
#' @template args-variable-weight
#'
#' @return
#' Returns a "DBSCAN" objects with the following attributes:
#' \itemize{
#'    \item{labels : \code{DataFrame}}\cr
#'         Label assigned to each sample.
#'    \item{model : \code{DataFrame}}\cr
#'         PMML model. Set to NULL if no PMML model was requested.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'     ID     V1     V2 V3
#' 1    1   0.10   0.10  B
#' 2    2   0.11   0.10  A
#' 3    3   0.10   0.11  C
#' 4    4   0.11   0.11  B
#' ......
#' 28  28  16.11  16.11  A
#' 29  29  20.11  20.12  C
#' 30  30  15.12  15.11  A
#' }
#'
#' Call the function
#' \preformatted{
#' > DBSCAN <-hanaml.DBSCAN(data, key = "ID",
#'                          thread.ratio = 0.2,
#'                          metric = "Manhattan")
#' }
#'
#' Output:
#' \preformatted{
#' > DBSCAN$labels$Collect()
#'       ID    CLUSTER.ID
#' 1      1             0
#' 2      2             0
#' 3      3             0
#' 4      4             0
#' 5      5             0
#' ......
#' 28    28            -1
#' 29    29            -1
#' 30    30            -1
#' }
#' @keywords Clustering
#' @export
hanaml.DBSCAN <- function(data = NULL, key = NULL, features = NULL,
                          minpts = NULL, eps = NULL, thread.ratio = NULL, metric = NULL,
                          minkowski.power = NULL, categorical.variable = NULL,
                          category.weights = NULL, algorithm = NULL,
                          save.model = NULL, string.variable = NULL,
                          variable.weight = NULL) {
  DBSCAN$new(data, key, features, minpts, eps, thread.ratio,
             metric, minkowski.power, categorical.variable, category.weights,
             algorithm, save.model, string.variable, variable.weight)
}


#' @title Make Predictions from a "DBSCAN" Object
#' @name predict.DBSCAN
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "DBSCAN" object.
#' @keywords Clustering
#' @seealso \code{\link{hanaml.DBSCAN}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#' A "DBSCAN" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param    ... Reserved parameter.
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data}'s ID column.}
#'   \item{Cluster_ID, type INTEGER, the assigned cluster ID.}
#'   \item{DISTANCE, type DOUBLE, Distance between a given point and the nearest
#'    core object .}
#' }
#'
#' @section Examples:
#' Perform the predict on DataFrame data2 using "DBSCAN" object dbscan:
#' \preformatted{
#' > data2$Collect()
#'    ID  V000  V001  V002
#' 1   1  0.10  0.10     B
#' 2   2  0.11  0.10     A
#' 3   3  0.10  0.11     C
#' 4   4  0.11  0.11     B
#' 5   5  0.12  0.11     A
#' ......
#' 28 28 16.11 16.11     A
#' 29 29 20.11 20.12     C
#' 30 30 15.12 15.11     A
#' > fitted <- predict(model = dbscan, data = data2)
#' }
#'
#' Output:
#' \preformatted{
#' > fitted$Collect()
#'     ID   CLUSTER_ID  DISTANCE
#' 1   1             0     0.000
#' 2   2             0     0.000
#' 3   3             0     0.000
#' 4   4             0     0.000
#' 5   5             0     0.000
#' ......
#' 28 28            -1    11.950
#' 29 29            -1    21.374
#' 30 30            -1     9.960
#' }
#' @export
predict.DBSCAN <- function(model,
                           data,
                           key,
                           features = NULL,
                           ...) {
  return(model$predict(model = model,
                        data = data,
                        key = key,
                        features = features))
}

#' @export
print.DBSCAN <- function(x, ...) {
  writeLines("\n")
  writeLines("DBSCAN attributes:")
  cat(sprintf("minpts : %s", to.null(x$minpts)))
  writeLines("\n")
  cat(sprintf("eps : %s", to.null(x$eps)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("metric : %s", to.null(x$metric)))
  writeLines("\n")
  cat(sprintf("minkowski.power : %s", to.null(x$minkowski.power)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("category.weights : %s", to.null(x$category.weights)))
  writeLines("\n")
  cat(sprintf("algorithm : %s", to.null(x$algorithm)))
  writeLines("\n")
  cat(sprintf("save.model : %s", to.null(x$save.model)))
  writeLines("\n")
  cat(sprintf("string.variable : %s", to.null(x$string.variable)))
  writeLines("\n")
  cat(sprintf("variable.weight : %s", to.null(x$variable.weight)))
  writeLines("\n")
}

#' @export
summary.DBSCAN <- function(object, ...) {
  writeLines("DBSCAN labels DataFrame:")
  print(object$labels)
  writeLines("\n")
  writeLines("DBSCAN model DataFrame:")
  print(object$model)
  writeLines("\n")
}


GeoDBSCAN <- R6Class(
  "GeoDBSCAN",
  inherit = ClusterAssignmentBase,
  public = list(
    minpts = NULL,
    eps = NULL,
    thread.ratio = NULL,
    metric = NULL,
    minkowski.power = NULL,
    algorithm = NULL,
    save.model = NULL,
    labels = NULL,
    model = NULL,
    metric.map = list(
      manhattan = 1,
      euclidean = 2,
      minkowski = 3,
      chebyshev = 4,
      standardized.euclidean = 5,
      cosine = 6
    ),
    algorithm.map = list(
      "brute.force" = 0,
      "kd.tree" = 1),
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          minpts = NULL,
                          eps = NULL,
                          thread.ratio = NULL,
                          metric = NULL,
                          minkowski.power = NULL,
                          algorithm = NULL,
                          save.model = NULL) {
      super$initialize()
      conn.context <- data$connection.context
      if (!is.null(data)) {
        self$minpts <- validateInput("minpts", minpts, "integer")
        self$eps <- validateInput("eps", eps, "numeric")
        if (length(c(self$minpts, self$eps)) == 2) {
          auto.param <- "false"
        } else {
          auto.param <- "true"
        }
        if (length(c(self$minpts, self$eps)) == 1) {
          msg <- "minpts and eps need to be provided together."
          flog.error(msg)
          stop(msg)
        }
        self$thread.ratio <- validateInput("thread.ratio",
                                           thread.ratio,
                                           "numeric")
        self$metric <- validateInput("metric", metric, self$metric.map)
        self$minkowski.power <-
          validateInput("minkowski.power", minkowski.power, "numeric")
        if (self$metric != "minkowski" && !is.null(self$minkowski.power)) {
          msg <- paste("minkowski.power will only be applicable if",
                       "metric is minkowski.")
          flog.error(msg)
          stop(msg)
        }
        self$algorithm <- validateInput("algorithm", algorithm, self$algorithm.map)
        self$save.model <- validateInput("save.model", save.model, "logical")

        cols <- data$columns
        key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        if (is.null(features)) {
          features <- cols[[1]]
        }
      }
      if (inherits(data, "DataFrame")) {
        CheckConnection(data)
        training.set <- data$Select(c(key, features))

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <-
          sprintf("#PAL_GEO_PARAMETER_TBL_%s_%s", self$id, unique.id)
        result.tbl <-
          sprintf("#PAL_GEO_DBSCAN_RESULT_TBL_%s_%s", self$id, unique.id)
        model.tbl <-
          sprintf("#PAL_GEO_DBSCAN_MODEL_TBL_%s_%s", self$id, unique.id)
        statistics.tbl <-
          sprintf("#PAL_DSCBAN_STATS_TBL_%s_%s", self$id, unique.id)
        placeholder.tbl <-
          sprintf("#PAL_GEO_DSCBAN_PH_TBL_%s_%s", self$id, unique.id)
        param.array <- list(
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple("AUTO_PARAM", NULL, NULL, auto.param),
          tuple("DISTANCE_METHOD",
                map.null(self$metric, self$metric.map),
                NULL, NULL),
          tuple("MINPTS", self$minpts, NULL, NULL),
          tuple("RADIUS", NULL, self$eps, NULL),
          tuple("MINKOW_P", self$minkowski.power, NULL, NULL),
          tuple("METHOD",
                map.null(self$algorithm, self$algorithm.map),
                NULL, NULL),
          tuple("SAVE_MODEL", to.integer(self$save.model),
                NULL, NULL))
        proc.name <- "PAL_GEO_DBSCAN"
        temp.list <-
          tuple(proc.name, param.array)
        tables <-
          list(
            param.tbl,
            result.tbl,
            model.tbl,
            statistics.tbl,
            placeholder.tbl
          )
        in.tables <- list(training.set, param.tbl)
        out.tables <-
          list(result.tbl, model.tbl, statistics.tbl, placeholder.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            (ParameterTable$new(param.tbl))$WithData(param.array)))
          errorhelper(CallPalAutoWithConnection(conn.context,
            proc.name, in.tables, out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$labels <- conn.context$table(result.tbl)
        self$model  <- conn.context$table(model.tbl)
      } else {
        msg <- "data must be given as DataFrame."
        flog.error(msg)
        stop(msg)
      }
    }
  )
)
#' @title Geometry DBSCAN
#' @name hanaml.GeoDBSCAN
#' @description hanaml.GeoDBSCAN is a R wrapper for SAP HANA PAL GeoDBSCAN algorithm.
#' @template args-data
#' @param key   \code{character}\cr
#' Name of ID column.
#' @param features    \code{character, optional}\cr
#' Name of the feature column. GeoDBSCAN only supports one feature.\cr
#' If is not provided, it defaults to first non-ID columns.
#' @param minpts \code{integer, optional}\cr
#' The minimum number of points required to form a cluster\cr
#' Note that\cr
#' \emph{minpts} and \emph{eps} need to be provided together by user or these
#' two parameters are automatically determined.
#' @param eps    \code{double, optional}\cr
#' The scan radius.\cr
#' Note that \emph{minpts} and \emph{eps} need to be provided together
#' by user or these two parameters are automatically determined.
#' @template args-threadratio-1
#' @param metric  \code{character, optional}\cr
#' Ways to compute the distance between two points. Valid metric options include:\cr
#' \itemize{
#'  \item{\code{'manhattan'}}
#'  \item{\code{'euclidean'}}
#'  \item{\code{'minkowski'}}
#'  \item{\code{'chebyshev'}}
#'  \item{\code{'standardized.euclidean'}}
#'  \item{\code{'cosine'}}
#'  }
#'   Defaults to "euclidean".
#' @param minkowski.power  \code{integer, optional}\cr
#' When \emph{minkowski} is choosed for "metric", this parameter
#' controls the value of power.
#' Only applicable when \emph{metric} is 'minkowski'.\cr
#' Defaults to 3.
#' @param algorithm  \code{{"brute.force", "kd.tree"}, optional}\cr
#' Ways to search for neighbours.\cr
#' Defaults to "kd.tree".
#' @param save.model \code{logical, optional}\cr
#' If TRUE, the generated model will be saved.
#' \emph{save.model} must be TRUE to call.\cr
#' Defaults to TRUE.
#' @return
#' A "GeoDBSCAN" object with the following attributes:
#' \itemize{
#'   \item{labels :  \code{DataFrame}}\cr
#'         Label assigned to each sample. -1 means the point is labeled as noise.
#'   \item{model :  \code{DataFrame}}\cr
#'         PMML model.\cr Set to NULL if no PMML model was requested.
#' }
#' @section Examples:
#' In SAP HANA, the test table PAL_GEO_DBSCAN_DATA_TBL can be created by the
#' following SQL:
#' \preformatted{
#'  CREATE COLUMN TABLE PAL_GEO_DBSCAN_DATA_TBL (
#'                             "ID" INTEGER,
#'                             "POINT" ST_GEOMETRY);
#' }
#'
#' Input DataFrame for clustering:
#' \preformatted{
#' > data$Collect()
#'    ID                      POINT
#' 1   1     SRID=0;POINT (0.1 0.1)
#' 2   2    SRID=0;POINT (0.11 0.1)
#' 3   3    SRID=0;POINT (0.1 0.11)
#' 4   4   SRID=0;POINT (0.11 0.11)
#' 5   5   SRID=0;POINT (0.12 0.11)
#' ......
#' 28 28 SRID=0;POINT (16.11 16.11)
#' 29 29 SRID=0;POINT (20.11 20.12)
#' 30 30 SRID=0;POINT (15.12 15.11)
#' }
#'
#' Call the function:
#' \preformatted{
#' > GeoDBSCAN <- hanaml.GeoDBSCAN(data,
#'                                 key = "ID",
#'                                 thread.ratio = 0.2,
#'                                 metric = "Manhattan")
#' }
#'
#' Output:
#' \preformatted{
#' > DBSCAN$labels$Collect()
#'       ID    CLUSTER.ID
#' 1      1             0
#' 2      2             0
#' 3      3             0
#' 4      4             0
#' 5      5             0
#' ......
#' 28    28            -1
#' 29    29            -1
#' 30    30            -1
#' }
#' @keywords Clustering
#' @export
hanaml.GeoDBSCAN <- function(data = NULL, key = NULL, features = NULL,
                             minpts = NULL, eps = NULL, thread.ratio = NULL,
                             metric = NULL, minkowski.power = NULL, algorithm = NULL,
                             save.model = NULL) {
  GeoDBSCAN$new(data, key, features, minpts, eps, thread.ratio,
                metric, minkowski.power, algorithm, save.model)
}

#' @export
print.GeoDBSCAN <- function(x, ...) {
  writeLines("\n")
  writeLines("GeoDBSCAN attributes:")
  cat(sprintf("minpts : %s", to.null(x$minpts)))
  writeLines("\n")
  cat(sprintf("eps : %s", to.null(x$eps)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("metric : %s", to.null(x$metric)))
  writeLines("\n")
  cat(sprintf("minkowski.power : %s", to.null(x$minkowski.power)))
  writeLines("\n")
  cat(sprintf("algorithm : %s", to.null(x$algorithm)))
  writeLines("\n")
  cat(sprintf("save.model : %s", to.null(x$save.model)))
  writeLines("\n")
}

#' @export
summary.GeoDBSCAN <- function(object, ...) {
  if (!is.null(object)) {
    writeLines("GeoDBSCAN labels DataFrame:")
    print(object$labels$Collect())
    writeLines("\n")
    writeLines("GeoDBSCAN model DataFrame:")
    print(object$model$Collect())
    writeLines("\n")
  } else {
    print("Please create a GeoDBSCAN object first!")
  }
}


SOM <- R6Class(
  "SOM",
  inherit = ClusterAssignmentBase,
  public = list(
    tol = NULL,
    normalization = NULL,
    random.state = NULL,
    height.of.map = NULL,
    width.of.map = NULL,
    kernel = NULL,
    alpha = NULL,
    learning.rate = NULL,
    grid = NULL,
    radius = NULL,
    batch.som = NULL,
    max.iter = NULL,
    decay = NULL,
    map = NULL,
    model = NULL,
    labels = NULL,
    kernel.map = list("gaussian" = 1, "bubble" = 2),
    decay.map = list("exponential" = 1, "linear" = 2),
    grid.map = list("rectangle" = 1, "hexagon" = 2),
    norm.map = list(no = 0, min.max = 1, z.score = 2),
    initialize =  function(data = NULL,
                           key = NULL,
                           features = NULL,
                           tol = NULL,
                           normalization = NULL,
                           random.state = NULL,
                           height.of.map = NULL,
                           width.of.map = NULL,
                           kernel = NULL,
                           alpha = NULL,
                           learning.rate = NULL,
                           grid = NULL,
                           radius = NULL,
                           batch.som = NULL,
                           max.iter = NULL,
                           decay = NULL) {
      super$initialize()
      conn.context <- data$connection.context
      if (!is.null(data)) {
        self$tol <- validateInput("tol", tol, "double")
        self$normalization <- validateInput("normalization",
                                            normalization,
                                            self$norm.map)
        self$random.state <- validateInput("random.state",
                                           random.state,
                                           "integer")
        self$height.of.map <- validateInput("height.of.map", height.of.map, "integer")
        self$width.of.map <- validateInput("width.of.map", width.of.map, "integer")
        self$kernel <- validateInput("kernel", kernel, self$kernel.map)
        self$alpha <- validateInput("alpha", alpha, "double")
        self$learning.rate <- validateInput("learning.rate", learning.rate,
                                            self$decay.map)
        self$decay <- validateInput("decay", decay, self$decay.map)
        if (is.null(self$decay)) {
          self$decay <- self$learning.rate
        }
        self$grid <- validateInput("grid", grid, self$grid.map)
        self$radius <- validateInput("radius", radius, "double")
        self$batch.som <- validateInput("batch.som", batch.som, "logical")
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        cols <- data$columns
        key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        if (is.null(features)) {
          features <- cols
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        data <- data$Select(c(key, features))

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s_%s", self$id, unique.id)
        map.tbl <- sprintf("#PAL_SOM_MAP_TBL_%s_%s", self$id, unique.id)
        assignment.tbl <- sprintf("#PAL_SOM_ASSIGN_TBL_%s_%s", self$id, unique.id)
        model.tbl <- sprintf("#PAL_SOM_MODEL_TBL_%s_%s", self$id, unique.id)
        statis.tbl <- sprintf("#PAL_SOM_STATISTIC_TBL_%s_%s", self$id, unique.id)
        placeholder.tbl <- sprintf("#PAL_SOM_PLACEHOLDER_TBL_%s_%s", self$id, unique.id)
        tables <- list(param.tbl, map.tbl, assignment.tbl,
                       model.tbl, statis.tbl, placeholder.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(map.tbl, assignment.tbl, model.tbl,
                           statis.tbl, placeholder.tbl)
        param.rows <- list(
          tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
          tuple("HEIGHT_OF_MAP", self$height.of.map, NULL, NULL),
          tuple("WIDTH_OF_MAP", self$width.of.map, NULL, NULL),
          tuple("NORMALIZATION",
                map.null(self$normalization, self$norm.map),
                NULL, NULL),
          tuple("RANDOM_SEED", self$random.state, NULL, NULL),
          tuple("KERNEL_FUNCTION",
                map.null(self$kernel, self$kernel.map),
                NULL, NULL),
          tuple("LEARNING_RATE",
                map.null(self$decay, self$decay.map),
                NULL, NULL),
          tuple("COVERGENCE_CRITERION", NULL, self$tol,
                NULL),
          tuple("BATCH_SOM", to.integer(self$batch.som),
                NULL, NULL),
          tuple("ALPHA", NULL, self$alpha, NULL),
          tuple("SHAPE_OF_GRID",
                map.null(self$grid, self$grid.map), NULL, NULL),
          tuple("RADIUS", NULL, self$radius, NULL)
        )
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            (ParameterTable$new(param.tbl))$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn.context,
            "PAL_SOM", in.tables, out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        conn <- conn.context
        self$map <- conn$table(map.tbl)
        self$labels <- conn$table(assignment.tbl)
        self$model <- conn$table(model.tbl)
      }
    }
  )
)

#' @title Self-Organizing Maps
#' @name hanaml.SOM
#' @description hanaml.SOM is an R wrapper for SAP HANA PAL Self-Organizing Maps algorithm.
#' @seealso \code{\link{predict.SOM}}
#' @template args-data
#' @param key  \code{character}\cr
#'  Name of ID column.
#' @param features \code{character or list of characters, optional}\cr
#'  Names of the features columns.
#' @param tol \code{double, optional}\cr
#' If the largest difference of the successive maps is less than this value,
#' the calculation is regarded as convergence, and SOM is completed
#' consequently. \cr
#' Defaults to 1.0e-6.
#' @param normalization \code{character, optional} \cr
#' Normalization type:\cr
#' \itemize{
#'   \item{\code{"no"}: no normalization.}
#'   \item{\code{"min.max"}: Transform to new rang: 0 to 1}
#'   \item{\code{"z.score"}: Z-score normalization}
#'   }
#'   Defaults to "no".
#' @param random.state \code{integer, optional}\cr
#'  \itemize{
#'   \item{\code{-1}: Random}
#'   \item{\code{0}: Sets every weight to zero}
#'   \item{\code{Other value}: Uses this value as seed}
#'   }
#' Defaults to -1.
#' @param height.of.map \code{integer, optional}\cr
#' Indicates the height of the map.\cr
#' Defaults to 10.
#' @param width.of.map \code{integer, optional}\cr
#' Indicates the width of the map.\cr
#' Defaults to 10.
#' @param kernel \code{character, optional}\cr
#' Represents the neighborhood kernel function.\cr
#' \itemize{
#'  \item{\code{"gaussian"}: Gaussian kernel function}
#'  \item{\code{"bubble"}: Bubble/Flat kernel function.}
#'  }
#'Defaults to "gaussian".
#' @param alpha \code{double, optional}\cr
#'Specifies the learning rate.\cr
#'Defaults to 0.5
#' @param learning.rate \code{character, optional(deprecated)}\cr
#' Indicates the decay function for learning rate:\cr
#' \itemize{
#'  \item{\code{"exponential"}}
#'  \item{\code{"linear"}}
#'  }
#' Will be replaced by \code{decay} in future release.\cr
#' Defaults to "exponential".
#' @param grid \code{character, optional}\cr
#' Indicates the shape of the grid.\cr
#' \itemize{
#'  \item{\code{"rectangle"}}
#'  \item{\code{"hexagon"}}
#'  }
#' Defaults to "hexagon".
#' @param radius \code{double, optional}\cr
#' Specifies the scan radius.\cr
#' Defaults to the bigger value of \emph{height.of.map} and \emph{width.of.map}.
#' @param batch.som \code{logical, optional}\cr
#' Indicates whether batch SOM is carried out.\cr
#' Defaults to FALSE.
#' Note that for batch SOM, \emph{kernel.function} is always Gaussian,
#' and the \emph{learning.rate} factors take no effect.\cr
#' Defaults to FALSE.
#' @param max.iter \code{integer, optional}\cr
#' Maximum number of iterations.\cr
#' Note that the training might not converge if this value is too small,
#' for example, less than 1000.\cr
#' Defaults to 1000 plus 500 times the number of neurons in the lattice.
#' @param decay  \code{character, optional}\cr
#' Indicates the decay function for learning rate:\cr
#' \itemize{
#'  \item{\code{"exponential"}}
#'  \item{\code{"linear"}}
#'  }
#' If both \code{learning.rate} and \code{decay} are set,
#' \code{decay} takes precedence.\cr
#' Defaults to "exponential".
#' @return
#' A "SOM" object with the following attributes:
#' \itemize{
#'   \item{map : \code{DataFrame}}\cr
#' The map after training. The structure is as follows:
#' \itemize{
#'  \item 1st column: CLUSTER_ID, int. Unit cell ID.
#'  \item Other columns except the last one: FEATURE (in input data)
#'  column with prefix "WEIGHT_", float. Weight vectors used to simulate
#'  the original tuples.
#'  \item Last column: COUNT, int. Number of original tuples that
#'  every unit cell contains.
#'  }
#'    \item{labels : \code{DataFrame}}\cr
#'         The label of input data, the structure is as follows:
#'  \itemize{
#'    \item 1st column: ID (in input table) data type, ID (in input table) column name
#' ID of original tuples.
#'    \item 2nd column: BMU, int. Best match unit (BMU).
#'    \item 3rd column: DISTANCE, float, The distance between the tuple and its BMU.
#'    \item 4th column: SECOND_BMU, int, Second BMU.
#'    \item 5th column: IS_ADJACENT. int.
#'    Indicates whether the BMU and the second BMU are adjacent.
#'    \itemize{
#'      \item{0}: Not adjacent
#'      \item{1}: Adjacent
#'    }
#'  }
#' \item{model : \code{DataFrame}}\cr
#' The SOM model.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    TRANS_ID  V000  V001
#' 1         0  0.10  0.20
#' 2         1  0.22  0.25
#' 3         2  0.30  0.40
#' 4         3  0.40  0.50
#' ......
#' 16       15 49.00 40.10
#' 17       16 50.10 50.20
#' 18       17 50.20 48.30
#' 19       18 55.30 50.40
#' 20       19 50.40 56.50
#' }
#'
#' Call the function:
#' \preformatted{
#' > som <- hanaml.SOM(data,
#'                     key = "TRANS_ID",
#'                     tol = 1.0e-6,
#'                     normalization = "no",
#'                     random.state = 1,
#'                     height.of.map =4,
#'                     width.of.map = 4,
#'                     kernel = "gaussian",
#'                     learning.rate = "exponential",
#'                     grid = "hexagon",
#'                     batch.som = FALSE,
#'                     max.iter = 4000)
#' }
#'
#' Output:
#' \preformatted{
#' > som$map$Collect()
#'    CLUSTER_ID  WEIGHT_V000 WEIGHT_V001 COUNT
#'  1           0  52.8376884  53.4653266     2
#'  2           1  50.1502513  49.2452261     2
#'  3           2  18.5976067  27.1745897     0
#'  4           3   1.2676711  15.2676711     3
#'  5           4  49.0000211  40.1000986     1
#'  6           5  33.4309941  34.4504915     0
#'  7           6   3.4999807  15.8999720     1
#'  8           7   2.2000010  11.2000508     1
#'  9           8  24.8149919  11.7383922     0
#'  10          9  20.6962530   8.3151278     0
#'  11         10   9.8170045   6.4531495     0
#'  12         11   1.1444060   4.2462051     0
#'  13         12  16.4690145   1.5680112     3
#'  14         13  12.7482412   1.7532663     2
#'  15         14   3.8868516   0.8463565     0
#'  16         15   0.3059696   0.4737271     5
#' }
#' @keywords Clustering
#' @export
hanaml.SOM <- function(data = NULL, key = NULL, features = NULL,
                       tol = NULL, normalization = NULL,
                       random.state = NULL, height.of.map = NULL, width.of.map = NULL,
                       kernel = NULL, alpha = NULL, learning.rate = NULL,
                       grid = NULL, radius = NULL, batch.som = NULL, max.iter = NULL,
                       decay = NULL) {
  SOM$new(data, key, features,
          tol, normalization, random.state, height.of.map,
          width.of.map, kernel, alpha, learning.rate,
          grid, radius, batch.som, max.iter, decay)
}

#' @title Make Predictions from a "SOM" Object
#' @name predict.SOM
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "SOM" object.
#' @keywords Clustering
#' @seealso \code{\link{hanaml.SOM}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#' A 'SOM' object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param     ... Reserved parameter.
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data} 's ID column.}
#'   \item{Cluster_ID, type INTEGER, the assigned cluster ID.}
#'   \item{DISTANCE, type DOUBLE, Distance between a given point and the
#'    weight vector.}
#' }
#'
#' @section Examples:
#' Perform the predict on DataFrame data2 using "SOM" object som:
#' \preformatted{
#' > data2$Collect()
#'    TRANS_ID  V000  V001
#' 1         0  0.10  0.20
#' 2         1  0.22  0.25
#' 3         2  0.30  0.40
#' 4         3  0.40  0.50
#' 5         4  0.50  1.00
#' ......
#' 18       17 50.20 48.30
#' 19       18 55.30 50.40
#' 20       19 50.40 56.50
#'
#' > fitted <- predict(model = som, data = data2)
#' }
#'
#' Output:
#' \preformatted{
#' > fitted$Collect()
#'    TRANS_ID CLUSTER_ID     DISTANCE
#' 1         0         15 3.425638e-01
#' 2         1         15 2.396760e-01
#' 3         2         15 7.396834e-02
#' 4         3         15 9.763190e-02
#' 5         4         15 5.609020e-01
#' ......
#' 18       17          1 9.465344e-01
#' 19       18          0 3.931820e+00
#' 20       19          0 3.892501e+00
#'}
#' @export
predict.SOM <- function(model, data, key, features = NULL, ...) {
  return(model$predict(model = model,
                       data = data,
                       key = key,
                       features = features))
}

#' @export
print.SOM <- function(x, ...) {
  writeLines("\n")
  writeLines("SOM attributes:")
  cat(sprintf("covergence.criterion : %s", to.null(x$covergence.criterion)))
  writeLines("\n")
  cat(sprintf("normalization : %s", to.null(x$normalization)))
  writeLines("\n")
  cat(sprintf("random.state : %s", to.null(x$random.state)))
  writeLines("\n")
  cat(sprintf("height.of.map : %s", to.null(x$height.of.map)))
  writeLines("\n")
  cat(sprintf("width.of.map : %s", to.null(x$width.of.map)))
  writeLines("\n")
  cat(sprintf("kernel : %s", to.null(x$kernel)))
  writeLines("\n")
  cat(sprintf("alpha : %s", to.null(x$alpha)))
  writeLines("\n")
  cat(sprintf("learning.rate : %s", to.null(x$learning.rate)))
  writeLines("\n")
  cat(sprintf("grid : %s", to.null(x$grid)))
  writeLines("\n")
  cat(sprintf("radius : %s", to.null(x$radius)))
  writeLines("\n")
  cat(sprintf("batch.som : %s", to.null(x$batch.som)))
  writeLines("\n")
  cat(sprintf("max.iter : %s", to.null(x$max.iter)))
  writeLines("\n")
}

#' @export
summary.SOM <- function(object, ...) {
    writeLines("SOM map DataFrame:")
    print(object$map$Collect())
    writeLines("\n")
    writeLines("SOM labels DataFrame:")
    print(object$labels$Collect())
    writeLines("\n")
    writeLines("SOM model DataFrame:")
    print(object$model$Collect())
    writeLines("\n")
}

#' @title Slight Silhouette
#' @name hanaml.SlightSilhouette
#' @description Silhouette refers to a method used to validate the cluster of data.
#' PAL provides a light version of silhouette called Slight Silhouette. hanaml.SlightSilhouette
#' is an R wrapper for this light version silhouette method. \cr
#' @template args-data
#' @template args-feature-clustering
#' @template args-label
#' @param distance.level \code{character, optional}\cr
#' Specifies how to compute the distance between the item and the cluster center.
#' \itemize{
#' \item{\code{'manhattan'}}
#' \item{\code{'euclidean'}}
#' \item{\code{'minkowski'}}
#' \item{\code{'chebyshev'}}
#' }
#' Defaults to 'euclidean'.
#' @param minkowski.power \code{double, optional}\cr
#' When Minkowski distance is used, this parameter controls the value of power.\cr
#' Only valid when \code{distance.level} is 'minkowski'.\cr
#' Defaults to 3.0.
#' @template args-normalization
#' @param thread.number \code{integer, optional}\cr
#' Number of threads.\cr
#' Defaults to 1.
#' @template args-cate-var
#' @param category.weights \code{double, optional}\cr
#' Represents the weight of category attributes.\cr
#' Defaults to 0.707.
#' @return
#' DataFrame containing the validation value of Slight Silhouette.
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    V000 V001 V002 CLUSTER
#' 1   0.5    A  0.5       0
#' 2   1.5    A  0.5       0
#' 3   1.5    A  1.5       0
#' 4   0.5    A  1.5       0
#' 5   1.1    B  1.2       0
#' 6   0.5    B 15.5       1
#' 7   1.5    B 15.5       1
#' 8   1.5    B 16.5       1
#' 9   0.5    B 16.5       1
#' 10  1.2    C 16.1       1
#' 11 15.5    C 15.5       2
#' 12 16.5    C 15.5       2
#' 13 16.5    C 16.5       2
#' 14 15.5    C 16.5       2
#' 15 15.6    D 16.2       2
#' 16 15.5    D  0.5       3
#' 17 16.5    D  0.5       3
#' 18 16.5    D  1.5       3
#' 19 15.5    D  1.5       3
#' 20 15.7    A  1.6       3
#'  }
#'
#' Call the function:
#' \preformatted{
#' > res <- hanaml.SlightSilhouette(data,
#'                                  label = "CLUSTER",
#'                                  features = c('V000','V001','V002'),
#'                                  distance.level = "euclidean",
#'                                  normalization = "no",
#'                                  category.weights = 0.7,
#'                                  categorical.variable = "V001")
#' }
#'
#' Output:
#' \preformatted{
#' > print(res)
#'   VALIDATE_VALUE
#' 1      0.9385944
#'
#' }
#' @keywords Clustering
#' @export
hanaml.SlightSilhouette <- function(data,
                                    features = NULL,
                                    label = NULL,
                                    distance.level = NULL,
                                    minkowski.power = NULL,
                                    normalization = NULL,
                                    thread.number = NULL,
                                    categorical.variable = NULL,
                                    category.weights = NULL) {

  distance.map <- list("manhattan" = 1, "euclidean" = 2, "minkowski" = 3, "chebyshev" = 4)
  distance.level <- validateInput("distance.level", distance.level, distance.map)
  if ((distance.level != "minkowski") && !is.null(minkowski.power)) {#nolint
    msg <- "Invalid minkowski.power, valid when distance.level is Minkowski distance"
    flog.error(msg)
    stop(msg)
  }
  minkowski.power <- validateInput("minkowski.power", minkowski.power, "double")
  normalization.map <- list(no = 0, l1.norm = 1, min.max = 2)
  normalization <- validateInput("normalization", normalization, normalization.map)
  thread.number <- validateInput("thread.number", thread.number, "integer")
  categorical.variable <- validateInput("categorical.variable",
                                        categorical.variable,
                                        data$columns,
                                        case.sensitive = TRUE)
  category.weights <- validateInput("category.weights", category.weights, "double")

  cols <-  data$columns
  label  <-  validateInput("label", label, cols, case.sensitive = TRUE)
  if (is.null(label)) {
    label <- cols[length(data)]
  }
  cols <- cols[! cols %in% label]
  features <- validateInput("features", features, cols, case.sensitive = TRUE)
  if (is.null(features)) {
    features <- cols
  }

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }

  conn <- data$connection.context
  CheckConnection(data)
  data <- data$Select(c(features, label))

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_SLIGHT_SIL_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_SLIGHT_SIL_RESULT_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables  <-  c(param.tbl, out.tables)
  param.array  <-  list(
    tuple("DISTANCE_LEVEL",
          map.null(distance.level, distance.map), NULL, NULL),
    tuple("MINKOWSKI_POWER", NULL, minkowski.power, NULL),
    tuple("NORMALIZATION",
          map.null(normalization, normalization.map), NULL, NULL),
    tuple("THREAD_NUMBER", thread.number, NULL, NULL),
    tuple("CATEGORY_WEIGHTS", NULL, category.weights, NULL)
  )

  if (!is.null(categorical.variable)) {
    for (each in categorical.variable) {
      column.number <- which(data$columns == each) - 1
      temp.list <- tuple("CATEGORY_COL", column.number, NULL, NULL)
      param.array <- append(param.array, tuple(temp.list))
    }
  }

  tryCatch({
    errorhelper(CreateTWithConnection(
      conn, ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(
      conn, "PAL_SLIGHT_SILHOUETTE", in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(result.tbl))
}

#' @title Spectral Clustering
#' @name hanaml.SpectralClustering
#' @description Spectral clustering is an algorithm evolved from graph theory,
#' and has been widely used in clustering.
#' @details The main idea of Spectral Clustering is to treat
#' all data as points in space, which can be connected by edges.
#' The edge weight between two points farther away is low, while the edge
#' weight between two points closer is high. Cutting the graph composed
#' of all data points to make the edge weight sum between different subgraphs
#' after cutting as low as possible, while make the edge weight sum within the
#' subgraph as high as possible to achieve the purpose of clustering.\cr
#' It performs a low-dimension embedding of the affinity matrix between samples,
#' followed by k-means clustering of the components of the eigenvectors
#' in the low dimensional space.
#' @param n.clusters \code{integer}\cr
#' The number of clusters for spectral clustering.\cr
#' The valid range for this parameter is from 2 to the number of records
#' in the input data.
#' @param n.components \code{integer, optional}\cr
#' The number of eigenvectors used for spectral embedding.
#' Defaults to the value of \code{n.clusters}.
#' @param gamma \code{numeric, optional}\cr
#' RBF kernel coefficient \eqn{\gamma} used in constructing affinity matrix with
#' distance metric \code{d}, illustrated as \eqn{e^(-\gamma * d^2)}.\cr
#' Defaults to 1.0.
#' @param affinity \code{character, optional}\cr
#' Specifies the type of graph used to construct
#' the affinity matrix. Valid options include:
#' \itemize{
#'   \item{'knn':} binary affinity matrix constructed from the
#'   graph of k-nearest-neighbors(knn).
#'   \item{'mutual-knn':} binary affinity matrix constructed from
#'   the graph of mutual k-nearest-neighbors(mutual-knn).
#'  \item{'fully-connected':} affinity matrix constructed from
#'   fully-connected graph, with weights defined by RBF
#'  kernel coefficients.}
#' Defaults to 'fully-connected'.
#' @param  n.neighbors \code{integer, optional}\cr
#' The number neighbors to use when constructing the affinity matrix using
#' nearest neighbors method.\cr
#' Valid only when \code{graph} is 'knn' or 'mutual-knn'.\cr
#' Defaults to 10.
#' @param cut \code{character, optional}\cr
#' Specifies the method to cut the graph.
#' \itemize{
#'  \item{'ratio-cut':}  Ratio-Cut.
#'  \item{'n-cut':} Normalized-Cut.
#'  }
#' Defaults to 'ratio-cut'.
#' @param eigen.tol \code{numeric, optional}\cr
#' Stopping criterion for eigendecomposition of the Laplacian matrix.\cr
#' Defaults to 1e-10.
#' @param krylov.dim \code{int, optional}\cr
#' Specifies the dimension of Krylov subspaces used in Eigenvalue decomposition.
#' In general, this parameter controls the convergence speed of the algorithm.
#' Typically a larger \code{krylov.dim} means faster convergence,
#' but it may also result in greater memory use and more matrix operations
#' in each iteration.\cr
#' Defaults to \eqn{2* n.components}.\cr
#' __NOTE__: This parameter must satisfy\cr
#' n.components < \code{krylov.dim} <= the number of training records.
#' @param  distance.level \code{character, optional}\cr
#' Specifies the method for computing the distance between data records
#' and cluster centers:
#' \itemize{
#'   \item{'manhattan'}: Manhattan distance.
#'   \item{'euclidean'}: Euclidean distance.
#'   \item{'minkowski'}: Minkowski distance.
#'   \item{'chebyshev'}: Chebyshev distance.
#'   \item{'cosine'}: Cosine distance.
#' }
#' Defaults to 'euclidean'.
#' @param minkowski.power \code{numeric, optional}\cr
#' Specifies the power parameter in Minkowski distance.\cr
#' Valid only when \code{distance.level} is 'minkowski'.\cr
#' Defaults to 3.0.
#' @param category.wights \code{numeric, optional}\cr
#' Represents the weight of category attributes.\cr
#' Defaults to 0.707.
#' @param max.iter \code{integer, optional}\cr
#' Maximum number of iterations for K-Means algorithm.\cr
#' Defaults to 100.
#' @param init \code{c('first_k', 'replace', 'no_replace', 'patent'), optional}\cr
#' Controls how the initial centers are selected in K-Means algorithm:\cr
#' \itemize{
#'   \item{'first_k':} First k observations.
#'   \item{'replace':} Random with replacement.
#'   \item{'no_replace':} Random without replacement.
#'   \item{'patent':} Patent of selecting the init center (US 6,882,998 B1).
#' }
#' Defaults to 'patent'.
#' @param  tol \code{numeric, optional}\cr
#' Specifies the exit threshold for K-Means iterations.\cr
#' Defaults to 1e-6.
#' @return
#' List of DataFrames:
#' \itemize{
#'   \item{labels:} DataFrame containing the cluster labels of
#'   the input data.
#'   \item{statistics:} DataFrame containing the related statistics for
#'   spectral clustering.
#' }
#' @section Examples:
#' Input data:
#' \preformatted{
#' > data$Collect()
#'    ID   X1   X2
#' 1   0  0.5  0.5
#' 2   1  1.5  0.5
#' 3   2  1.5  1.5
#' 4   3  0.5  1.5
#' 5   4  1.1  1.2
#' 6   5  0.5 15.5
#' 7   6  1.5 15.5
#' 8   7  1.5 16.5
#' 9   8  0.5 16.5
#' 10  9  1.2 16.1
#' 11 10 15.5 15.5
#' 12 11 16.5 15.5
#' 13 12 16.5 16.5
#' 14 13 15.5 16.5
#' 15 14 15.6 16.2
#' 16 15 15.5  0.5
#' 17 16 16.5  0.5
#' 18 17 16.5  1.5
#' 19 18 15.5  1.5
#' 20 19 15.7  1.6
#' }
#' Apply spectral clustering:
#' \preformatted{
#' spc <- hanaml.SpectralClustering(data=data,
#'                                  key='ID',
#'                                  thread.ratio=0.2,
#'                                  n.clusters=4,
#'                                  n.neighbors=4,
#'                                  init='patent',
#'                                  distance.level='euclidean',
#'                                  max.iter=100,
#'                                  tol=1e-6,
#'                                  category.weights=0.5)
#' }
#' Check the cluster labels:
#' \preformatted{
#' > spc$labels$Collect()
#'    ID CLUSTER_ID
#' 1   0          0
#' 2   1          0
#' 3   2          0
#' 4   3          0
#' 5   4          0
#' 6   5          1
#' 7   6          1
#' 8   7          1
#' 9   8          1
#' 10  9          1
#' 11 10          2
#' 12 11          2
#' 13 12          2
#' 14 13          2
#' 15 14          2
#' 16 15          3
#' 17 16          3
#' 18 17          3
#' 19 18          3
#' 20 19          3
#' }
#' @keywords clustering, affinity matrix, graph-cut
#' @export
hanaml.SpectralClustering <- function(data,
                                      key,
                                      features = NULL,
                                      n.clusters = NULL,
                                      n.components = NULL,
                                      gamma = NULL,
                                      affinity = NULL,
                                      n.neighbors = NULL,
                                      cut = NULL,
                                      eigen.tol = NULL,
                                      krylov.dim = NULL,
                                      distance.level = NULL,
                                      minkowski.power = NULL,
                                      category.weights = NULL,
                                      max.iter = NULL,
                                      init = NULL,
                                      tol = NULL,
                                      thread.ratio = NULL) {
  affinity.map <- list("knn" = 0, "mutual-knn" = 1,
                       "fully-connected" = 2)
  cut.map <- list("ratio-cut" = 0, "n-cut" = 1)
  distance.map <- list(manhattan = 1, euclidean = 2,
                       minkowski = 3, chebyshev = 4,
                       cosine = 6)
  init.map <- list("first_k" = 1, "replace" = 2,
                   "no_replace" = 3, "patent" = 4)
  n.clusters <- validateInput("n.clusters", n.clusters, "integer",
                              required = TRUE)
  n.components <- validateInput("n.components", n.components, "integer")
  gamma <- validateInput("gamma", gamma, "numeric")
  affinity <- validateInput("affinity", affinity, affinity.map)
  n.neighbors <- validateInput("n.neighbors", n.neighbors, "integer")
  cut <- validateInput("cut", cut, cut.map)
  eigen.tol <- validateInput("eigen.tol", eigen.tol, "numeric")
  krylov.dim <- validateInput("krylov.dim", krylov.dim, "integer")
  distance.level <- validateInput("distance.level", distance.level, distance.map)
  minkowski.power <- validateInput("minkowski.power", minkowski.power, "numeric")
  category.weights <- validateInput("category.weights", category.weights, "numeric")
  max.iter <- validateInput("max.iter", max.iter, "integer")
  init <- validateInput("init", init, init.map)
  tol <- validateInput("tol", tol, "numeric")
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
  cols <- cols[!cols %in% key]
  features <- validateInput("features", features, cols, case.sensitive = TRUE)
  if (is.null(features)) {
    features <- cols
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }

  conn <- data$connection.context
  CheckConnection(data)
  data <- data$Select(c(key, features))

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_SPECTRAL_CLUSTERING_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_SPECTRAL_CLUSTERING_RESULT_TBL_%s", unique.id)
  stats.tbl <- sprintf("#PAL_SPECTRAL_CLUSTERING_STATISTICS_TBL_%s", unique.id)
  ph.tbl <- sprintf("#PAL_SPECTRAL_CLUSTERING_PLACEHOLDER_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl, stats.tbl, ph.tbl)
  tables  <-  c(param.tbl, out.tables)
  param.array  <-  list(
    tuple("GROUP_NUMBER", n.clusters, NULL, NULL),
    tuple("N_COMPONENTS", n.components, NULL, NULL),
    tuple("GAMMA", NULL, gamma, NULL),
    tuple("AFFIINITY", map.null(affinity, affinity.map),
          NULL, NULL),
    tuple("N_NEIGHBOURS", n.neighbors, NULL, NULL),
    tuple("CUT_METHOD", map.null(cut, cut.map),
          NULL, NULL),
    tuple("EIGEN_TOL", NULL, eigen.tol, NULL),
    tuple("KRYLOV_DIMENSION", krylov.dim, NULL, NULL),
    tuple("MAX_ITERATION", max.iter, NULL, NULL),
    tuple("INIT_TYPE", map.null(init, init.map), NULL, NULL),
    tuple("EXIT_THRESHOLD", NULL, tol, NULL),
    tuple("DISTANCE_LEVEL",
          map.null(distance.level, distance.map), NULL, NULL),
    tuple("MINKOWSKI_POWER", NULL, minkowski.power, NULL),
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
    tuple("CATEGORY_WEIGHTS", NULL, category.weights, NULL),
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL)
  )
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn, ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(
      conn, "PAL_SPECTRAL_CLUSTERING", in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(list(labels = conn$table(result.tbl),
              statistics = conn$table(stats.tbl)))
}
