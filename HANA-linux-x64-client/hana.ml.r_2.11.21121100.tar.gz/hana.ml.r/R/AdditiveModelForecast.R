AdditiveModelForecast <- R6Class(
  "AdditiveModelForecast",
  inherit = MlBase,
  public = list(
    growth = NULL,
    logistic.growth.capacity = NULL,
    seasonality.mode = NULL,
    seasonality = NULL,
    num.changepoints = NULL,
    changepoint.range = NULL,
    regressor = NULL,
    changepoints = NULL,
    yearly.seasonality = NULL,
    weekly.seasonality = NULL,
    daily.seasonality = NULL,
    seasonality.prior.scale = NULL,
    holiday.prior.scale = NULL,
    changepoint.prior.scale = NULL,
    categorical.variable = NULL,
    growth.list = list("linear", "logistic"),
    seasonality.mode.list = list("additive",
                                 "multiplicative"),
    seasonality.options = list(auto = -1, false = 0, true = 1),
    initialize = function(data = NULL,
                          key = NULL,
                          endog = NULL,
                          exog = NULL,
                          holiday = NULL,
                          growth = NULL,
                          logistic.growth.capacity = NULL,
                          seasonality.mode = NULL,
                          seasonality = NULL,
                          num.changepoints = NULL,
                          changepoint.range = NULL,
                          regressor = NULL,
                          changepoints = NULL,
                          yearly.seasonality = NULL,
                          weekly.seasonality = NULL,
                          daily.seasonality = NULL,
                          seasonality.prior.scale = NULL,
                          holiday.prior.scale = NULL,
                          changepoint.prior.scale = NULL,
                          categorical.variable = NULL){
      super$initialize()

      if (!is.null(data)){
        self$growth <- validateInput("growth", growth, self$growth.list,
                                     case.sensitive = TRUE)
        self$logistic.growth.capacity <-
          validateInput("logistic.growth.capacity",
                        logistic.growth.capacity,
                        "numeric")
        self$seasonality.mode <- validateInput("seasonality.mode",
                                               seasonality.mode,
                                               self$seasonality.mode.list,
                                               case.sensitive = TRUE)

        self$num.changepoints <- validateInput("num.changepoints",
                                               num.changepoints,
                                               "integer")
        self$changepoint.range <- validateInput("changepoint.range",
                                                changepoint.range,
                                                "numeric")

        self$yearly.seasonality <- validateInput("yearly.seasonality",
                                                 yearly.seasonality,
                                                 self$seasonality.options)
        self$weekly.seasonality <- validateInput("weekly.seasonality",
                                                 weekly.seasonality,
                                                 self$seasonality.options)
        self$daily.seasonality <- validateInput("daily.seasonality",
                                                daily.seasonality,
                                                self$seasonality.options)
        self$seasonality.prior.scale <-
          validateInput("seasonality.prior.scale",
                        seasonality.prior.scale,
                        "numeric")
        self$holiday.prior.scale <-
          validateInput("holiday.prior.scale",
                        holiday.prior.scale,
                        "numeric")
        self$changepoint.prior.scale <-
          validateInput("changepoint.prior.scale",
                        changepoint.prior.scale,
                        "numeric")

        if (!is.null(changepoints) &&
            typeof(changepoints) == "character") {
          changepoints <- as.list(changepoints)
        }
        self$changepoints <- validateInput("changepoints",
                                           changepoints,
                                           "LISTOFSTRINGS")
        if (!is.null(categorical.variable) &&
            typeof(categorical.variable) == "character") {
          categorical.variable <- as.list(categorical.variable)
        }
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   "LISTOFSTRINGS")
        if (!is.null(seasonality) &&
            typeof(seasonality) == "character") {
          seasonality <- as.list(seasonality)
        }
        self$seasonality <- validateInput("seasonality",
                                          seasonality,
                                          "LISTOFSTRINGS")
        if (!is.null(regressor) &&
            typeof(regressor) == "character")  {
          regressor <- as.list(regressor)
        }
        self$regressor <- validateInput("regressor",
                                        regressor,
                                        "LISTOFSTRINGS")
        cols <- data$columns
        if (!is.null(self$categorical.variable)) {
          for (cate in self$categorical.variable) {
            validateInput("categorical.variable",
                          cate,
                          cols,
                          case.sensitive = TRUE)
          }
        }

        if (is.null(key)){
          key <- cols[[1]]
        }
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]

        if (is.null(endog)){
          endog <- cols[[1]]
        }
        endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
        cols <- cols[! cols %in% endog]

        exog <- validateInput("exog", exog, cols, case.sensitive = TRUE)

        if (!inherits(data, "DataFrame")) {
          msg <- "data must be given as DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn <- data$connection.context
        selected <- list(key, endog)
        data <- data$Select(append(selected, exog))

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_ADDITIVE_MODEL_FORECAST_PARAM_TBL_%s_%s",
                             self$id, unique.id)
        model.tbl <- sprintf("#PAL_ADDITIVE_MODEL_FORECAST_MODEL_TBL_%s_%s",
                             self$id, unique.id)
        holiday.tbl <- sprintf("#PAL_ADDITIVE_MODEL_FORECAST_HOLIDAY_TBL_%s_%s",
                               self$id, unique.id)
        param.rows <- list(
          tuple("GROWTH", NULL, NULL, self$growth),
          tuple("CAP", NULL, self$logistic.growth.capacity, NULL),
          tuple("SEASONALITY_MODE", NULL, NULL, self$seasonality.mode),
          tuple("NUM_CHANGEPOINTS", self$num.changepoints, NULL, NULL),
          tuple("CHANGEPOINT_RANGE", NULL, self$changepoint.range, NULL),
          tuple("YEARLY_SEASONALITY", map.null(self$yearly.seasonality,
                                               self$seasonality.options),
                NULL, NULL),
          tuple("WEEKLY_SEASONALITY", map.null(self$weekly.seasonality,
                                               self$seasonality.options),
                NULL, NULL),
          tuple("DAILY_SEASONALITY", map.null(self$daily.seasonality,
                                              self$seasonality.options),
                NULL, NULL),
          tuple("SEASONALITY_PRIOR_SCALE", NULL,
                self$seasonality.prior.scale, NULL),
          tuple("HOLIDAYS_PRIOR_SCALE", NULL,
                self$holidays.prior.scale, NULL),
          tuple("CHANGEPOINT_PRIOR_SCALE", NULL,
                self$changepoint.prior.scale, NULL))

        if (!is.null(self$changepoints)) {
          for (each in self$changepoints) {
            temp.list <- tuple("CHANGE_POINT", NULL, NULL, each)
            param.rows <- append(param.rows, tuple(temp.list))
          }
        }
        if (!is.null(self$categorical.variable)) {
          for (var in self$categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, var)
            param.rows <- append(param.rows, tuple(temp.list))
          }
        }
        if (!is.null(self$seasonality)) {
          for (ss in self$seasonality) {
            temp.list <- tuple("SEASONALITY", NULL, NULL, ss)
            param.rows <- append(param.rows, tuple(temp.list))
          }
        }
        if (!is.null(self$regressor)) {
          for (reg in self$regressor) {
            temp.list <- tuple("REGRESSOR", NULL, NULL, reg)
            param.rows <- append(param.rows, tuple(temp.list))
          }
        }

        tables <- list(param.tbl, model.tbl)
        if (is.null(holiday)){
          tryCatch({
            TryDropWithConnection(conn, holiday.tbl)
            ExecuteLogged(conn$connection,
                        paste("CREATE LOCAL TEMPORARY TABLE",
                              holiday.tbl,
                              "(\"ts\" TIMESTAMP,",
                              "\"holiday\" NVARCHAR(50))"))
          },
          error = function(err){
            msg <- paste("Error:", err[["message"]])
            flog.error(msg)
            stop(msg)
          }
          )
          holiday <- holiday.tbl
        }
        in.tables <- list(data, holiday, param.tbl)
        out.tables <- list(model.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
            (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
          errorhelper(CallPalAutoWithConnection(conn,
            "PAL_ADDITIVE_MODEL_ANALYSIS", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        self$model <- conn$table(model.tbl)
      }
    }
  ) #public method end
)

#' @title Additive Model Forecast
#' @name hanaml.AdditiveModelForecast
#' @description hanaml.AdditiveModelForecast is a R wrapper
#' for SAP HANA PAL additive model forecast algorithm.
#' @details   Additive Model Forecast use a decomposable time series model
#' with three main components: trend, seasonality, and holidays or event.
#' @seealso \code{\link{predict.AdditiveModelForecast}}
#' @param data \code{DataFrame}\cr
#' Input data which includes key and endog columns and may contain exog column(s).
#' @template args-key-first
#' @template args-endog
#' @param     exog \code{character or list of character, optional}\cr
#'            An optional array of exogenous variables.\cr
#'            Defaults to NULL.
#' @param     holiday \code{DataFrame, optional}\cr
#'            Input holiday data. The structure is as follows.
#'            \itemize{
#'               \item{The first column:} index (ID), timestamp.
#'               \item{The second column:} name, varchar.
#'               \item{The third column:}: lower window of holiday, int.
#'               \item{The last column:}: upper window of holiday, int.
#'            }
#'            Defaults to NULL.
#' @param     growth \code{{'linear', 'logistic'}, optional}\cr
#'            Specify a trend, which could be either linear or logistic.\cr
#'            Defaults to 'linear'.
#' @param     logistic.growth.capacity \code{numeric, optional}\cr
#'            Specify the carrying capacity for logistic growth.\cr
#'            Mandatory and valid only when the value of \emph{growth} is 'logistic'.\cr
#'            Defaults to NULL.
#' @param     seasonality.mode \code{{'additive', 'multiplicative'}, optional}\cr
#'            Mode for seasonality.\cr
#'            Defaults to 'additive'.
#' @param     seasonality \code{character or list of characters, optional}\cr
#'            Add seasonality to model which is a json format, include NAME, PERIOD, FOURIER.ORDER, PRIOR.SCALE, MODE.\cr
#'            For example: seasonality = '{ "NAME": "MONTHLY", "PERIOD":30, "FOURIER_ORDER":5 }'.\cr
#'            Defaults to NULL.
#' @param     num.changepoints \code{integer, optional}\cr
#'            Number of potential changepoints.\cr
#'            Defaults to 25.
#' @param     changepoint.range \code{numeric, optional}\cr
#'            Proportion of history in which trend changepoints will be estimated.\cr
#'            Defaults to 0.8.
#' @param     regressor \code{character or list of characters, optional}\cr
#'            Specify the regressor, include PRIOR.SCALE, STANDARDIZE, and MODE, which is json format.\cr
#'            For example, regressor = '{ "NAME": "X1", "PRIOR_SCALE":4, "MODE": "additive" }'.
#'            Defaults to NULL.
#' @param     changepoints \code{character or list of characters, optional}\cr
#'            Specify a list of changepoints in the format of timestamp, \cr
#'            such as changepoints = list('2019-01-01 00:00:00, '2019-02-04 00:00:00').
#'            Defaults to NULL.
#' @param     yearly.seasonality \code{{'auto', 'false', 'true'}, optional}\cr
#'            Specify whether or not to fit yearly seasonality.\cr
#'            'false' and 'true' simply corresponds to their logical meaning, while 'auto' means automatically determined from the input data.
#'            Defaults to 'auto'.
#' @param     weekly.seasonality \code{{'auto', 'false', 'true'}, optional}\cr
#'            Specify whether or not to fit the weekly seasonality.\cr
#'            'auto' means automatically determined from input data.
#'            Defaults to 'auto'.
#' @param     daily.seasonality \code{{'auto', 'false', 'true'}, optional}\cr
#'            Specify whether or not to fit the daily seasonality.\cr
#'            'auto' means automatically determined from input data.
#'            Defaults to 'auto'.
#' @param     seasonality.prior.scale \code{numeric, optional}\cr
#'            Parameter modulating the strength of the seasonality model.\cr
#'            Defaults to 10.
#' @param     holiday.prior.scale \code{numeric, optional}\cr
#'            Parameter modulating the strength of the holiday components model.\cr
#'            Defaults to 10.
#' @param     changepoint.prior.scale \code{numeric, optional}\cr
#'            Parameter modulating the flexibility of the automatic changepoint selection.\cr
#'            Defaults to 0.05.
#' @param     categorical.variable \code{character or list of characters, optional}\cr
#'            Indicate which variables are treated as categorical. The default behavior is:
#'            \itemize{
#'              \item{"VARCHAR" and "NVARCHAR"}: categorical.\cr
#'              \item{"INTEGER" and "DOUBLE"}: continuous.
#'            }
#'            VALID only for variables of "INTEGER", "VARCHAR" and "NVARCHAR" type, omitted otherwise.\cr
#'            Defaults to NULL.
#' @return
#' Returns a "hanaml.AdditiveModelForecast" object with following values:
#' \itemize{
#'    \item{model : \code{DataFrame}}\cr
#'         Fitted model.
#' }
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    TIMESTAMP          Y
#' 1 2007-12-11 -0.6361264
#' 2 2007-12-12  3.0925087
#' 3 2007-12-13 -0.7373356
#' 4 2007-12-14 -3.1421910
#'
#' }
#' Call the function:
#' \preformatted{
#' > amf <- hanaml.AdditiveModelForecast(data = amf.df,
#'                                       yearly.seasonality = "auto",
#'                                       weekly.seasonality = "auto",
#'                                       daily.seasonality = "auto")
#' }
#' Output:
#' \preformatted{
#' > amf$model$Collect()
#' ROW_INDEX
#' 1         0
#' MODEL_CONTENT
#' 1 {"FLOOR":0.0,"GROWTH":"linear","SEASONALITY_MODE":"additive","beta":[[0.0]],"changepoints_t":[[0.3333333333333333,0.6666666666666666]],"delta":[[3.606905203289095e-10,2.161407465026720e-10]],"holidays_prior_scale":10.0,"k":-0.692426758115090,"m":0.04386341358443890,"sigma_obs":0.5074218980767474,"start":"2007-12-11 00:00:00.0000000","t_scale":259200.0,"y_scale":3.1421909830}\n
#' }
#' @keywords TimeSeries
#' @export
hanaml.AdditiveModelForecast <- function(data = NULL,
                                         key = NULL,
                                         endog = NULL,
                                         exog = NULL,
                                         holiday = NULL,
                                         growth = NULL,
                                         logistic.growth.capacity = NULL,
                                         seasonality.mode = NULL,
                                         seasonality = NULL,
                                         num.changepoints = NULL,
                                         changepoint.range = NULL,
                                         regressor = NULL,
                                         changepoints = NULL,
                                         yearly.seasonality = NULL,
                                         weekly.seasonality = NULL,
                                         daily.seasonality = NULL,
                                         seasonality.prior.scale = NULL,
                                         holiday.prior.scale = NULL,
                                         changepoint.prior.scale = NULL,
                                         categorical.variable = NULL){
  AdditiveModelForecast$new(data,
                            key,
                            endog,
                            exog,
                            holiday,
                            growth,
                            logistic.growth.capacity,
                            seasonality.mode,
                            seasonality,
                            num.changepoints,
                            changepoint.range,
                            regressor,
                            changepoints,
                            yearly.seasonality,
                            weekly.seasonality,
                            daily.seasonality,
                            seasonality.prior.scale,
                            holiday.prior.scale,
                            changepoint.prior.scale,
                            categorical.variable)
}

#' @title Make Predictions from a "hanaml.AdditiveModelForecast" Object
#' @name predict.AdditiveModelForecast
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "hanaml.AdditiveModelForecast" object.
#' @seealso \code{\link{hanaml.AdditiveModelForecast}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'        A 'hanaml.AdditiveModelForecast' object for prediction.
#' @param data \code{DataFrame}\cr
#' Input data which includes key and endog columns and may contain exog column(s).
#' @template args-key-first
#' @template args-endog
#' @param exog \code{character or list of character, optional}\cr
#'        An optional array of exogenous variables.\cr
#'        Defaults to NULL.
#' @param logistic.growth.capacity \code{numeric, optional}\cr
#'        Specify the carrying capacity for logistic growth.\cr
#'        Mandatory and valid only when the \code{growth} attribute is 'logistic'.\cr
#'        Defaults to NULL.
#' @param interval.width \code{numeric, optional}\cr
#'        Width of the uncertainty intervals.\cr
#'        Defaults to 0.8.
#' @param uncertainty.samples \code{numeric, optional}\cr
#'        Number of simulated draws used to estimate uncertainty intervals.\cr
#'        Defaults to 1000.
#' @return
#' Predicted values are returned as a \code{DataFrame}, structured as follows.
#' \itemize{
#'   \item{ID column: type timestamp.}
#'   \item{YHAT: type DOUBLE, representing predicted values.}
#'   \item{YHAT_LOWER: type DOUBLE, lower bound of confidence region.}
#'   \item{YHAT_UPPER: type DOUBLE, upper bound of confidence region.}
#' }
#'
#' @section Examples:
#' Input DataFrame data2:
#' \preformatted{
#' > data2$Collect()
#'    TIMESTAMP          X
#' 1 2007-12-11 -0.6361264
#' 2 2007-12-12  3.0925087
#' 3 2007-12-13 -0.7373356
#' 4 2007-12-14 -3.1421910
#' }
#' Call the function with a "hanaml.AdditiveModelForecast" object amf and obtain the result:
#' \preformatted{
#' > res <- predict(amf, data2)
#'    TIMESTAMP       YHAT YHAT_LOWER YHAT_UPPER
#' 1 2007-12-11  0.1378272  -1.922812  2.2191343
#' 2 2007-12-12 -0.5874185  -2.610632  1.4819355
#' 3 2007-12-13 -1.3126642  -3.376615  0.5591713
#' 4 2007-12-14 -2.0379099  -4.086953  0.1144007
#' }
#' @keywords TimeSeries
#' @export
predict.AdditiveModelForecast <- function(model,
                                          data,
                                          key = NULL,
                                          endog = NULL,
                                          exog = NULL,
                                          logistic.growth.capacity = NULL,
                                          interval.width = NULL,
                                          uncertainty.samples = NULL){
  if (!is.null(model$model)){
    predict.model <- model$model$name
  } else {
    msg <- "Model not initialized. Perform a fit first."
    flog.error(msg = msg)
    stop(msg)
  }

  cols <- data$columns
  if (is.null(key)){
    key <- cols[[1]]
  }
  key <- validateInput("key", key, cols, case.sensitive = TRUE)
  cols <- cols[! cols %in% key]

  if (is.null(endog)){
    endog <- cols[[1]]
  }
  endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
  cols <- cols[! cols %in% endog]

  exog <- validateInput("exog", exog, cols, case.sensitive = TRUE)

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context
  selected <- list(key, endog)
  data <- data$Select(append(selected, exog))
  logistic.growth.capacity <-
    validateInput("logistic.growth.capacity",
                  logistic.growth.capacity,
                  "numeric",
                  required = isTRUE(model$growth == "logistic"))
  interval.width <-
    validateInput("interval.width",
                  interval.width,
                  "numeric")
  uncertainty.samples <-
    validateInput("uncertainty.samples",
                  uncertainty.samples,
                  "integer")
  conn <- data$connection.context

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_ADDITIVE_MODEL_PARAM_TBL_%s_%s",
                       model$id, unique.id)
  predict.tbl <- sprintf("#PAL_ADDITIVE_MODEL_PREDICT_TBL_%s_%s",
                         model$id, unique.id)
  param.rows <- list(tuple("CAP", NULL, logistic.growth.capacity, NULL),
                     tuple("INTERVAL_WIDTH", NULL, interval.width, NULL),
                     tuple("UNCERTAINTY_SAMPLES", uncertainty.samples,
                           NULL, NULL))
  tables <- list(param.tbl, predict.tbl)
  in.tables <- list(data, predict.model, param.tbl)
  out.tables <- list(predict.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
      (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
    errorhelper(CallPalAutoWithConnection(conn,
      "PAL_ADDITIVE_MODEL_PREDICT", in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(predict.tbl))
}

#' @export
print.AdditiveModelForecast <- function(x, ...){
  writeLines("Additive Model Forecast Attributes::")
  cat(sprintf("Growth : %s", to.null(x$growth)))
  writeLines("\n")
  cat(sprintf("Logistic growth capacity : %s",
              to.null(x$logistic.growth.capacity)))
  writeLines("\n")
  cat(sprintf("Seasonality mode :%s", to.null(x$seasonality.mode)))
  writeLines("\n")
  cat(sprintf("Seasonality :%s", to.null(x$seasonality)))
  writeLines("\n")
  cat(sprintf("Number of changepoints :%s", to.null(x$num.changepoints)))
  writeLines("\n")
  cat(sprintf("Range of changepoint :%s", to.null(x$changepoint.range)))
  writeLines("\n")
  cat(sprintf("Regressor :%s", to.null(x$regressor)))
  writeLines("\n")
  cat(sprintf("Changepoints :%s", to.null(x$changepoints)))
  writeLines("\n")
  cat(sprintf("Yearly seasonality :%s", to.null(x$yearly.seasonality)))
  writeLines("\n")
  cat(sprintf("Weekly seasonality :%s", to.null(x$weekly.seasonality)))
  writeLines("\n")
  cat(sprintf("Daily seasonality :%s", to.null(x$daily.seasonality)))
  writeLines("\n")
  cat(sprintf("Seasonality prior scale :%s",
              to.null(x$seasonality.prior.scale)))
  writeLines("\n")
  cat(sprintf("Holiday prior scale :%s", to.null(x$holiday.prior.scale)))
  writeLines("\n")
  cat(sprintf("Changepoint prior scale :%s",
              to.null(x$changepoint.prior.scale)))
  writeLines("\n")
}
