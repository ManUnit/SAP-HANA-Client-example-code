#' @title M4 Sampling
#' @name hanaml.M4Sampling
#' @description hanaml.M4Sampling a visalization method for time serie data
#' @details
#' This algorithm takes a subset of the original data for visualiztion.
#' @param data \code{DataFrame}\cr
#' Time series data whose 1st column is index and 2nd one is value.
#' @param width \code{integer}\cr
#' Sampling Rate. It is an indicator of how many pixels being in the picture.
#' @return
#' Return the sampled DataFrame.
#' @section Examples:
#'\preformatted{
#' > data$Collect()
#'                    Time            y
#' 1   2015-12-05 08:00:29  0.000000000
#' 2   2015-12-05 09:00:29 -0.019810209
#' 3   2015-12-05 10:00:29 -0.014002897
#' 4   2015-12-05 11:00:29 -0.040427794
#' 5   2015-12-05 12:00:29  0.010019414
#' 6   2015-12-05 13:00:29  0.020439365
#' 7   2015-12-05 14:00:29 -0.005506123
#' 8   2015-12-05 15:00:29  0.009907737
#' ......
#' 120 2015-12-10 07:00:29  0.421931228
#' 121 2015-12-10 08:00:29  0.416323546
#'}
#' Call the function:
#' \preformatted{
#' > result <- hanaml.M4Sampling(data = data, width = 20)
#' }
#' Results:
#' \preformatted{
#' > result$Collect()
#'                   Time           y
#' 1  2015-12-05 08:00:29  0.00000000
#' 2  2015-12-05 09:00:29 -0.01981021
#' 3  2015-12-05 10:00:29 -0.01400290
#' 4  2015-12-05 11:00:29 -0.04042779
#' 5  2015-12-05 16:00:29  0.03325561
#' 6  2015-12-05 20:00:29  0.10194083
#' 7  2015-12-05 22:00:29  0.01226052
#' 8  2015-12-06 01:00:29  0.04590105
#' 9  2015-12-06 04:00:29  0.12049788
#' ......
#' 51 2015-12-10 06:00:29  0.40630362
#' 52 2015-12-10 07:00:29  0.42193123
#' 53 2015-12-10 08:00:29  0.41632355
#' }
#' @keywords Visualization
#' @export

hanaml.M4Sampling  <-  function(
  data,
  width
) {
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)

  max.statement <- sprintf('SELECT MAX("%s") FROM (%s)',
                           data$columns[[1]], data$select.statement)
  max <- ExecuteLogged(
    conn$connection, max.statement)[[1]]
  min <- ExecuteLogged(
    conn$connection, sprintf('SELECT MIN("%s") FROM (%s)',
                             data$columns[[1]], data$select.statement))[[1]]

  if (any(data$dtypes()[[1]][[2]] %in% c("TIMESTAMP", "DATATIME"))) {
    start.time <- strftime(min, format = "%Y-%m-%d %H:%M:%S")
    end.time <- strftime(max, format = "%Y-%m-%d %H:%M:%S")
  }else{
    start.time <- min
    end.time <- max
  }
  width <- validateInput("width", width, "integer", required = TRUE)

  cols <- data$columns
  timestamp.name <- sprintf("%s",  cols[[1]])
  value.name <- sprintf("%s",  cols[[2]])


  to.ts.start.time <-  sprintf("TO_TIMESTAMP('%s','YYYY-MM-DD HH24:MI:SS')",
                               start.time)
  to.ts.end.time <-  sprintf("TO_TIMESTAMP('%s','YYYY-MM-DD HH24:MI:SS')",
                             end.time)


  add.key.sql.statement <- sprintf(
    'SELECT round(%s*SECONDS_BETWEEN("%s",%s)/(1e-10 + SECONDS_BETWEEN(%s,%s)))
    "k", "%s" , "%s"  FROM (%s)',
    width, timestamp.name, to.ts.start.time, to.ts.end.time, to.ts.start.time,
    timestamp.name, value.name, data$select.statement)

  min.max.groupby.sql.statement <- sprintf(
    'SELECT "k", MIN("%s") "v_min", MAX("%s") "v_max", MAX("%s") "t_min",
    MAX("%s") "t_max" FROM (%s) GROUP BY "k"',
    value.name, value.name, timestamp.name, timestamp.name,
    add.key.sql.statement)

  join.sql.statement <- sprintf(
    'SELECT "T"."%s", "T"."%s" FROM(%s) "T" INNER JOIN (%s) "Q" ON
    "T"."k" = "Q"."k" and ("T"."%s" = "Q"."v_min" or "T"."%s" = "Q"."v_max" or
    "T"."%s" = "Q"."t_min" or "T"."%s" = "Q"."t_max")',
    timestamp.name, value.name, add.key.sql.statement,
    min.max.groupby.sql.statement, value.name, value.name,
    timestamp.name, timestamp.name)

  Result <- hanaml.DataFrame(conn, join.sql.statement)
  return(Result)
}
