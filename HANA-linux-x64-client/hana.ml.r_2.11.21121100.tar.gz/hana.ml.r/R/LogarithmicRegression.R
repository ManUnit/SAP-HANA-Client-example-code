LogarithmicRegression <- R6Class(
  "LogarithmicRegression",
  inherit = RegressionBase,
  public = list(
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          decomposition = NULL,
                          adjusted.r2 = NULL,
                          pmml.export = NULL){
      super$initialize(data,
                       key,
                       features,
                       label,
                       formula,
                       NULL,
                       decomposition,
                       adjusted.r2,
                       pmml.export,
                       "PAL_LOGARITHMIC_REGRESSION")
   }))
#' @title  Bi-variate Natural Logarithmic Regression
#' @name hanaml.LogarithmicRegression
#' @description hanaml.LogarithmicRegression is a R wrapper
#' for SAP HANA PAL Bi-variate natural logarithmic regression algorithm.
#' @details Bi-variate natural logarithmic regression is an approach to modeling
#' the relationship between a scalar variable y and one variable denoted X.
#' In natural logarithmic regression, data is modeled using natural logarithmic
#' functions, and unknown model parameters are estimated from the data.
#' Such models are called natural logarithmic models.
#' @seealso \code{\link{predict.LogarithmicRegression}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-one
#' @template args-label
#' @template args-formula
#' @template args-decompostion
#' @template args-adjustedr2
#' @template args-pmmlexport
#' @return
#' Returns a "LogarithmicRegression" object with following values:
#' \itemize{
#' \item{coefficients: \code{DataFrame}}\cr
#'       Fitted regression coefficients.
#' \item{pmml: \code{DataFrame}}\cr
#'       Regression model content in PMML format.
#'       Set to NULL if no PMML model was requested.
#' \item{model : \code{DataFrame}}\cr
#'     Model is used to save coefficients or PMML model. If PMML model is requested,
#'     model defaults to PMML model. Otherwise, it is coefficients.
#' \item{fitted: \code{DataFrame}}\cr
#'       Predicted dependent variable values for training data.
#'       Set to NULL if the training data has no row IDs.
#' \item{statistics: \code{DataFrame}}\cr
#'       Regression-related statistics, like mean square error, F-statistics, etc.
#'}
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#'  > data$Collect()
#'    ID   Y X1
#'  1  0  10  1
#'  2  1  80  2
#'  3  2 130  3
#'  4  3 160  4
#'  5  4 180  5
#'  6  5 190  6
#'  7  6 192  7
#' }
#' Call the function:
#' \preformatted{
#' > nlr <-  hanaml.LogarithmicRegression(data = df,
#'                                         key = 'ID',
#'                                         label = 'Y',
#'                                         pmml.export='multi-row')
#' }
#' Output:
#' \preformatted{
#'  > nlr$coefficients$Collect()
#'
#'        VARIABLE_NAME COEFFICIENT_VALUE
#'  1 __PAL_INTERCEPT__           14.8616
#'  2                X1           98.2936
#' }
#' @keywords Regression
#' @export
hanaml.LogarithmicRegression <- function(data = NULL,
                                         key = NULL,
                                         features = NULL,
                                         label = NULL,
                                         formula = NULL,
                                         decomposition = NULL,
                                         adjusted.r2 = NULL,
                                         pmml.export = NULL){
  LogarithmicRegression$new(data,
                            key,
                            features,
                            label,
                            formula,
                            decomposition,
                            adjusted.r2,
                            pmml.export)
}

#' @title Make Predictions from a "LogarithmicRegression" Object
#' @name predict.LogarithmicRegression
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "LogarithmicRegression" object.
#' @seealso \code{\link{hanaml.LogarithmicRegression}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#' A "LogarithmicRegression" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict-1
#' @template args-threadratio
#' @template args-modelformat
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID: with same name and type as \emph{data}'s ID column.}
#'   \item{VALUE: type DOUBLE, representing predicted values.}
#' }
#'
#' @section Examples:
#' DataFrame data2 for prediction:
#'  \preformatted{
#' > data2$Collect()
#'     ID X1
#'   1  0  1
#'   2  1  2
#'   3  2  3
#'   4  3  4
#'   5  4  5
#'   6  5  6
#'   7  6  7
#' }
#' Perform prediction based on a "LogarithmicRegression" Object nlr:
#' \preformatted{
#' > predict(nlr, data2, key = 'ID')
#'     ID     VALUE
#'   1  0  14.86160
#'   2  1  82.99353
#'   3  2 122.84816
#'   4  3 151.12546
#'   5  4 173.05905
#'   6  5 190.98009
#'   7  6 206.13211
#' }
#' @export
#' @keywords Regression
predict.LogarithmicRegression <- function(model,
                                          data,
                                          key,
                                          features = NULL,
                                          thread.ratio = NULL,
                                          model.format = NULL){
  model$predict(data,
                key,
                features,
                thread.ratio,
                model.format,
                "PAL_LOGARITHMIC_REGRESSION_PREDICT")
}

#' @export
print.LogarithmicRegression <- function(x, ...){
  writeLines("\n")
  writeLines("LogarithmicRegression attributes:")
  writeLines("\n")
  cat(sprintf("decomposition : %s", to.null(x$decomposition)))
  writeLines("\n")
  cat(sprintf("adjusted.r2 : %s", to.null(x$adjusted.r2)))
  writeLines("\n")
  cat(sprintf("pmml.export : %s", to.null(x$poly.pmml.export)))
  writeLines("\n")
}

#' @export
summary.LogarithmicRegression <- function(object, ...){
    writeLines("LogarithmicRegression coefficients DataFrame:")
    print(object$coefficients$Collect())
    writeLines("\n")
    writeLines("LogarithmicRegression fitted DataFrame:")
    print(object$fitted$Collect())
    writeLines("\n")
    writeLines("LogarithmicRegression model DataFrame:")
    print(object$model$Collect())
    writeLines("\n")
    writeLines("LogarithmicRegression statistics DataFrame:")
    print(object$statistics$Collect())
    writeLines("\n")
    writeLines("LogarithmicRegression pmml DataFrame:")
    print(object$pmml$Collect())
    writeLines("\n")
}
