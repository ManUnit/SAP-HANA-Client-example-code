#' @title Tomek's links
#' @name hanaml.TomekLinks
#' @description hanaml.TomekLinks is an R wrapper
#' for SAP HANA PAL Tomek's links.\cr
#' @details
#' For a collection of sample points, a Tomek's link exists between two points if
#' they are nearest neighbor mutually.
#' The function performs under-sampling by removing Tomek’s links.
#' @seealso \code{\link{hanaml.SMOTETomek}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @param     label \code{character}\cr
#'            Specifies the dependent variable by name
#' @param     sampling.strategy \code{c("majority", "non-minority", "non-majority", "all"), optioanl}\cr
#'            Specifies the samping strategy to resample the input dataset.
#'             \itemize{
#'                 \item{\code{"majority"}  resamples only the majority class}
#'                 \item{\code{"non-minority"} resamples all classes but the minority class}
#'                 \item{\code{"non-majority"} resamples all classes but the majority class}
#'                 \item{\code{"all"} resamples all classes}
#'             }
#'             Defaults to "majority".
#' @template  args-cate-var
#' @param     category.weights  \code{double, optional}\cr
#'            Specifies the weight for categorical attributes.\cr
#'            Defaults to 0.707.
#' @param     distance.level \code{c("manhattan", "euclidean", "minkowski", "chebyshev", "cosine"), optional}\cr
#'            Specifies the distance method between sample points.\cr
#'            Defaults to "euclidean".
#' @param     minkowski.power \code{double, optional}\cr
#'            Specifies value of power in the definition of minkowski distance.\cr
#'            Valid only when \code{distance.level} is set to "minkowski".
#'            sample amount
#' @param     variable.weight  \code{named list/vector of double, optional}\cr
#'            Specifies the weight of a variable(feature) participating in distance calculation.\cr
#'            The weight value must be non-negative.\cr
#'            Weight values default to 1 for non-specified variables(features).
#' @param     algorithm \code{c("brute-force", "kd-tree"), optional}\cr
#'            Specifies the searching algorithms for finding the nearest neighbors.
#'            \itemize{
#'                \item{\code{"brute-force"} use brute-force method}
#'                \item{\code{"kd-tree"} use kd-tree searching}
#'
#'            }
#'            Defaults to "brute-force".
#' @template args-threadratio
#' @return
#' \itemize{
#'   \item{\code{DataFrame}}\cr
#'   Return dataset after sampling.
#'    The Output Table has the same structure as defined in the Input Table.\cr
#'  }
#'
#'@section Examples:
#'\preformatted{
#' > data$Collect()
#'    X1   X2   X3 TYPE
#' 1   2    1 3.50    1
#' 2   3   10 7.60    1
#' 3   3   10 5.50    2
#' 4   3   10 4.70    1
#' 5   7 1000 8.50    1
#' 6   8 1000 9.40    2
#' 7   6 1000 0.34    1
#' 8   8  999 7.40    2
#' 9   7  999 3.50    1
#' 10  6 1000 7.00    1
#'}
#' Call the function:
#' \preformatted{
#' > result <- hanaml.TomekLinks(data=data,
#'                               label = "TYPE",
#'                               algorithm = "kd-tree",
#'                               sampling.strategy = "all",
#'                               thread.ratio = 0.1)
#' }
#' Results:
#' \preformatted{
#' > result$Collect()
#'    X1   X2   X3 TYPE
#' 1   2    1 3.50    1
#' 2   3   10 7.60    1
#' 3   6 1000 0.34    1
#' 4   8  999 7.40    2
#' 5   7  999 3.50    1
#' 6   6 1000 7.00    1
#'}
#' @keywords Preprocessing
#' @export

hanaml.TomekLinks <- function(
  data,
  key = NULL,
  features = NULL,
  label = NULL,
  thread.ratio = NULL,
  sampling.strategy = NULL,
  categorical.variable = NULL,
  category.weights = NULL,
  distance.level = NULL,
  minkowski.power = NULL,
  variable.weight = NULL,
  algorithm = NULL
  ) {
  strategy.map <- list("majority" = 0, "non-minority" = 1,
                       "non-majority" = 2,
                       "all" = 3)
  distance.map <- list(manhattan = 1, euclidean = 2, minkowski = 3,
                       chebyshev = 4, cosine = 6)
  cols <-  data$columns
  key <- validateInput("key", key, cols, case.sensitive = TRUE)
  cols <- cols[!cols %in% key]
  label  <-  validateInput("label", label, cols,
                           required =  TRUE,
                           case.sensitive = TRUE)
  cols <- cols[! cols %in% label]
  features <- validateInput("features", features, cols,
                            case.sensitive = TRUE)
  if (is.null(features)) {
    features <- cols
  }
  algorithm.map  <-  list(
    "brute-force" = 0,
    "kd-tree" = 1
  )
  algorithm  <-  validateInput("algorithm", algorithm, algorithm.map)
  categorical.variable  <-  validateInput("categorical.variable",
                                          categorical.variable,
                                          features,
                                          case.sensitive = TRUE)
  category.weights  <-  validateInput("category.weights", category.weights,
                                      "numeric")
  distance.level  <-  validateInput("distance.level", distance.level,
                                    distance.map)
  mikowski.power <-  validateInput("minkowski.power", minkowski.power,
                                   "numeric")
  if (is.list(variable.weight)) {
    variable.weight <- unlist(variable.weight)
  }
  validateInput("Names of variable.weight", names(variable.weight), features,
                case.sensitive = TRUE)
  variable.weight <- validateInput("variable.weight", variable.weight,
                                   "numeric")
  sampling.strategy <- validateInput("sampling.strategy", sampling.strategy,
                                     strategy.map)
  thread.ratio  <-  validateInput("thread.ratio", thread.ratio, "double")
  if (isTRUE(thread.ratio < 0 || thread.ratio > 1)) {
    msg  <-  "The thread.ratio value range is from 0 to 1!"
    flog.error(msg)
    stop(msg)
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)
  data <- data$Select(c(key, features, label))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_TOMEKLINKS_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_TOMEKLINKS_RESULT_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables  <-  c(param.tbl, out.tables)
  param.array  <-  list(
    tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL),
    tuple("DEPENDENT_VARIABLE", NULL, NULL, label),
    tuple("METHOD", map.null(algorithm, algorithm.map), NULL, NULL),
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
    tuple("CATEGORY_WEIGHTS", NULL, category.weights, NULL),
    tuple("DISTANCE_LEVEL", map.null(distance.level, distance.map),
          NULL, NULL),
    tuple("MINKOWSKI_POWER", NULL, minkowski.power, NULL),
    tuple("SAMPLING_STRATEGY", map.null(sampling.strategy,
                                        strategy.map),
          NULL, NULL)
  )
  if (!is.null(categorical.variable)) {
    for (var in categorical.variable) {
      param.array <- c(param.array,
                       list(
                         tuple("CATEGORICAL_VARIABLE", NULL, NULL,
                               var)
                      ))
    }
  }
  if (length(variable.weight) > 0) {
    for (i in seq_len(length(variable.weight))) {
      param.array <- c(param.array,
                       list(
                         tuple("VARIABLE_WEIGHT", NULL,
                               variable.weight[[i]],
                               names(variable.weight[i]))
                       ))
    }
  }
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn, ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(
      conn, "PAL_TOMEKLINKS", in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(result.tbl))
}
