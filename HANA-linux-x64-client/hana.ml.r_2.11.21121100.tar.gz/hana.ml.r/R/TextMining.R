#' @title TF.Analysis
#' @description hanaml.TF.Analysis is a R wrapper for SAP HANA PAL TF Analysis algorithm.
#' @name hanaml.TF.Analysis
#' @template args-data
#' @return
#' \code{List of DataFrames}\cr
#' DataFrames of TF-IDF results:\cr
#' \itemize{
#'   \item{DataFrame 1:} TF-IDF result,
#'   \item{DataFrame 2:} Document term frequency table,
#'   \item{DataFrame 3:} Document category table
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$collect()
#'       ID                                                  CONTENT       CATEGORY
#' 1   doc1                      term1 term2 term2 term3 term3 term3     CATEGORY_1
#' 2   doc2                      term2 term3 term3 term4 term4 term4     CATEGORY_1
#' 3   doc3                      term3 term4 term4 term5 term5 term5     CATEGORY_2
#' 4   doc4    term3 term4 term4 term5 term5 term5 term5 term5 term5     CATEGORY_2
#' 5   doc5                                              term4 term6     CATEGORY_3
#' 6   doc6                                  term4 term6 term6 term6     CATEGORY_3
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.TF.Analysis(data)
#' }
#' Output:
#' \preformatted{
#' > result[[1]]$head(3)$Collect()
#'   TM_TERMS TM_TERM_TF_F  TM_TERM_IDF_F  TM_TERM_TF_V  TM_TERM_IDF_V
#' 1    term1            1              1      0.030303       1.791759
#' 2    term2            3              2      0.090909       1.098612
#' 3    term3            7              4      0.212121       0.405465
#' }
#' @keywords TextMining
#' @export
hanaml.TF.Analysis <- function(data) {
  CheckConnection(data)
  conn <- data$connection.context
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_TF_ANALYSIS_PARAMETER_TBL_%s", unique.id)
  output.tbl1 <- sprintf("#PAL_TF_ANALYSIS_OUTPUT_TBL_1_%s", unique.id)
  output.tbl2 <- sprintf("#PAL_TF_ANALYSIS_OUTPUT_TBL_2_%s", unique.id)
  output.tbl3 <- sprintf("#PAL_TF_ANALYSIS_OUTPUT_TBL_3_%s", unique.id)
  tables <- list(param.tbl, output.tbl1, output.tbl2, output.tbl3)
  in.tables <- list(data, param.tbl)
  out.tables <- list(output.tbl1, output.tbl2, output.tbl3)
  param.array <- list()
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
               (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_TF_ANALYSIS",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (list(conn$table(output.tbl1),
               conn$table(output.tbl2),
               conn$table(output.tbl3)))
}

#' @title Text.Classification
#' @description hanaml.Text.Classification is a R wrapper for SAP HANA PAL Text Classification algorithm.
#' @name hanaml.Text.Classification
#' @param     pred.data \code{DataFrame}\cr
#'            The prediction data for classification.
#' @param     ref.data \code{DataFrame, optional}\cr
#'            The reference data for classification.
#' @param     k.nearest.neighbours \code{integer, optional}\cr
#'            Number of nearest neighbors (k).
#' @param     thread.ratio \code{double, optional}\cr
#'            Specifies the ratio of total number of threads that can be used by this function.
#'            The range of this parameter is from 0 to 1, where 0 means only using 1 thread,
#'            and 1 means using at most all the currently available threads.
#'            Values outside this range are ignored and this function heuristically determines the number of threads to use.
#' @return
#' \code{List of DataFrames}\cr
#' DataFrames of text classification results:\cr
#' \itemize{
#'   \item{DataFrame 1:} Text classification result
#'   \item{DataFrame 2:} Statistics table
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$collect()
#'       ID                                                  CONTENT       CATEGORY
#' 1   doc1                      term1 term2 term2 term3 term3 term3     CATEGORY_1
#' 2   doc2                      term2 term3 term3 term4 term4 term4     CATEGORY_1
#' 3   doc3                      term3 term4 term4 term5 term5 term5     CATEGORY_2
#' 4   doc4    term3 term4 term4 term5 term5 term5 term5 term5 term5     CATEGORY_2
#' 5   doc5                                              term4 term6     CATEGORY_3
#' 6   doc6                                  term4 term6 term6 term6     CATEGORY_3
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Text.Classification(data$Select(data$columns[0], data$columns[1]), data)
#' }
#' Output:
#' \preformatted{
#' > result[[1]]$head(1)$Collect()
#'        ID              TARGET
#' 1    doc1          CATEGORY_1
#' }
#' @keywords TextMining
#' @export
hanaml.Text.Classification <- function(pred.data,
                                       ref.data = NULL,
                                       k.nearest.neighbours = NULL,
                                       thread.ratio = NULL) {
  CheckConnection(pred.data)
  conn <- pred.data$connection.context
  if (!is.list(ref.data)) {
    tfidf = hanaml.TF.Analysis(ref.data)
  } else {
    tfidf = ref.data
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_TEXT_CLASSIFICATION_PARAMETER_TBL_%s", unique.id)
  output.tbl1 <- sprintf("#PAL_TEXT_CLASSIFICATION_OUTPUT_TBL_1_%s", unique.id)
  output.tbl2 <- sprintf("#PAL_TEXT_CLASSIFICATION_OUTPUT_TBL_2_%s", unique.id)
  tables <- list(param.tbl, output.tbl1, output.tbl2)
  in.tables <- c(tfidf, list(pred.data, param.tbl))
  out.tables <- list(output.tbl1, output.tbl2)
  param.array <- list(tuple("K_NEAREST_NEIGHBOURS", k.nearest.neighbours, NULL, NULL),
                      tuple("THREAD_RATIO", NULL, thread.ratio, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_TEXTCLASSIFICATION",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (list(conn$table(output.tbl1),
               conn$table(output.tbl2)))
}

#' @title Get.Related.Doc
#' @description hanaml.Get.Related.Doc is a R wrapper for SAP HANA PAL get related doc algorithm.
#' @name hanaml.Get.Related.Doc
#' @param     pred.data \code{DataFrame}\cr
#'            The prediction data for classification.
#' @param     ref.data \code{DataFrame, optional}\cr
#'            The reference data for classification.
#' @param     top \code{integer, optional}\cr
#'            Only show top N results. If 0, it shows all.
#' @param     threshold \code{double, optional}\cr
#'            Only the results which score bigger than this value will be put into the result table.
#' @return
#' \code{DataFrame}\cr
#' DataFrame of get related doc result.\cr
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > ref_df$Collect()
#'       ID                                                  CONTENT       CATEGORY
#' 1   doc1                      term1 term2 term2 term3 term3 term3     CATEGORY_1
#' 2   doc2                      term2 term3 term3 term4 term4 term4     CATEGORY_1
#' 3   doc3                      term3 term4 term4 term5 term5 term5     CATEGORY_2
#' 4   doc4    term3 term4 term4 term5 term5 term5 term5 term5 term5     CATEGORY_2
#' 5   doc5                                              term4 term6     CATEGORY_3
#' 6   doc6                                  term4 term6 term6 term6     CATEGORY_3
#' > pred_df$Collect()
#'                     CONTENT
#' 1  term2 term2 term3 term3
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Get.Related.Doc(pred_df, ref_df)
#' }
#' Output:
#' \preformatted{
#' > result$Collect()
#'        ID       SCORE
#' 1    doc2    0.891550
#' 2    doc1    0.804670
#' 3    doc3    0.042024
#' 4    doc4    0.021225
#' }
#' @keywords TextMining
#' @export
hanaml.Get.Related.Doc <- function(pred.data,
                                   ref.data = NULL,
                                   top = NULL,
                                   threshold = NULL) {
  CheckConnection(pred.data)
  conn <- pred.data$connection.context
  if (!is.list(ref.data)) {
    tfidf = hanaml.TF.Analysis(ref.data)
  } else {
    tfidf = ref.data
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_GET_RELATED_DOC_PARAMETER_TBL_%s", unique.id)
  output.tbl <- sprintf("#PAL_GET_RELATED_DOC_OUTPUT_TBL_%s", unique.id)
  tables <- list(param.tbl, output.tbl)
  in.tables <- c(tfidf, list(pred.data, param.tbl))
  out.tables <- list(output.tbl)
  param.array <- list(tuple("TOP", top, NULL, NULL),
                      tuple("THRESHOLD", NULL, threshold, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_TMGETRELATEDDOC",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(output.tbl))
}

#' @title Get.Related.Term
#' @description hanaml.Get.Related.Term is a R wrapper for SAP HANA PAL get related term algorithm.
#' @name hanaml.Get.Related.Term
#' @param     pred.data \code{DataFrame}\cr
#'            The prediction data for classification.
#' @param     ref.data \code{DataFrame, optional}\cr
#'            The reference data for classification.
#' @param     top \code{integer, optional}\cr
#'            Only show top N results. If 0, it shows all.
#' @param     threshold \code{double, optional}\cr
#'            Only the results which score bigger than this value will be put into the result table.
#' @return
#' \code{DataFrame}\cr
#' DataFrame of get related doc result.\cr
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > ref_df$Collect()
#'       ID                                                  CONTENT       CATEGORY
#' 1   doc1                      term1 term2 term2 term3 term3 term3     CATEGORY_1
#' 2   doc2                      term2 term3 term3 term4 term4 term4     CATEGORY_1
#' 3   doc3                      term3 term4 term4 term5 term5 term5     CATEGORY_2
#' 4   doc4    term3 term4 term4 term5 term5 term5 term5 term5 term5     CATEGORY_2
#' 5   doc5                                              term4 term6     CATEGORY_3
#' 6   doc6                                  term4 term6 term6 term6     CATEGORY_3
#' > pred_df$Collect()
#'      CONTENT
#' 1     term3
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Get.Related.Term(pred_df, ref_df)
#' }
#' Output:
#' \preformatted{
#' > result$Collect()
#'         ID       SCORE
#' 1    term2    0.923760
#' 2    term1    0.774597
#' 3    term4    0.550179
#' 4    term5    0.346410
#' }
#' @keywords TextMining
#' @export
hanaml.Get.Related.Term <- function(pred.data,
                                    ref.data = NULL,
                                    top = NULL,
                                    threshold = NULL) {
  CheckConnection(pred.data)
  conn <- pred.data$connection.context
  if (!is.list(ref.data)) {
    tfidf = hanaml.TF.Analysis(ref.data)
  } else {
    tfidf = ref.data
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_GET_RELATED_TERM_PARAMETER_TBL_%s", unique.id)
  output.tbl <- sprintf("#PAL_GET_RELATED_TERM_OUTPUT_TBL_%s", unique.id)
  tables <- list(param.tbl, output.tbl)
  in.tables <- c(tfidf, list(pred.data, param.tbl))
  out.tables <- list(output.tbl)
  param.array <- list(tuple("TOP", top, NULL, NULL),
                      tuple("THRESHOLD", NULL, threshold, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_TMGETRELATEDTERM",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(output.tbl))
}

#' @title Get.Relevant.Doc
#' @description hanaml.Get.Relevant.Doc is a R wrapper for SAP HANA PAL get relevant doc algorithm.
#' @name hanaml.Get.Relevant.Doc
#' @param     pred.data \code{DataFrame}\cr
#'            The prediction data for classification.
#' @param     ref.data \code{DataFrame, optional}\cr
#'            The reference data for classification.
#' @param     top \code{integer, optional}\cr
#'            Only show top N results. If 0, it shows all.
#' @param     threshold \code{double, optional}\cr
#'            Only the results which score bigger than this value will be put into the result table.
#' @return
#' \code{DataFrame}\cr
#' DataFrame of get related doc result.\cr
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > ref_df$collect()
#'       ID                                                  CONTENT       CATEGORY
#' 1   doc1                      term1 term2 term2 term3 term3 term3     CATEGORY_1
#' 2   doc2                      term2 term3 term3 term4 term4 term4     CATEGORY_1
#' 3   doc3                      term3 term4 term4 term5 term5 term5     CATEGORY_2
#' 4   doc4    term3 term4 term4 term5 term5 term5 term5 term5 term5     CATEGORY_2
#' 5   doc5                                              term4 term6     CATEGORY_3
#' 6   doc6                                  term4 term6 term6 term6     CATEGORY_3
#' > pred_df$collect()
#'     CONTENT
#' 1     term3
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Get.Relevant.Doc(pred_df, ref_df)
#' }
#' Output:
#' \preformatted{
#' > result$Collect()
#'        ID       SCORE
#' 1    doc1    0.774597
#' 2    doc2    0.516398
#' 3    doc3    0.258199
#' 4    doc4    0.258199
#' }
#' @keywords TextMining
#' @export
hanaml.Get.Relevant.Doc <- function(pred.data,
                                    ref.data = NULL,
                                    top = NULL,
                                    threshold = NULL) {
  CheckConnection(pred.data)
  conn <- pred.data$connection.context
  if (!is.list(ref.data)) {
    tfidf = hanaml.TF.Analysis(ref.data)
  } else {
    tfidf = ref.data
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_GET_RELEVANT_DOC_PARAMETER_TBL_%s", unique.id)
  output.tbl <- sprintf("#PAL_GET_RELEVANT_DOC_OUTPUT_TBL_%s", unique.id)
  tables <- list(param.tbl, output.tbl)
  in.tables <- c(tfidf, list(pred.data, param.tbl))
  out.tables <- list(output.tbl)
  param.array <- list(tuple("TOP", top, NULL, NULL),
                      tuple("THRESHOLD", NULL, threshold, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_TMGETRELEVANTDOC",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(output.tbl))
}

#' @title Get.Relevant.Term
#' @description hanaml.Get.Relevant.Term is a R wrapper for SAP HANA PAL get relevant term algorithm.
#' @name hanaml.Get.Relevant.Term
#' @param     pred.data \code{DataFrame}\cr
#'            The prediction data for classification.
#' @param     ref.data \code{DataFrame, optional}\cr
#'            The reference data for classification.
#' @param     top \code{integer, optional}\cr
#'            Only show top N results. If 0, it shows all.
#' @param     threshold \code{double, optional}\cr
#'            Only the results which score bigger than this value will be put into the result table.
#' @return
#' \code{DataFrame}\cr
#' DataFrame of get related doc result.\cr
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > ref_df$collect()
#'       ID                                                  CONTENT       CATEGORY
#' 1   doc1                      term1 term2 term2 term3 term3 term3     CATEGORY_1
#' 2   doc2                      term2 term3 term3 term4 term4 term4     CATEGORY_1
#' 3   doc3                      term3 term4 term4 term5 term5 term5     CATEGORY_2
#' 4   doc4    term3 term4 term4 term5 term5 term5 term5 term5 term5     CATEGORY_2
#' 5   doc5                                              term4 term6     CATEGORY_3
#' 6   doc6                                  term4 term6 term6 term6     CATEGORY_3
#' > pred_df$collect()
#'     CONTENT
#' 1     term3
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Get.Relevant.Term(pred_df, ref_df)
#' }
#' Output:
#' \preformatted{
#' > result$Collect()
#'        ID       SCORE
#' 1    term3        1.0
#' }
#' @keywords TextMining
#' @export
hanaml.Get.Relevant.Term <- function(pred.data,
                                     ref.data = NULL,
                                     top = NULL,
                                     threshold = NULL) {
  CheckConnection(pred.data)
  conn <- pred.data$connection.context
  if (!is.list(ref.data)) {
    tfidf = hanaml.TF.Analysis(ref.data)
  } else {
    tfidf = ref.data
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_GET_RELEVANT_TERM_PARAMETER_TBL_%s", unique.id)
  output.tbl <- sprintf("#PAL_GET_RELEVANT_TERM_OUTPUT_TBL_%s", unique.id)
  tables <- list(param.tbl, output.tbl)
  in.tables <- c(tfidf, list(pred.data, param.tbl))
  out.tables <- list(output.tbl)
  param.array <- list(tuple("TOP", top, NULL, NULL),
                      tuple("THRESHOLD", NULL, threshold, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_TMGETRELEVANTTERM",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(output.tbl))
}

#' @title Get.Suggested.Term
#' @description hanaml.Get.Relevant.Term is a R wrapper for SAP HANA PAL get suggested term algorithm.
#' @name hanaml.Get.Suggested.Term
#' @param     pred.data \code{DataFrame}\cr
#'            The prediction data for classification.
#' @param     ref.data \code{DataFrame, optional}\cr
#'            The reference data for classification.
#' @param     top \code{integer, optional}\cr
#'            Only show top N results. If 0, it shows all.
#' @param     threshold \code{double, optional}\cr
#'            Only the results which score bigger than this value will be put into the result table.
#' @return
#' \code{DataFrame}\cr
#' DataFrame of get related doc result.\cr
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > ref_df$collect()
#'       ID                                                  CONTENT       CATEGORY
#' 1   doc1                      term1 term2 term2 term3 term3 term3     CATEGORY_1
#' 2   doc2                      term2 term3 term3 term4 term4 term4     CATEGORY_1
#' 3   doc3                      term3 term4 term4 term5 term5 term5     CATEGORY_2
#' 4   doc4    term3 term4 term4 term5 term5 term5 term5 term5 term5     CATEGORY_2
#' 5   doc5                                              term4 term6     CATEGORY_3
#' 6   doc6                                  term4 term6 term6 term6     CATEGORY_3
#' > pred_df$collect()
#'     CONTENT
#' 1     term3
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Get.Suggested.Term(pred_df, ref_df)
#' }
#' Output:
#' \preformatted{
#' > result$Collect()
#'         ID     SCORE
#' 1    term5  0.830048
#' 2    term6  0.368910
#' 3    term2  0.276683
#' 4    term3  0.238269
#' 5    term1  0.150417
#' 6    term4  0.137752
#' }
#' @keywords TextMining
#' @export
hanaml.Get.Suggested.Term <- function(pred.data,
                                      ref.data = NULL,
                                      top = NULL,
                                      threshold = NULL) {
  CheckConnection(pred.data)
  conn <- pred.data$connection.context
  if (!is.list(ref.data)) {
    tfidf = hanaml.TF.Analysis(ref.data)
  } else {
    tfidf = ref.data
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_GET_SUGGESTED_TERM_PARAMETER_TBL_%s", unique.id)
  output.tbl <- sprintf("#PAL_GET_SUGGESTED_TERM_OUTPUT_TBL_%s", unique.id)
  tables <- list(param.tbl, output.tbl)
  in.tables <- c(tfidf, list(pred.data, param.tbl))
  out.tables <- list(output.tbl)
  param.array <- list(tuple("TOP", top, NULL, NULL),
                      tuple("THRESHOLD", NULL, threshold, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_TMGETSUGGESTEDTERM",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(output.tbl))
}

#' @title Text.Collector
#' @description hanaml.Text.Collector is a R wrapper for SAP HANA PAL text collector algorithm.
#' @name hanaml.Text.Collector
#' @param     data \code{DataFrame}\cr
#'            Data to be analysis.
#' @return
#' \code{DataFrame}\cr
#' \itemize{
#'   \item{DataFrame 1:} Inverse document frequency of documents.
#'   \item{DataFrame 2:} Extended table.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$collect()
#'        ID                                CONTENT
#' 1    doc1    term1 term2 term2 term3 term3 term3
#' 2    doc2    term2 term3 term3 term4 term4 term4
#' 3    doc3    term3 term4 term4 term5 term5 term5
#' 4    doc5    term3 term4 term4 term5 term5 term5 term5 term5 term5
#' 5    doc4    term4 term6
#' 6    doc6    term4 term6 term6 term6
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Text.Collector(data)
#' }
#' Output:
#' \preformatted{
#' > result[[1]]$Collect()
#'      TM_TERMS    TM_TERM_IDF_VALUE
#' 1       term1             1.791759
#' 2       term2             1.098612
#' 3       term3             0.405465
#' 4       term4             0.182322
#' 5       term5             1.098612
#' 6       term6             1.098612
#' }
#' @keywords TextMining
#' @export
hanaml.Text.Collector <- function(data) {
  CheckConnection(data)
  conn <- data$connection.context
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_TEXT_COLLECTOR_PARAMETER_TBL_%s", unique.id)
  output.tbl1 <- sprintf("#PAL_TEXT_COLLECTOR_OUTPUT_TBL1_%s", unique.id)
  output.tbl2 <- sprintf("#PAL_TEXT_COLLECTOR_OUTPUT_TBL2_%s", unique.id)
  tables <- list(param.tbl, output.tbl1, output.tbl2)
  in.tables <- list(data, param.tbl)
  out.tables <- list(output.tbl1, output.tbl2)
  param.array <- list()
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_TEXT_COLLECT",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (list(conn$table(output.tbl1),
               conn$table(output.tbl2)))
}

#' @title Text.TFIDF
#' @description hanaml.Text.TFIDF is a R wrapper for SAP HANA PAL text tfidf algorithm.
#' @name hanaml.Text.TFIDF
#' @param     data \code{DataFrame}\cr
#'            Data to be analysis.
#' @param     idf \code{DataFrame, optional}\cr
#'            Inverse document frequency of documents.
#' @return
#' \code{DataFrame}\cr
#' Inverse document frequency of documents.
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$collect()
#'        ID                                CONTENT
#' 1    doc1    term1 term2 term2 term3 term3 term3
#' 2    doc2    term2 term3 term3 term4 term4 term4
#' 3    doc3    term3 term4 term4 term5 term5 term5
#' 4    doc5    term3 term4 term4 term5 term5 term5 term5 term5 term5
#' 5    doc4    term4 term6
#' 6    doc6    term4 term6 term6 term6
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.Text.Collector(data)
#' > tfidf <- hanaml.Text.TFIDF(data, result[[1]])
#' }
#' Output:
#' \preformatted{
#' > tfidf$Head(3)$Collect()
#'      ID  TERMS   TF_VALUE    TFIDF_VALUE
#' 1  doc1  term1        1.0       1.791759
#' 2  doc1  term2        2.0       2.197225
#' 3  doc1  term3        3.0       1.216395
#' }
#' @keywords TextMining
#' @export
hanaml.Text.TFIDF <- function(data, idf = NULL) {
  CheckConnection(data)
  conn <- data$connection.context
  if (is.null(idf)) {
    result = hanaml.Text.Collector(data)
    idf = result[[1]]
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_TEXT_TFIDF_PARAMETER_TBL_%s", unique.id)
  output.tbl <- sprintf("#PAL_TEXT_TFIDF_OUTPUT_TBL_%s", unique.id)
  tables <- list(param.tbl, output.tbl)
  in.tables <- list(data, idf, param.tbl)
  out.tables <- list(output.tbl)
  param.array <- list()
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_TEXT_TFIDF",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(output.tbl))
}
