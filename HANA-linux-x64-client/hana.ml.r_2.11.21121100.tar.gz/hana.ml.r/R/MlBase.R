#MLbase is the base class and it has a number of helper functions.
#' @import R6 futile.logger sets uuid
#' @importFrom utils tail head

MlBase <- R6Class(
  "MlBase",
  public = list (
    connection.context = NULL,
    id = NULL,
    model = NULL,
    initialize = function(connection.context = NULL) {
      self$connection.context <- connection.context
      self$id <- self$getMlBaseCounter()
      self$model <- NULL
      private$shared_env$mlbase.count <- self$getMlBaseCounter() + 1
    },
    getMlBaseCounter = function() {
      #don't delete, need to keep count for ID
      mlbase.count <- private$shared_env$mlbase
      if (is.null(mlbase.count))
        mlbase.count <-  0
      return(mlbase.count)
    }
  ),
  private = list(shared_env = new.env())
)

####
## Global functions and variables called by MLBase class
####
#' @title sqlQueryMix
#' @name sqlQueryMix
#' @description
#' Execute a SQL statment with a SAP HANA connection.
#' @param channel \code{ConnectionContext}\cr
#' A connection to SAP HANA.
#' @param query \code{character}\cr
#' SQL statement to be executed.
#' @param ... Reserved parameter.
#' @return Output of SQL query.
#' @export

sqlQueryMix <- function(channel, query, ...) {
  if (is.null(channel)) {
    stop("No connection provided.")
  }
  output <- "No Data"
  tryCatch({
    if (grepl("JDBC", toString(class(channel)), fixed = TRUE)) {
      first.word.in.query <- toupper(strsplit(query,
                                              " ")[[1]][1])
      second.term.in.query <- toupper(strsplit(query,
                                               " ")[[1]][2])
      if (grepl("SELECT", first.word.in.query, fixed = TRUE) ||
          (grepl("CALL", first.word.in.query, fixed = TRUE) &&
           !grepl("REMOTE_EXECUTE", second.term.in.query, fixed = TRUE))) {
        output <- RJDBC::dbGetQuery(channel, query, ...)
      } else {
        RJDBC::dbSendUpdate(channel, query, ...)
      }
    } else if (grepl("HDB", toString(class(channel)), fixed = TRUE)) {
      first.word.in.query <- toupper(strsplit(query,
                                              " ")[[1]][1])
      if (grepl("SELECT", first.word.in.query, fixed = TRUE) ||
          (grepl("CALL", first.word.in.query, fixed = TRUE) &&
           !grepl("REMOTE_EXECUTE", second.term.in.query, fixed = TRUE))) {
        output <- odbc::dbGetQuery(channel, query, ...)
      } else {
        rs <- odbc::dbSendStatement(channel, query, ...)
        now <- Sys.time()
        while (!odbc::dbHasCompleted(rs)) {
          if (diff.difftime(Sys.time() - now) > 60 * 60 * 24) {
            break
          }
        }
        odbc::dbClearResult(rs)
      }
    } else {
      output <- RODBC::sqlQuery(channel, query, ...)
    }
  },
  error = function(err) {
    flog.error(sprintf("%s: %s", query, err))
    if (grepl("_SYS_AFL.AFLPAL", err$message)){
      stop(err$message)
    }
  })
  return(output)
}

#' @title ExecuteLogged
#' @name ExecuteLogged
#' @description
#' Executes a sql statement and enter the information into the logs.
#' @param cur \code{ConnectionContext$connection}\cr
#' Database Cursor to execute the statement.
#' @param stmt \code{character}\cr
#' SQL statement to be executed.
#' @param ... Reserved parameter.
#' @return
#' Output of SQL statment execution.
#' @export
ExecuteLogged <- function(cur, stmt, ...) {
  if (!is.character(stmt)) {
    stop("Statement provided for execution should be a string")
  }
  output <- sqlQueryMix(cur, stmt, ...)
  flog.appender(appender.tee("hanaml_r.log"))
  flog.threshold(INFO) ## comment out for debugging
  if (hanaml.sqltrace()) {
    flog.threshold(TRACE)
    flog.trace(msg = stmt, name = "mylog")
  }
  return(output)
}

INTEGER <- "INTEGER"
DOUBLE <- "DOUBLE"

nvarchar <- function(size = 50) {
  new.varchar <- sprintf("NVARCHAR(%s)", size)
  return(new.varchar)
}
NVARCHAR <- nvarchar()
NCLOB <- "NCLOB"

CheckConnection <- function(data){
    if (is.null(data$connection.context))
        stop("No connection.context in dataframe.")
    if (!(inherits(data$connection.context, "R6")))
        stop("Wrong dataframe's connection.context type.")
}


CreateTable <- function(name, spec) {
  header <- sprintf("CREATE LOCAL TEMPORARY COLUMN TABLE %s (", QuoteName(name))
  h <- NULL
  if (!is.list(spec)) {
    stop("Spec should be given as a list")
  }
  for (val in spec) {
    new.string <- NULL
    new.string <- sprintf("%s %s", QuoteName(val[[1]]), val[[2]])
    h <- append(h, new.string)
  }
  h.new <- paste(unlist(h), collapse = " , ")
  footer <- ")"
  full.create <- sprintf("%s %s %s", header, h.new, footer)
  return(full.create)
}

DataListPerRow <- function(data) {
  result <- " "
  flag <- TRUE
  for (x in data) {
    if (is.character(x)) {
      if (flag) {
        result <- paste(result, sprintf("\'%s\'", x))
        flag <- FALSE
      } else{
        result <- paste(result, sprintf(", \'%s\' ", x))
      }
    }
    else if (is.null(x)) {
      if (flag) {
        result <- paste(result, "NULL ")
        flag <- FALSE
      } else{
        result <- paste(result, ",NULL ")
      }
    }
    else if (is.integer(x) || is.numeric(x)) {
      if (flag) {
        result <- paste(result, sprintf("%s", x))
        flag <- FALSE
      } else{
        result <- paste(result, sprintf(",%s", x))
      }
    }
  }
  result
}

dbplyr2hana <- function(connection.context, table) {
  if (grepl("tbl", toString(class(table)), fixed = TRUE)) {
    return (hanaml.DataFrame(connection.context, toString(dbplyr::sql_render(table))))
  }
  return (table)
}

hana2dbplyr <- function(dataframe) {
  if (grepl("DataFrame", toString(class(dataframe)), fixed = TRUE)) {
    return (dataframe$connection.context$tbl(dbplyr::sql(dataframe$select.statement)))
  }
  return (dataframe)
}

InsertMany <- function(table.name, data) {
  temp.list <- list()
  for (vals in data) {
    insert.stmt <- sprintf("INSERT INTO %s VALUES(%s)",
                           table.name,
                           DataListPerRow(vals))
    temp.list <- append(temp.list, insert.stmt)
  }
  return (temp.list)
}

DropTable <- function(table.name) {
  dropCmd <- sprintf("DROP TABLE %s", QuoteName(table.name))
  return(dropCmd)
}

# \describe{
#     \item{\code{Class ParameterTable}}{
#      Represents a SAP HANA PAL parameter table to be created on HANA.
#      \emph{Arguments:}
#         \itemize{
#         \item{\code{name}:  Parameter Table name}
#         \item{\code{data}:   list of tuples which is the initial data to populate the table with}
#         }
#         \emph{Returns:}
#         \code{table}\cr
#          New ParameterTable with data
ParameterTable <- R6Class(
  "ParameterTable",
  inherit = Table,
  public = list(
    initialize = function(name) {
      parameterTableSpec <- list(
        tuple("PARAM_NAME", "NVARCHAR(5000)"),
        tuple("INT_VALUE", INTEGER),
        tuple("DOUBLE_VALUE", DOUBLE),
        tuple("STRING_VALUE", "NVARCHAR(5000)")
      )
      super$initialize(name, parameterTableSpec)
    },
    WithData = function(data) {
      i <- 1
      row <- 1
      for (vals in data) {
        i <- 1
        null.flag <- is.null(unlist(vals[2:4]))
        if (null.flag) {
          data[row] <- NULL
          row <- row - 1
        }
        i <- i + 1
        row <- row + 1
      }
      return (super$WithData(data))
    }
  )
)

#' @title Table
#' @description
#' Represents a Table object to be created on SAP HANA.
#' @return
#' A new Table object.
#' @export
Table <- R6Class(
  "Table",
  public = list(
    #' @field name \code{character}\cr  Table name.
    name = NULL,
    #' @field spec \code{list of tuples}\cr Table specification.
    spec = NULL,
    #' @field data \code{list of tuples}\cr Data stored in the table.
    data = NULL,
    #' @description
    #' Create a Table object.
    #' @param name \code{character}\cr Name of the new Table object.
    #' @param spec \code{list of tuples, optional}\cr The specification of the Table.
    initialize = function(name, spec = NULL) {
      self$name <- name
      self$spec <- spec
    },
    #' @description
    #' Create a Table object with data.
    #' @param initialData  \code{list of tuples}\cr The data to be inserted into the table (by row).
    #' @return A new Table object with Data.
    WithData = function(initialData) {
      if ("data.table" %in% rownames(installed.packages()) == FALSE) {
        install.packages("data.table")
        library(data.table)
      } else {
        library(data.table)
      }
      newobj <- copy(self)
      newobj$data <- initialData
      return (newobj)
    },
    #' @description
    #' Create a table with the same specification of another DataFrame.
    #' @param table.name \code{character}\cr Name of the table to be created.
    #' @param df \code{DataFrame}\cr DataFrame for table specification extraction.
    #' @return \code{A Table object}\cr A new Table object with the specification of a given DataFrame.
    like = function(table.name, df) {
      return (Table$new(table.name, ColspecFromDf(df)))
    }
  )
)

####
##Global functions and variables called by Table class
####

ONE.PARAM.TYPES <-
  c("VARBINARY", "VARCHAR", "NVARCHAR", "ALPHANUM", "SHORTTEXT")

ColspecFromDf <- function(df) {
  return.list <- list()
  for (dt in df$dtypes()) {
    return.list <- append(return.list, list(ParseOneDtype(dt)))
  }
  return.tuple <- sets::as.tuple(x = return.list)
  return (return.tuple)
}

ParseOneDtype <- function(dtype) {
  name <- dtype[[1]]
  sqltype <- dtype[[2]]
  size <- dtype[[3]]
  if (sqltype == "DECIMAL") {
    flog.error("DECIMAL columns are currently not supported")
    stop("Decimal columns are not supported currently")
  }
  if (sqltype %in% ONE.PARAM.TYPES) {
    return.type <- sprintf("%s,%s(%s)", name, sqltype, size)
    return.list <- list()
    tuple.list <- unlist(strsplit(return.type, split = ","))
    for (each.val in tuple.list) {
      return.list <- append(return.list, each.val)
    }
    return(return.list)
  }
  return(list(name, sqltype))
}

ParseFormula <- function(df = NULL, x) {
  if (length(x) == 2) {
    # one sided formula
    lhs.formula <- NULL
    rhs.formula <- format(x[[2]])
  } else if (length(x) == 3) {
    # two sided formula
    lhs.formula <- x[[2]]
    if (length(x[[3]]) == 1) {
      if (identical(x[[3]], as.name(".")))
        rhs.formula <- setdiff(df$columns, as.list(lhs.formula))
      else
        rhs.formula <- as.character(x[[3]])
      result <- sets::tuple(as.character(lhs.formula), rhs.formula)
      return (result)
    }
    rhs.formula <- format(x[[3]])
  }
  if (grepl("+", rhs.formula, fixed = TRUE)) {
    operation <- "+"
  } else if (grepl("-", rhs.formula, fixed = TRUE)) {
    operation <- "-"
  }
  string.formula <-
    unlist(strsplit(rhs.formula, operation, fixed = TRUE))
  label <- lhs.formula
  features <- as.list(trimws(string.formula))
  features <- features[features != ""]
  if (identical(operation, "-")) {
    features <- append(features, label)
    features <- setdiff(df$columns, features)
  }
  result <- sets::tuple(as.character(label), features)
  return (result)
}

validateInput <- function(name, value, constraint, required=FALSE, case.sensitive=FALSE){
  valid <- FALSE
  if (is.null(value)){
    if (!isTRUE(required)){
    return (NULL)
    } else {
      msg <- paste(name, "is mandatory,",
                   "Please provide a concrete value.")
      flog.error(msg)
      stop(msg)
    }
  }
  if (!inherits(constraint, "list")){
    if (inherits(value, constraint))
      valid <- TRUE
    else if (constraint == "double" && (inherits(value, "numeric")
                                      || identical(typeof(value), "double")))
      valid <- TRUE
    else if (constraint == "integer" &&
             (inherits(value, "numeric") && all(round(value) == value)))
      valid <- TRUE
    else if (constraint == "logical" && inherits(value, "logical"))
      valid <- TRUE
    else if (constraint == "character" && inherits(value, "character"))
      valid <- TRUE
    else if (toupper(constraint) == "LISTOFSTRINGS"){
      tryCatch(
        if (!all(sapply(value, is.character))){
          msg <- paste(name, "must be list of strings.")
          flog.error(msg)
          stop()
        },
        error = function(err){
          msg <- "value does not match constraint type"
          flog.error(msg)
          stop(msg)
        }
      )
      valid <- TRUE
    } else if (toupper(constraint) == "TUPLE" && identical(class(value), "tuple")){
      valid <- TRUE
    }
  } else {
    if (length(value) > 1) {
      value <- as.list(value)
    }
    if (case.sensitive == FALSE){
      if (length(value) > 1) {
        value <- sapply(value, tolower)
      } else {
        value <- tolower(value)
      }
    }
    if (!is.null(names(constraint))){
      if (!all(value %in% names(constraint))){
        msg <- paste(name, "should be selected from:",
                     paste(names(constraint), collapse = ", "))
        flog.error(msg)
        stop(msg)
      } else {
        valid <- TRUE
      }
    } else {
      if (!all(value %in% constraint)){
        msg <- paste(name, "should be selected from:",
                     paste(constraint, collapse = ", "))
        flog.error(msg)
        stop(msg)
      } else {
        valid <- TRUE
      }
    }
  }
  if (valid){
    return(value)
  } else {
    msg <- "value does not match constraint type"
    flog.error(msg)
    stop(msg)
  }
}

map.null <- function(value, map){
  if (is.null(value)){
    return(NULL)
  }
  else {
    return(map[[value]])
  }
}

to.integer <- function(value) {
  if (is.null(value)){
    return(NULL)
  } else {
    if (typeof(value) != "logical"){
      stop("to.integer function only supports logical inputs.")
    }
    return(as.integer(value))
  }
}

# for print function
to.null <- function(value) {
  if (is.null(value)) {
    return("NULL")
  } else {
    return(value)
  }

}
errorhelper <- function(msg) {
  if (length(grep("Base table or view not found", msg)) > 0){
    stop(msg)
  } else if (length(grep("ERROR",
                         msg, ignore.case = TRUE)) > 0){
    stop(msg)
  }
}

r2.score <- function(conn.context,
                     data,
                     label.true,
                     label.pred) {
  label.true <- validateInput("label.true", label.true, "character")
  label.pred <- validateInput("label.pred", label.pred, "character")
  data <- (data$Select(list(label.true, label.pred)))$rename.columns(list("ACTUAL", "PREDICTED"))
  select.mean <-
    sprintf("SELECT AVG(TO_DOUBLE(ACTUAL)) AS AV FROM (%s)", data$select.statement)
  rss <- "SUM(POWER(TO_DOUBLE(ACTUAL) - TO_DOUBLE(PREDICTED), 2))"
  tss <- "SUM(POWER(TO_DOUBLE(ACTUAL) - TO_DOUBLE(AV), 2))"
  r2.select <- sprintf(
    "SELECT 1- %s/%s FROM (%s) as data,
    (%s) as avg_tbl",
    rss,
    tss,
    data$select.statement,
    select.mean
  )
  result <-
    ExecuteLogged(conn.context$connection, r2.select)
  if (length(grep("Base table or view not found", result)) >= 1)
    stop("HANA error during r2 score")
  return (result[[1]])
}

accuracy.score <- function(conn.context,
                           data,
                           label.true,
                           label.pred) {
  label.true <- validateInput("label.true", label.true, "character")
  label.pred <- validateInput("label.pred", label.pred, "character")
  data <- (data$Select(list(label.true, label.pred)))$rename.columns(list("ACTUAL", "PREDICTED"))
  accuracy.select <- sprintf("SELECT TO_DOUBLE(COUNT(CASE WHEN ACTUAL = PREDICTED THEN 1 END))/TO_DOUBLE(COUNT(*)) FROM (%s)", data$select.statement) #nolint
  result <-
    ExecuteLogged(conn.context$connection, accuracy.select)
  if (length(grep("Base table or view not found", result)) >= 1)
    stop("HANA error during accuracy score")
  return (result[[1]])
}

MaterializeWithConnection <- function(conn, table.name, df, force = TRUE) {
  if (!is.character(table.name)) {
    stop("Table name should be a string")
  }
  stmt <-
    sprintf("CREATE LOCAL TEMPORARY COLUMN TABLE  %s  AS (%s)",
            table.name,
            df$select.statement)
  if (force == TRUE) {
    ExecuteLogged(conn$connection,
                  DropTable(table.name))
  }
  ExecuteLogged(conn$connection, stmt)
}

CreateTWithConnection <- function(conn, table, force = TRUE) {
  name <- table$name
  spec <- table$spec
  data <- table$data
  value.set <- is.null(data)
  if (!is.character(name)) {
    stop("Table name should be a string")
  }
  if (!is.list(spec)) {
    stop("Spec should be given as a list of tuples")
  }
  if (force == TRUE) {
    ExecuteLogged(conn$connection, DropTable(name))
  }
  ExecuteLogged(conn$connection,
                CreateTable(name, spec))
  if (!value.set == TRUE) {
    list.of.queries <- InsertMany(name, data)
    for (each.query in list.of.queries) {
      ExecuteLogged(conn$connection, each.query)
    }
  }
}

TryDropWithConnection <- function(conn, ...) {
  names <- list(...)
  len <- length(names)
  if (length(names) == 0)
    stop("Please pass name(s) of table(s) to drop")
  for (table.name in names) {
    ExecuteLogged(conn$connection, DropTable(table.name))
  }
}

CallPalAutoWithConnection <- function(conn, funcname, tableNames, resultNames) {
  ttabsql <- function(ttab) {
    tabletype <- function(mytable) {
      if (grepl("#", mytable)) {
        temp.table.desc.query <- sprintf(paste0("select COLUMN_NAME, DATA_TYPE_NAME,LENGTH FROM ",
                                                "M_TEMPORARY_TABLE_COLUMNS WHERE TABLE_NAME = '%s'
                                                AND COLUMN_NAME != '$rowid$'",
                                                "ORDER BY POSITION"), mytable)
      } else {
        temp.table.desc.query <- NULL
        if (grepl("[.]", mytable)) {
          split.str <- strsplit(mytable, "[.]")[[1]]
          schema <- split.str[1]
          table <- split.str[2]
          temp.table.desc.query <- sprintf(paste0("select COLUMN_NAME, DATA_TYPE_NAME,LENGTH FROM ",
                                "TABLE_COLUMNS WHERE TABLE_NAME = '%s' AND SCHEMA_NAME = '%s'
                                AND COLUMN_NAME != '$rowid$'", "ORDER BY POSITION"),
                                table, schema)
        } else{
          temp.table.desc.query <- sprintf(paste0("select COLUMN_NAME, DATA_TYPE_NAME,LENGTH FROM ",
                                "TABLE_COLUMNS WHERE TABLE_NAME = '%s' AND SCHEMA_NAME = CURRENT_SCHEMA
                                AND COLUMN_NAME != '$rowid$'", "ORDER BY POSITION"),
                                mytable)
        }
      }
      temp.table.result <- unique(sqlQueryMix(conn$connection, temp.table.desc.query))
      ttlist <- list()
      for (i in 1:nrow(temp.table.result)) {
        row <- temp.table.result[i, ]
        ttype <- row[[2]]
        if (grepl("CHAR", toupper(row[[2]]))) {
          ttype <- paste0(ttype, "(", row[[3]], ")")
        }
        ttlist <- c(ttlist, paste(QuoteName(row[[1]]), ttype))
      }
      return (sprintf("TABLE(%s)", paste(ttlist, collapse = ",")))
    }
    ttabinputs <- list()
    tab.no <- 0
    for (tab in ttab) {
      if (!grepl("DataFrame", paste0(list(class(tab))))){
        ttabinputs <- c(ttabinputs, paste0("\nIN in_", tab.no, " ", tabletype(tab), " => ", QuoteName(tab)))
      }
      tab.no <- tab.no + 1
    }
    return (ttabinputs)
  }
  header <- "DO\nBEGIN\n"
  materialize.tab <- list()
  if (length(tableNames) > 0){
    new.tableNames <- list()
    count <- 0
    for (tab in tableNames) {
      if (grepl("DataFrame", paste0(list(class(tab))))) {
        if (grepl("#", paste0(list(tab$select.statement)))) {
          unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
          mat.name <- sprintf("#TMP_PAL_AUTO_%s_%s", unique.id, count)
          MaterializeWithConnection(conn, mat.name, tab)
          materialize.tab <- c(materialize.tab, mat.name)
          new.tableNames <- c(new.tableNames, mat.name)
          count <- count + 1
        } else {
          new.tableNames <- c(new.tableNames, tab)
        }
      } else {
        new.tableNames <- c(new.tableNames, tab)
      }
    }
    header <- paste("DO (", paste0(ttabsql(new.tableNames), collapse = ","), ")\nBEGIN\n")
  }
  input.no <- 0
  input.def <- list()
  for (tab in new.tableNames) {
    if (grepl("DataFrame", paste0(list(class(tab))))){
      if (!grepl("#", paste0(list(tab$select.statement)))) {
        input.def <- c(input.def, paste0("in_", input.no, "=",
                                        tab$select.statement, ";\n"))
      }
    }
    input.no <- input.no + 1
  }
  inputdata <- list()
  for (in.no in 0:(length(new.tableNames) - 1)) {
    inputdata <- c(inputdata, paste0(":in_", in.no))
  }
  outputdata <- list()
  for (output in 0:(length(resultNames) - 1)) {
    outputdata <- c(outputdata, paste0("out_", output))
  }
  callPalString <- sprintf("CALL _SYS_AFL.%s(%s,%s);\n", QuoteName(funcname),
                           paste0(inputdata, collapse = ","),
                           paste0(outputdata, collapse = ","))
  materialize <- list()
  output.no <- 0
  for (rtab in resultNames) {
    materialize <- c(materialize,
                     sprintf("CREATE LOCAL TEMPORARY COLUMN TABLE %s AS (SELECT * FROM %s);",
                             rtab, paste0(":out_", output.no)))
    output.no <- output.no + 1
  }
  footer <- "\nEND\n"
  for (rtab in resultNames) {
    ExecuteLogged(conn$connection,
                  DropTable(rtab))
  }
  callString <- paste(header, paste(input.def, collapse = "\n"), callPalString
                      , paste(materialize, collapse = "\n"), footer, collapse = "")
  conn$last.pal.call <- callString
  ExecuteLogged(conn$connection, callString)
  for (mat.tab in materialize.tab) {
    TryDropWithConnection(conn, mat.tab)
  }
}


confusion.matrix <- function(data,
                             key,
                             label.true = NULL,
                             label.pred = NULL,
                             beta = NULL){
  CheckConnection(data)
  conn <- data$connection.context
  native <- FALSE
  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE,
                       case.sensitive = TRUE)
  cols <- cols[! cols %in% key]
  label.true <- validateInput("label.true", label.true, cols,
                              case.sensitive = TRUE)
  if (is.null(label.true)){
    label.true <- cols[[1]]
  }
  label.pred <- validateInput("label.pred", label.pred,
                              cols[! cols %in% label.true],
                              case.sensitive = TRUE)
  if (is.null(label.pred)){
    label.pred <- cols[[2]]
  }
  beta <- validateInput("beta", beta, "double")
  native <- validateInput("native", native, "logical")
  true.type <- data$dtypes(label.true)[[1]][[2]]
  pred.type <- data$dtypes(label.pred)[[1]][[2]]
  if (true.type != pred.type){
    msg <- "The data type of the original.label column and predict.label
    column must be the same."
    flog.error(msg)
    stop(msg)
  }
  temp <- list(key)
  temp <- append(temp, label.true)
  temp <- append(temp, label.pred)
  data <- data$Select(temp)
  unique.id <-
    toupper(gsub("-", "_", UUIDgenerate()))
  label.true.index <- data$dtypes(label.true)[[1]]
  temp <- ParseOneDtype(label.true.index)
  label.true.name <- temp[[1]]
  label.true.type <- temp[[2]]
  label.pred.index <- data$dtypes(label.pred)[[1]]
  temp <- ParseOneDtype(label.pred.index)
  label.pred.name <- temp[[1]]
  label.pred.type <- temp[[2]]
  cm.tbl.spec <- list(tuple(label.true.name, label.true.type),
                      tuple(label.pred.name, label.pred.type),
                      tuple("COUNT", INTEGER))
  cr.tbl.spec <- list(tuple("CLASS", nvarchar(100)),
                      tuple("RECALL", DOUBLE),
                      tuple("PRECISION", DOUBLE),
                      tuple("F_MEASURE", DOUBLE),
                      tuple("SUPPORT", INTEGER))
  if (isTRUE(native)){
    cm.tbl <- sprintf("#CM_%s", unique.id)
    not.in.sql <- sprintf("(SELECT %s, %s FROM (%s))", QuoteName(label.true),
                          QuoteName(label.pred), data$select.statement)
    col.names <- list(QuoteName(label.true), QuoteName(label.pred))
    union.sqls.list <- list()
    for (col1 in col.names)
      for (col2 in col.names){
        temp.sql <- sprintf(paste0("(SELECT DISTINCT T1.%s AS %s, T2.%s AS %s,",
                                   " 0 AS COUNT FROM (%s) T1, (%s) T2 WHERE ",
                                   "(T1.%s, T2.%s) NOT IN %s)"), col1,
                            QuoteName(label.true),
                            col2,
                            QuoteName(label.pred),
                            data$select.statement,
                            data$select.statement,
                            col1, col2, not.in.sql)
        union.sqls.list <- append(union.sqls.list, temp.sql)
      }
    temp.sentence <- sprintf(paste0("(SELECT %s, %s, COUNT(*) AS COUNT FROM (%s) dt GROUP BY %s, %s)",
                                    " ORDER BY %s, %s INTO %s"), QuoteName(label.true), QuoteName(label.pred),
                             data$select.statement, QuoteName(label.true), QuoteName(label.pred),
                             QuoteName(label.true), QuoteName(label.pred), cm.tbl)

    union.sqls.list <- append(union.sqls.list, temp.sentence)
    union.sqls.list <- paste(union.sqls.list, collapse = " UNION ")
    mid.sql <- sprintf(paste0("SELECT A.%s AS CLASS, CASE WHEN A.UP = 0 OR B.P_DOWN = 0 ",
                              "THEN 0 ELSE A.UP/B.P_DOWN END AS PRECISION, CASE WHEN A.UP ",
                              "= 0 OR C.R_DOWN = 0 THEN 0 ELSE A.UP/C.R_DOWN END AS RECALL,",
                              "C.R_DOWN AS SUPPORT FROM (SELECT %s, SUM(COUNT) AS UP FROM ",
                              "%s WHERE %s = %s GROUP BY %s) A, (SELECT %s, SUM(COUNT) ",
                              "AS P_DOWN FROM %s GROUP BY %s) B, (SELECT %s, SUM(COUNT) ",
                              "R_DOWN FROM %s GROUP BY %s) C WHERE A.%s = B.%s AND A.%s ",
                              "= C.%s"), QuoteName(label.true), QuoteName(label.true), cm.tbl,
                       QuoteName(label.true), QuoteName(label.pred), QuoteName(label.true),
                       QuoteName(label.pred), cm.tbl, QuoteName(label.pred), QuoteName(label.true),
                       cm.tbl, QuoteName(label.true), QuoteName(label.true), QuoteName(label.pred),
                       QuoteName(label.true), QuoteName(label.true))

    cr.tbl <- sprintf("#CR_%s", unique.id)
    beta.used <- 1
    if (!is.null(beta))
      beta.used <- beta
    cr.insert.sql <- sprintf(paste0("SELECT CLASS, RECALL, PRECISION, CASE WHEN (%s * %s * ",
                                    " PRECISION + RECALL) = 0 THEN 0 ELSE (1 + %s*%s) *",
                                    " PRECISION * RECALL / (%s * %s * PRECISION + RECALL) ",
                                    "END AS F_MEASURE, SUPPORT FROM (%s) INTO %s;"),
                             beta.used, beta.used, beta.used, beta.used, beta.used, beta.used,
                             mid.sql, cr.tbl)
    tryCatch({
      CreateTWithConnection(conn, Table$new(cm.tbl, cm.tbl.spec))
      CreateTWithConnection(conn, Table$new(cr.tbl, cr.tbl.spec))
      ExecuteLogged(conn$connection, union.sqls.list)
      ExecuteLogged(conn$connection, cr.insert.sql)
      cm.df <- conn$table(cm.tbl)
      cm.df.sorted <- cm.df$Sort(list(cm.df$columns[[1]], cm.df$columns[[2]]), desc = TRUE)
      return (list(cm.df.sorted, conn$table(cr.tbl)))
    },
    error = function(err){
      msg <- paste("Error:", err[["message"]])
      flog.error(msg)
      stop(msg)
    })
  }#native if loop
  data.tbl <- sprintf("#CM_DATA_TBL_%s", unique.id)
  param.tbl <- sprintf("#CM_PARAM_TBL_%s", unique.id)
  matrix.tbl <- sprintf("#CM_MATRIX_TBL_%s", unique.id)
  classification.tbl <- sprintf("#CM_CLASSIFICATION_REPORT_TBL_%s", unique.id)
  tables <- list(param.tbl, matrix.tbl, classification.tbl)
  tryCatch({
    if (!is.null(beta)){
      params <- list(tuple("BETA", NULL, beta, NULL))
      CreateTWithConnection(conn, ParameterTable$new(param.tbl)$WithData(params))
    } else {
      CreateTWithConnection(conn, ParameterTable$new(param.tbl))
    }
    errorhelper(CallPalAutoWithConnection(conn, "PAL_CONFUSION_MATRIX",
                                          list(data, param.tbl),
                                          list(matrix.tbl, classification.tbl)))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  matrix.tbl <- conn$table(matrix.tbl)
  return (list(matrix.tbl$Sort(list(matrix.tbl$columns[[1]], matrix.tbl$columns[[2]]), desc = TRUE),
               conn$table(classification.tbl)))
}

validate.columns.in.DataFrame <- function(df, cols){
  valid.set <- unique(df$columns)
  check.name <- list()
  for (col in cols){
    if (inherits(col, "character")){
      check.name <- append(check.name, col)
    }
  }
  invalid.names <- setdiff(check.name, valid.set)
  if (length(invalid.names) > 0){
    stop(sprintf("Column(s) not in DataFrame: %s", paste(invalid.names, collapse = ", ")))
  }
}
#' @title Confusion Matrix
#' @description Compute confusion matrix to evaluate the accuracy
#' of a classification.
#' @name hanaml.confusion.matrix
#' @template args-data
#' @template args-key
#' @param     label.true \code{character, optional}\cr
#'            Name of the original label column.\cr
#'            If not given, defaults to 1st non-ID columm.
#' @param     label.pred \code{character, optional)}\cr
#'            Name of the predicted label column.\cr
#'            If not given, defaults to 2nd non-ID columm.
#' @param     beta \code{double, optional}\cr
#'            Parameter used to compute the F-Beta score.\cr
#'            Defaults to 1.
#' @return
#' Returns a list of DataFrame:
#' \itemize{
#'  \item{\code{DataFrame 1}}\cr
#'     Confusion matrix, structured as follows:
#'  \itemize{
#'    \item{Original label: with same name and data type as it is in data.}
#'    \item{Predicted label: with same name and data type as it is in data.}
#'    \item{Count: type INTEGER, the number of data points with the
#'              corresponding combination of predicted and original label.}
#'    }
#'  The DataFrame is sorted by (original label, predicted label)
#'  in descending order.
#'  NOTE: The data type of the original.label column and predict.label
#'  column must be the same.
#'  \item{\code{DataFrame 2}}\cr
#'     Classfication report, structured as follows:
#'  \itemize{
#'    \item{Class: type NVARCHAR(100), class name}
#'    \item{Recall: type DOUBLE, the recall of each class}
#'    \item{Precision: type DOUBLE, the precision of each class}
#'    \item{F_MEASURE: type DOUBLE, the F_measure of each class}
#'    \item{SUPPORT: type INTEGER, the support - sample number in each class}
#'  }
#' }
#' @section Examples:
#' DataFrame df to calculate the confusion matrix:
#' \preformatted{
#'    > df$Collect()
#'       ID  ORIGINAL  PREDICT
#'    1   1         1        1
#'    2   2         1        1
#'    3   3         1        1
#'    4   4         1        2
#'    5   5         1        1
#'    6   6         2        2
#'    7   7         2        1
#'    8   8         2        2
#'    9   9         2        2
#'    10 10         2        2
#' }
#' Calculate the confusion matrix:
#' \preformatted{
#' > cm, cr <- hanaml.confusion.matrix(data = df,
#'                                     key = "ID", label.true = "ORIGINAL",
#'                                     label.pred = "PREDICT")
#' }
#' Return:
#' \preformatted{
#' > cm$Collect()
#'    ORIGINAL  PREDICT  COUNT
#' 1         1        1      4
#' 2         1        2      1
#' 3         2        1      1
#' 4         2        2      4
#'
#' > cr$Collect()
#'   CLASS  RECALL  PRECISION  F_MEASURE  SUPPORT
#' 1     1     0.8        0.8        0.8        5
#' 2     2     0.8        0.8        0.8        5
#' }
#' @keywords Metrics
#' @export
hanaml.confusion.matrix <- function(data, key, label.true=NULL, label.pred=NULL,
                                    beta=NULL){
  confusion.matrix(data, key, label.true, label.pred, beta)
}

get.list.of.str <- function(cols, message){
  if ( (length(cols) < 2) && inherits(class(cols), "character"))
      cols <- list(cols)
  for (col in cols){
      if (!inherits(cols, "list") || is.null(cols) || !inherits(col, "character"))
        stop(message)
  }
  return (cols)
}

#' @title dbplyr2hana
#' @description Convert dbplyr tbl to HANA DataFrame.
#' @name hanaml.dbplyr2hana
#' @template args-conn
#' @param table \code{R tbl}\cr
#' The R tbl.
#' @return \code{DataFrame} \cr
#' Returns a HANA Dataframe including data from the R data.frame.
#' @export
hanaml.dbplyr2hana <- function(connection.context, table){
  return (dbplyr2hana(connection.context, table))
}

#' @title hana2dbplyr
#' @description Convert HANA DataFrame to dbplyr tbl.
#' @name hanaml.hana2dbplyr
#' @param dataframe \code{DataFrame} \cr
#' The HANA DataFrame.
#' @return \code{R tbl}\cr
#' Returns a dbplyr tbl.
#' @export
hanaml.hana2dbplyr <- function(dataframe){
  return (hana2dbplyr(dataframe))
}




