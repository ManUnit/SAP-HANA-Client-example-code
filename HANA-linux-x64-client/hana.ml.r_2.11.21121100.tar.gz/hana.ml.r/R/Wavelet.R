WaveletBase <- R6Class(
  "WaveletBase",
  inherit = MlBase,
  public = list(
    filter = NULL,
    n.levels = NULL,
    boundary = NULL,
    coeff.order = NULL,
    coeff = NULL,
    stat = NULL,
    boundary.map = list(zero = 0, symmetric = 1,
                        periodic = 2, reflect = 3,
                        smooth = 4, constant = 5),
    order.map = list(node = 0, frequency = 1),
    initialize = function(data = NULL,
                          key = NULL,
                          endog = NULL,
                          filter = NULL,
                          n.levels = NULL,
                          boundary = NULL,
                          coeff.order = NULL,
                          packet = NULL) {
      if (!is.null(data)) {
        filter <- validateInput("filter", filter, "character", required = TRUE)
        self$filter <- validateInput("filter", tolower(filter),
                                     private$GetWaveletFilters())
        self$n.levels <- validateInput("n.levels", n.levels, "integer")
        self$boundary <- validateInput("boundary", boundary, self$boundary.map)
        coeff.order <- validateInput("coeff.order", coeff.order, self$order.map)
        packet <- validateInput("packet", packet, "logical")
        cols <- data$columns
        key <- validateInput("key", key, cols,
                             required = TRUE,
                             case.sensitive = TRUE)
        cols <- cols[!cols %in% key]
        endog <- validateInput("endog", endog, cols,
                               case.sensitive = TRUE)
        if (is.null(endog)) {
          endog <- cols[[1]]
        }
        CheckConnection(data)
        conn <- data$connection.context
        if (!inherits(data, "DataFrame")) {
          msg <- "data must be given as a DataFrame"
          flog.error(msg)
          stop(msg)
        }
        data <- data$Select(c(key, endog))
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        func <- ifelse(isTRUE(packet), "WPT", "DWT")
        procedure <- ifelse(isTRUE(packet), "PAL_WAVELET_PACKET_TRANSFORM",
                            "PAL_DISCRETE_WAVELET_TRANSFORM")
        param.tbl <- sprintf("#PAL_%s_PARAMETER_TBL_%s", func, unique.id)
        result.tbl <- sprintf("#PAL_%s_RESULT_TBL_%s", func, unique.id)
        in.tables <- list(data, param.tbl)
        out.tables <- list(result.tbl)
        tables <- list(param.tbl, result.tbl)
        if (isTRUE(packet)) {
          stat.tbl <- sprintf("#PAL_%s_STATS_TBL_%s", func, unique.id)
          out.tables <- c(out.tables, stat.tbl)
          tables <- c(tables, stat.tbl)
        }
        param.rows <- list(tuple("FILTER_TYPE", NULL, NULL, filter),
                           tuple("PADDING_TYPE", map.null(boundary,
                                                          self$boundary.map),
                                 NULL, NULL),
                           tuple("LEVEL", n.levels, NULL, NULL),
                           tuple("OUT_TYPE", map.null(coeff.order,
                                                      self$order.map),
                                 NULL, NULL))
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
                                            ParameterTable$new(param.tbl)$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn,
                                                procedure,
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        self$coeff <- conn$table(result.tbl)
        if (isTRUE(packet)) {
          self$stat <- conn$table(stat.tbl)
        }
      }
    },
    inverse = function(data = NULL,
                       stat = NULL,
                       filter = NULL,
                       boundary = NULL,
                       packet = FALSE) {
      if (is.null(data) && is.null(self$coeff)) {
        msg <- "The coefficient DataFrame cannot be NULL."
        stop(msg)
      } else if (is.null(data)) {
        data <- self$coeff
      }
      if (is.null(filter)) {
        filter <- self$filter
      }
      filter <- validateInput("filter", filter, "character", required = TRUE)
      filter <- validateInput("filter", tolower(filter),
                              private$GetWaveletFilters())
      boundary <- validateInput("boundary", boundary, self$boundary.map)
      if (is.null(boundary)) {
        boundary <- self$boundary
      }
      CheckConnection(data)
      conn <- data$connection.context
      if (!inherits(data, "DataFrame")) {
        msg <- "data must be given as a DataFrame"
        flog.error(msg)
        stop(msg)
      }
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      func <- "IDWT"
      procedure <- "PAL_DISCRETE_WAVELET_TRANSFORM_INVERSE"
      if (is.null(packet)) {
        packet <- !is.null(self$stat)
      }
      if (isTRUE(packet)) {
        func <- "IWPT"
        procedure <- "PAL_WAVELET_PACKET_TRANSFORM_INVERSE"
        if (is.null(stat) && is.null(self$stat)) {
          msg <- "statistics table must be provided."
          stop(msg)
        } else if (is.null(stat)) {
          stat <- self$stat
        }
      }
      param.tbl <- sprintf("#PAL_%s_PARAMETER_TBL_%s", func, unique.id)
      result.tbl <- sprintf("#PAL_%s_RESULT_TBL_%s", func, unique.id)
      in.tables <- list(data, param.tbl)
      if (isTRUE(packet)) {
        in.tables <- list(data, stat, param.tbl)
      }
      out.tables <- list(result.tbl)
      tables <- list(param.tbl, result.tbl)
      param.rows <- list(tuple("FILTER_TYPE", NULL, NULL, filter),
                         tuple("PADDING_TYPE", map.null(boundary,
                                                        self$boundary.map),
                               NULL, NULL))
      tryCatch({
        errorhelper(CreateTWithConnection(conn,
                                          ParameterTable$new(param.tbl)$WithData(param.rows)))
        errorhelper(CallPalAutoWithConnection(conn,
                                              procedure,
                                              in.tables,
                                              out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn, tables)
        stop(msg)
      })
      return(conn$table(result.tbl))
    }
  ),
  private = list(
    GetWaveletFilters = function() {
      db.vec <- paste0(rep("db", 20), c(1:20))
      bio.vec <- c( "bior1.1", "bior1.3", "bior1.5",
                    "bior2.2", "bior2.4", "bior2.6", "bior2.8",
                    "bior3.1", "bior3.3", "bior3.5", "bior3.7",
                    "bior3.9", "bior4.4", "bior5.5", "bior6.8")
      rbio.vec <- paste0(rep("r", 15),
                         gsub("r", "", bio.vec))
      coif.vec <- paste0(rep("coif", 5), c(1:5))
      sym.vec <- paste0(rep("sym", 19), c(2:20))
      filter.list <- as.list(c(db.vec, bio.vec, rbio.vec, coif.vec, sym.vec))
      return(filter.list)
    }
  )
)

DWT <- R6Class(
  "DWT",
  inherit = WaveletBase,
  public = list(
    initialize = function(data = NULL,
                          key = NULL,
                          endog = NULL,
                          filter = NULL,
                          n.levels = NULL,
                          boundary = NULL) {
      super$initialize(data = data,
                       key = key,
                       endog = endog,
                       filter = filter,
                       n.levels = n.levels,
                       boundary = boundary,
                       NULL, FALSE)

    }
  )
)



#' @title Discrete wavelet transform.
#' @name hanaml.DWT
#' @description hanaml.DWT is an R wrapper for PAL discrete wavelet transform.
#' @details Applying discrete wavelet transform to 1D time-series, using different
#'          wavelet filters, up to different decomposition levels and on various
#'          boundary extension modes.
#' @seealso \code{\link{hanaml.IDWT}, \link{hanaml.WPT}}
#' @param data \code{DataFrame}\cr
#'        DataFrame containing the time-series data to apply discrete wavelet transform.
#' @param key \code{character}\cr
#'        Name of the time-stamp column in \code{data}.\cr
#' @template args-endog
#' @param filter \code{character}\cr
#'         Specifies the wavelet filter used for discrete wavelet transform.\cr
#'         Valid options include:
#'         \itemize{
#'           \item{Daubechies family:} "db1" ~ "db20".
#'           \item{Biorthognal family:} "bior1.1", "bior1.3", "bior1.5", "bior2.2",
#'             "bior2.4", "bior2.6", "bior2.8", "bior3.1", "bior3.3", "bior3.5",
#'             "bior3.7", "bior3.9", "bior4.4", "bior5.5", "bior6.8".
#'           \item{Reverse Biorthogal family:} "rbio1.1", "rbio1.3", "rbio1.5", "rbio2.2",
#'              "rbio2.4", "rbio2.6", "rbio2.8", "rbio3.1", "rbio3.3", "rbio3.5",
#'              "rbio3.7", "rbio3.9", "rbio4.4", "rbio5.5", "rbio6.8"
#'          \item{Coifman family:} "coif1" ~ "coif5".
#'          \item{Symmetric family:} "sym2" ~ "sym20".}
#' @param boundary \code{character, optional}\cr
#'        Specifies the padding method for boundary values.
#'        Valid options include:
#'        \itemize{
#'          \item{"zero":} Zero padding
#'          \item{"symmetric":} Symmetric padding
#'          \item{"periodic":} Periodic padding
#'          \item{"reflect":} Reflect padding
#'          \item{"smooth":} Smooth padding
#'          \item{"constant":} Constant padding}
#'       Defaults to "zero".
#' @param n.levels \code{numeric/integer, optional}
#'        Specifies the decompose level for discrete wavelet transform.\cr
#'        Defaults to 1.
#' @return
#' Returns a "DWT" object with the following attributes:
#' \itemize{
#' \item{coeff: \code{DataFrame}}\cr
#'      Wavelet coefficients of the time-series data up to the specified
#'      decomposition level using the specified wavelet filter.
#' }
#' @export
hanaml.DWT <- function(data = NULL,
                       key = NULL,
                       endog = NULL,
                       filter = NULL,
                       n.levels = NULL,
                       boundary = NULL) {
  DWT$new(data = data, key = key,
          endog = endog, filter = filter,
          n.levels = n.levels,
          boundary = boundary)
}

#' @title Inverse discrete wavelet transform.
#' @name hanaml.IDWT
#' @description hanaml.IDWT is the R wrapper for PAL inverse discrete wavelet transform.
#' @details Perform inverse discrete wavelet transform given an \code{DWT} object that
#' contains discrete wavelet coefficients, as well as other related information for
#' applying the inverse transformation.
#' @seealso \code{\link{hanaml.DWT}}
#' @param wt \code{DWT or DataFrame}\cr
#'        A \code{DWT} object or a DataFrame that contains the wavelet coefficients for
#'        applying the inverse transformation.\cr
#'        If \code{wt} is an \code{DWT} object, it is supposed to contain other related
#'        information for inverse wavelet transformation, like wavelet filter and boundary
#'        extension method.
#' @param filter \code{character, optional}\cr
#'        Specifies the wavelet filter used for inverse discrete wavelet transform.\cr
#'        It is assumed to be the same as the filter used for discrete wavelet transform.\cr
#'        Valid options include:
#'        \itemize{
#'          \item{Daubechies family:} "db1" ~ "db20".
#'          \item{Biorthognal family:} "bior1.1", "bior1.3", "bior1.5", "bior2.2",
#'             "bior2.4", "bior2.6", "bior2.8", "bior3.1", "bior3.3", "bior3.5",
#'             "bior3.7", "bior3.9", "bior4.4", "bior5.5", "bior6.8".
#'          \item{Reverse Biorthogal family:} "rbio1.1", "rbio1.3", "rbio1.5", "rbio2.2",
#'              "rbio2.4", "rbio2.6", "rbio2.8", "rbio3.1", "rbio3.3", "rbio3.5",
#'              "rbio3.7", "rbio3.9", "rbio4.4", "rbio5.5", "rbio6.8"
#'          \item{Coifman family:} "coif1" ~ "coif5".
#'          \item{Symmetric family:} "sym2" ~ "sym20".}
#'        Defaults to \code{wt$filter} if \code{wt} is a \code{DTW} object,
#'        otherwise it must be specified.
#' @param boundary \code{character, optional}\cr
#'        Specifies the padding method for boundary values.
#'        Valid options include:
#'        \itemize{
#'          \item{"zero":} Zero padding
#'          \item{"symmetric":} Symmetric padding
#'          \item{"periodic":} Periodic padding
#'          \item{"reflect":} Reflect padding
#'          \item{"smooth":} Smooth padding
#'          \item{"constant":} Constant padding}
#'       Defaults to \code{wt$boundary} if \code{wt} is a \code{DWT} object,
#'       otherwise it defaults to "zero".
#' @return
#' A DataFrame containing the reconstructed time-series data from the given wavelet coefficients.
#' @export
hanaml.IDWT <- function(wt = NULL,
                        filter = NULL,
                        boundary = NULL) {
  if (!is.null(wt)){
    if (is(wt, "DWT")) {
      coeff <- wt$coeff
      res <- wt$inverse(data = coeff,
                        stat = NULL,
                        filter = filter,
                        boundary = boundary,
                        packet = FALSE)
    } else if (is(wt, "DataFrame")) {
      coeff <- wt
      res <- DWT$new()$inverse(data = coeff,
                               stat = NULL,
                               filter = filter,
                               boundary = boundary,
                               packet = FALSE)
    } else{
      msg <- paste("The wt parameter for IDWT must",
                   "either be a DWT object or a DataFrame.")
      stop(msg)
    }
  } else {
    msg <- "The wt parameter is mandatory."
    stop(msg)
  }
  return(res)
}

WPT <- R6Class(
  "WPT",
  inherit = WaveletBase,
  public = list(
    initialize = function(data = NULL,
                          key = NULL,
                          endog = NULL,
                          filter = NULL,
                          n.levels = NULL,
                          boundary = NULL,
                          coeff.order = NULL) {
      super$initialize(data = data,
                       key = key,
                       endog = endog,
                       filter = filter,
                       n.levels = n.levels,
                       boundary = boundary,
                       coeff.order = coeff.order,
                       packet = TRUE)

    }
  )
)

#' @title Discrete wavelet packet transform.
#' @name hanaml.WPT
#' @description hanaml.DPT is an R wrapper for PAL discrete wavelet packet transform.
#' @details Applying discrete wavelet packet transform to 1D time-series, using different
#'          wavelet filters, up to different decomposition levels and on various
#'          boundary extension modes.
#' @seealso \code{\link{hanaml.IWPT}, \link{hanaml.DWT}}
#' @param data \code{DataFrame}\cr
#'        DataFrame containing the time-series data to apply discrete wavelet packet transform.
#' @param key \code{character}\cr
#'        Name of the time-stamp column in \code{data}.\cr
#' @template args-endog
#' @param filter \code{character}\cr
#'         Specifies the wavelet filter used for discrete wavelet transform.\cr
#'         Valid options include:
#'         \itemize{
#'           \item{Daubechies family:} "db1" ~ "db20".
#'           \item{Biorthognal family:} "bior1.1", "bior1.3", "bior1.5", "bior2.2",
#'             "bior2.4", "bior2.6", "bior2.8", "bior3.1", "bior3.3", "bior3.5",
#'             "bior3.7", "bior3.9", "bior4.4", "bior5.5", "bior6.8".
#'           \item{Reverse Biorthogal family:} "rbio1.1", "rbio1.3", "rbio1.5", "rbio2.2",
#'              "rbio2.4", "rbio2.6", "rbio2.8", "rbio3.1", "rbio3.3", "rbio3.5",
#'              "rbio3.7", "rbio3.9", "rbio4.4", "rbio5.5", "rbio6.8"
#'          \item{Coifman family:} "coif1" ~ "coif5".
#'          \item{Symmetric family:} "sym2" ~ "sym20".}
#' @param boundary \code{character, optional}\cr
#'        Specifies the padding method for boundary values.
#'        Valid options include:
#'        \itemize{
#'          \item{"zero":} Zero padding
#'          \item{"symmetric":} Symmetric padding
#'          \item{"periodic":} Periodic padding
#'          \item{"reflect":} Reflect padding
#'          \item{"smooth":} Smooth padding
#'          \item{"constant":} Constant padding}
#'       Defaults to "zero".
#' @param n.levels \code{numeric/integer, optional}
#'        Specifies the decompose level for discrete wavelet transform.\cr
#'        Defaults to 1.
#' @param coeff.order \code{c("index", "frequency"), optional}\cr
#'        Specifies the order of nodes in the wavelet packet coefficients table.
#'        \itemize{
#'          \item{"index":} ordered by the indices of nodes(ascending).
#'          \item{"frequency":} ordered by the frequencies of nodes, from low to high.
#'        }
#'        Defaults to "index".
#' @return
#' Returns a "WPT" object with the following attributes:
#' \itemize{
#' \item{coeff: \code{DataFrame}}\cr
#'      Wavelet packet coefficients of the time-series data up to the specified
#'      decomposition level using the specified wavelet filter.
#' \item{stat: \code{DataFrame}}\cr
#'      DataFrame containing the key statistics for multi-level wavelet
#'      packet transformation.
#' }
#' @export
hanaml.WPT <- function(data = NULL,
                       key = NULL,
                       endog = NULL,
                       filter = NULL,
                       n.levels = NULL,
                       boundary = NULL,
                       coeff.order = NULL) {
  WPT$new(data = data, key = key,
          endog = endog, filter = filter,
          n.levels = n.levels,
          boundary = boundary,
          coeff.order = coeff.order)
}

#' @title Inverse discrete wavelet packet transform.
#' @name hanaml.IWPT
#' @description hanaml.IWPT is the R wrapper for PAL inverse discrete wavelet packet transform.
#' @details Perform inverse discrete wavelet packet transform given an \code{WPT} object that
#' contains discrete wavelet coefficients, as well as other related information for
#' applying the inverse transformation.
#' @seealso \code{\link{hanaml.WPT}}
#' @param wpt \code{WPT}\cr
#'        A \code{WPT} object that contains the wavelet packet coefficients and coefficient order
#'        for applying the inverse transformation.\cr
#'        The \code{WPT} object is assumed to contain other related
#'        information for inverse transformation, like wavelet filter and boundary
#'        extension method.
#' @param filter \code{character, optional}\cr
#'        Specifies the wavelet filter used for inverse wavelet packet transform.\cr
#'        It is assumed to be the same as the filter used for wavelet packet transform.\cr
#'        Valid options include:
#'        \itemize{
#'          \item{Daubechies family:} "db1" ~ "db20".
#'          \item{Biorthognal family:} "bior1.1", "bior1.3", "bior1.5", "bior2.2",
#'             "bior2.4", "bior2.6", "bior2.8", "bior3.1", "bior3.3", "bior3.5",
#'             "bior3.7", "bior3.9", "bior4.4", "bior5.5", "bior6.8".
#'          \item{Reverse Biorthogal family:} "rbio1.1", "rbio1.3", "rbio1.5", "rbio2.2",
#'              "rbio2.4", "rbio2.6", "rbio2.8", "rbio3.1", "rbio3.3", "rbio3.5",
#'              "rbio3.7", "rbio3.9", "rbio4.4", "rbio5.5", "rbio6.8"
#'          \item{Coifman family:} "coif1" ~ "coif5".
#'          \item{Symmetric family:} "sym2" ~ "sym20".}
#'        Defaults to \code{wpt$filter}.
#' @param boundary \code{character, optional}\cr
#'        Specifies the padding method for boundary values.
#'        Valid options include:
#'        \itemize{
#'          \item{"zero":} Zero padding
#'          \item{"symmetric":} Symmetric padding
#'          \item{"periodic":} Periodic padding
#'          \item{"reflect":} Reflect padding
#'          \item{"smooth":} Smooth padding
#'          \item{"constant":} Constant padding}
#'       Defaults to \code{wpt$boundary}.
#' @return
#' A DataFrame containing the reconstructed time-series data from the given wavelet packet coefficients.
#' @export
hanaml.IWPT <- function(wpt = NULL,
                        filter = NULL,
                        boundary = NULL) {
  if (!is.null(wpt)){
    if (inherits(wpt, "WPT")) {
      coeff <- wpt$coeff
      stat <- wpt$stat
      if (is.null(coeff) || is.null(stat)) {
        msg <- "Either wavelet coefficients or statistics table is NULL"
        stop(msg)
      }
      res <- wpt$inverse(data = coeff,
                         stat = stat,
                         filter = filter,
                         boundary = boundary,
                         packet = TRUE)
    } else if (all(sapply(wpt, is, class2 = "DataFrame"))) {
      if (! all(c("coeff", "stat") %in% names(wpt))) {
        msg <- paste("DataFrames with names \"coeff\" and \"stat\" must be",
                     "included in the wpt parameter.")
        stop(msg)
      }
      coeff <- wpt[["coeff"]]
      stat <- wpt[["stat"]]
      res <- WPT$new()$inverse(data = coeff,
                               stat = stat,
                               filter = filter,
                               boundary = boundary,
                               packet = TRUE)
    } else {
      msg <- paste("The wpt parameter for IWPT must",
                   "either be a WPT object or list/vector",
                   "of DataFrames with names.")
      stop(msg)
    }
  } else {
    msg <- "The wt parameter is mandatory."
    stop(msg)
  }

  return(res)
}

#' @export
plot.DWT <- function(x, ...) {
  conn <- x$coeff$connection.context
  levels <- sqlQueryMix(conn$connection,
                        sprintf("SELECT MAX(LEVEL) FROM (%s)",
                                res$coeff$select.statement))[["MAX(LEVEL)"]]
  fig.h <- 1.0 / (levels + 1)
  count <- 0
  for (i in c(0, levels:1)) {
    vals <- conn$sql(sprintf(paste0("SELECT COEFFICIENTS FROM (%s) ",
                                    "WHERE LEVEL = (%s) ORDER BY ID"),
                             res$coeff$select.statement, i))$Collect()$COEFFICIENTS
    coef.name <- ifelse(i == 0, paste0("A", levels), paste0("W", i))
    l.type <- ifelse(i == 0, "l", "h")
    xlab <- ifelse(i == 1, "x", "")
    par(0, 1, 1 - fig.h * (count + 1), 1 - fig.h * count)
    plot(vals, xlab = xlab, ylab = coef.name, type = l.type)
    count <- count + 1
  }
}
