HGBTBaseClass <- R6Class(
  "HGBTBaseClass",
  inherit = MlBase,
  public = list(
    split.method.list = list("exact", "sketch", "sampling"),
    missing.replace.map = list("feature_marginalized" = 1,
                               "instance_marginalized" = 2,
                               "feature.marginalized" = 1,
                               "instance.marginalized" = 2),
    valid.metric.list = list("rmse" = "RMSE",
                             "mae" = "MAE",
                             "nll" = "NLL",
                             "error_rate" = "ERROR_RATE",
                             "auc" = "AUC"),
    hgbt.name.map = list("n.estimators" = "ITER_NUM",
                         "subsample" = "ROW_SAMPLE_RATE",
                         "max.depth" = "MAX_DEPTH",
                         "split.threshold" = "GAMMA",
                         "learning.rate" = "ETA",
                         "min.sample.weight.leaf" = "MIN_CHILD_HESSIAN",
                         "min.samples.leaf" = "NODE_SIZE",
                         "max.w.in.split" = "NODE_WEIGHT_CONSTRAINT",
                         "col.subsample.split" = "COL_SAMPLE_RATE_BYSPLIT",
                         "col.subsample.tree" = "COL_SAMPLE_RATE_BYTREE",
                         "lambda" = "LAMBDA",
                         "alpha" = "ALPHA",
                         "base.score" = "BASE_SCORE",
                         "sketch.eps" = "SKETCH_EPS",
                         "fold.num" = "FOLD_NUM",
                         "random.state" = "SEED",
                         "evaluation.metric" = "EVALUATION_METRIC",
                         "reference.metric" = "REF_METRIC",
                         "calculate.importance" = "CALCULATE_IMPORTANCE",
                         "calculate.cm" = "CALCULATE_CONFUSION_MATRIX"),
    n.estimators = NULL,
    random.state = NULL,
    subsample = NULL,
    max.depth = NULL,
    split.threshold = NULL,
    learning.rate = NULL,
    split.method = NULL,
    sketch.eps = NULL,
    fold.num = NULL,
    min.sample.weight.leaf = NULL,
    min.samples.leaf = NULL,
    max.w.in.split = NULL,
    col.subsample.split = NULL,
    col.subsample.tree = NULL,
    lambda = NULL,
    alpha = NULL,
    adopt.prior = NULL,
    evaluation.metric = NULL,
    reference.metric = NULL,
    parameter.range = NULL,
    parameter.values = NULL,
    resampling.method = NULL,
    repeat.times = NULL,
    param.search.strategy = NULL,
    random.search.times = NULL,
    timeout = NULL,
    progress.indicator.id = NULL,
    calculate.importance = NULL,
    calculate.cm = NULL,
    base.score = NULL,
    categorical.variable = NULL,
    model = NULL,
    confusion.matrix = NULL,
    feature.importances = NULL,
    stats = NULL,
    cv = NULL,
    initialize = function(functionality = NULL,
                          data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          n.estimators = NULL,
                          random.state = NULL,
                          subsample = NULL,
                          max.depth = NULL,
                          split.threshold = NULL,
                          learning.rate = NULL,
                          split.method = NULL,
                          sketch.eps = NULL,
                          fold.num = NULL,
                          min.sample.weight.leaf = NULL,
                          min.samples.leaf = NULL,
                          max.w.in.split = NULL,
                          col.subsample.split = NULL,
                          col.subsample.tree = NULL,
                          lambda = NULL,
                          alpha = NULL,
                          adopt.prior = NULL,
                          evaluation.metric = NULL,
                          reference.metric = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL,
                          resampling.method = NULL,
                          repeat.times = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL,
                          calculate.importance = NULL,
                          calculate.cm = NULL,
                          base.score = NULL,
                          thread.ratio = NULL,
                          categorical.variable = NULL) {
      super$initialize()
      private$functionality <- functionality
      if (!is.null(data)){
        self$n.estimators <- validateInput("n.estimators", n.estimators,
                                           "integer")
        self$random.state <- validateInput("random.state", random.state,
                                           "integer")
        self$subsample <- validateInput("subsample", subsample, "double")
        self$max.depth <- validateInput("max.depth", max.depth, "integer")
        self$split.threshold <- validateInput("split.threshold",
                                              split.threshold,
                                              "double")
        self$learning.rate <- validateInput("learning.rate", learning.rate,
                                            "double")

        self$split.method <- validateInput("split.method",
                                           split.method,
                                           self$split.method.list)
        self$sketch.eps <- validateInput("sketch.eps", sketch.eps, "double")
        self$fold.num <- validateInput("fold.num", fold.num, "integer")
        self$min.sample.weight.leaf <- validateInput("min.sample.weight.leaf",
                                                     min.sample.weight.leaf,
                                                     "double")
        self$min.samples.leaf <- validateInput("min.samples.leaf",
                                               min.samples.leaf,
                                               "integer")
        self$max.w.in.split <- validateInput("max.w.in.split",
                                             max.w.in.split,
                                             "double")
        self$col.subsample.split <- validateInput("col.subsample.split",
                                                  col.subsample.split,
                                                  "double")
        self$col.subsample.tree <- validateInput("col.subsample.tree",
                                                 col.subsample.tree,
                                                 "double")
        self$lambda <- validateInput("lambda", lambda, "double")
        self$alpha <- validateInput("alpha", alpha, "double")
        self$adopt.prior <- validateInput("adopt.prior", adopt.prior, "logical")
        thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
        if (functionality == 0){
          self$evaluation.metric <- validateInput("evaluation.metric",
                                                  evaluation.metric,
                                                  self$valid.metric.list[3:5])
          self$reference.metric <- validateInput("reference.metric",
                                                 reference.metric,
                                                 self$valid.metric.list[3:5])
        } else {
          self$evaluation.metric <- validateInput("evaluation.metric",
                                                  evaluation.metric,
                                                  self$valid.metric.list[1:2])
          self$reference.metric <- validateInput("reference.metric",
                                                 reference.metric,
                                                 self$valid.metric.list[1:2])
        }
        self$base.score <- validateInput("base.score", base.score, "double")
        self$calculate.importance <- validateInput("calculate.importance",
                                                   calculate.importance,
                                                   "logical")
        self$calculate.cm <- validateInput("calculate.cm",
                                           calculate.cm,
                                           "logical")
        if (length(categorical.variable) > 0){
          categorical.variable <- as.list(categorical.variable)
        }
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   data$columns,
                                                   case.sensitive = TRUE)
        self$parameter.range <- parameter.range
        self$parameter.values <- parameter.values
        self$resampling.method <- resampling.method
        self$repeat.times <- repeat.times
        self$param.search.strategy <- param.search.strategy
        self$random.search.times <- random.search.times
        self$timeout <- timeout
        self$progress.indicator.id <- progress.indicator.id

        cols.left <- data$columns
        key <- validateInput("key", key, cols.left, case.sensitive = TRUE)
        cols.left <- cols.left[! cols.left %in% key]
        if (inherits(formula, "formula")){
          parseformula <- ParseFormula(data, formula)
          label <- parseformula[[1]]
          features <- parseformula[[2]]
          features <- features[! features %in% key]
        }
        label <- validateInput("label", label, cols.left,
                               case.sensitive = TRUE)
        if (is.null(label)){
          label <- cols.left[[length(cols.left)]]
          cols.left <- cols.left[! cols.left %in% label]
        } else if (!is.list(label)) {
          label <- as.list(label)
          cols.left <- cols.left[! cols.left %in% label]
        } else {
          label <- label
          cols.left <- cols.left[! cols.left %in% label]
        }
        cols.left <- cols.left[! cols.left %in% label]
        features <- validateInput("features", features, cols.left,
                                  case.sensitive = TRUE)
        if (!is.null(key)){
          id.col <- list(key)
          features <- cols.left[! cols.left %in% key]
        } else {
          id.col <- list()
        }
        if (is.null(features)){
          features <- cols.left
        }
        collist <- c(key, features, label)
        used.cols <- list()
        for (col in collist){
          if (!is.null(col))
            used.cols <- append(used.cols, col)
        }
        label.type <- data$dtypes(label)[[1]][[2]]
        if (functionality == 0){
          if (label.type %in% c("DOUBLE", "DECIMAL")) {
            msg <- paste("Label variable is of continuous type,",
                         "not suitable for classification.")
            flog.error(msg)
            stop(msg)
          } else if (label.type %in% c("INTEGER", "INT")) {
            self$categorical.variable <- c(self$categorical.variable,
                                           label)
          }
        } else {
          if (label.type %in% c("VARCHAR", "NVARCHAR") ||
              (label.type %in% c("INT", "INTEGER") &&
               label %in% self$categorical.variable)){
            msg <- paste("Label variable is of categorical type,",
                         "not suitable for regression.")
            flog.error(msg)
            stop(msg)
          }
        }
        if (!inherits(data, "DataFrame")){
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        data <- data$Select(used.cols)

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#HGBT_PARAM_TBL_%s_%s", self$id, unique.id)
        model.tbl <- sprintf("#HGBT_MODEL_TBL_%s_%s", self$id, unique.id)
        var.imp.tbl <- sprintf("#HGBT_VAR_IMP_TBL_%s_%s", self$id, unique.id)
        confusion.mat.tbl <- sprintf("#HGBT_CONFUSION_MATRIX_TBL_%s_%s", self$id, unique.id)
        stat.tbl <- sprintf("#HGBT_STATS_TBL_%s_%s", self$id, unique.id)
        cross.validation.tbl <- sprintf("#HGBT_CROSS_VALIDATION_TBL_%s_%s", self$id, unique.id)

        tables <- list(param.tbl, model.tbl, var.imp.tbl,
                       confusion.mat.tbl, stat.tbl, cross.validation.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(model.tbl, var.imp.tbl,
                           confusion.mat.tbl, stat.tbl, cross.validation.tbl)
        param.data <- list(
          tuple("ITER_NUM", self$n.estimators, NULL, NULL),
          tuple("SEED", self$random.state, NULL, NULL),
          tuple("SPLIT_METHOD", NULL, NULL, self$split.method),
          tuple("SKETCH_EPS", NULL, self$sketch.eps, NULL),
          tuple("FOLD_NUM", self$fold.num, NULL, NULL),
          tuple("MAX_DEPTH", self$max.depth, NULL, NULL),
          tuple("NODE_SIZE", self$min.samples.leaf, NULL, NULL),
          tuple("ETA", NULL, self$learning.rate, NULL),
          tuple("GAMMA", NULL, self$split.threshold, NULL),
          tuple("MIN_CHILD_HESSIAN", NULL, self$min.sample.weight.leaf, NULL),
          tuple("NODE_WEIGHT_CONSTRAINT", NULL, self$max.w.in.split, NULL),
          tuple("ROW_SAMPLE_RATE", NULL, self$subsample, NULL),
          tuple("COL_SAMPLE_RATE_BYSPLIT", NULL, self$col.subsample.split, NULL),
          tuple("COL_SAMPLE_RATE_BYTREE", NULL, self$col.subsample.tree, NULL),
          tuple("LAMBDA", NULL, self$lambda, NULL),
          tuple("ALPHA", NULL, self$alpha, NULL),
          tuple("BASE_SCORE", NULL, self$base.score, NULL),
          tuple("START_FROM_AVERAGE", NULL, self$adopt.prior, NULL),
          tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL), #nolint
          tuple("CALCULATE_IMPORTANCE", self$calculate.importance, NULL, NULL),
          tuple("CALCULATE_CONFUSION_MATRIX", self$calculate.cm, NULL, NULL),
          tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
          tuple("RESAMPLING_METHOD", NULL, NULL, self$resampling.method),
          tuple("REPEAT_TIMES", self$repeat.times, NULL, NULL),
          tuple("PARAM_SEARCH_STRATEGY", NULL, NULL, self$param.search.strategy),
          tuple("RANDOM_SEARCH_TIMES", self$random.search.times, NULL, NULL),
          tuple("TIMEOUT", self$timeout, NULL, NULL),
          tuple("PROGRESS_INDICATOR_ID", NULL, NULL, self$progress.indicator.id)
        )
        if (!is.null(self$evaluation.metric)) {
          temp <- tuple("EVALUATION_METRIC", NULL, NULL,
                        self$valid.metric.list[tolower(evaluation.metric)][[1]])
          param.data <- append(param.data, list(temp))
        }
        if (!is.null(self$categorical.variable)) {
          for (each in self$categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
            param.data <- append(param.data, tuple(temp.list))
          }
        }
        if (!is.null(self$reference.metric)) {
          for (each in self$reference.metric) {
            temp.list <- tuple("REF_METRIC", NULL, NULL,
                               self$valid.metric.list[[each]])
            param.data <- append(param.data, tuple(temp.list))
          }
        }
        if (!is.null(self$parameter.range)) {
          range.names <- validateInput("Parameters for range specification",
                                       names(self$parameter.range),
                                       self$hgbt.name.map[1:13])
          for (i in 1:length(self$parameter.range)) {
            range.name <- tolower(range.names[[i]])
            range.value <- unlist(self$parameter.range[[i]])
            range_list <- paste(range.value, collapse = ", ")
            if (length(range.value) == 2) {
              range_list <- paste(range.value, collapse = ", , ")
            }
            param.val <- sprintf("%s_RANGE",
                                 self$hgbt.name.map[[range.name]])
            temp.list <- tuple(param.val, NULL, NULL,
                               sprintf("[%s]", as.character(range_list)))
            param.data <- append(param.data, tuple(temp.list))
          }
        }
        if (!is.null(self$parameter.values)) {
          values.names <- validateInput("Parameters for value specification",
                                        names(self$parameter.values),
                                        self$hgbt.name.map[1:13])
          for (i in 1:length(self$parameter.values)) {
            values.name <- tolower(values.names[[i]])
            values.value <- unlist(self$parameter.values[[i]])
            values_list <- paste(values.value, collapse = ", ")
            param.val <- sprintf("%s_VALUES",
                                 self$hgbt.name.map[[values.name]])
            temp.list <- tuple(param.val, NULL, NULL,
                               sprintf("{%s}", as.character(values_list)))
            param.data <- append(param.data, tuple(temp.list))
          }
        }
        for (name in label) {
          temp.list <- tuple("DEPENDENT_VARIABLE", NULL, NULL, name)
          param.data <- append(param.data, tuple(temp.list))
        }
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            (ParameterTable$new(param.tbl))$WithData(param.data))) #nolint
          errorhelper(CallPalAutoWithConnection(conn.context,
            "PAL_HGBT", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$model <-
          conn.context$table(model.tbl)
        if (functionality == 0){
          self$confusion.matrix <- conn.context$table(confusion.mat.tbl)
        }
        self$feature.importances <-
          conn.context$table(var.imp.tbl)
        self$stats <-
          conn.context$table(stat.tbl)
        self$cv <- conn.context$table(cross.validation.tbl)
      }
    },
    predict = function(data,
                       key,
                       features = NULL,
                       verbose = NULL,
                       thread.ratio = NULL,
                       missing.replacement = NULL){
      if (!inherits(self$model, "DataFrame")){
        msg <- "Model does not contain DataFrame. Perform a fit first."
        stop(msg)
      }
      cols.left <- data$columns
      key <- validateInput("key", key, cols.left, required = TRUE,
                           case.sensitive = TRUE)
      cols.left <- cols.left[!cols.left %in% key]
      verbose <- validateInput("verbose", verbose, "logical")
      thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
      missing.replacement.value <- validateInput("missing.replacement",
                                                 missing.replacement,
                                                 self$missing.replace.map)
      if (length(features) > 0){
        features <- as.list(features)
      }
      features <- validateInput("features", features, cols.left,
                                case.sensitive = TRUE)
      if (is.null(features) || length(features) == 0) {
        features <-  cols.left
      }
      features.id <- list()
      features.id <-
        append(features.id, key)
      features.id <-
        append(features.id, features)
      CheckConnection(data)
      conn.context <- data$connection.context
      data <- data$Select(features.id)
      if (inherits(self, "HGBTClassifier")){
        hgbt.type <- toupper("HGBTClassifier")
      } else if (inherits(self, "HGBTRegressor")){
        hgbt.type <- toupper("HGBTRegressor")
      }
      tables <- list(data, self$model$name)
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      for (name in c("PARAM", "RESULT")) {
        tables <- append(
          tables,
          sprintf(
            "#PAL_%s_%s_TBL_%s_%s",
            hgbt.type,
            name,
            self$id,
            unique.id
          )
        )
      }
      in.tables <- list(data, self$model$name)
      for (name in c("PARAM")) {
        in.tables <- append(
          in.tables,
          sprintf(
            "#PAL_%s_%s_TBL_%s_%s",
            hgbt.type,
            name,
            self$id,
            unique.id
          )
        )
      }
      out.tables <- list()
      for (name in c("RESULT")) {
        out.tables <- append(
          out.tables,
          sprintf(
            "#PAL_%s_%s_TBL_%s_%s",
            hgbt.type,
            name,
            self$id,
            unique.id
          )
        )
      }
      param.tbl <- tables[[3]]
      result.tbl <- tables[[4]]
      param.data <- list(tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
                         tuple("VERBOSE", to.integer(verbose), NULL, NULL),
                         tuple("MISSING_REPLACEMENT",
                               map.null(missing.replacement.value,
                                        self$missing.replace.map),
                               NULL, NULL))
      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
          (ParameterTable$new(param.tbl))$WithData(param.data))) #nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
          "PAL_HGBT_PREDICT", in.tables, out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      result <- conn.context$table(result.tbl)
      return (result)
    }
  ),
  private = list(
    functionality = NULL
  )
)

HGBTClassifier <- R6Class(
  "HGBTClassifier",
  inherit = HGBTBaseClass,

  public = list(
    score = function(data,
                     key,
                     features= NULL,
                     label = NULL,
                     verbose = NULL,
                     missing.replacement = NULL,
                     thread.ratio = NULL){
      if (is.null(self$model)){
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")){
        msg <- "Data for prediction must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      conn.context <- data$connection.context
      cols <- data$columns
      key <- validateInput("key", key, cols,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols,
                             case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      if (is.null(features))
        features <- cols
      verbose <- validateInput("verbose", verbose, "logical")
      missing.replacement <- validateInput("missing.replacement",
                                           missing.replacement,
                                           self$missing.replace.map)
      thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
      prediction <- self$predict(data, key = key, features = features,
                                 verbose = verbose,
                                 missing.replacement = missing.replacement,
                                 thread.ratio = thread.ratio)
      prediction <- prediction$Select(list(key, "SCORE"))
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      acc.score <- accuracy.score(conn.context,
                                  joined,
                                  label.true = "ACTUAL",
                                  label.pred = "PREDICTION")
      return(acc.score)

    } #score end

    )

)
#' @title Hybrid Gradient Boosting (HGBT) Tree Classifier
#' @name hanaml.HGBTClassifier
#' @description hanaml.HGBTClassifier is a R wrapper for SAP HANA PAL HGBT.
#' @seealso \code{\link{predict.HGBTClassifier}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @param  n.estimators \code{integer, optional}\cr
#' Total iteration number, which is equivalent to the number of trees in the final model. \cr
#' Defaults to 10.
#' @param  random.state \code{integer, optional}\cr
#' The seed for random number generating.\cr
#' 0 - current time as seed.\cr
#' Others - the seed.\cr
#' Defaults to 0.
#' @param subsample \code{double, optional}\cr
#' The sample rate of row (data points).\cr
#' Defaults to 1.0.
#' @param     max.depth \code{integer, optional}\cr
#' The maximum depth of a tree.\cr
#' Defaults to 6.
#' @param  split.threshold \code{double, optional}\cr
#' The minimum loss change value to make a split in tree growth (gamma in the equation). \cr
#' Default to 0.
#' @param  learning.rate \code{double, optional.}\cr
#' Learning rate of each iteration, must be within the range (0, 1).\cr
#' Defaults to 0.3.
#' @param  split.method \code{('exact', 'sketch', 'sampling'), optional}\cr
#' The method to finding split point for integeral features.\cr
#' - 'exact':trying all possible points.\cr
#' - 'sketch': accounting for the distribution of the sum of hessian.\cr
#' - 'sampling':samples the split point randomly.\cr
#' The exact method comparably has the highest test accuracy, but costs more time.
#' On the other hand, the other two methods have relative higher computational efficiency but might
#' lead to lower test accuracy, and are considered to be adopted as the training data set is huge.\cr
#' Valid only for integer features.\cr
#' Defaults to 'exact'.
#' @param sketch.eps \code{double, optional}\cr
#' The epsilon of the sketch method.
#' It indicates that the sum of hessian between two split points is not larger than this value.
#' That is, the number of bins is approximately 1/eps.\cr
#' The less is this value, the more split points are tried.\cr
#' Defaults to 0.1.
#' @param  fold.num \code{integer, optional}\cr
#' Specify fold number for cross validation method.\cr
#' Mandatory and valid only when resampling.method is set to cv or stratified_cv.\cr
#' No default value.
#' @param  min.sample.weight.leaf \code{double, optional}\cr
#' The minimum summation of sample weights (hessian) in leaf node.\cr
#' Defaults to 1.0.
#' @param  min.samples.leaf \code{integer, optional}\cr
#' The minimum number of data in a leaf node.\cr
#' Defaults to 1.
#' @param  max.w.in.split \code{double, optional}\cr
#' The maximum weight constraint assigned to each tree node.\cr
#' Defaults to 0 (i.e. no constraint).
#' @param col.subsample.split \code{double, optional}\cr
#' The fraction of features used for each split,
#' should be within range (0, 1].\cr
#' Defaults to 1.0.
#' @param col.subsample.tree \code{double, optional}\cr
#' The fraction of features used for each tree
#' growth, should be within range (0, 1]\cr
#' Defaults to 1.0.
#' @param  lambda \code{double, optional}\cr
#' Weight of L2 regularization for the target loss function.
#' Should be within range [0, 1].\cr
#' Defaults to 1.0.
#' @param  alpha \code{double, optional}\cr
#' Weight of L1 regularization for the target loss function.\cr
#' Defaults to 1.0.
#' @param adopt.prior \code{logical, optional}\cr
#' Indicates whether to adopt the prior distribution as the initial point.
#' To be specific, use average value if it is a regression problem, and use frequencies of labels if it is a classification problem.
#' Defaults to FALSE.
#' @param   evaluation.metric   \code{character, optional}\cr
#' Specify evaluation metric for model evaluation or parameter selection.\cr
#' Valid values include: 'nll','error_rate','auc'.\cr
#' It is mandatory if \code{resampling.method} is set.\cr
#' No default value.
#' @param  reference.metric \code{character or list of characters, optional}\cr
#' A list of reference metrics.\cr
#' Any element of the list must be a valid option of evaluation.metric.\cr
#' No default value.
#' @param parameter.range    \code{list, optional}\cr
#' Indicates the range of parameters for selection.\cr
#' Each element is a vector of numbers with the following structure:
#' c(<begin-value>, <step-size>, <end-value>).\cr
#' All elements must be named, with names being the following valid parameters for model selection:\cr
#' n.estimators, max.depth, learning.rate,
#' min.sample.weight.leaf, max.w.in.split, col.subsample.split, col.subsample.tree,
#' lambda, alpha, scale.pos.w, base.score.
#' Simple example for illustration - a list of two vectors\cr
#' list(n.estimators = c(4, 2, 10),
#'      learning.rate = c(0.1, 0.3, 1))\cr
#' Valid only when parameter selection is activated.
#' @param parameter.values  \code{list, optional}\cr
#' Indicates the values of parameters selection.\cr
#' Each element must be a vector of valid parameter values.\cr
#' All elements must be named, with names being the following valid parameters for model selection:\cr
#' n.estimators, max.depth, learning.rate,
#' min.sample.weight.leaf, max.w.in.split, col.subsample.split, col.subsample.tree,
#' lambda, alpha, scale.pos.w, base.score.
#' Simple example for illustration - a list of two vectors\cr
#' list(n.estimators = c(4, 5, 6),
#'      learning.rate = c(2.0, 2.5, 3))
#' Valid only when parameter selection is activated.
#' @param resampling.method \code{character, optional}\cr
#'  Specify resampling method for model evaluation or parameter selection.
#'  \itemize{
#'     \item{\code{'cv'}}
#'     \item{\code{'stratified_cv'}}
#'     \item{\code{'bootstrap'}}
#'     \item{\code{'stratified_bootstrap'}}}
#'  If no value is specified for this parameter,
#'  then no model evaluation or parameter selection will be activated.\cr
#'  No default value.
#' @param repeat.times \code{integer, optional}\cr
#' Specify repeat times for resampling.\cr
#' Defaults to 1.
#' @param param.search.strategy \code{character, optional}\cr
#' Specify value to this parameter to active parameter selection.
#'  \itemize{
#'     \item{\code{'grid'}}
#'     \item{\code{'random'}}}
#' If this parameter is not set, then only model evaluation is activated.\cr
#' No default value.
#' @param random.search.times \code{integer, optional}\cr
#' Specify times to randomly select candidate parameters for selection.\cr
#' Mandatory and valid when \code{param.search.strategy} is set to 'random'.\cr
#' No default value.
#' @param timeout \code{integer, optional}\cr
#' Specify maximum running time for model evaluation or parameter selection,
#' in seconds. No timeout when 0 is specified.\cr
#' Defaults to 0.
#' @param progress.indicator.id \code{character, optional}\cr
#' Set an ID of progress indicator for model evaluation or parameter selection.
#' No progress indicator will be active if no value is provided.\cr
#' No default value.
#' @param  calculate.importance   \code{logical, optional}\cr
#' Determines whether to calculate variable importance.\cr
#' Defaults to TRUE.
#' @param  calculate.cm   \code{logical, optional}\cr
#' Determines whether to calculate confusion matrix.\cr
#' Defaults to TURE.
#' @param   base.score  \code{double, optional}\cr
#' Initial prediction score for all instances.
#' Global bias for sufficient number
#' of iterations(changing this value will not have too much effect).\cr
#' Defaults to 0.5 for binary classification; 0 otherwise.
#' @template args-threadratio-1
#' @template args-cate-var
#' @return
#' A "HGBTClassifier" object with the following attributes:\cr
#'      model  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{ROW_INDEX} - model row index}
#'             \item{\code{TREE_INDEX} -  tree index( -1 indicates the global information.)}
#'             \item{\code{MODEL_CONTENT} - model content}
#'         }
#'
#'      feature.importances \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{VARIABLE_NAME} - Independent variable name}
#'             \item{\code{IMPORTANCE} - Variable importance}
#'         }
#'
#'      confusion.matrix  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{ACTUAL_CLASS} - The actual class name}
#'             \item{\code{PREDICTED_CLASS} -  The predicted class name}
#'             \item{\code{COUNT} - Number of records}
#'         }
#'
#'      stats   \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{STAT_NAME} - Statistics name}
#'             \item{\code{STAT_VALUE} -  Statistics value}
#'         }
#'
#'      cv   \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{PARM_NAME} - parameter name}
#'             \item{\code{INT_VALUE} -  integer value}
#'             \item{\code{DOUBLE_VALUE} - double value}
#'             \item{\code{STRING_VALUE} - character value}
#'         }

#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'     ATT1  ATT2   ATT3  ATT4 LABEL
#' 1   1.0  10.0  100.0   1.0     A
#' 2   1.1  10.1  100.0   1.0     A
#' 3   1.2  10.2  100.0   1.0     A
#' 4   1.3  10.4  100.0   1.0     A
#' 5   1.2  10.3  100.0   1.0     A
#' 6   4.0  40.0  400.0   4.0     B
#' 7   4.1  40.1  400.0   4.0     B
#' }
#' Call the function:
#' \preformatted{
#' > ghc <- hanaml.HGBTClassifier(data = data,
#'                               features = c('ATT1', 'ATT2', 'ATT3', 'ATT4'),
#'                               label = 'LABEL',
#'                               n.estimators = 4, split.threshold = 0,
#'                               learning.rate = 0.5, fold.num = 5, max.depth = 6,
#'                               evaluation.metric = 'error.rate', reference.metric = c('auc'),
#'                               parameter.range = list("learning.rate" = c(0.1, 1.0, 3),
#'                                                        "n.estimators" = c(4, 3, 10),
#'                                                        "split.threshold" = c(0.1, 0.3, 1.0)))
#' }
#' Output:
#' \preformatted{
#' > ghc.stats$Collect()
#'
#'          STAT_NAME STAT_VALUE
#' 1  ERROR_RATE_MEAN   0.133333
#' 2   ERROR_RATE_VAR  0.0266666
#' 3         AUC_MEAN        0.9
#'
#' }
#' @keywords Classification
#' @export
hanaml.HGBTClassifier <- function(data = NULL,
                                  key = NULL,
                                  features = NULL,
                                  label = NULL,
                                  formula = NULL,
                                  n.estimators = NULL,
                                  random.state = NULL,
                                  subsample = NULL,
                                  max.depth = NULL,
                                  split.threshold = NULL,
                                  learning.rate = NULL,
                                  split.method = NULL,
                                  sketch.eps = NULL,
                                  fold.num = NULL,
                                  min.sample.weight.leaf = NULL,
                                  min.samples.leaf = NULL,
                                  max.w.in.split = NULL,
                                  col.subsample.split = NULL,
                                  col.subsample.tree = NULL,
                                  lambda = NULL,
                                  alpha = NULL,
                                  adopt.prior = NULL,
                                  evaluation.metric = NULL,
                                  reference.metric = NULL,
                                  parameter.range = NULL,
                                  parameter.values = NULL,
                                  resampling.method = NULL,
                                  repeat.times = NULL,
                                  param.search.strategy = NULL,
                                  random.search.times = NULL,
                                  timeout = NULL,
                                  progress.indicator.id = NULL,
                                  calculate.importance = NULL,
                                  calculate.cm = NULL,
                                  base.score = NULL,
                                  thread.ratio = NULL,
                                  categorical.variable = NULL){
  HGBTClassifier$new(0, data, key, features, label, formula,
                     n.estimators, random.state,
                     subsample, max.depth, split.threshold, learning.rate, split.method,
                     sketch.eps, fold.num, min.sample.weight.leaf, min.samples.leaf,
                     max.w.in.split, col.subsample.split, col.subsample.tree, lambda,
                     alpha, adopt.prior,  evaluation.metric, reference.metric, parameter.range,
                     parameter.values, resampling.method, repeat.times, param.search.strategy,
                     random.search.times, timeout, progress.indicator.id,
                     calculate.importance, calculate.cm, base.score, thread.ratio,
                     categorical.variable)
}

#' @title Make Predictions from a "HGBTClassifier" Object
#' @name predict.HGBTClassifier
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "HGBTClassifier" object.
#' @seealso \code{\link{hanaml.HGBTClassifier}}
#' @format \code{\link{S3}} methods
#' @param  model \code{R6Class}\cr
#'  A "HGBTClassifier" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param   missing.replacement   \code{character, optional}\cr
#'  The missing replacement strategy:
#' \itemize{
#'     \item {\code{feature.marginalized}: marginalize each missing feature out independently.}
#'     \item {\code{instance.marginalized}: marginalize all missing features in
#'              an instance as a whole corr}}
#' @template args-verbose
#' @template args-threadratio-1
#' @return
#' \code{Dataframe}\cr
#' Prediction result, structured as follows:
#' \itemize{
#'     \item{\code{ID, integer} - ID column, with the same name and type as df's ID column}
#'      \item{\code{SCORE, NVARCHAR(100)} - representing the predicted classes.}
#'      \item{\code{CONFIDENCE, double} - representing the confidence of
#'                                          a class label assignment.}}
#'
#' @section Examples:
#' Performing predict() on given DataFrame:
#' \preformatted{
#' > df$Collect()
#'   ID  ATT1   ATT2  ATT3 ATT4
#' 1  1   1.0   10.0   100    1
#' 2  2   1.1   10.1   100    1
#' 3  3   1.2   10.2   100    1
#' 4  4   1.3   10.4   100    1
#' 5  5   1.2   10.3   100    3
#' 6  6   4.0   40.0   400    3
#' 7  7   4.1   40.1   400    3
#' 8  8   4.2   40.2   400    3
#' 9  9   4.3   40.4   400    3
#' 10 10  4.2   40.3   400    3
#' }
#' Call the function:
#' \preformatted{
#' > result <- predict.HGBTClassifier(ghc, df, key = 'ID', verbose = FALSE)
#' or
#' > result <- predict(ghc, df, key = 'ID', verbose = FALSE)
#' }
#'
#' Output:
#' \preformatted{
#' > result$Collect()
#'    ID  SCORE  CONFIDENCE
#' 1   1      A    0.852674
#' 2   2      A    0.852674
#' 3   3      A    0.852674
#' 4   4      A    0.852674
#' 5   5      A    0.751394
#' 6   6      B    0.703119
#' 7   7      B    0.703119
#' 8   8      B    0.703119
#' 9   9      B    0.830549
#' 10 10      B    0.703119
#' }
#' @keywords Classification
#' @export
predict.HGBTClassifier <- function(model,
                                   data,
                                   key,
                                   features = NULL,
                                   verbose = NULL,
                                   thread.ratio = NULL,
                                   missing.replacement = NULL){
  model$predict(data = data,
                key = key,
                features = features,
                thread.ratio = thread.ratio,
                missing.replacement = missing.replacement)
}


HGBTRegressor <- R6Class(
  "HGBTRegressor",
  inherit = HGBTBaseClass,
  public = list(
    score = function(data,
                     key,
                     features = NULL,
                     label = NULL,
                     verbose = NULL,
                     missing.replacement = NULL,
                     thread.ratio = NULL) {
      if (is.null(self$model)){
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")){
        msg <- "Data for prediction must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      conn.context <- data$connection.context
      cols <- data$columns
      key <- validateInput("key", key, cols,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols,
                             case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      if (is.null(features))
        features <- cols
      verbose <- validateInput("verbose", verbose, "logical")
      missing.replacement <- validateInput("missing.replacement",
                                           missing.replacement,
                                           self$missing.replace.map)
      thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
      prediction <- self$predict(data, key = key, features = features,
                                 verbose = verbose,
                                 missing.replacement = missing.replacement,
                                 thread.ratio = thread.ratio)
      original <- data$Select(list(key, label))
      prediction <- prediction$Select(list(key, "SCORE"))
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      original <- data$Select(list(key, label))
      original <- original$rename.columns(list("ID_A", "ACTUAL"))
      joined <- original$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      r2.score <- r2.score(conn.context,
                           joined,
                           label.true = "ACTUAL",
                           label.pred = "PREDICTION")
      return(r2.score)
    }
  )
)
#' @title Hybrid Gradient Boosting Tree (HGBT) Regressor
#' @name hanaml.HGBTRegressor
#' @description hanaml.HGBTRegressor is a R wrapper for SAP HANA PAL HGBT.
#' @seealso \code{\link{predict.HGBTRegressor}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @param  n.estimators \code{integer, optional}\cr
#' Total iteration number, which is equivalent to the number of trees in the final model. \cr
#' Defaults to 10.
#' @param  random.state \code{integer, optional}\cr
#' The seed for random number generating.\cr
#' 0 - current time as seed.\cr
#' Others - the seed.\cr
#' Defaults to 0.
#' @param subsample \code{double, optional}\cr
#' The sample rate of row (data points).\cr
#' Defaults to 1.0.
#' @param  max.depth \code{integer, optional}\cr
#' The maximum depth of a tree.\cr
#' Defaults to 6.
#' @param  split.threshold \code{double, optional}\cr
#' The minimum loss change value to make a split in tree growth (gamma in the equation). \cr
#' Default to 0.
#' @param  learning.rate \code{double, optional.}\cr
#' Learning rate of each iteration, must be within the range (0, 1).\cr
#' Defaults to 0.3.
#' @param  split.method \code{('exact', 'sketch', 'sampling'), optional}\cr
#' The method to finding split point for integral features.
#' \itemize{
#'  \item{'exact'} : trying all possible points.
#'  \item{'sketch'} : accounting for the distribution of the sum of hessian.
#'  \item{'sampling'} : samples the split point randomly.
#' }
#' The exact method comparably has the highest test accuracy, but costs more time.
#' On the other hand, the other two methods have relative higher computational efficiency but might
#' lead to lower test accuracy, and are considered to be adopted as the training data set is huge.\cr
#' Valid only for integer features.\cr
#' Defaults to 'exact'.
#' @param sketch.eps \code{double, optional}\cr
#' The epsilon of the sketch method.
#' It indicates that the sum of hessian between two split points is not larger than this value.
#' That is, the number of bins is approximately 1/eps.\cr
#' The less is this value, the more split points are tried.\cr
#' Defaults to 0.1.
#' @param  fold.num \code{integer, optional}\cr
#' Specify fold number for cross validation method.\cr
#' Mandatory and valid only when resampling.method is set to cv or stratified_cv.\cr
#' No default value.
#' @param  min.sample.weight.leaf \code{double, optional}\cr
#' The minimum summation of sample weights (hessian) in leaf node.\cr
#' Defaults to 1.0.
#' @param  min.samples.leaf \code{integer, optional}\cr
#' The minimum number of data in a leaf node.\cr
#' Defaults to 1.
#' @param  max.w.in.split \code{double, optional}\cr
#' The maximum weight constraint assigned to each tree node.\cr
#' Defaults to 0 (i.e. no constraint).
#' @param col.subsample.split \code{double, optional}\cr
#' The fraction of features used for each split,
#' should be within range (0, 1].\cr
#' Defaults to 1.0.
#' @param col.subsample.tree \code{double, optional}\cr
#' The fraction of features used for each tree
#' growth, should be within range (0, 1]\cr
#' Defaults to 1.0.
#' @param  lambda \code{double, optional}\cr
#' Weight of L2 regularization for the target loss function.
#' Should be within range [0, 1].\cr
#' Defaults to 1.0.
#' @param  alpha \code{double, optional}\cr
#' Weight of L1 regularization for the target loss function.\cr
#' Defaults to 1.0.
#' @param adopt.prior \code{logical, optional}\cr
#' Indicates whether to adopt the prior distribution as the initial point.
#' To be specific, use average value if it is a regression problem, and use frequencies of labels if it is a classification problem.
#' \emph{base.score} is ignored if this parameter is set to TRUE.\cr
#' Defaults to FALSE.
#' @param evaluation.metric   \code{character, optional}\cr
#' Specify evaluation metric for model evaluation or parameter selection.\cr
#' Valid values include: 'rmse', 'mae'.\cr
#' It is mandatory if \code{resampling.method} is set.\cr
#' No default value.
#' @param  reference.metric \code{character or list of characters, optional}\cr
#' A list of reference metrics.\cr
#' Any element of the list must be a valid option of evaluation.metric.\cr
#' No default value.
#' @param parameter.range    \code{list, optional}\cr
#' Indicates the range of parameters for selection.\cr
#' Each element is a vector of numbers with the following structure:
#' c(<begin-value>, <step-size>, <end-value>).
#' All elements must be named, with names being the following valid parameters for model selection:\cr
#' n.estimators, max.depth, learning.rate,
#' min.sample.weight.leaf, max.w.in.split, col.subsample.split, col.subsample.tree,
#' lambda, alpha, scale.pos.w, base.score.
#' Simple example for illustration - a list of two vectors:\cr
#' list(n.estimators = c(4, 2, 10),
#'      learning.rate = c(0.1, 0.3, 1))\cr
#' Valid only when parameter selection is activated.
#' @param parameter.values  \code{list, optional}\cr
#' Indicates the values of parameters selection.\cr
#' Each element must be a vector of valid parameter values.\cr
#' All elements must be named, with names being the following valid parameters for model selection:\cr
#' n.estimators, max.depth, learning.rate,
#' min.sample.weight.leaf, max.w.in.split, col.subsample.split, col.subsample.tree,
#' lambda, alpha, scale.pos.w, base.score.
#' Simple example for illustration - a list of two vectors\cr
#' list(n.estimators = c(4, 5, 6),
#'      learning.rate = c(2.0, 2.5, 3))
#' Valid only when parameter selection is activated.
#' @param resampling.method \code{character, optional}\cr
#'  Specify resampling method for model evaluation or parameter selection.
#'  \itemize{
#'     \item{\code{'cv'}}
#'     \item{\code{'stratified_cv'}}
#'     \item{\code{'bootstrap'}}
#'     \item{\code{'stratified_bootstrap'}}}
#'  If no value is specified for this parameter,
#'  then no model evaluation or parameter selection will be activated.\cr
#'  No default value.
#' @param repeat.times \code{integer, optional}\cr
#' Specify repeat times for resampling.\cr
#' Defaults to 1.
#' @param param.search.strategy \code{character, optional}\cr
#' Specify value to this parameter to active parameter selection.
#'  \itemize{
#'     \item{\code{'grid'}}
#'     \item{\code{'random'}}}
#' If this parameter is not set, then only model evaluation is activated.\cr
#' No default value.
#' @param random.search.times \code{integer, optional}\cr
#' Specify times to randomly select candidate parameters for selection.\cr
#' Mandatory and valid when \code{param.search.strategy} is set to 'random'.\cr
#' No default value.
#' @param timeout \code{integer, optional}\cr
#' Specify maximum running time for model evaluation or parameter selection,
#' in seconds. No timeout when 0 is specified.\cr
#' Defaults to 0.
#' @param progress.indicator.id \code{character, optional}\cr
#' Set an ID of progress indicator for model evaluation or parameter selection.
#' No progress indicator will be active if no value is provided.\cr
#' No default value.
#' @param  calculate.importance   \code{logical, optional}\cr
#' Determines whether to calculate variable importance.\cr
#' Defaults to TRUE.
#' @param   base.score  \code{double, optional}\cr
#' Initial prediction score for all instances.
#' Global bias for sufficient number
#' of iterations(changing this value will not have too much effect).\cr
#' Defaults to 0.5 for binary classification; 0 otherwise.
#' @template args-threadratio-1
#' @template args-cate-var
#' @return
#' An "HGBTRegressor" object with the following attributes:\cr
#'      model: \code{ DataFrame}
#'          \itemize{
#'             \item{\code{ROW_INDEX} - model row index}
#'             \item{\code{TREE_INDEX} -  tree index( -1 indicates the global information.)}
#'             \item{\code{MODEL_CONTENT} - model content}
#'         }
#'
#'      feature.importances \code{DataFrame}
#'          \itemize{
#'             \item{\code{VARIABLE_NAME} - Independent variable name}
#'             \item{\code{IMPORTANCE} - Variable importance}
#'         }
#'
#'
#'      stats  \code{DataFrame}
#'          \itemize{
#'             \item{\code{STAT_NAME} - Statistics name}
#'             \item{\code{STAT_VALUE} -  Statistics value}
#'         }
#'
#'      cv  \code{DataFrame}
#'          \itemize{
#'             \item{\code{PARM_NAME} - parameter name}
#'             \item{\code{INT_VALUE} -  integer value}
#'             \item{\code{DOUBLE_VALUE} - double value}
#'             \item{\code{STRING_VALUE} - character value}
#'         }
#'
#' @section Examples:
#' Input DataFrame data for training:
#' \preformatted{
#' > data$Collect()
#'     ATT1     ATT2    ATT3    ATT4  TARGET
#' 1  19.76   6235.0  100.00  100.00   25.10
#' 2  17.85  46230.0   43.67   84.53   19.23
#' 3  19.96   7360.0   65.51   81.57   21.42
#' 4  16.80  28715.0   45.16   93.33   18.11
#' 5  18.20  21934.0   49.20   83.07   19.24
#' 6  16.71   1337.0   74.84   94.99   19.31
#' 7  18.81  17881.0   70.66   92.34   20.07
#' }
#' Call the function:
#' \preformatted{
#' > hgr <- HGBTRegressor(data,
#'                        features = c('ATT1','ATT2','ATT3', 'ATT4'),
#'                        label = "TARGET",
#'                        n.estimators = 20, split.threshold = 0.75,
#'                        split.method = 'exact', learning.rate = 0.75,
#'                        fold.num = 5, max.depth = 6,
#'                        evaluation.metric = 'rmse', reference.metric = c('mae'),
#'                        parameter.range = list("learning.rate" = c(0.25, 1.0, 4),
#'                                               "n.estimators" = c(10, 1, 20),
#'                                               "split.threshold" = c(0.0, 0.2, 1.0)))
#' }
#' Output:
#' \preformatted{
#' > hgr$feature.importances$Collect()
#'   VARIABLE_NAME  IMPORTANCE
#' 1          ATT1    0.744019
#' 2          ATT2    0.164429
#' 3          ATT3    0.078935
#' 4          ATT4    0.012617
#' }
#' @keywords Regression
#' @export
hanaml.HGBTRegressor <- function(data = NULL,
                                 key = NULL,
                                 features = NULL,
                                 label = NULL,
                                 formula = NULL,
                                 n.estimators = NULL,
                                 random.state = NULL,
                                 subsample = NULL,
                                 max.depth = NULL,
                                 split.threshold = NULL,
                                 learning.rate = NULL,
                                 split.method = NULL,
                                 sketch.eps = NULL,
                                 fold.num = NULL,
                                 min.sample.weight.leaf = NULL,
                                 min.samples.leaf = NULL,
                                 max.w.in.split = NULL,
                                 col.subsample.split = NULL,
                                 col.subsample.tree = NULL,
                                 lambda = NULL,
                                 alpha = NULL,
                                 adopt.prior = NULL,
                                 evaluation.metric = NULL,
                                 reference.metric = NULL,
                                 parameter.range = NULL,
                                 parameter.values = NULL,
                                 resampling.method = NULL,
                                 repeat.times = NULL,
                                 param.search.strategy = NULL,
                                 random.search.times = NULL,
                                 timeout = NULL,
                                 progress.indicator.id = NULL,
                                 calculate.importance = NULL,
                                 base.score = NULL,
                                 thread.ratio = NULL,
                                 categorical.variable = NULL){
  HGBTRegressor$new(1, data, key, features, label, formula,
                    n.estimators, random.state,
                    subsample, max.depth, split.threshold, learning.rate, split.method,
                    sketch.eps, fold.num, min.sample.weight.leaf, min.samples.leaf,
                    max.w.in.split, col.subsample.split, col.subsample.tree, lambda,
                    alpha, adopt.prior, evaluation.metric, reference.metric, parameter.range,
                    parameter.values, resampling.method, repeat.times, param.search.strategy,
                    random.search.times, timeout, progress.indicator.id,
                    calculate.importance, NULL, base.score, thread.ratio,
                    categorical.variable)
}


#' @title Make Predictions from an "HGBTRegressor" Object
#' @name predict.HGBTRegressor
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "HGBTRegressor" object.
#' @seealso \code{\link{hanaml.HGBTRegressor}}
#' @format \code{\link{S3}} methods
#' @param  model \code{R6Class object}\cr
#'  An "HGBTRegressor" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-threadratio-1
#' @param missing.replacement   \code{character, optional}\cr
#'   The missing replacement strategy:
#' \itemize{
#'    \item {\code{feature.marginalized}- marginalise each missing feature out independently.}
#'    \item {\code{instance.marginalized} marginalise all missing features
#'    in an instance as a whole corr}
#' }
#' @param ... Reserved parameter.
#' @return
#'  \code{DataFrame}\cr
#'    DataFrame containing the prediction result, structured as follows:\cr
#'  \itemize{
#'      \item{\code{ID, INTEGER} - ID column, with the same name and type as df's ID column}
#'      \item{\code{SCORE, NVARCHAR} - representing the predicted values.}
#'      \item{\code{CONFIDENCE, DOUBLE} - representing the confidence of
#'                                           a class label assignment.}
#'          }
#' @section Examples:
#' Input DataFrame df:
#' \preformatted{
#'  > df.predict$Collect()
#'     ID   ATT1     ATT2    ATT3    ATT4
#'  1   1  19.76   6235.0  100.00  100.00
#'  2   2  17.85  46230.0   43.67   84.53
#'  3   3  19.96   7360.0   65.51   81.57
#'  4   4  16.80  28715.0   45.16   93.33
#'  5   5  18.20  21934.0   49.20   83.07
#'  6   6  16.71   1337.0   74.84   94.99
#'  7   7  18.81  17881.0   70.66   92.34
#'  8   8  20.74   2319.0   63.93   95.08
#'  9   9  16.56  18040.0   14.45   61.24
#'  10 10  18.55   1147.0   68.58   97.90
#' }
#'  Call the function and predict with a "HGBTRegressor" object hgr:
#' \preformatted{
#'  > result <- predict(hgr, df.predict, key = 'ID')
#'  > result$Collect()
#'     ID               SCORE   CONFIDENCE
#'  1   1   23.79109147050638           NA
#'  2   2   19.09572889593064           NA
#'  3   3   21.56501359501561           NA
#'  4   4  18.622664075787082           NA
#'  5   5   19.05159916592106           NA
#'  6   6  18.815530665858763           NA
#'  7   7  19.761714911364443           NA
#'  8   8   23.79109147050638           NA
#'  9   9   17.84416828725911           NA
#'  10 10  19.915574945518465           NA
#' }
#' @keywords Regression
#' @export
predict.HGBTRegressor <- function(model,
                                  data,
                                  key,
                                  features = NULL,
                                  thread.ratio = NULL,
                                  missing.replacement = NULL,
                                  ...){
   model$predict(data = data,
                 key = key,
                 features = features,
                 thread.ratio = thread.ratio,
                 missing.replacement = missing.replacement)
}
