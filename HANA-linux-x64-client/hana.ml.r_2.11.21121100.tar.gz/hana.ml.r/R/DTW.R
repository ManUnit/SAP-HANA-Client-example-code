#' @title Generic Dynamic Time Warping
#' @name hanaml.DTW
#' @description hanaml.DTW is a R wrapper
#' for SAP HANA PAL DTW.\cr
#' @details
#' Dynamic Time Warping is a method for measuring similarity between two
#' time series, which may vary in their speed, it makes one series match the other one
#' as much as possible by stretching or compressing one or both series.
#' It can be used for pattern matching and anomaly detection.\cr
#' @param query.data \code{DataFrame}\cr
#' DataFrame containting the time-series data for query, expected to be structured as follows:
#' \itemize{
#'   \item{1st column: ID of query series, type \code{INTEGER, VARCHAR or NVARCHAR}}\cr
#'   \item{2nd column: Order of time series, type \code{INTEGER, VARCHAR or NVARCHAR}}\cr
#'   \item{Other columns: Series data, type \code{INTEGER, DOUBLE or DECIMAL(p,s)}}
#'   }
#' @param ref.data \code{DataFrame}\cr
#' \itemize{
#'   \item{1st column: ID of query series, type \code{INTEGER, VARCHAR or NVARCHAR}}\cr
#'   \item{2nd column: Order of time series, type \code{INTEGER, VARCHAR or NVARCHAR}}\cr
#'   \item{Other columns: Series data, type \code{INTEGER, DOUBLE or DECIMAL(p,s)}}
#'  }
#' \code{ref.data} must have the same number of columns as \code{query.data}.
#' @template args-threadratio-1
#' @param     radius \code{integer, optional}\cr
#'            A constraint to restrict match curve in an area near diagonal.\cr
#'            -1 means no such constraint, otherwise the number must be nonnegative.\cr
#'            By setting this constraint, users may get suboptimal result in exchange for runtime reduction.\cr
#'            Inappropriate setting of this value may lead to no result
#'            at all(e.g. set to 0 for two time-series of different sizes).\cr
#'            Defaults to -1.
#' @param      distance.level \code{c("manhattan", "euclidean", "minkowski",
#' "chebyshev", "cosine"), optional}\cr
#'            Specifies the method used to compute distance between two points.
#'            \itemize{
#'                \item{\code{"manhattan"} Manhattan distance(l1 norm)}
#'                \item{\code{"euclidean"} Euclidean distance(l2 norm)}
#'                \item{\code{"minkowski"} Minkowski distance(p-norm)}
#'                \item{\code{"chebyshev"} Chebyshev distance(maximum norm)}
#'                \item{\code{"cosine"} Cosine distance}
#'            }
#'            Defaults to "euclidean".
#' @param      minkowski.power \code{double, optional}\cr
#'            Only valid when \code{distance.level} is "minkowski".\cr
#'            Specifies the power value of Minkowski p-norm.\cr
#'            Defaults to 3.0.
#' @param     alignment.method \code{character, optional}\cr
#'            Specifies the alignment method for begin/end points of time-series.\cr
#'            Valid optional include:
#'            \itemize{
#'              \item{\code{"closed"}: both begin and end points must be aligned.}
#'              \item{\code{"open_end"}: only begin point needs to be aligned.}
#'              \item{\code{"open_begin"}: only end point needs to be aligned.}
#'              \item{\code{"open"}: neither begin or end point needs to be aligned.}
#'            }
#'            Defaults to "closed".
#' @param     step.pattern \code{integer or list}
#'            Specifies the step pattern for DTW calculation.\cr
#'            Integers refer to pre-defined steps patterns, ranging from 1 to 5.\cr
#'            Lists are for custom defined step patterns, where each element is a step.\cr
#'            For example, the predefined step pattern 1 can be written in custom defined step
#'            pattern as follows:\cr
#'            list(c(1,0,1), c(1,1,1), c(0,1,1)),\cr
#'            while predefined step pattern 5 can be written as:\cr
#'            list(c(1,1,1,1,0,1), c(1,1,1), c(1,1,0.5,0,1,0.5)).\cr
#'            \bold{Note}: Each step could be a simple step, or a intricate one composed of several simple steps
#'            executed consecutively. Each simple step is represented by 3 numbers(i.e. a traid),
#'            with the first two numbers representing the movement along the query and reference index
#'            respectively, and the 3rd number representing the weight of this simple step.\cr
#'            Defaults to 3.
#' @param     save.alignment \code{logical, optional}\cr
#'            Specifies whether or not to output
#'            alignment information.\cr
#'            If set to FALSE, the alignment table will be empty.\cr
#'            Defaults to FALSE.
#' @return
#' Returns a list of DataFrames.
#' \itemize{
#'   \item{\code{DataFrame} Result for DTW, structured as follows:
#'   \itemize{
#'     \item{QUERY_<ID column of query data>} : ID of time-series for query.
#'     \item{REF_<ID column of refernece data>} : ID of time-series for reference.
#'     \item{DISTANCE}: DTW distance of the two time-series
#'     \item{WEIGHT}: Total weight of match
#'     \item{AVG_DISTANCE}: Normalized distance of two-series.
#'    }
#'   }
#'   \item{\code{DataFrame} Alignment(optimal match) between input time-series, structured as:
#'   \itemize{
#'     \item{QUERY_<ID column of query data>} : ID of time-series for query
#'     \item{REF_<ID column of reference data>} : ID of time-series for reference.
#'     \item{QUERY_INDEX} : Corresponding to index(timestamp) of query data.
#'     \item{REF_INDEX} : Corresponding to index(timestamp) of reference data.
#'    }
#'  }
#'  \item{\code{DataFrame} Statistics for time series, structured as follows:
#'  \itemize{
#'    \item{STAT_NAME} : Statistics name
#'    \item{STAT_VALUE} : Statistics value
#'   }
#'   }
#'  }
#'
#'
#' @section Examples:
#' Input DataFrame:
#' \preformatted{
#' > query.data$Collect()
#'    ID TIMESTAMP ATTR1 ATTR2
#' 1   1         1     1   5.2
#' 2   1         2     2   5.1
#' 3   1         3     3   2.0
#' 4   1         4     4   0.3
#' 5   1         5     5   1.2
#' 6   1         6     6   7.7
#' 7   1         7     7   0.0
#' 8   1         8     8   1.1
#' 9   1         9     9   3.2
#' 10  1        10    10   2.3
#' 11  2         1     7   2.0
#' 12  2         2     6   1.4
#' 13  2         3     1   0.9
#' 14  2         4     3   1.2
#' 15  2         5     2  10.2
#' 16  2         6     5   2.3
#' 17  2         7     4   4.5
#' 18  2         8     3   4.6
#' 19  2         9     3   3.5
#'
#' > ref.data$Collect()
#'    ID TIMESTAMP ATTR1 ATTR2
#' 1   3         1    10   1.0
#' 2   3         2     5   2.0
#' 3   3         3     2   3.0
#' 4   3         4     8   1.4
#' 5   3         5     1  10.8
#' 6   3         6     5   7.7
#' 7   3         7     5   6.3
#' 8   3         8    12   2.4
#' 9   3         9    20   9.4
#' 10  3        10     4   0.5
#' 11  3        11     6   2.2
#' }
#' Call the function:
#' \preformatted{
#' > output <- hanaml.DTW(query.data,
#'                        ref.data,
#'                        radius = -1,
#'                        thread.ratio = 1,
#'                        distance.level = "euclidean",
#'                        step.pattern = list(c(1,1,1,1,0,1),
#'                                            c(1,1,1),
#'                                            c(1,1,0.5,0,1,0.5)),
#'                        alignment.method = "closed",
#'                        save.alignment = TRUE)
#' }
#' Results:
#' \preformatted{
#' > output[["alignment"]]$Collect()
#'    QUERY_ID REF_ID QUERY_INDEX REF_INDEX
#' 1         1      3           0         0
#' 2         1      3           1         1
#' 3         1      3           2         2
#' 4         1      3           3         2
#' 5         1      3           4         3
#' 6         1      3           5         4
#' 7         1      3           5         5
#' 8         1      3           6         6
#' 9         1      3           6         7
#' 10        1      3           7         8
#' 11        1      3           7         9
#' 12        1      3           8        10
#' 13        1      3           9        10
#' 14        2      3           0         0
#' 15        2      3           1         1
#' 16        2      3           2         2
#' 17        2      3           3         3
#' 18        2      3           4         4
#' 19        2      3           4         5
#' 20        2      3           5         6
#' 21        2      3           6         6
#' 22        2      3           7         7
#' 23        2      3           7         8
#' 24        2      3           8         9
#' 25        2      3           8        10
#' }
#' @keywords TimeSeries
#' @export
hanaml.DTW <- function(
  query.data,
  ref.data,
  radius = NULL,
  distance.level = NULL,
  minkowski.power = NULL,
  alignment.method = NULL,
  step.pattern = NULL,
  save.alignment = NULL,
  thread.ratio = NULL) {
  distance.level.map <- list(
    "manhattan" = 1,
    "euclidean" = 2,
    "minkowski" = 3,
    "chebyshev" = 4,
    "cosine" = 6
  )
  distance.level <- validateInput(
    "distance.level", distance.level, distance.level.map)
  radius <- validateInput("radius", radius, "integer")
  minkowski.power  <- validateInput("minkowski.power",
                                    minkowski.power,
                                    "numeric")
  alignment.list <- list(closed = "CLOSED",
                         open_begin = "OPEN_BEGIN",
                         open_end = "OPEN_END",
                         open = "OPEN")
  alignment.method <- validateInput("alignment.method", alignment.method,
                                    alignment.list)
  step.pattern <- validateInput("step.pattern", step.pattern, c("integer",
                                                                "numeric",
                                                                "list"))
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
  save.alignment <- validateInput("save.alignment",
                                  save.alignment,
                                  "logical")
  if (!(inherits(query.data, "DataFrame") && inherits(ref.data, "DataFrame"))) {#nolint
    msg <- "Query data and reference data must be given as DataFrames."
    flog.error(msg)
    stop(msg)
  }
  conn <- query.data$connection.context
  CheckConnection(query.data)
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_DTW_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_DTW_RESULT_TBL_%s", unique.id)
  alignment.tbl <- sprintf("#PAL_DTW_ALIGNMENT_TBL_%s", unique.id)
  stat.tbl <- sprintf("#PAL_DTW_STAT_TBL_%s", unique.id)
  in.tables <- list(query.data, ref.data, param.tbl)
  out.tables <- list(result.tbl, alignment.tbl, stat.tbl)
  tables <- c(param.tbl, out.tables)
  param.array <- list(tuple("WINDOW", radius, NULL, NULL),
                      tuple("DISTANCE_METHOD",
                            map.null(distance.level, distance.level.map),
                            NULL, NULL),
                      tuple("MINKOWSKI_POWER", NULL, minkowski.power, NULL),
                      tuple("BEGIN_END_ALIGNMENT", NULL, NULL,
                            map.null(alignment.method, alignment.list)),
                      tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
                      tuple("SAVE_ALIGNMENT", to.integer(save.alignment),
                            NULL, NULL))
  if (!is.null(step.pattern)) {
    if (inherits(step.pattern, c("numeric", "integer"))) {
      param.array <- c(param.array,
                       list(tuple("STEP_PATTERN_TYPE", step.pattern,
                                  NULL, NULL)))
    } else {
      for (step in step.pattern) {
        step.len <- length(step)
        no.base.step <- step.len / 3
        stp <- ""
        for (i in c(1:no.base.step)) {
          stp <- paste(stp, "(",
                       paste(step[(3 * i - 2):(i * 3)],
                             collapse = ","),
                       ifelse(i == no.base.step, ")", "),"),
                       sep = "")
        }
        tp <- tuple("STEP_PATTERN", NULL, NULL, stp)
        param.array <- c(param.array, list(tp))
      }
    }
  }
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn, ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_DTW",
                                          in.tables,
                                          out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  output <- lapply(out.tables, conn$table)
  names(output) <- c("result", "alignment", "statistics")
  return(output)
}
