FRM <- R6Class(
  "FRM",
  inherit = MlBase,
  public = list(
    model = NULL,
    iter.info = NULL,
    stat = NULL,
    optim.param = NULL,
    #param.array = NULL,
    solver = NULL,
    factor.num = NULL,
    init.variance = NULL,
    random.state = NULL,
    learning.rate = NULL,
    linear.lambda = NULL,
    poly2.lambda = NULL,
    max.iter = NULL,
    sgd.tol = NULL,
    sgd.exit.interval = NULL,
    momentum = NULL,
    thread.ratio = NULL,
    resampling.method = NULL,
    evaluation.metric = NULL,
    fold.num = NULL,
    param.search.strategy = NULL,
    repeat.times = NULL,
    progress.indicator.id = NULL,
    random.search.times = NULL,
    timeout = NULL,
    solver.map = list(
      "sgd" = 0,
      "momentum" = 1,
      "nag" = 2,
      "adagrad" = 3
    ),
    resampling.list = list(bootstrap = "bootstrap", cv = "cv"),
    search.strategy.list = list(grid = "grid", random = "random"),
    metric.list = list(rmse = "RMSE"),
    range.name.map = list(factor.num = "FACTOR_NUMBER_RANGE",
                          linear.lambda = "LINEAR_REGULARIZATION_RANGE",
                          poly2.lambda = "REGULARIZATION_RANGE",
                          momentum = "MOMENTUM_RANGE"),
    values.name.map = list(factor.num = "FACTOR_NUMBER_VALUES",
                           linear.lambda = "LINEAR_REGULARIZATION_VALUES",
                           poly2.lambda = "REGULARIZATION_VALUES",
                           momentum = "MOMENTUM_VALUES"),
    initialize = function(
      data = NULL,
      key = NULL,
      user.info = NULL,
      item.info = NULL,
      categorical.variable = NULL,
      user.categorical.variable = NULL,
      item.categorical.variable = NULL,
      solver = NULL,
      factor.num = NULL,
      init.variance = NULL,
      random.state = NULL,
      learning.rate = NULL,
      linear.lambda = NULL,
      poly2.lambda = NULL,
      max.iter = NULL,
      sgd.tol = NULL,
      sgd.exit.interval = NULL,
      momentum = NULL,
      thread.ratio=NULL,
      resampling.method = NULL,
      evaluation.metric = NULL,
      fold.num = NULL,
      param.search.strategy = NULL,
      repeat.times= NULL,
      progress.indicator.id = NULL,
      random.search.times = NULL,
      timeout = NULL,
      parameter.values = NULL,
      parameter.range = NULL) {
      super$initialize()
      if (!is.null(data)) {
        cols <- data$columns
        user.cols <- user.info$columns
        item.cols <- item.info$columns
        key <- validateInput("key", key, cols,
                             case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        categorical.variable <- validateInput("categorical.variable",
                                              categorical.variable,
                                              cols,
                                              case.sensitive = TRUE)
        user.categorical.variable <-
          validateInput("user.categorical.variable",
                        user.categorical.variable,
                        user.cols,
                        case.sensitive = TRUE)
        item.categorical.variable <-
          validateInput("item.categorical.variable",
                        item.categorical.variable,
                        item.cols,
                        case.sensitive = TRUE)
        if (!is.null(thread.ratio)) {
          self$thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                             "numeric")
          if (thread.ratio < 0 || thread.ratio > 1) {
            msg <- "The thread.ratio value range is from 0 to 1!"
            flog.error(msg)
            stop(msg)
          }
        }
        self$solver <- validateInput("solver", solver, self$solver.map)
        self$factor.num <- validateInput("factor.num", factor.num, "integer")
        self$init.variance <- validateInput("init.variance",
                                            init.variance,
                                            "numeric")
        self$random.state <- validateInput("random.state", random.state,
                                           "integer")
        self$learning.rate <- validateInput("learning.rate", learning.rate,
                                            "numeric")
        self$linear.lambda <- validateInput("linear.lambda", linear.lambda, "numeric")
        self$poly2.lambda <- validateInput("poly2.lambda", poly2.lambda, "numeric")
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        self$sgd.tol <- validateInput("sgd.tol", sgd.tol, "numeric")
        self$sgd.exit.interval <- validateInput("sgd.exit.interval",
                                                sgd.exit.interval,
                                                "integer")
        self$momentum <- validateInput("momentum", momentum, "numeric")
        private$IsPositiveValue(learning.rate)
        private$IsPositiveValue(linear.lambda)
        private$IsPositiveValue(poly2.lambda)
        private$IsPositiveValue(max.iter)
        private$IsPositiveValue(sgd.tol)
        private$IsPositiveValue(sgd.exit.interval)
        private$IsPositiveValue(momentum)
        param.array <- list(
          tuple("HAS_ID", 0, NULL, NULL),
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple("METHOD", map.null(self$solver,
                                   self$solver.map),
                NULL, NULL),
          tuple("FACTOR_NUMBER", self$factor.num, NULL, NULL),
          tuple("INITIALIZATION", NULL, self$init.variance, NULL),
          tuple("LEARNING_RATE", NULL, self$learning.rate, NULL),
          tuple("MOMENTUM", NULL, self$momentum, NULL),
          tuple("LINEAR_REGULARIZATION", NULL, self$linear.lambda, NULL),
          tuple("REGULARIZATION", NULL, self$poly2.lambda, NULL),
          tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
          tuple("SGD_EXIT_THRESHOLD", NULL, self$sgd.tol, NULL),
          tuple("SGD_EXIT_INTERVAL", self$sgd.exit.interval, NULL, NULL),
          tuple("SEED", self$random.state, NULL, NULL)
        )
        if (!is.null(categorical.variable)) {
          for (var in categorical.variable) {
            param.array <- append(param.array,
                                  list(tuple("CATEGORICAL_VARIABLE",
                                             NULL, NULL,
                                             var)))
          }
        }
        if (!is.null(user.categorical.variable)) {
          for (var in user.categorical.variable) {
            param.array <- append(param.array,
                                  list(tuple("USER_CATEGORICAL_VARIABLE",
                                             NULL, NULL,
                                             var)))
          }
        }
        if (!is.null(item.categorical.variable)) {
          for (var in item.categorical.variable) {
            param.array <- append(param.array,
                                  list(tuple("ITEM_CATEGORICAL_VARIABLE",
                                             NULL, NULL,
                                             var)))
          }
        }
        self$param.search.strategy <-
          validateInput("param.search.strategy",
                        param.search.strategy,
                        self$search.strategy.list)
        self$random.search.times <-
          validateInput("random.search.times",
                        random.search.times,
                        "integer",
                        isTRUE(grepl("random",
                                     self$param.search.strategy)))
        self$resampling.method <- validateInput("resampling.method",
                                                resampling.method,
                                                self$resampling.list)
        self$fold.num <-
          validateInput("fold.num", fold.num,
                        "integer",
                        required = isTRUE(grepl("cv",
                                                self$resampling.method)))

        self$evaluation.metric <- validateInput("evaluation.metric",
                                                evaluation.metric,
                                                self$metric.list)
        self$repeat.times <- validateInput("repeat.times",
                                           repeat.times, "integer")
        self$timeout <- validateInput("timeout", timeout, "integer")
        private$IsPositiveValue(fold.num)
        private$IsPositiveValue(repeat.times)
        private$IsPositiveValue(timeout)
        self$progress.indicator.id <- validateInput("progress.indicator.id",
                                                    progress.indicator.id,
                                                    "character")
        param.search.list <- list("factor.num",
                                  "linear.lambda",
                                  "poly2.lambda",
                                  "momentum")
        if (length(parameter.values) != 0) {
          if (! isTRUE(self$solver %in% c("momentum", "nag")) &&
              "momentum" %in% names(parameter.values)) {
            msg <- paste("Parameter selection for momentum is only possible",
                         "when solver is set as 'momentum' or 'nag'!")
            flog.error(msg)
            stop(msg)
          }
          validateInput("Parameters for values specification",
                        names(parameter.values),
                        param.search.list,
                        case.sensitive = TRUE)
          str.values <- lapply(parameter.values,
                               function(X) paste0(X,
                                                  collapse = ","))
          values <- lapply(X = str.values, a = "{", b = "}",
                           function(X, a, b) paste0(a, X, b))
          values.name <- self$values.name.map[
            names(parameter.values)]
          for (i in c(1:length(parameter.values))){
            param.array <- append(param.array,
                                 list(tuple(values.name[[i]],
                                            NULL, NULL,
                                            values[[i]])))
          }
        }
        if (length(parameter.range) != 0) {
          validateInput("Parameters for range specification",
                        names(parameter.range),
                        param.search.list,
                        case.sensitive = TRUE)
          ranges.length <- lapply(parameter.range, FUN = length)
          invalid.range <- parameter.range[
            !(ranges.length == 2 | ranges.length == 3)]
          if (length(invalid.range) != 0) {
            msg <- sprintf("Length of %s invalid for range specification",
                           paste(names(invalid.range),
                                 collapse = ", "))
            flog.error(msg)
            stop(msg)
          }
          str.range <- lapply(parameter.range,
                              function(X) paste0(X, collapse = ifelse(
                                length(X) == 2, ",,", ",")))
          ranges <- lapply(X = str.range, a = "[", b = "]",
                           function(X, a, b) paste0(a, X, b))
          range.name <- self$range.name.map[
            names(parameter.range)]
          for (i in c(1:length(parameter.range))){
            param.array <- append(param.array,
                                  list(tuple(range.name[[i]],
                                             NULL, NULL,
                                             ranges[[i]])))
          }
        }
        param.ps.array <- list(
          tuple("RESAMPLING_METHOD", NULL, NULL,
                self$resampling.method),
          tuple("EVALUATION_METRIC", NULL, NULL,
                map.null(self$evaluation.metric,
                         self$metric.list)),
          tuple("FOLD_NUM", self$fold.num, NULL, NULL),
          tuple("REPEAT_TIMES", self$repeat.times, NULL, NULL),
          tuple("PARAM_SEARCH_STRATEGY", NULL, NULL,
                self$param.search.strategy),
          tuple("PROGRESS_INDICATOR_ID", NULL, NULL,
                self$progress.indicator.id),
          tuple("TIMEOUT", self$timeout, NULL, NULL),
          tuple("RANDOM_SEARCH_TIMES", self$random.search.times,
                NULL, NULL)
        )
        param.array <- append(param.array, param.ps.array)
        if (!all(sapply(list(parameter.values,
                             parameter.range),
                        is.null)) &&
            any(sapply(list(self$resampling.method,
                            self$param.search.strategy,
                            self$evaluation.metric),
                 is.null))) {
          msg <- paste("parameter.values and parameter.range are ignored",
                       "since parameter search is not activated!")
          flog.warn(msg)
        }
        if (!all(sapply(list(data, user.info, item.info),
                        inherits, what = "DataFrame"))) {
          msg <- "data, user.info and item.info must all be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        conn <- data$connection.context
        CheckConnection(data)
        data <- data$Select(cols)
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_PARAM_TBL_%s_%s", self$id, unique.id)
        model.meta.data.tbl <- sprintf("#PAL_MODEL_META_DATA_TBL_%s_%s",
                                       self$id, unique.id)
        model.tbl <- sprintf("#PAL_MODEL_TBL_%s_%s", self$id, unique.id)
        model.factors.tbl <- sprintf("#PAL_MODEL_FACTORS_TBL_%s_%s",
                                     self$id, unique.id)
        iter.info.tbl <- sprintf("#PAL_ITER_INFO_TBL_%s_%s", self$id, unique.id)
        stat.tbl <- sprintf("#PAL_STAT_TBL_%s_%s", self$id, unique.id)
        optim.param.tbl <- sprintf("#PAL_OPT_PARAM_TBL_%s_%s", self$id, unique.id)
        in.tables <- list(data, user.info, item.info, param.tbl)
        out.tables <- list(model.meta.data.tbl, model.tbl,
                           model.factors.tbl, iter.info.tbl,
                           stat.tbl, optim.param.tbl)
        tables <- c(param.tbl, out.tables)

        tryCatch({
          errorhelper(CreateTWithConnection(conn,
            ParameterTable$new(param.tbl)$WithData(param.array)))#nolint
          errorhelper(CallPalAutoWithConnection(conn,
            "PAL_FRM", in.tables, out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err$message)
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        model.meta.data <- conn$table(model.meta.data.tbl)
        model.data <- conn$table(model.tbl)
        model.factors <- conn$table(model.factors.tbl)
        self$iter.info <- conn$table(iter.info.tbl)
        self$stat <- conn$table(stat.tbl)
        self$optim.param <- conn$table(optim.param.tbl)
        self$model <- list(model.meta.data, model.data, model.factors)
      }
    },
    predict = function(
      data = NULL,
      key = NULL,
      user.info = NULL,
      item.info = NULL,
      thread.ratio = NULL) {
      model.meta.data <- self$model[[1]]
      model.data <- self$model[[2]]
      model.factors <- self$model[[3]]
      cols <- data$columns
      user.cols <- user.info$columns
      item.cols <- item.info$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE,
                           required = TRUE)
      cols <- cols[! cols %in% key]
      thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                    "numeric")
      if (!is.null(thread.ratio)) {
        if (thread.ratio < 0 || thread.ratio > 1) {
          msg <- "The thread.ratio value range is from 0 to 1!"
          flog.error(msg)
          stop(msg)
        }
      }
      param.array <- list(tuple("THREAD_RATIO", NULL,
                                thread.ratio, NULL))
      if (!all(sapply(list(data, user.info, item.info),
                      inherits, what = "DataFrame"))) {
        msg <- "data, user.info and item.info must all be DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)
      data <- data$Select(c(key, cols))
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#PAL_PREDICT_PARAMETER_TBL_%s", unique.id)
      result.tbl <- sprintf("#PAL_RESULT_TBL_%s", unique.id)
      in.tables <- list(data, user.info, item.info, model.meta.data,
                        model.data, model.factors, param.tbl
      )
      out.tables <- list(result.tbl)
      tables <- c(param.tbl, out.tables)
      tryCatch({
        errorhelper(CreateTWithConnection(conn,
          ParameterTable$new(param.tbl)$WithData(param.array)))
        errorhelper(CallPalAutoWithConnection(conn,
          "PAL_FRM_PREDICT", in.tables, out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err$message)
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
      return(conn$table(result.tbl))
    }
  ),
  private = list(
    IsPositiveValue = function(value) {
      if (!is.null(value)) {
        if (inherits(value, "numeric")) {
          if (value < 0) {
            msg <- sprintf("Invalid input! %s is less than 0.",
                           deparse(substitute(param.name)))
            flog.error(msg)
            stop(msg)
          }
        }
      }
    }
  )
)

#' @title Make Predictions from an "FRM" Object
#' @name predict.FRM
#' @seealso \code{\link{hanaml.FRM}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#' A "FRM" object for prediction.
#' @param data \code{DataFrame}\cr
#' DataFrame containting data of user-item interaction and global
#' side features, structured as follows:
#' \itemize{
#'  \item{} Data ID column(optional).
#'  \item{} USER ID column.
#'  \item{} ITEM ID column.
#'  \item{} Side feature columns.
#' }
#' @template args-key-optional
#' @param user.info \code{DataFrame}\cr
#' DataFrame containting information of side features about user,
#' structured as follows:
#' \itemize{
#'  \item{} USER ID column.
#'  \item{} Side feature columns.}
#' @param item.info \code{DataFrame}
#' DataFrame containing information of side features about item,
#' structured as follows:
#' \itemize{
#'  \item{} ITEM ID column.
#'  \item{} Side feature columns.
#' }
#' @template args-threadratio
#'
#' @return
#' \code{DataFrame}\cr
#'  Prediction made by the model, structured as follows:
#'  \itemize{
#'  \item{} ID column
#'  \item{} USER ID column
#'  \item{} ITEM ID column
#'  \item{} Predicted rating value.
#'  }
#'
#' @section Examples:
#' Input DataFrames：
#' \preformatted{
#' > predict.data$Collect()
#'   ID USER     MOVIE TIMESTAMP
#'  1 1    A    Movie3        NA
#'  2 2    A    Movie7         4
#'  3 3    B    Movie1         2
#'  4 4    B    Movie6         3
#'  5 5    C    Movie3         2
#'  6 6    D    Movie2         1
#'  7 7    D    Movie5         3
#'  8 8    E Bad_Movie         2
#'
#' > user.info$Collect()
#'    USER     USER_SIDE_FEATURE
#' 1    NA                    NA
#'
#' > item.info$Head(5)$Collect()
#'    MOVIE  GENRES
#' 1 Movie1  Sci-Fi
#' 2 Movie2  Drama,Romance
#' 3 Movie3  Drama,Sci-Fi
#' 4 Movie4  Crime,Drama
#' 5 Movie5  Crime,Drama
#' }
#'
#' Call the function with a "FRM" object fm:
#' \preformatted{
#' result <- predict(model = fm,
#'                   predict.data = predict.data,
#'                   user.info = user.info,
#'                   item.info = item.info)
#' }
#' Output:
#' \preformatted{
#' > result$Collect()
#'  ID USER      ITEM  PREDICTION
#' 1 1    A   Movie3     3.705492
#' 2 2    A   Movie7     3.401231
#' 3 3    B   Movie1     5.457519
#' 4 4    B   Movie6     5.815021
#' 5 5    C   Movie3     3.421293
#' 6 6    D   Movie2     4.441541
#' 7 7    D   Movie5     4.314721
#' 8 8    E   Bad_Movie  2.585036
#'}
#' @keywords Recommender system
#' @export

predict.FRM <- function(
  model,
  data,
  key = NULL,
  user.info = NULL,
  item.info = NULL,
  thread.ratio = NULL) {
  result <- model$predict(data = data, key = key,
                          user.info = user.info,
                          item.info = item.info,
                          thread.ratio = thread.ratio)
}

#' @title Factorized Polynomial Regression Models
#' @name hanaml.FRM
#' @description hanaml.FRM is an R wrapper
#'  for SAP HANA PAL Factorized Polynomial Regression Models(FRM).
#' @seealso \code{\link{predict.FRM}}
#' @details Factorized Polynomial
#' Regression Models has been proven to be a powerfuk
#' tool for prediction applications such as recommendation.
#' It combines the advantages of polynomial regression
#' models with factorization models. Unlike SVM, it allows
#' reliable parameter estimation under very sparse data,
#' where just a few observations for higher-order effects are
#' available. Due to the factorization of those
#' higher-order interactions, FMs can be calculated with linear
#' complexity. \cr
#' \itemize{
#'    \item{each user-item rating/transaction. For
#'    example, location or time of a movie was rated by
#'    or lent to a user}
#'    \item{each user, e.g. gender, age, education, etc }
#'    \item{each item, such as genre of a movie}
#'    }
#'
#' @param data \code{DataFrame}\cr
#' DataFrame containting data of user-item interaction and global
#' side features, structured as follows:
#' \itemize{
#'  \item{} ID
#'  \item{} USER ID column
#'  \item{} ITEM ID column
#'  \item{} Side feature columns
#'  \item{} feedback/rationg column}
#' @template args-key-optional
#' @param user.info \code{DataFrame}\cr
#' DataFrame containting information of side features about user,
#' structured as follows:
#' \itemize{
#'  \item{} USER ID column
#'  \item{} Side feature columns
#' }
#' @param item.info \code{DataFrame}\cr
#' DataFrame containting information of side features about item,
#' structured as follows:
#' \itemize{
#'  \item{} ITEM ID column
#'  \item{} Side feature columns
#' }
#' @template args-cate-var
#' @param user.categorical.variable \code{list/vector of characters, optional}\cr
#'    Name of columns \emph{user.info} that correspond to
#'    categorical variable even the data type is INTEGER.\cr
#'    By default, 'VARCHAR' or 'NVARCHAR' is category
#'    variable, and 'INTEGER' or 'DOUBLE' is continuous variable.
#' @param  item.categorical.variable \code{list/vector of characters, optional}\cr
#'    Name of columns \emph{item.info} that correspond to
#'    categorical variable even the data type is INTEGER.\cr
#'    By default, 'VARCHAR' or 'NVARCHAR' is category
#'    variable, and 'INTEGER' or 'DOUBLE' is continuous variable.
#' @param   solver \code{c("sgd", "momentum", "nag", "adagrad"), optional}\cr
#'    Specifies optimization solver used to train the model
#'    \itemize{
#'    \item{\code{"sgd"} Stochastic Gradient Descent
#'    solver}
#'    \item{\code{"momentum"} Momentum.}
#'    \item{\code{"nag"} Nesterov Accelerated Gradient.}
#'    \item{\code{"adagrad"} Adaptive gradient algorithm.}
#'    }
#'    Defaults to "sgd".
#' @param   factor.num \code{integer, optional}\cr
#'    length of factor vectors.\cr
#'    Defaults to 8.
#' @param   init.variance \code{numeric, optional}\cr
#'    Variance of the normal distribution used to initialize
#'    the model parameters.\cr
#'    Defaults to 1e-2.
#' @param   learning.rate \code{numeric, optional}\cr
#'    Secifies the learning rate/ step size for optimization
#'    process.
#'    If you set it to the default value 0, the function
#'    chooses the step size automatically, based on a small
#'    part of the dataset.\cr
#'    Defaults to 0.
#' @param linear.lambda \code{numeric, optional}\cr
#'    Specifies the penalization assigned to the L2 regularization term of linear weights.\cr
#'    Defaults to 1e-10.
#' @param poly2.lambda \code{numeric, optional}\cr
#'    Specifies the penalization assigned to the L2 regularization term of quadratic factors.\cr
#'    Defaults to 1e-8.
#' @param random.state \code{numeric, optional}\cr
#'    Specifies the seed for random number generation, where
#'    0 means current system time
#'    is used as seed, and other values are simply real seed
#'    values.\cr
#'    Defaults to 0.
#' @param   max.iter \code{integer, optional}\cr
#'    Specifies the maximum number of iterations for
#'    optimization process.\cr
#'    Defaults to 50.
#' @param   sgd.tol \code{numeric, optional}\cr
#'    Specifies the stop creteria.
#'    The algorithm exits when the cost function has not
#'    decreased more than sgd.tol in
#'    sgd.exit.interval steps.\cr
#'    Defaults to 1e-5.
#' @param   sgd.exit.interval \code{numeric, optional}\cr
#'    Specifies the stop creteria.
#'    The algorithm exits when the cost function has not
#'    decreased more than sgd.tol in sgd.exit.interval steps.\cr
#'    Defaults to 5.
#' @template args-threadratio
#' @param   momentum \code{numeric, optional}\cr
#'    Specifies the momentum value for Momemtum or NAG method.
#'    Only valid when solver is "momentum" or "nag".\cr
#'    Defaults to 0.9.
#' @param resampling.method  \code{{"cv", "bootstrap"}, optional}\cr
#'   specifies the resampling values to perform model
#'   evaluation and parameter selection.\cr
#'   If no value is specified for this parameter, neither model
#'   evaluation nor parameter selection is activated.
#' @param evaluation.metric  \code{{"rmse"}, optional}\cr
#'   Specifies the evaluation metric for model evaluation or
#'   parameter selection, only RMSE is supported.\cr
#'   If not specified, neither model evaluation nor parameter
#'   selection is activated.\cr
#' @param fold.num \code{integer, optional}\cr
#'   Specifies the fold number for the cross-validation(cv).
#'   Mandatory and valid only when \code{resampling.method}
#'   is "cv".
#' @param repeat.times \code{numeric, optional}\cr
#'   Specifies the number of repeat times for resampling.\cr
#'   Defaults to 1.
#' @param param.search.strategy  \code{{'grid', 'random'}, optional}\cr
#'   Specifies the method to activate parameter selection.
#'   If not specified, parameter selection shall not be
#'   triggered.
#' @param timeout \code{integer, optional}\cr
#'   Specifies maximum running time for model evaluation or
#'   parameter selection in seconds.
#'   No timeout when 0 is specified.
#' @param progress.indicator.id   \code{character, optional}\cr
#'   Sets an ID of progress indicator for model evaluation or
#'   parameter selection.\cr
#'   No progress indicator is active if no value is provided.
#' @param random.search.times   \code{integer, optional}\cr
#'   Specifies the number of times to randomly select candidate
#'   parameters for selection.\cr
#'   Mandatory and valid when \code{param.search.strategy} is
#'   set to "random".
#' @param parameter.values  \code{named list/vector, optional}\cr
#'   Specifies values of the following parameters for parameter
#'   selection:\cr
#'   \code{factor.num, linear.lambda,regularization,
#'   momentum}.
#' @param parameter.range  \code{named list/vector, optional}\cr
#'   Specifies range of the following parameters for parameter
#'   selection:\cr
#'   \code{factor.num, linear.lambda,regularization,
#'   momentum}.\cr
#'   Parameter range should be specified by 3 numbers in the
#'   form of c(start, step, end).\cr
#'   Examples:\cr
#'   parameter.range <- list(factor.num = c(3, 1, 6)).\cr
#'
#' @return
#' A "FRM" object with the following attributes:\cr
#' \itemize{
#' \item \code{model.meta.data: DataFrame} meta data of the trained
#' model.
#' \item \code{model: DataFrame} weights of the trained model
#'
#' \item \code{model.factors: DataFrame} Factors of the trained model.
#' \item \code{iter.info: DataFrame} recorded information while the
#' optimazation process.
#' \item \code{stat: DataFrame} Statistics for model-evaluation/
#' parameter-selection.
#'   Available only when model-evaluation/parameter selection
#'   is enabled.
#' \item{\code{optim.param: DataFrame}} shows the selected optimal
#' parameters.
#'   Available only when model-evaluation/parameter selection
#'   is enabled.
#'}
#' @section Examples:
#' \preformatted{
#' > data$Head(5)$Collect()
#'  ID USER    MOVIE TIMESTAMP RATING
#' 1 1    A   Movie1         3    4.8
#' 2 2    A   Movie2         3    4.0
#' 3 3    A   Movie4         1    4.0
#' 4 4    A   Movie5         2    4.0
#' 5 5    A   Movie6         3    4.8
#'
#' > user.info$Collect()
#'      USER     USER_SIDE_FEATURE
#' 1      NA                    NA
#'
#' > item.info$Head(5)$Collect()
#'    MOVIE  GENRES
#' 1 Movie1  Sci-Fi
#' 2 Movie2  Drama,Romance
#' 3 Movie3  Drama,Sci-Fi
#' 4 Movie4  Crime,Drama
#' 5 Movie5  Crime,Drama
#' }
#' Call the function:
#' \preformatted{
#' FM <- hanaml.FRM(data = data,
#'                  user.info = user.info,
#'                  item.info = item.info,
#'                  categorical.variable = "TIMESTAMP",
#'                  resampling.method = "cv",
#'                  solver = "momentum",
#'                  learning.rate = 0,
#'                  max.iter = 100,
#'                  param.search.strategy = "grid",
#'                  evaluation.metric = "rmse",
#'                  fold.num = 5, repeat.times = 1, timeout = 0,
#'                  progress.indicator.id = "PAL_FRM",
#'                  thread.ratio = 0.5, random.state = 1,
#'                  parameter.range = list(factor.num= c(1,1,3)),
#'                  parameter.values = list(linear.lambda = c(1e-6, 1e-8, 1e-10),
#'                                          poly2.lambda = c(1e-4, 1e-6, 1e-8),
#'                                          momentum = c(0.8, 0.9)))
#' }
#' Output:
#' \preformatted{
#' > FM$model$Head(5)$Collect()
#'  ID MAP      WEIGHT
#' 1 0   A -0.01932846
#' 2 1   B  0.73047553
#' 3 2   C -0.22821216
#' 4 3   D  0.05358953
#' 5 4   E  0.03182115
#'
#' > FM$optim.param$Collect()
#'              PARAM_NAME INT_VALUE numeric_VALUE STRING_VALUE
#' 1              MOMENTUM        NA         9e-01         <NA>
#' 2        REGULARIZATION        NA         1e-08         <NA>
#' 3 LINEAR_REGULARIZATION        NA         1e-06         <NA>
#' 4         FACTOR_NUMBER         1            NA         <NA>
#' }
#' @keywords Recommender system
#' @export


hanaml.FRM <- function(
  data = NULL,
  key = NULL,
  user.info = NULL,
  item.info = NULL,
  categorical.variable = NULL,
  user.categorical.variable = NULL,
  item.categorical.variable = NULL,
  solver = NULL,
  factor.num = NULL,
  init.variance = NULL,
  random.state = NULL,
  learning.rate = NULL,
  linear.lambda = NULL,
  poly2.lambda = NULL,
  max.iter = NULL,
  sgd.tol = NULL,
  sgd.exit.interval = NULL,
  momentum = NULL,
  thread.ratio=NULL,
  resampling.method = NULL,
  evaluation.metric = NULL,
  fold.num = NULL,
  param.search.strategy = NULL,
  repeat.times= NULL,
  progress.indicator.id = NULL,
  random.search.times = NULL,
  timeout = NULL,
  parameter.values = NULL,
  parameter.range = NULL) {
  FRM$new(
    data = data,
    key = key,
    user.info = user.info,
    item.info = item.info,
    categorical.variable = categorical.variable,
    user.categorical.variable = user.categorical.variable,
    item.categorical.variable = item.categorical.variable,
    solver = solver,
    factor.num = factor.num,
    init.variance = init.variance,
    random.state = random.state,
    learning.rate = learning.rate,
    linear.lambda = linear.lambda,
    poly2.lambda = poly2.lambda,
    max.iter = max.iter,
    sgd.tol = sgd.tol,
    sgd.exit.interval = sgd.exit.interval,
    momentum = momentum,
    thread.ratio = thread.ratio,
    resampling.method = resampling.method,
    evaluation.metric = evaluation.metric,
    fold.num = fold.num,
    param.search.strategy = param.search.strategy,
    repeat.times = repeat.times,
    progress.indicator.id = progress.indicator.id,
    random.search.times = random.search.times,
    timeout = timeout,
    parameter.values = parameter.values,
    parameter.range = parameter.range
  )
}
