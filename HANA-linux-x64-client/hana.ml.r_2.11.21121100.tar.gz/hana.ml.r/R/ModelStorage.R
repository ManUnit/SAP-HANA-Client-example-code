ModelStorage <- R6Class("ModelStorage",
                        public = list(
                          conn.context = NULL,
                          schema = NULL,
                          meta.tbl = NULL,
                          initialize = function(conn.context = NULL,
                                                schema = NULL,
                                                meta.tbl = NULL) {
                            self$conn.context <- conn.context
                            self$schema <- schema
                            if (is.null(schema)) {
                              self$schema <- ExecuteLogged(self$conn.context$connection,
                                "SELECT CURRENT_SCHEMA FROM DUMMY")$CURRENT_SCHEMA[1]
                            }
                            self$meta.tbl <- meta.tbl
                            if (is.null(meta.tbl)) {
                              self$meta.tbl <- "HANAML_R_API_MODEL_STORAGE_META_TBL"
                            }

                            tryCatch({
                              if (is.null(self$schema)) {
                                schema.sql <- ""
                              } else {
                                schema.sql <- sprintf("%s.", QuoteName(self$schema))
                              }
                              sql <- sprintf("CREATE TABLE %s%s(
                                            NAME VARCHAR(5000),
                                            VERSION INTEGER,
                                            CLASS VARCHAR(5000),
                                            DETAILS VARCHAR(5000),
                                            TIMESTAMP TIMESTAMP,
                                            STORAGE_TYPE VARCHAR(255)
                                            )
                                            ", schema.sql, self$meta.tbl)
                              ExecuteLogged(self$conn.context$connection, sql)
                            }
                            , error = function(ex) {
                            })
                          },
                          SaveModel = function(model, name, version, force = FALSE,
                                               storage.type = "default", data.lake.container = "SYSRDL#CG") {
                            meta.class <- class(model)[[1]]
                            gen.name <- private$gen.model.name(model, name, version)
                            meta.timestamp <- Sys.time()
                            meta.details <- private$encode(model, name, version)
                            if (force == TRUE) {
                              self$DeleteModel(name, version)
                            }
                            if (private$check.meta.exist(name, version) == TRUE){
                              msg <- paste("Model already exists.",
                              "Set force = TRUE if the model needs to be replaced.")
                              flog.error(msg)
                              stop(msg)
                            } else {
                              private$insert.meta(name, version, meta.class,
                                                  meta.details, meta.timestamp, storage.type)
                              if (is.list(gen.name)) {
                                for (i in c(1: length(gen.name))) {
                                  if (storage.type == "HDL") {
                                    model$model[[i]]$save(table = gen.name[[i]],
                                                          force = force,
                                                          schema = self$schema,
                                                          append = FALSE,
                                                          data.lake = TRUE,
                                                          data.lake.container = data.lake.container)
                                  } else {
                                    model$model[[i]]$save(table = gen.name[[i]],
                                                          force = force,
                                                          schema = self$schema)
                                  }
                                }
                              } else {
                                if (storage.type == "HDL") {
                                  model$model$save(table = gen.name,
                                                   force = force,
                                                   schema = self$schema,
                                                   append = FALSE,
                                                   data.lake = TRUE,
                                                   data.lake.container = data.lake.container)
                                } else {
                                  model$model$save(table = gen.name,
                                                   force = force,
                                                   schema = self$schema)
                                }
                              }
                            }
                          },
                          ListModels = function(name = NULL) {
                            return(self$conn.context$table(self$meta.tbl,
                                                           self$schema))
                          },
                          UnloadModels = function(name, version, unload = TRUE) {
                            model.loc <- self$GetModelTable(name, version)
                            for (i in c(1:length(model.loc[[2]]))){
                              table.loc <- as.character(model.loc[[2]][i])
                              DataManipulation(connection.context = self$connection.context,
                                              table = table.loc,
                                              schema = model.loc[[1]],
                                              unload = unload
                                              )
                              }
                          },
                          DeleteModel = function(name, version) {
                            model.loc <- self$GetModelTable(name, version)
                            storage.type <- self$GetStorageType(name, version)
                            private$delete.meta(name, version)
                            if (!is.null(model.loc)){
                              for (i in c(1:length(model.loc[[2]]))){
                                  table.loc <- as.character(model.loc[[2]][i])
                                  if (storage.type == "HDL"){
                                    self$conn.context$drop.table(table = table.loc, data.lake = TRUE)
                                  }
                                  self$conn.context$drop.table(table = table.loc, schema = model.loc[[1]])
                                }
                              }
                          },
                          GetModelTable = function(name, version) {
                            details.sql <- sprintf("SELECT DETAILS
                                                 FROM %s.%s WHERE NAME='%s' AND VERSION=%s;",
                                                 self$schema, self$meta.tbl,
                                                 name, version)

                            details <- ExecuteLogged(self$conn.context$connection,
                                                     details.sql)
                            loc <- NULL
                            if (nrow(details) > 0) {
                              details <- details[1, 1]
                              loc <- fromJSON(as.character(details))$location
                            }
                            return(loc)
                          },
                          GetModelClass = function(name, version) {
                            class.sql <- sprintf("SELECT CLASS
                                                 FROM %s.%s WHERE NAME='%s' AND VERSION=%s;",
                                                 self$schema, self$meta.tbl,
                                                 name, version)
                            meta.class <- ExecuteLogged(self$conn.context$connection,
                                                     class.sql)[1, 1]
                            return (paste0("hanaml.", meta.class))
                          },
                          GetStorageType = function(name, version) {
                            storage.type.sql <- sprintf("SELECT STORAGE_TYPE
                                                        FROM %s.%s WHERE NAME='%s' AND VERSION=%s;",
                                                        self$schema, self$meta.tbl,
                                                        name, version)
                            storage.type <- ExecuteLogged(self$conn.context$connection,
                                                        storage.type.sql)[1, 1]
                            return (storage.type)
                          },
                          GetModelParameters = function(name, version) {
                            details.sql <- sprintf("SELECT DETAILS
                                                 FROM %s.%s WHERE NAME='%s' AND VERSION=%s;",
                                                 self$schema, self$meta.tbl,
                                                 name, version)
                            details <- ExecuteLogged(self$conn.context$connection,
                                                        details.sql)[1, 1]

                            parameters <- fromJSON(as.character(details))$parameters
                            return(parameters)
                          },
                          LoadModel = function(name, version) {
                            model.loc <- self$GetModelTable(name, version)
                            model.class <- self$GetModelClass(name, version)
                            model.parameters <- self$GetModelParameters(name, version)
                            header <- self$GetModelClass(name, version)
                            my.model <- NULL
                            if (is.null(model.parameters$model.format)){
                              construct.call <- sprintf("my.model <- %s()",
                                                        header)
                            } else {
                              construct.call <-
                                sprintf("my.model <- %s(model.format='%s')",
                                        header, model.parameters$model.format)
                            }
                            eval(parse(text = construct.call))
                            if (!is.null(model.loc)) {
                              if (length(model.loc[[2]]) > 1) {
                                  for (i in c(1:length(model.loc[[2]]))){
                                      table.loc <- as.character(model.loc[[2]][i])
                                      if (!is.null(model.loc[[1]])){
                                      my.model$model[[i]] <-
                                      self$conn.context$table(table = table.loc,
                                                              schema = model.loc[[1]])
                                      }
                                  }
                              } else {
                                my.model$model <-
                                  self$conn.context$table(table = model.loc[[2]],
                                                          schema = model.loc[[1]])
                              }
                            }

                            algorithms <- list('hanaml.OnlineARIMA', 'hanaml.VectorARIMA', 'hanaml.ARIMA', 'hanaml.AutoARIMA')
                            if (model.class %in% algorithms){
                              my.model$conn.context <- self$conn.context
                            }
                            return (my.model)
                          }
                        ),
                        private = list(
                          shared_env = new.env(),
                          gen.model.name = function(model, name, version) {
                            meta.class <- class(model)[[1]]
                            alg <- gsub("[.]", "_", toupper(meta.class))
                            if (is.list(model$model)) {
                              name.list <- list()
                              for (i in c(1:length(model$model))) {
                                model.name <- sprintf("HANAML_R_API_MODEL_%s_%s_%s_%s",
                                                alg, name, i, version)
                                name.list <- append(name.list, model.name)
                              }
                              return(name.list)
                            }else {
                              return(sprintf("HANAML_R_API_MODEL_%s_%s_%s",
                                             alg, name, version))
                            }
                          },
                          encode = function(model, name, version) {
                            if ("jsonlite" %in% rownames(installed.packages()) == FALSE) {
                              install.packages("jsonlite")
                              library("jsonlite")
                            } else {
                              library("jsonlite")
                            }
                            parameters <- list()
                            for (param in names(model)){
                              if (param != "model") {
                                if (eval(parse(text = sprintf("class(model$%s) == 'numeric'", param))) ||
                                  eval(parse(text = sprintf("class(model$%s) == 'logical'", param))) ||
                                  eval(parse(text = sprintf("class(model$%s) == 'list'", param))) ||
                                  eval(parse(text = sprintf("class(model$%s) == 'character'", param))) ||
                                  eval(parse(text = sprintf("class(model$%s) == 'factor'", param)))) {
                                    eval(parse(
                                      text = sprintf("parameters <- c(parameters, %s = model$%s)",
                                                          param, param)))
                                   }
                              }
                            }
                            location <- list(schema = self$schema,
                                             table = private$gen.model.name(model, name, version))
                            details <- list(location = location, parameters = parameters)
                            json <- toJSON(details, auto_unbox = TRUE, force = TRUE)
                            return (json)
                          },
                          check.meta.exist = function(name, version) {
                            check.sql <- sprintf("SELECT NAME,
                                          VERSION FROM %s.%s WHERE NAME='%s' AND VERSION=%s;",
                                          self$schema, self$meta.tbl,
                                          name, version)
                            if (nrow(ExecuteLogged(self$conn.context$connection, check.sql)) > 0) {
                              return (TRUE)
                            }
                            return (FALSE)
                          },
                          delete.meta = function(name, version) {
                            delete.sql <- sprintf("DELETE FROM %s.%s
                                                   WHERE NAME='%s' AND VERSION=%s;",
                                                  self$schema, self$meta.tbl,
                                                  name, version)
                            ExecuteLogged(self$conn.context$connection, delete.sql)
                          },
                          insert.meta = function(name, version, meta.class,
                                                 meta.details, meta.timestamp, storage.type){
                            insert.sql <- sprintf("INSERT INTO %s.%s VALUES(
                                                  '%s', %s, '%s', '%s', '%s', '%s'
                                                  );", self$schema, self$meta.tbl,
                                                  name, version,
                                                  meta.class, meta.details, meta.timestamp, storage.type)
                            ExecuteLogged(self$conn.context$connection, insert.sql)
                          }
                        )
)

#' @title ModelStorage
#' @name hanaml.ModelStorage
#' @description
#' A model management tool.
#' hanaml.ModelStorage includes methods for saving and versioning the model from
#' trained PAL model on SAP HANA.
#' @param conn.context \code{ConnectionContext}\cr
#'        The connection to the SAP HANA system.
#' @param schema \code{character, optional}\cr
#'        The schema to persist models.\cr
#'        Defaults to current schema.
#' @param meta.tbl \code{character, optional}\cr
#'        The table to store meta data of models.\cr
#'        Defaults to the table "HANAML_R_API_MODEL_STORAGE_META_TBL".
#' @return
#'        An object of \code{\link{R6Class}} with methods for hanaml.ModelStorage.
#'
#' @section Methods:
#' \describe{
#'    \item{\code{SaveModel(model, name, version, force = FALSE)}}{
#'    Save a PAL model in the SAP HANA.\cr
#'    \emph{Usage:}
#'    \code{model.storage$SaveModel(model = model, name = 'RDT', version = 1)}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{model}:   A hanaml function object with fitted model.  }
#'     \item{\code{name}:    The model's name.  }
#'     \item{\code{version}: The model's version.  }
#'     \item{\code{force, optional}:   If TRUE, the existing model will be replaced by the latest model.
#'                           Defaults to be FALSE.  }
#'     }
#'    }
#'
#'
#'   \item{\code{ListModels(name = NULL)}}{
#'    Returns a DataFrame of the meta data of the saved models.\cr
#'    \emph{Usage:}
#'    \code{model.storage$ListModels()}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{name, optional}:   The model's name. Defaults to NULL. }
#'     }
#'    \emph{Returns:}
#'    \code{DataFrame}
#'    A Dataframe of the meta data of the saved models.
#'    }
#'
#'
#'   \item{\code{DeleteModel(name, version)}}{
#'    Delete the model defined in the model storage.\cr
#'    \emph{Usage:}
#'    \code{model.storage$DeleteModel('RDT', 1)}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{name}:   The model's name.  }
#'     \item{\code{version}:   The model's version.  }
#'     }
#'    }
#'
#'
#'   \item{\code{LoadModel(name, version)}}{
#'    Load a model defined in the model storage.\cr
#'    \emph{Usage:}
#'    \code{model.storage$LoadModel('RDT', 1)}\cr
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{name}:   The model's name.  }
#'     \item{\code{version}:   The model's version.  }
#'     }
#'    \emph{Returns:}
#'    \code{DataFrame}
#'    An object of \code{\link{R6Class}} with methods for PAL functions.
#'    }
#'  }
#' @import R6 futile.logger sets uuid
#' @export
hanaml.ModelStorage <- function(conn.context, schema = NULL, meta.tbl = NULL) {
  ModelStorage$new(conn.context, schema, meta.tbl)
}
