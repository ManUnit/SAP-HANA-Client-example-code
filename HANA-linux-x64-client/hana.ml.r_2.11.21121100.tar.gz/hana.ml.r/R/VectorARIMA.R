VectorARIMA <- R6Class(
  "VectorARIMA",
  inherit = MlBase,
  public = list(
    model.type.map = list("var" = 0, "vma" = 1, "varma" = 2),
    search.method.map = list("eccm" = 0, "grid.search" = 1),
    init.guess.map = list("arma" = 0, "var" = 1),
    information.criterion.map = list("aic" = 0, "bic" = 1),
    fitted = NULL,
    model = NULL,
    irf = NULL,
    order = NULL,
    seasonal.order = NULL,
    model.type = NULL,
    search.method = NULL,
    lag.num = NULL,
    max.p = NULL,
    max.q = NULL,
    max.seasonal.p = NULL,
    max.seasonal.q = NULL,
    max.lag.num = NULL,
    init.guess = NULL,
    information.criterion = NULL,
    include.mean = NULL,
    max.iter = NULL,
    finite.diff.accuracy = NULL,
    displacement = NULL,
    ftol = NULL,
    gtol = NULL,
    calculate.hessian = NULL,
    calculate.irf = NULL,
    irf.lags = NULL,
    alpha = NULL,
    output.fitted = NULL,
    thread.ratio = NULL,
    conn.context = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          endog = NULL,
                          exog = NULL,
                          order = NULL,
                          seasonal.order = NULL,
                          model.type = NULL,
                          search.method = NULL,
                          lag.num = NULL,
                          max.p = NULL,
                          max.q = NULL,
                          max.seasonal.p = NULL,
                          max.seasonal.q = NULL,
                          max.lag.num = NULL,
                          init.guess = NULL,
                          information.criterion = NULL,
                          include.mean = NULL,
                          max.iter = NULL,
                          finite.diff.accuracy = NULL,
                          displacement = NULL,
                          ftol = NULL,
                          gtol = NULL,
                          calculate.hessian = NULL,
                          calculate.irf = NULL,
                          irf.lags = NULL,
                          alpha = NULL,
                          output.fitted = NULL,
                          thread.ratio = NULL){
      super$initialize()
      if (!is.null(data)){
        #order check
        self$order <- validateInput("order", unlist(order), c("integer","numeric"))
        if (!is.null(order) && length(order)!= 3){
          msg <- "order must contain exactly 3 integers for regression order, differentiation order and moving average order!"
          flog.error(msg)
          stop(msg)
        }
        #seasonal.order check
        self$seasonal.order <- validateInput("seasonal.order", unlist(seasonal.order), c("integer","numeric"))
        if (!is.null(seasonal.order) && length(seasonal.order)!= 4){
          msg <- "seasonal.order must contain exactly 4 integers for regression, differentiation order, moving average order for seasonal part and seasonal period!"
          flog.error(msg)
          stop(msg)
        }

        self$model.type <-  validateInput("model.type", model.type, self$model.type.map)
        self$search.method <- validateInput("search.method", search.method,
                                            self$search.method.map)
        self$lag.num <- validateInput("lag.num", lag.num, "integer")
        self$max.p <- validateInput("max.p", max.p, "integer")
        self$max.q <- validateInput("max.q", max.q, "integer")
        self$max.seasonal.p <- validateInput("max.seasonal.p", max.seasonal.p, "integer")
        self$max.seasonal.q <- validateInput("max.seasonal.q", max.seasonal.q, "integer")
        self$max.lag.num <- validateInput("max.lag.num", max.lag.num, "integer")
        self$init.guess <- validateInput("init.guess", init.guess, self$init.guess.map)
        self$information.criterion <- validateInput("information.criterion", information.criterion, self$information.criterion.map)
        self$include.mean <- validateInput("include.mean", include.mean, "logical")
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        self$finite.diff.accuracy <- validateInput("finite.diff.accuracy", finite.diff.accuracy, "integer")
        self$displacement <- validateInput("displacement", displacement, "numeric")
        self$ftol <- validateInput("ftol", ftol, "numeric")
        self$gtol <- validateInput("gtol", gtol, "numeric")
        self$calculate.hessian <- validateInput("calculate.hessian", calculate.hessian, "logical")
        self$calculate.irf <- validateInput("calculate.irf", calculate.irf, "logical")
        self$irf.lags <- validateInput("irf.lags", irf.lags, "integer")
        self$alpha <- validateInput("alpha", alpha, "numeric")
        self$output.fitted <- validateInput("output.fitted", output.fitted, "logical")
        self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <-
          sprintf("#PAL_VARMA_PARAM_TBL_%s_%s", self$id, unique.id)#nolint
        model.tbl <-
          sprintf("#PAL_VARMA_MODEL_TBL_%s_%s", self$id, unique.id)#nolint
        fitted.tbl <-
          sprintf("#PAL_VARMA_FIT_TBL_%s_%s", self$id, unique.id)#nolint
        irf.tbl <-
          sprintf("#PAL_VARMA_IRF_TBL_%s_%s", self$id, unique.id)#nolint

        cols <- data$columns

        if (is.null(key)){
          key <- cols[[1]]
        }
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]

        exog <- validateInput("exog", exog, cols, case.sensitive = TRUE)
        cols <- cols[! cols %in% exog]

        if (is.null(endog)){
          endog <- cols
        }
        endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)

        if (!inherits(data, "DataFrame") ) {
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        self$conn.context <- conn.context

        selected <- append(append(key, endog), exog)
        data <- data$Select(selected)

        param.rows <- list(
          tuple("P", self$order[1], NULL, NULL),
          tuple("D", self$order[2], NULL, NULL),
          tuple("Q", self$order[3], NULL, NULL),
          tuple("SEASONAL_P", self$seasonal.order[1], NULL, NULL),
          tuple("SEASONAL_D", self$seasonal.order[2], NULL, NULL),
          tuple("SEASONAL_Q", self$seasonal.order[3], NULL, NULL),
          tuple("SEASONAL_PERIOD", self$seasonal.order[4], NULL, NULL),
          tuple("MODEL", map.null(self$model.type, self$model.type.map), NULL, NULL),
          tuple("SEARCH_METHOD", map.null(self$search.method, self$search.method.map), NULL, NULL),
          tuple("M", self$lag.num, NULL, NULL),
          tuple("MAX_P", self$max.p, NULL, NULL),
          tuple("MAX_Q", self$max.q, NULL, NULL),
          tuple("MAX_SEASONAL_P", self$max.seasonal.p, NULL, NULL),
          tuple("MAX_SEASONAL_Q", self$max.seasonal.q, NULL, NULL),
          tuple("MAX_M", self$max.lag.num, NULL, NULL),
          tuple("INITIAL_GUESS", map.null(self$init.guess, self$init.guess.map), NULL, NULL),
          tuple("INFORMATION_CRITERION", map.null(self$information.criterion, self$information.criterion.map), NULL, NULL),
          tuple("INCLUDE_MEAN", to.integer(self$include.mean), NULL, NULL),
          tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
          tuple("FINITE_DIFFERENCE_ACCURACY", self$finite.diff.accuracy, NULL, NULL),
          tuple("DISPLACEMENT", NULL, self$displacement, NULL),
          tuple("FTOL", NULL, self$ftol, NULL),
          tuple("GTOL", NULL, self$gtol, NULL),
          tuple("HESSIAN", to.integer(self$calculate.hessian), NULL, NULL),
          tuple("CALCULATE_IRF", to.integer(self$calculate.irf), NULL, NULL),
          tuple("IRF_LAGS", NULL, self$irf.lags, NULL),
          tuple("ALPHA", NULL, self$alpha, NULL),
          tuple("OUTPUT_FITTED", to.integer(self$output.fitted), NULL, NULL),
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL)
        )

        if (!is.null(exog)) {
          for (element in exog) {
            temp.list <- tuple("EXOGENEOUS_VARIABLE", NULL, NULL, element)
            param.rows <- append(param.rows, tuple(temp.list))
          }
        }

        tables <- list(param.tbl, model.tbl, fitted.tbl, irf.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(model.tbl, fitted.tbl, irf.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
                                            (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
          errorhelper(CallPalAutoWithConnection(conn.context,
                                                "PAL_VARMA", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$model <- conn.context$table(model.tbl)
        self$fitted <- conn.context$table(fitted.tbl)
        self$irf <- conn.context$table(irf.tbl)
      }
    }
  )
)

#' @title  Vector AutoregRessive Moving Average
#' @name hanaml.VectorARIMA
#' @description hanaml.VectorARIMA is a R wrapper
#' for SAP HANA PAL Vector AutoregRessive Moving Average.
#' @details The vector autoregressive moving average models (VARMA) is a vector form of autoregressive
#' integrated moving average (ARMA) that can be used to examine the relationships among several variables
#' in multivariate time series analysis, comparing to ARMA which is used in univariate time series.
#' @seealso \code{\link{predict.VectorARIMA}}
#' @param     data \code{DataFrame}\cr
#'            DataFrame includes key, endogenous variables and exogenous variables.
#' @param     key \code{character, optional}\cr
#'            Name of the key. The type of key column is integer.\cr
#'            If not provide, defaults to the first column.
#' @param     endog \code{list of character, optional}\cr
#'            The endogenous variable, i.e. time series. The type of endog column is integer or double.\cr
#'            Defaults to the non-key and non-exog columns of data if not provided.
#' @param     exog \code{list of character, optional}\cr
#'            The exogeneous variables.\cr
#'            Defaults to NULL.
#' @param     order \code{list/vector of integer, optional}\cr
#'            Indicate the order (p, d, q).
#'            \itemize{
#'              \item{p}: value of the auto regression order. -1 indicates auto and >=0 is user-defined.
#'              \item{d}: value of the differentiation order.
#'              \item{q}: value of the moving average order. -1 indicates auto and >=0 is user-defined.
#'            }
#'            Defaults to c(-1, 0, -1).
#' @param     seasonal.order \code{list/vector of integer, optional}\cr
#'            Indicate the seasonal order (P, D, Q, s).
#'            \itemize{
#'              \item{P}: value of the auto regression order for the seasonal part. -1 indicates auto and >=0 is user-defined.
#'              \item{D}: value of the differentiation order for the seasonal part.
#'              \item{Q}: value of the moving average order for the seasonal part. -1 indicates auto and >=0 is user-defined.
#'              \item{s}: value of the seasonal period. -1 indicates auto and >=0 is user-defined.
#'            }
#'            Defaults to c(-1, 0, -1, 0).
#' @param     model.type \code{c('VAR', 'VMA', 'VARMA'), optional}\cr
#'            The model type.\cr
#'            Defaults to 'VARMA'.
#' @param     search.method \code{c('eccm', 'grid.search'), optional}\cr
#'            Specifies the orders of the model. 'eccm' is valid only when seasonal period is less than 1.\cr
#'            Defaults to 'grid.search'.
#' @param     lag.num \code{integer, optional}\cr
#'            The lag number of explanatory variables. Valid only when \code{model.type}='VAR'.\cr
#'            Defaults to 0.05.
#' @param     max.p \code{integer, optional}\cr
#'            The maximum value of vector AR order p.\cr
#'            Defaults to 6 if \code{model.type}='VAR' or if \code{model.type}='VARMA' and \code{search.method}='eccm'.\cr
#'            Defaults to 2 if \code{model.type}='VARMA' and \code{search.method}='grid.search'.
#' @param     max.q \code{integer, optional}\cr
#'            The maximum value of vector MA order q.\cr
#'            Defaults to 8 if \code{model.type}='VMA'.\cr
#'            Defaults to 5 if \code{model.type}='VARMA' and \code{search.method}='eccm'.\cr
#'            Defaults to 2 if \code{model.type}='VARMA' and \code{search.method}='grid.search'.
#' @param     max.seasonal.p \code{integer, optional}\cr
#'            The maximum value of seasonal vector AR order P.\cr
#'            Defaults to 3 if \code{model.type}='VAR'.\cr
#'            Defaults to 1 if \code{model.type}='VARMA' and \code{search.method}='grid.search'.
#' @param     max.seasonal.q  \code{integer, optional}\cr
#'            The maximum value of seasonal vector MA order Q.\cr
#'            Defaults to 1.
#' @param     max.lag.num \code{, optional}\cr
#'            The maximum lag number of explanatory variables. Valid only when \code{model.type}='VAR'.\cr
#'            Defaults to 4.
#' @param     init.guess \code{integer, optional}\cr
#'            The model used as initial estimation for VARMA. Valid only for VARMA.\cr
#'            Defaults to 'VAR'.
#' @param     information.criterion \code{character, optional}\cr {'AIC', 'BIC'}, optional
#'            Information criteria for order specification.\cr
#'            Defaults to 'AIC'.
#' @param     include.mean \code{logical, optional}\cr
#'            ARMA model includes a constant part if TRUE.\cr
#'            Valid only when d + D <= 1.\cr
#'            Defaults to TRUE if d + D = 0 else FALSE.
#' @param     max.iter \code{integer, optional}\cr
#'            Maximum number of iterations of L-BFGS-B optimizer. Valid only for VMA and VARMA.\cr
#'            Defaults to 200.
#' @param     finite.diff.accuracy \code{integer, optional}\cr
#'            Polynomial order of finite difference. \cr
#'            Approximate the gradient of objective function with finite difference. \cr
#'            The valid range is from 1 to 4.
#'            Defaults to 1.
#' @param     displacement \code{double, optional}\cr
#'            The step length for finite-difference method. Valid only for VMA and VARMA.\cr
#'            Defaults to 2.2e-6.
#' @param     ftol \code{double, optional}\cr
#'            Tolerance for objective convergence test. Valid only for VMA and VARMA.
#'            Defaults to 1e-5.
#' @param     gtol \code{doulbe, optional}\cr
#'            Tolerance for gradient convergence test. Valid only for VMA and VARMA.\cr
#'            Defaults to 1e-5.
#' @param     calculate.hessian \code{logical, optional}\cr
#'            Specifies whether to calculate the Hessian matrix. \cr
#'            VMA and VARMA will output standard error of parameter estimates only when calculate.hessian is TRUE.\cr
#'            Defaults to FALSE.
#' @param     calculate.irf \code{logical, optional}\cr
#'            Specifies whether to calculate impulse response function.\cr
#'            Defaults to FALSE.
#' @param     irf.lags \code{integer, optional}\cr
#'            The number of lags of the IRF to be calculated. Valid only when calculate.irf is True.\cr
#'            Defaults to 8.
#' @param     alpha \code{double, optional}\cr
#'            Type-I error used in the Ljung-Box tests and eccm.\cr
#'            Defaults to 0.05.
#' @param     output.fitted \code{logical, optional}\cr
#'            Output fitted result and residuals if True.\cr
#'            Defaults to TRUE.
#' @template args-threadratio
#' @return
#' Returns an "VectorARIMA" object with the following attributes:
#' \itemize{
#' \item{model: \code{DataFrame}}\cr
#'      Fitted model.
#' \item{fitted: \code{DataFrame}}\cr
#'      Predicted dependent variable values for training data.
#'      Set to NULL if the training data has no row IDs.
#' \item{irf: \code{DataFrame}}\cr
#'      Impulse response function.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'   TIMESTAMP       Y
#' 1         1 -24.525
#' 2         2  34.720
#' 3         3  57.325
#' 4         4  10.340
#' 5         5 -12.890
#' ......
#' }
#' Invoke the function:
#' \preformatted{
#' > varima <- hanaml.VectorARIMA(data = data, search.strategy = 1)
#' }
#' Output:
#' \preformatted{
#' > varima$fitted
#'     TIMESTAMP      FITTED   RESIDUALS
#' 1           1          NA          NA
#' 2           2          NA          NA
#' 3           3          NA          NA
#' 4           4          NA          NA
#' 5           5 -24.5250000 11.63500000
#' 6           6  37.5839311  1.46106885
#' 7           7  57.9926243 -0.69262431
#' 8           8   8.6228706 -1.88787060
#' 9           9 -20.3259208  0.96092077
#  .......
#' }
#' @keywords TimeSeries
#' @export
hanaml.VectorARIMA <- function(data = NULL,
                               key = NULL,
                               endog = NULL,
                               exog = NULL,
                               order = NULL,
                               seasonal.order = NULL,
                               model.type = NULL,
                               search.method = NULL,
                               lag.num = NULL,
                               max.p = NULL,
                               max.q = NULL,
                               max.seasonal.p = NULL,
                               max.seasonal.q = NULL,
                               max.lag.num = NULL,
                               init.guess = NULL,
                               information.criterion = NULL,
                               include.mean = NULL,
                               max.iter = NULL,
                               finite.diff.accuracy = NULL,
                               displacement = NULL,
                               ftol = NULL,
                               gtol = NULL,
                               calculate.hessian = NULL,
                               calculate.irf = NULL,
                               irf.lags = NULL,
                               alpha = NULL,
                               output.fitted = NULL,
                               thread.ratio = NULL) {
  VectorARIMA$new(data,
                  key,
                  endog,
                  exog,
                  order,
                  seasonal.order,
                  model.type,
                  search.method,
                  lag.num,
                  max.p,
                  max.q,
                  max.seasonal.p,
                  max.seasonal.q,
                  max.lag.num,
                  init.guess,
                  information.criterion,
                  include.mean,
                  max.iter,
                  finite.diff.accuracy,
                  displacement,
                  ftol,
                  gtol,
                  calculate.hessian,
                  calculate.irf,
                  irf.lags,
                  alpha,
                  output.fitted,
                  thread.ratio)
}


#' @title Make Predictions from a "VectorARIMA" Object
#' @name predict.VectorARIMA
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "VectorARIMA" object.
#' @seealso \code{\link{hanaml.VectorARIMA}}
#' @format \code{\link{S3}} methods
#' @param     model \code{R6Class object}\cr
#'            A "VectorARIMA" object for prediction.
#' @param     data \code{DataFrame, optional}\cr
#'            Includes the timestamp column and external Data (exogenous variables) for prediction.\cr
#'            Defaults to NULL.
#' @param     key \code{character, optional}\cr
#'            Name of the timestamp column in \code{data}.\cr
#'            Valid only when \code{data} is not NULL.\cr
#'            Defaults to the first column of \code{data} when \code{data} is not NULL.
#' @param     forecast.length \code{integer, optional}\cr
#'            Number of points to forecast.\cr
#'            Defaults to NULL.
#' @param     ... Reserved parameter.
#' @return
#' Predicted values are returned as a DataFrame, structured as follows:
#' \itemize{
#'  \item{\code{COLNAME}: Column name of endogenous variables.}
#'  \item{\code{ID}: with same name and type the ID column of \emph{data}.}
#'  \item{\code{FORECAST}: type DOUBLE, representing predicted values.}
#'  \item{\code{SE}: type DOUBLE, standard error.}
#'  \item{\code{LO95}: type DOUBLE, low 95\% values.}
#'  \item{\code{HI95}: type DOUBLE, high 95\% values.}
#' }
#' @section Examples:
#' Call the function and obtain the result:
#' \preformatted{
#' > predict(model = varima, forecast.length = 5)
#'   TIMESTAMP   FORECAST       SE       LO80      HI80        LO95      HI95
#' 1         0 -15.544832 3.298697 -19.772283 -11.31738 -22.0101587 -9.079505
#' 2         1  35.587390 3.404891  31.223846  39.95094  28.9139269 42.260854
#' 3         2  56.498532 3.411723  52.126231  60.87083  49.8116773 63.185386
#' 4         3   7.086176 3.412170   2.713303  11.45905   0.3984467 13.773906
#' 5         4 -16.266996 3.412250 -20.639972 -11.89402 -22.9548838 -9.579108
#' }
#' @keywords TimeSeries
#' @export
predict.VectorARIMA <- function(model,
                                data = NULL,
                                key = NULL,
                                forecast.length = NULL,
                                ...){
  if (is.null(model$model)) {
    msg <- "model of object is empty!"
    flog.error(msg)
    stop(msg)
  }

  forcast.length <- validateInput("forecast.length",
                                  forecast.length,
                                  "integer")
  if (is.null(data)){
    conn.context <- model$conn.context
  } else {
    conn.context <- data$connection.context
  }

  if (!is.null(data))
  {
    cols <- data$columns
    if (is.null(key)){
      key <- cols[[1]]
    }
    key <- validateInput("key", key, cols, case.sensitive = TRUE)
    cols <- cols[! cols %in% key]
    exog <- cols
    data <- data$Select(append(key, exog))
  }

  conn <- conn.context$connection
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_VARMA_PARAM_TBL_%s_%s", model$id, unique.id)
  res.tbl <- sprintf("#PAL_VARMA_RESULT_TBL_%s_%s",model$id, unique.id)
  data.flag <- is.null(data)
  if (data.flag){
    data.tbl <- sprintf("PAL_VARMA_DATA_TBL_%s", unique.id)
    tryCatch({
      ExecuteLogged(conn, paste("CREATE COLUMN TABLE",
                              data.tbl,
                              "(\"TIMESTAMP\" INTEGER,",
                              "\"Y\" DOUBLE)"))
    },
    error = function(err){
      msg <- paste("Error:", err[["message"]])
      flog.error(msg)
      ExecuteLogged(conn, sprintf("DROP TABLE %s", data.tbl))
      stop(msg)
    }
    )
    data <- conn.context$table(data.tbl)
  }
  in.tables <- list(data, model$model$name, param.tbl)
  tables <- list(param.tbl, res.tbl)
  out.tables <- list(res.tbl)
  param.rows <- list(tuple("FORECAST_LENGTH", forecast.length, NULL, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
                                      (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
    errorhelper(CallPalAutoWithConnection(conn.context,
                                          "PAL_VARMA_FORECAST", in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    if (data.flag){
      ExecuteLogged(conn, paste("DROP TABLE", data.tbl))
    }
    stop(msg)
  })
  if (data.flag){
    ExecuteLogged(conn, paste("DROP TABLE", data.tbl))
  }
  return(conn.context$table(res.tbl))
}
