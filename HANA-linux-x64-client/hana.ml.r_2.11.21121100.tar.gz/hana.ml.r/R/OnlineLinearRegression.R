OnlineLinearRegression <- R6Class(
  "OnlineLinearRegression",
  inherit = MlBase,
  public = list(
    enet.lambda = NULL,
    enet.alpha = NULL,
    max.iter = NULL,
    tol = NULL,
    thread.ratio = NULL,
    model = NULL,
    coefficients = NULL,
    intermediate.result = NULL,
    initialize = function(enet.lambda = NULL,
                          enet.alpha = NULL,
                          max.iter = NULL,
                          tol = NULL){
      super$initialize()
      self$enet.lambda <- validateInput("enet.lambda", enet.lambda, "double")
      self$enet.alpha <- validateInput("enet.alpha", enet.alpha, "double")
      self$max.iter <- validateInput("max.iter", max.iter, "integer")
      self$tol <- validateInput("tol", tol, "double")
      self$model = NULL
      self$intermediate.result = NULL
      self$coefficients = NULL
    },
    fit = function(data,
                   key = NULL,
                   features = NULL,
                   label = NULL,
                   thread.ratio = NULL){
        CheckConnection(data)
        conn <- data$connection.context
        self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")

        if (is.null(self$model)){
          unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
          param.tbl <- sprintf("#PAL_OLR_PARAM_TBL_%s_%s", self$id, unique.id)
          inter.tbl <- sprintf("#PAL_OLR_INTER_RESULT_TBL_%s_%s", self$id, unique.id)
          param.rows <- list(
            tuple("ENET_LAMBDA", NULL, self$enet.lambda, NULL),
            tuple("ENET_ALPHA", NULL, self$enet.alpha, NULL),
            tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
            tuple("THRESHOLD", NULL, self$tol, NULL),
            tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL))
          in.tables <- list(param.tbl)
          out.tables <- list(inter.tbl)
          tables <- list(param.tbl, inter.tbl)
          tryCatch({
            errorhelper(CreateTWithConnection(conn,(ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
            errorhelper(CallPalAutoWithConnection(conn,
                                                  "PAL_INIT_ONLINE_LINEAR_REGRESSION",
                                                  in.tables,
                                                  out.tables))
          },
          error = function(err){
            msg <- paste("Error:", err[["message"]])
            flog.error(msg)
            TryDropWithConnection(conn, tables)
            stop(msg)
          })
          self$intermediate.result <- conn$table(inter.tbl)
        }

        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        cols <- cols[!cols %in% key]
        if (inherits(formula, "formula")){
          parseformula <- ParseFormula(data, formula)
          label <- parseformula[[1]]
          features <- parseformula[[2]]
          features <- features[! features %in% key]
        }
        label <- validateInput("label", label, cols, case.sensitive = TRUE)

        if (is.null(label)){
          label <- cols[[length(cols)]]
        }
        cols <- cols[! cols %in% label]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        if (is.null(features)){
          features <- cols
        }
        if (!is.null(key)){
          id.col <- list(key)
          cols <- cols[! cols %in% key]
        } else {
          id.col <- list()
        }

        selected <- append(id.col, label)
        selected <- append(selected, features)

        if (!inherits(data, "DataFrame")) {
          msg <- "data must be given as a DataFrame."
          flog.error(msg)
          stop(msg)
        }

        data <- data$Select(selected)

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_OLR_PARAM_TBL_%s_%s", self$id, unique.id)
        inter.name.tbl <- sprintf("#PAL_OLR_INTER_TBL_%s_%s", self$id, unique.id)
        coef.tbl <- sprintf("#PAL_OLR_COEF_TBL_%s_%s", self$id, unique.id)
        inter.update.tbl <- sprintf("#PAL_OLR_INTER_UPDATE_TBL_%s_%s", self$id, unique.id)

        ExecuteLogged(conn$connection, paste("CREATE LOCAL TEMPORARY COLUMN TABLE",
                                       inter.name.tbl,
                                       "(\"SEQUENCE\" INTEGER,",
                                       "\"INTERMEDIATE_MODEL\" NVARCHAR(5000))"))
        tryCatch({
          if (is.null(self$model)){
            ExecuteLogged(conn$connection, sprintf("INSERT INTO %s SELECT * FROM (%s)",
                                                   inter.name.tbl,
                                                   self$intermediate.result$select.statement))
          } else {
            ExecuteLogged(conn$connection, sprintf("INSERT INTO %s SELECT * FROM (%s)",
                                                   inter.name.tbl,
                                                   self$model[[2]]$select.statement))
          }

        },
          error = function(err){
            msg <- paste("Error:", err[["message"]])
            flog.error(msg)
            TryDropWithConnection(conn, inter.name.tbl)
            stop(msg)
          })
        inter.tbl <- conn$table(inter.name.tbl)

        param.rows <- list(
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL))

        tables <- list(param.tbl, coef.tbl, inter.update.tbl)
        in.tables <- list(data, inter.tbl, param.tbl)
        out.tables <- list(coef.tbl, inter.update.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,(ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
          errorhelper(CallPalAutoWithConnection(conn, "PAL_TRAIN_ONLINE_LINEAR_REGRESSION",
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })

        self$coefficients <- conn$table(coef.tbl)
        self$intermediate.result <- conn$table(inter.update.tbl)
        self$model <- list(self$coefficients, self$intermediate.result)
    },
    score = function(data, key, features=NULL, label=NULL){
      if (is.null(self$model)) {
        msg <- "Model not initialized. Perform a fit first."
        flog.error(msg = msg)
        stop(msg)
      }

      lr <- hanaml.LinearRegression()
      lr$pmml <- NULL
      lr$coefficients <- NULL
      lr$model <- self$model[[1]]
      score <- lr$score(data, key, features, label, model.format=NULL)
      return(score)
    }
  )
)
#' @title Online Linear Regression
#' @name hanaml.OnlineLinearRegression
#' @description hanaml.OnlineLinearRegression is a R wrapper
#' for SAP HANA PAL Online linear regression algorithm.
#' @details Online linear regression is an online version of the linear regression and is
#' used when the training data are obtained multiple rounds.
#' Additional data are obtained in each round of training.
#' By making use of the current computed linear model and combining with the obtained data in each round,
#' online linear regression adapts the linear model to make the prediction as precise as possible.
#' @seealso \code{\link{predict.OnlineLinearRegression}}
#' @param     enet.lambda \code{double, optional}\cr
#'            Penalized weight. Value should be greater than or equal to 0.\cr
#'            Defaults to 0.
#' @param     enet.alpha \code{double, optional}\cr
#'            Elastic net mixing parameter.
#'            Ranges from 0 (Ridge penalty) to 1 (LASSO penalty) inclusively.
#'            Defaults to 0.
#' @param     max.iter \code{integer, optional}\cr
#'            Maximum number of passes over training data.
#'            Defaults to 1000.
#' @param     tol \code{double, optional}\cr
#'            Convergence threshold for coordinate descent.
#'            Defaults to 1.0e-5.
#'
#' @section Methods:
#' \describe{
#'    \code{fit(data = NULL, key = NULL, features = NULL, formula = NULL, thread.ratio = NULL)}\cr\cr
#'    The fit function of an OnlineLinearRegression object.\cr
#'
#'    \emph{Usage:\cr
#'    olr <- hanaml.OnlineLinearRegression()\cr
#'    olr$fit(data, key='ID', features=list('X1','X2'))}\cr
#'
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{data, DataFrame}\cr Input data.}
#'     \item{\code{key, character, optional}\cr Name of the ID column.\cr
#'                 If not provided, the \emph{data} is assumed to have no ID column.\cr
#'                 No default value.}
#'     \item{\code{features, character of list of characters, optional}\cr
#'                 Name of feature columns.\cr
#'                 If not provided, it defaults all non-key, non-label columns of \emph{data}.}
#'     \item{\code{label, character, optional}\cr
#'                 Name of the column which specifies the dependent variable.\cr
#'                 Defaults to the last column of \emph{data} if not provided.}
#'     \item{\code{formula, formula type, optional}\cr
#'                 Formula to be used for model generation.
#'                 format = label ~ <feature_list>
#'                 e.g.: formula = CATEGORY~V1+V2+V3 \cr
#'                 You can either give the formula,
#'                 or a feature and label combination, but do not provide both.\cr
#'                 Defaults to NULL.}
#'     \item{\code{thread.ratio, double, optional}\cr
#'                 Controls the proportion of available threads that can be used by this
#'                 function. The value range is from 0 to 1, where 0 indicates a single thread,
#'                 and 1 indicates all available threads. Values between 0 and 1 will use up to
#'                 that percentage of available threads. Values outside this
#'                 range are ignored.\cr
#'                 Defaults to -1. }
#'  }
#' }
#'
#' @return
#' Returns a 'hanaml.OnlineLinearRegression' object with following values:
#' \itemize{
#'    \item{coefficients : \code{DataFrame}}\cr
#'          Fitted regression coefficients.
#'    \item{intermediate.result : \code{DataFrame}}\cr
#'          Intermediate model.
#' }
#'
#' @section Examples:
#' First, initialize a 'hanaml.OnlineLinearRegression' object:
#'
#' \preformatted{
#' > olr <- hanaml.OnlineLinearRegression(enet.lambda=0.1,
#'                                        enet.alpha=0.5,
#'                                        max.iter=1200,
#'                                        tol=1E-6)
#' }
#'
#' Three rounds of data:
#'
#' \preformatted{
#' > df.1$Collect()
#'   ID      Y    X1    X2     X3
#' 0  1  130.0   7.0  26.0 -888.0
#' 1  2  124.0   1.0  29.0 -888.0
#' 2  3  262.0  11.0  56.0 -888.0
#' 3  4  162.0  11.0  31.0 -888.0
#'
#' > df.2$Collect()
#'    ID      Y    X1    X2     X3
#' 0   5  234.0   7.0  52.0 -888.0
#' 1   6  258.0  11.0  55.0 -888.0
#' 2   7  298.0   3.0  71.0 -888.0
#' 3   8  132.0   1.0  31.0 -888.0
#'
#' > df.3$Collect()
#'    ID      Y    X1    X2     X3
#' 0   9  227.0   2.0  54.0 -888.0
#' 1  10  256.0  21.0  47.0 -888.0
#' 2  11  168.0   1.0  40.0 -888.0
#' 3  12  302.0  11.0  66.0 -888.0
#' 4  13  307.0  10.0  68.0 -888.0
#' }
#'
#' Round 1, invoke fit() of olr for training the model with df.1:
#' \preformatted{
#' > olr$fit(df.1, key='ID', label='Y', features=list('X1', 'X2'))
#' }
#'
#' Output:
#' \preformatted{
#' > olr$coefficients$Collect()
#' VARIABLE_NAME  COEFFICIENT_VALUE
#' 0  __PAL_INTERCEPT__           5.076245
#' 1                 X1           2.987277
#' 2                 X2           4.000540
#'
#' > olr$intermediate.result$Collect()
#' SEQUENCE                                 INTERMEDIATE_MODEL
#' 0         0  "algorithm":"batch_algorithm","batch_algorith...
#' }
#'
#' Round 2, invoke fit() for training the model with df.2:
#'
#' \preformatted{
#' > olr$fit(df.2, key='ID', label='Y', features=list('X1', 'X2'))
#' }
#' Output:
#' \preformatted{
#' > olr$coefficients$Collect()
#'        VARIABLE_NAME  COEFFICIENT_VALUE
#' 0  __PAL_INTERCEPT__           5.094444
#' 1                 X1           2.988419
#' 2                 X2           3.999563
#'
#' > olr$intermediate.result$Collect()
#'    SEQUENCE                                 INTERMEDIATE_MODEL
#' 0         0  "algorithm":"batch_algorithm","batch_algorith...
#'
#' }
#'
#' Round 3, invoke fit() for training the model with df.3:
#' \preformatted{
#' > olr$fit(df.3, key='ID', label='Y', features=list('X1', 'X2'))
#' }
#' Output:
#'
#' \preformatted{
#' > olr$coefficients$Collect()
#' VARIABLE_NAME  COEFFICIENT_VALUE
#' 0  __PAL_INTERCEPT__           5.073338
#' 1                 X1           2.994118
#' 2                 X2           3.999389
#'
#' > olr$intermediate.result$Collect()
#' SEQUENCE                                 INTERMEDIATE_MODEL
#' 0         0  "algorithm":"batch_algorithm","batch_algorith...
#'
#' }
#'
#' Call score() function:
#'
#' \preformatted{
#' > score <- olr$score(df.2, key='ID', label='Y', features=list('X1', 'X2'))
#' 0.9999997918249237
#' }
#' @keywords Regression
#' @export
hanaml.OnlineLinearRegression <- function(enet.lambda = NULL,
                                          enet.alpha = NULL,
                                          max.iter = NULL,
                                          tol = NULL){
  OnlineLinearRegression$new(enet.lambda,
                             enet.alpha,
                             max.iter,
                             tol)
}

#' @title Make Predictions from a "OnlineLinearRegression" Object
#' @name predict.OnlineLinearRegression
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "OnlineLinearRegression" object.
#' @seealso \code{\link{hanaml.OnlineLinearRegression}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#' An "OnlineLinearRegression" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data}'s ID column.}
#'   \item{VALUE, type DOUBLE, representing predicted values.}
#' }
#'
#' @section Examples:
#' Call predict() with df.predict:
#' \preformatted{
#' > df.predict$Collect()
#'     ID    X1    X2
#'  0  14     2    67
#'  1  15     3    51
#' }
#'
#' Invoke predict():
#' \preformatted{
#' > fitted <- predict(olr, df.predict, key='ID', features=list('X1', 'X2'))
#' > fitted$Collect()
#'     ID       VALUE
#'  0  14  279.020611
#'  1  15  218.024511
#' }
#' @keywords Regression
#' @export
predict.OnlineLinearRegression <- function(model,
                                           data,
                                           key,
                                           features = NULL){
  if (is.null(model$model)) {
    msg <- "Model not initialized. Perform a fit first."
    flog.error(msg = msg)
    stop(msg)
  }

  lr <- hanaml.LinearRegression()
  lr$pmml <- NULL
  lr$coefficients <- NULL
  lr$model <- model$model[[1]]
  fitted <- predict(model=lr, data=data, key=key, features=features, model.format=NULL)
  return(fitted)
}

