RDTBase <- R6Class(
  "RDTBase",
  inherit = MlBase,
  public = list(
    n.estimators = NULL,
    max.features = NULL,
    max.depth = NULL,
    min.samples.leaf = NULL,
    split.threshold = NULL,
    calculate.oob = TRUE,
    random.state = NULL,
    thread.ratio = NULL,
    allow.missing.dependent = TRUE,
    categorical.variable = NULL,
    sample.fraction = NULL,
    model = NULL,
    confusion.matrix = NULL,
    feature.importances = NULL,
    oob.error = NULL,
    missing.replacement.map = list(
      "feature.marginalized" = 1,
      "instance.marginalized" = 2
    ),
    initialize = function(functionality,
                          data = NULL,
                          n.estimators = NULL,
                          max.features = NULL,
                          max.depth = NULL,
                          min.samples.leaf = NULL,
                          split.threshold = NULL,
                          calculate.oob = TRUE,
                          random.state = NULL,
                          thread.ratio = NULL,
                          allow.missing.dependent = TRUE,
                          categorical.variable = NULL,
                          sample.fraction = NULL) {
      super$initialize()
      private$functionality <- functionality
      if (!is.null(data)){
        self$n.estimators <- validateInput("n.estimators", n.estimators, "numeric")
        self$max.features <- validateInput("max.features", max.features, "numeric")
        self$max.depth <- validateInput("max.depth", max.depth, "numeric")
        self$min.samples.leaf <- validateInput("min.samples.leaf",
                                               min.samples.leaf, "numeric")
        self$split.threshold <- validateInput("split.threshold",
                                              split.threshold, "double")
        self$calculate.oob <- validateInput("calculate.oob", calculate.oob, "logical")
        self$random.state <- validateInput("random.state", random.state, "numeric")
        self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
        self$allow.missing.dependent <- validateInput("allow.missing.dependent",
                                                      allow.missing.dependent, "logical")
        if (!is.null(categorical.variable) && typeof(categorical.variable) == "character"){
          categorical.variable <- as.list(categorical.variable)
        }
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   data$columns,
                                                   case.sensitive = TRUE)
        self$sample.fraction <- validateInput("sample.fraction",
                                              sample.fraction, "double")
        self$model <- NULL
        self$confusion.matrix <- NULL
        self$feature.importances <- NULL
        self$oob.error <- NULL
      }
    },
    fit = function(data,
                   key = NULL,
                   features = NULL,
                   label = NULL,
                   formula = NULL,
                   compression = NULL,
                   max.bits = NULL,
                   quantize.rate = NULL,
                   fittings.quantization = NULL) {
      compression <- validateInput("compression",
                                   compression,
                                   "logical")
      max.bits <- validateInput("max.bits", max.bits, "integer")
      quantize.rate <- validateInput("quantize.rate",
                                     quantize.rate,
                                     "numeric")
      fittings.quantization <- validateInput("fittings.quantization",
                                             fittings.quantization,
                                             "logical")
      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE)
      if (inherits(formula, "formula")){
        parseformula <- ParseFormula(data, formula)
        label <- parseformula[[1]]
        features <- parseformula[[2]]
        features <- features[! features %in% key]
      }
      if (!is.null(key)){
        id.col <- list(key)
        cols <- cols[! cols %in% key]
      } else {
        id.col <- list()
      }
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      label.type <- data$dtypes(label)[[1]][[2]]
      if (private$functionality == 2){
        if (label.type %in% c("VARCHAR", "NVARCHAR") ||
            (label.type %in% c("INT", "INTEGER") &&
             label %in% self$categorical.variable)){
          msg <- paste("Label variable is of categorical type,",
                       "not suitable for regression.")
          flog.error(msg)
          stop(msg)
        }
      } else {
        if (label.type == "DOUBLE"){
          msg <- paste("Label variable is of continuous type,",
                       "not suitable for classification.")
          flog.error(msg)
          stop(msg)
        } else if (label.type %in% c("INT", "INTEGER")) {
          self$categorical.variable <- c(self$categorical.variable,
                                         label)
        }
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features)){
        features <- cols
      }
      if (!is.null(self$max.features) && (self$max.features > length(features))) {
        msg <- paste("max.features should not be larger",
                     "than the number of features in the input.")
        flog.error(msg)
        stop(msg)
      }

      feature.col <- id.col
      for (element in features)
        feature.col <- append(feature.col, element)
      feature.col <- append(feature.col, label)
      if (!inherits(data, "DataFrame")) {
        msg <- "If training data is not omitted, it must be DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)

      df <- data$Select(feature.col)

      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#PAL_RANDOM_FOREST_PARAMS_TBL_%s", self$id, unique.id)
      model.tbl <- sprintf("#PAL_RANDOM_FOREST_MODEL_TBL_%s_%s", self$id, unique.id)
      cm.tbl <- sprintf("#PAL_RANDOM_FOREST_CONFUSION_MATRIX_TBL_%s_%s", self$id, unique.id)
      var.importance.tbl <- sprintf("#PAL_RANDOM_FOREST_VAR_IMPORTANCE_TBL_%s_%s", self$id, unique.id)
      oob.err.tbl <- sprintf("#PAL_RANDOM_FOREST_OOB_ERR_TBL_%s_%s", self$id, unique.id)

      param.rows <- list(
        tuple("TREES_NUM", self$n.estimators, NULL, NULL),
        tuple("TRY_NUM", self$max.features, NULL, NULL),
        tuple("MAX_DEPTH", self$max.depth, NULL, NULL),
        tuple("NODE_SIZE", self$min.samples.leaf, NULL, NULL),
        tuple("SPLIT_THRESHOLD", NULL, self$split.threshold, NULL),
        tuple("CALCULATE_OOB", to.integer(self$calculate.oob), NULL, NULL),
        tuple("SEED", self$random.state, NULL, NULL),
        tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
        tuple(
          "ALLOW_MISSING_DEPENDENT",
          to.integer(self$allow.missing.dependent),
          NULL,
          NULL
        ),
        tuple("SAMPLE_FRACTION", NULL, self$sample.fraction, NULL),
        tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL),
        tuple("COMPRESSION", to.integer(compression),
              NULL, NULL),
        tuple("MAX_BITS", max.bits, NULL, NULL),
        tuple("QUANTIZE_RATE", NULL, quantize.rate, NULL),
        tuple("FITTINGS_QUANTIZATION", to.integer(fittings.quantization),
              NULL, NULL)
      )
      if (!is.null(self$categorical.variable)) {
        for (each in self$categorical.variable) {
          temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
          param.rows <-
            append(param.rows, tuple(temp.list))
        }
      }
      index.dtype.temp <- df$dtypes(label)
      index.dtype <- index.dtype.temp[[1]]
      label.t <- index.dtype[2]

      if (length(self$strata) > 0) { #nolint
        lenstrata <- length(self$strata)
        ltuple.flag <- is.tuple(self$strata[[1]])
        for (x in seq(lenstrata)) {
          if (ltuple.flag) {
            strata_value <- unlist(self$strata[[x]])
            cl.type <- strata_value[1]
            frctn <- strata_value[2]
          } else {
            cl.type <- names(self$strata[x])
            frctn <- self$strata[[x]]
          }
          if (isTRUE(grepl("INT", label.t))) {
            tempstrata.tuple <- tuple("STRATA", cl.type, frctn, NULL)
            param.rows <-
              append(param.rows, list(tempstrata.tuple))
          } else {
            if (isTRUE(grepl("CHAR", label.t))) {
              tempstrata.tuple <- tuple("STRATA", NULL, frctn, cl.type)
              param.rows <- append(param.rows, list(tempstrata.tuple))
            }
          }
        }
      }
      if (length(self$priors) > 0) { #nolint
        lenpriors <- length(self$priors)
        ltuple.flag <- is.tuple(self$priors[[1]])
        for (x in seq(lenpriors)) {
          if (ltuple.flag) {
            priors_value <- unlist(self$priors[[x]])
            cl.type <- priors_value[1]
            priorprob <- priors_value[2]
          } else {
            cl.type <- names(self$priors[x])
            priorprob <- self$priors[[x]]
          }
          if (isTRUE(grepl("INT", label.t))) {
            temppriors.tuple <- tuple("PRIORS", cl.type, priorprob, NULL)
            param.rows <-
              append(param.rows, list(temppriors.tuple))
          } else {
            if (isTRUE(grepl("CHAR", label.t))) {
              temppriors.tuple <- tuple("PRIORS", NULL, priorprob, cl.type)
              param.rows <- append(param.rows, list(temppriors.tuple))
            }
          }
        }
      }
      tables <-
        list(param.tbl,
             model.tbl,
             var.importance.tbl,
             oob.err.tbl,
             cm.tbl)
      in.tables <- list(df, param.tbl)
      out.tables <-
        list(model.tbl,
             var.importance.tbl,
             oob.err.tbl,
             cm.tbl)
      tryCatch({
        errorhelper(CreateTWithConnection(conn,
                                          ParameterTable$new(param.tbl)$WithData(param.rows)))
        errorhelper(CallPalAutoWithConnection(conn,
                                              "PAL_RANDOM_DECISION_TREES",
                                              in.tables,
                                              out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn, tables)
        stop(msg)
      })

      self$model <- conn$table(model.tbl)
      if (private$functionality == 1){
        self$confusion.matrix <- conn$table(cm.tbl)
      }
      self$feature.importances <- conn$table(var.importance.tbl)
      self$oob.error <- conn$table(oob.err.tbl)
    },
    predict = function(data,
                       key,
                       features = NULL,
                       verbose = NULL,
                       block.size = NULL,
                       missing.replacement = NULL) {
      if (is.null(self$model)){
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")){
        msg <- "Data for prediction must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)

      verbose <- validateInput("verbose", verbose, "logical")
      block.size <- validateInput("block.size", block.size, "integer")
      missing.replacement <- validateInput("missing.replacement",
                                           missing.replacement,
                                           self$missing.replacement.map)
      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features)){
        features <- cols
      }
      temp <- list(key)
      for (element in features)
        temp <- append(temp, element)
      df <- data$Select(temp)
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      model.tbl <- sprintf("#PAL_RANDOM_FOREST_MODEL_TBL_%s_%s", self$id, unique.id)
      param.tbl <- sprintf("#PAL_RANDOM_FOREST_PARAM_%s_%s", self$id, unique.id)
      result.tbl <- sprintf("#PAL_RANDOM_FOREST_FITTED_TBL_%s_%s", self$id, unique.id)
      tables <- list(param.tbl, result.tbl)
      in.tables <- list(df, self$model$name, param.tbl)
      out.tables <- list(result.tbl)
      param.rows <-
        list(
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple("VERBOSE", to.integer(verbose), NULL, NULL),
          tuple("BLOCK_SIZE", block.size, NULL, NULL),
          tuple("MISSING_REPLACEMENT",
                map.null(missing.replacement, self$missing.replacement.map),
                NULL, NULL)
        )
      tryCatch({
        errorhelper(CreateTWithConnection(conn,
                                          ParameterTable$new(param.tbl)$WithData(param.rows)))
        errorhelper(CallPalAutoWithConnection(conn,
                                              "PAL_RANDOM_DECISION_TREES_PREDICT",
                                              in.tables,
                                              out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn, tables)
        stop(msg)
      })
      return (conn$table(result.tbl))
    }
  ),
  private = list(
    functionality = NULL
  )
)


RDTClassifier <- R6Class(
  "RDTClassifier",
  inherit = RDTBase,
  public = list(
    strata = NULL,
    priors = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          n.estimators = NULL,
                          max.features = NULL,
                          max.depth = NULL,
                          min.samples.leaf = NULL,
                          split.threshold = NULL,
                          calculate.oob = TRUE,
                          random.state = NULL,
                          thread.ratio = NULL,
                          allow.missing.dependent = TRUE,
                          categorical.variable = NULL,
                          sample.fraction = NULL,
                          strata = NULL,
                          priors = NULL,
                          compression = NULL,
                          max.bits = NULL,
                          quantize.rate = NULL) {
      super$initialize(1,
                       data,
                       n.estimators,
                       max.features,
                       max.depth,
                       min.samples.leaf,
                       split.threshold,
                       calculate.oob,
                       random.state,
                       thread.ratio,
                       allow.missing.dependent,
                       categorical.variable,
                       sample.fraction)
      if (!is.null(data)) {
        self$strata <- strata
        self$priors <- priors
        super$fit(data = data,
                  key = key,
                  features = features,
                  label = label,
                  formula = formula,
                  compression = compression,
                  max.bits = max.bits,
                  quantize.rate = quantize.rate)
      }
    },
    predict = function(data,
                       key,
                       features = NULL,
                       verbose = NULL,
                       block.size = NULL,
                       missing.replacement = NULL) {
      predictreturn <- super$predict(
        data = data,
        key = key,
        features = features,
        verbose = verbose,
        block.size = block.size,
        missing.replacement = missing.replacement
      )
      return(predictreturn)
    },
    score = function(data,
                     key,
                     features = NULL,
                     label = NULL,
                     verbose = NULL,
                     block.size = NULL,
                     missing.replacement = NULL) {
      block.size <- validateInput("block.size", block.size, "integer")
      if (!inherits(data, "DataFrame")) {
        msg <- "Data for score must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)
      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features)){
        features <- cols
      }
      prediction <- self$predict(data,
                                 key = key,
                                 features = features,
                                 verbose = verbose,
                                 block.size = block.size,
                                 missing.replacement = missing.replacement)#nolint
      prediction <- prediction$Select(list(key, "SCORE"))
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      acc.score <- accuracy.score(conn,
                                  joined,
                                  label.true = "ACTUAL",
                                  label.pred = "PREDICTION")
      return(acc.score)
    }
  )
)
#' @title Random Decision Trees for Classification
#' @name hanaml.RDTClassifier
#' @description hanaml.RDTClassifier is a R wrapper for SAP HANA PAL Random
#'  Decision Trees for classification.
#' @seealso \code{\link{predict.RDTClassifier}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @param   n.estimators  \code{integer, optional}\cr
#'         Specifies the number of decision trees in the model.\cr
#'         Defaults to 100.
#' @param   max.features  \code{integer, optional}\cr
#'         Specifies the number of randomly selected splitting variables.\cr
#'         Should not be larger than the number of input features.\cr
#'         Defaults to \eqn{sqrt(p)},
#'         where p is the number of input features.
#' @param  max.depth  \code{integer, optional}\cr
#'         The maximum depth of a tree.\cr
#'         No default value, but the maximum value SAP HANA PAL supports is 56.
#' @param  min.samples.leaf  \code{integer, optional}\cr
#'         Specifies the minimum number of records in a leaf.\cr
#'         Defaults to 1 for classification.
#' @param  split.threshold  \code{double, optional}\cr
#'         Specifies the stop condition: if the improvement value of the best
#'         split is less than this value, the tree stops growing.
#'         Defaults to 1e-5.
#' @param  calculate.oob  \code{logical, optional}\cr
#'         If TRUE, calculate the out-of-bag error.\cr
#'         Defaults to TRUE.
#' @param  random.state  \code{integer, optional}\cr
#'         Specifies the seed for random number generator.
#'         \itemize{
#'           \item{0}: Uses the current time (in seconds) as the seed.
#'           \item{Others}: Uses the specified value as the seed.
#'         }
#'         Defaults to 0.
#' @template args-threadratio-1
#' @param   allow.missing.dependent  \code{logical, optional}\cr
#'         Specifies if a missing target value is allowed.
#'         \itemize{
#'           \item{FALSE}: Not allowed. An error occurs if a missing target is present.
#'           \item{TRUE}: Allowed. The datum with the missing target is removed.
#'         }
#'         Defaults to TRUE.
#' @template args-cate-var
#' @param  sample.fraction  \code{double, optional}\cr
#'         The fraction of data used for training.\cr
#'         Assume there are n pieces of data, sample fraction is r, then n*r
#'         data is selected for training.\cr
#'         Defaults to 1.0.
#' @param  strata  \code{List of tuples: (class, fraction), optional}\cr
#'         Strata proportions for stratified sampling. A (class, fraction) tuple
#'         specifies that rows with that class should make up the specified
#'         fraction of each sample. If the given fractions do not add up to 1,
#'         the remaining portion is divided equally between classes with
#'         no entry in \emph{strata}, or between all classes if all classes have
#'         an entry in \emph{strata}.\cr
#'         If \emph{strata} is not provided, bagging is used instead of stratified
#'         sampling.
#' @param  priors  \code{List of tuples: (class, prior_prob), optional}\cr
#'         Prior probabilities for classes. A (class, prior_prob) tuple
#'         specifies the prior probability of this class. If the given
#'         priors do not add up to 1, the remaining portion is divided equally
#'         between classes with no entry in \emph{priors}, or between all classes
#'         if all classes have an entry in 'priors'.\cr
#'         If \emph{priors} is not provided, it is determined by the proportion of
#'         every class in the training data.
#' @param  compression \code{logical, optional}\cr
#'         Specifies whether model is stored in compressed format or not.\cr
#'         Defaults to FALSE.
#' @param  max.bits \code{integer, optional}\cr
#'         Spefifies the maximum number of bits to quantize continous features, which
#'         is equivalent to use \ifelse{html}{\out{2<sup>max.bits</sup>}}{\eqn{2^{max.bits}}}
#'         bins.
#'         Must be less than 31.\cr
#'         Defaults to 12.
#' @param  quantize.rate \code{numeric, optional}\cr
#'         Specifies the threshold value that, if the frequency of the largest class of a categorical features
#'         is below the threshold, then this categorical feature is quantized.\cr
#'         Valid only when \code{compression} is TRUE.\cr
#'         Defaults to 0.05.
#' @return
#'Return a "RDTClassifier" object with following attributes:
#'\itemize{
#'    \item{model : \code{DataFrame}}\cr
#'         Trained model content.
#'    \item{feature.importances : \code{DataFrame}}\cr
#'         The feature importance (the higher, the more important the feature).
#'    \item{oob.error : \code{DataFrame}}\cr
#'        Out-of-bag error rate or mean squared error for random decision trees up
#'         to indexed tree.
#'         Set to NULL if \emph{calculate.oob} is FALSE.
#'    \item{confusion.matrix : \code{DataFrame}}\cr
#'        Confusion matrix used to evaluate the performance of
#'        classification algorithms.
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#'  > data$Collect()
#'       OUTLOOK TEMP HUMIDITY WINDY       CLASS
#'   1     Sunny   75       70   Yes        Play
#'   2     Sunny   80       90   Yes Do not Play
#'   3     Sunny   85       85    No Do not Play
#'   4     Sunny   72       95    No Do not Play
#'   5     Sunny   69       70    No        Play
#'   6  Overcast   72       90   Yes        Play
#'   7  Overcast   83       78    No        Play
#'   8  Overcast   64       65   Yes        Play
#'   9  Overcast   81       75    No        Play
#'  10     Rain   71       80    Yes Do not Play
#'  11     Rain   65       70    Yes Do not Play
#'  12     Rain   75       80     No        Play
#'  13     Rain   68       80     No        Play
#'  14     Rain   70       96     No        Play
#' }
#' Call the function:
#' \preformatted{
#' > rfc <- hanaml.RDTClassifier(data = data,
#'                               n.estimators=300,
#'                               max.features=3,
#'                               random.state=2,
#'                               split.threshold=0.00001,
#'                               calculate.oob=TRUE,
#'                               min.samples.leaf=1,
#'                               thread.ratio=1.0)
#' }
#'
#' OR Giving features and labels as input to generating a model:
#' \preformatted{
#' > rfc <- hanaml.RDTClassifier(data = data,
#'                               n.estimators=300,
#'                               max.features=3,
#'                               features = list('TEMP', 'HUMIDITY', 'WINDY'),
#'                               label = "CLASS",
#'                               random.state=2,
#'                               split.threshold=0.00001,
#'                               calculate.oob=TRUE,
#'                               min.samples.leaf=1,
#'                               thread.ratio=1.0)
#' }
#' OR Giving input to model generation as a formula:
#' \preformatted{
#' > rfc <- hanaml.RDTClassifier(data = data,
#'                               n.estimators=300,
#'                               max.features=3,
#'                               formula=CATEGORY~V1+V2+V3,
#'                               random.state=2,
#'                               split.threshold=0.00001,
#'                               calculate.oob=TRUE,
#'                               min.samples.leaf=1,
#'                               thread.ratio=1.0)
#' }
#' Output:
#' \preformatted{
#' > rfc$feature.importances$Collect()
#'   VARIABLE_NAME IMPORTANCE
#' 1       OUTLOOK  0.3475185
#' 2          TEMP  0.2770724
#' 3      HUMIDITY  0.2476346
#' 4         WINDY  0.1277744
#' }
#' @keywords Classification
#' @export
hanaml.RDTClassifier <- function(data = NULL,
                                 key = NULL,
                                 features = NULL,
                                 label = NULL,
                                 formula = NULL,
                                 n.estimators = NULL,
                                 max.features = NULL,
                                 max.depth = NULL,
                                 min.samples.leaf = NULL,
                                 split.threshold = NULL,
                                 calculate.oob = NULL,
                                 random.state = NULL,
                                 thread.ratio = NULL,
                                 allow.missing.dependent = NULL,
                                 categorical.variable = NULL,
                                 sample.fraction = NULL,
                                 strata = NULL,
                                 priors = NULL,
                                 compression = NULL,
                                 max.bits = NULL,
                                 quantize.rate = NULL) {
  RDTClassifier$new(data, key, features, label, formula,
                    n.estimators, max.features,
                    max.depth, min.samples.leaf, split.threshold,
                    calculate.oob, random.state, thread.ratio,
                    allow.missing.dependent, categorical.variable,
                    sample.fraction, strata, priors, compression,
                    max.bits, quantize.rate)
}


RDTRegressor <- R6Class(
  "RDTRegressor",
  inherit = RDTBase,
  public = list(
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          n.estimators = NULL,
                          max.features = NULL,
                          max.depth = NULL,
                          min.samples.leaf = NULL,
                          split.threshold = NULL,
                          calculate.oob = TRUE,
                          random.state = NULL,
                          thread.ratio = NULL,
                          allow.missing.dependent = TRUE,
                          categorical.variable = NULL,
                          sample.fraction = NULL,
                          compression = NULL,
                          max.bits = NULL,
                          quantize.rate = NULL,
                          fittings.quantization = NULL) {
      super$initialize(2,
                       data,
                       n.estimators,
                       max.features,
                       max.depth,
                       min.samples.leaf,
                       split.threshold,
                       calculate.oob,
                       random.state,
                       thread.ratio,
                       allow.missing.dependent,
                       categorical.variable,
                       sample.fraction)
      if (!is.null(data)){
        self$confusion.matrix <- NULL
        super$fit(data = data,
                  key = key,
                  features = features,
                  label = label,
                  formula = formula,
                  compression = compression,
                  max.bits = max.bits,
                  quantize.rate = quantize.rate,
                  fittings.quantization = fittings.quantization)
      }
    },
    predict = function(data,
                       key,
                       features = NULL,
                       block.size = NULL,
                       verbose = NULL,
                       missing.replacement = NULL) {
      predictreturn <- super$predict(data = data,
                                     key = key,
                                     features = features,
                                     block.size = block.size,
                                     verbose = verbose,
                                     missing.replacement = missing.replacement)
      return(predictreturn)
    },
    score = function(data,
                     key,
                     features = NULL,
                     label = NULL,
                     block.size = NULL,
                     missing.replacement = NULL) {
      if (!inherits(data, "DataFrame")) {
        msg <- "Data for score must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)

      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features)){
        features <- cols
      }

      prediction <- self$predict(data,
                                 key = key,
                                 features = features,
                                 verbose = NULL,
                                 block.size = block.size,
                                 missing.replacement = missing.replacement)#nolint
      original <- data$Select(list(key, label))
      prediction <- prediction$Select(list(key, "SCORE"))
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      original <- data$Select(list(key, label))
      original <- original$rename.columns(list("ID_A", "ACTUAL"))
      joined <- original$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      r2.score <- r2.score(conn,
                           joined,
                           label.true = "ACTUAL",
                           label.pred = "PREDICTION")
      return(r2.score)
    }
  )
)
#' @title Random Decision Trees for Regression
#' @name hanaml.RDTRegressor
#' @description hanaml.RDTRegressor is a R wrapper for SAP HANA PAL
#'  Random Decision Trees for regression.

#' @keywords Regression
#' @seealso \code{\link{predict.RDTRegressor}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @param     n.estimators  \code{integer, optional}\cr
#'            Specifies the number of decision trees in the model.\cr
#'            Defaults to 100.
#' @param     max.features  \code{integer, optional}\cr
#'            Specifies the number of randomly selected splitting variables.\cr
#'            Should not be larger than the number of input features.\cr
#'            Defaults to \eqn{p/3}, where p is the number of input features.
#' @param     max.depth  \code{integer, optional}\cr
#'            The maximum depth of a tree.\cr
#'            No default value, but the maximum value SAP HANA PAL supports is 56.
#' @param     min.samples.leaf  \code{integer, optional}\cr
#'            Specifies the minimum number of records in a leaf.\cr
#'            Defaults to 5 for regression.
#' @param     split.threshold  \code{double , optional}\cr
#'            Specifies the stop condition: if the improvement value of the best
#'            split is less than this value, the tree stops growing.\cr
#'            Defaults to 1e-5.
#' @param     calculate.oob  \code{logical, optional}\cr
#'            If TRUE, calculate the out-of-bag error.\cr
#'            Defaults to TRUE.
#' @param     random.state  \code{integer, optional}\cr
#'            Specifies the seed for random number generator.
#'            \itemize{
#'              \item{0}: Uses the current time (in seconds) as the seed.
#'              \item{Others}: Uses the specified value as the seed.
#'            }
#'            Defaults to 0.
#' @template args-threadratio-1
#' @param     allow.missing.dependent  \code{logical, optional}\cr
#'            Specifies if a missing target value is allowed.
#'            \itemize{
#'              \item{FALSE}: Not allowed. An error occurs if a missing target is present.
#'              \item{TRUE}: Allowed. The datum with a missing target is removed.
#'              }
#'            Defaults to TRUE.
#' @template args-cate-var
#' @param     sample.fraction  \code{double, optional}\cr
#'            The fraction of data used for training.\cr
#'            Assume there are n pieces of data, sample fraction is r, then n*r
#'            data is selected for training.\cr
#'            Defaults to 1.0.
#' @param  compression \code{logical, optional}\cr
#'         Specifies whether model is stored in compressed format or not.\cr
#'         Defaults to FALSE.
#' @param  max.bits \code{integer, optional}\cr
#'         Spefifies the maximum number of bits to quantize continous features, which
#'         is equivalent to use \ifelse{html}{\out{2<sup>max.bits</sup>}}{\eqn{2^{max.bits}}}
#'         bins.\cr
#'         Must be less than 31.\cr
#'         Defaults to 12.
#' @param  quantize.rate \code{numeric, optional}\cr
#'         Specifies the threshold value that, if the frequency of the largest class of a categorical features
#'         is below the threshold, then this categorical feature is quantized.\cr
#'         Valid only when \code{compression} is TRUE.\cr
#'         Defaults to 0.05.
#' @param  fittings.quantization \code{logical, optional}\cr
#'         Specifies whether to quantize fitting values or not.\cr
#'         Valid only when \code{compression} is TRUE.\cr
#'         Defaults to FALSE.
#' @return
#' Returns a "RDTRegressor" object with following values:
#'\itemize{
#'    \item{model : \code{DataFrame}}\cr
#'         Trained model content.
#'    \item{feature.importances : \code{DataFrame}}\cr
#'         The feature importance (the higher, the more important the feature).
#'    \item{oob.error : \code{DataFrame}}\cr
#'         Out-of-bag error rate or mean squared error for random decision trees up
#'         to indexed tree.
#'         Set to NULL if \emph{calculate.oob} is FALSE.
#'}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' >data$Collect()
#'    ID         A         B         C         D       CLASS
#' 1   0 -0.965679  1.142985 -0.019274 -1.598807  -23.633813
#' 2   1  2.249528  1.459918  0.153440 -0.526423  212.532559
#' 3   2 -0.631494  1.484386 -0.335236  0.354313   26.342585
#' 4   3 -0.967266  1.131867 -0.684957 -1.397419  -62.563666
#' 5   4 -1.175179 -0.253179 -0.775074  0.996815 -115.534935
#' ......
#' }
#' Call the function:
#' \preformatted{
#' > rfr <- hanaml.RDTRegressor(data = data, random.state = 3)
#' }
#' Output:
#' \preformatted{
#' > rfr$feature.importances$Collect()
#'    VARIABLE_NAME  IMPORTANCE
#' 1             A    0.249593
#' 2             B    0.381879
#' 3             C    0.291403
#' 4             D    0.077125
#' }
#' @keywords Regression
#' @export
hanaml.RDTRegressor <- function(data = NULL,
                                key = NULL,
                                features = NULL,
                                label = NULL,
                                formula = NULL,
                                n.estimators = NULL,
                                max.features = NULL,
                                max.depth = NULL,
                                min.samples.leaf = NULL,
                                split.threshold = NULL,
                                calculate.oob = NULL,
                                random.state = NULL,
                                thread.ratio = NULL,
                                allow.missing.dependent = NULL,
                                categorical.variable = NULL,
                                sample.fraction = NULL,
                                compression = NULL,
                                max.bits = NULL,
                                quantize.rate = NULL,
                                fittings.quantization = NULL) {
  RDTRegressor$new(data, key, features, label, formula,
                   n.estimators, max.features,
                   max.depth, min.samples.leaf, split.threshold,
                   calculate.oob, random.state, thread.ratio,
                   allow.missing.dependent, categorical.variable,
                   sample.fraction, compression,
                   max.bits, quantize.rate,
                   fittings.quantization)
}

#' @title Make Predictions from a "RDTClassifier" Object
#' @name predict.RDTClassifier
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "RDTClassifier" object.
#' @seealso \code{\link{hanaml.RDTClassifier}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#' A "RDTClassifier" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-verbose
#' @param block.size  \code{integer, optional}\cr
#'        The number of rows loaded per time during prediction.
#'        0 indicates load all data at once.\cr
#'        Defaults to 0.
#' @param missing.replacement  \code{character, optional}\cr
#'        The missing replacement strategy:
#'        \itemize{
#'          \item{'feature.marginalized'}: marginalize each missing feature out
#'            independently.
#'          \item{'instance.marginalized'}: marginalize all missing features
#'            in an instance as a whole corresponding to each category.
#'        }
#'        Defaults to "feature.marginalized".
#' @return \code{Dataframe}\cr
#' Predicted values, structured as follows.
#' \itemize{
#'   \item{ID}, with same name and type as \code{data}'s ID column.
#'   \item{SCORE}, type NVARCHAR, predicted class labels.
#'   \item{CONFIDENCE}, type DOUBLE. Representing the confidence of a class.
#' }
#' @section Examples:
#' Call the function with a "RDTClassifier" object rfc:
#' \preformatted{
#' > predict(rfc, data, key = 'ID')
#'}
#' @keywords Classification
#' @export
predict.RDTClassifier <-
  function(model,
           data,
           key,
           features = NULL,
           verbose = NULL,
           block.size = NULL,
           missing.replacement = NULL) {
    model$predict(data = data,
                  key = key,
                  features = features,
                  verbose = verbose,
                  block.size = block.size,
                  missing.replacement = missing.replacement)
  }

#' @title Make Predictions from a "RDTRegressor" Object
#' @name predict.RDTRegressor
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "RDTRegressor" object.
#' @seealso \code{\link{hanaml.RDTRegressor}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A "RDTRegressor" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param block.size  \code{integer, optional}\cr
#'        The number of rows loaded per time during prediction.
#'        0 indicates load all data at once. \cr
#'        Defaults to 0.
#' @param missing.replacement  \code{character, optional}\cr
#'        The missing replacement strategy:
#'        \itemize{
#'          \item{'feature.marginalized'}: marginalize each missing feature out
#'            independently.
#'          \item{'instance.marginalized'}: marginalize all missing features
#'            in an instance as a whole corresponding to each category.
#'        }
#'        Defaults to 'feature.marginalized'.
#' @return
#' DataFrame of predicted values, structured as follows.
#'\itemize{
#'   \item{ID}, with same name and type as \code{data}'s ID column.
#'   \item{SCORE}, type NVARCHAR, predicted values.
#'   \item{CONFIDENCE}, type DOUBLE. Representing the confidence of a class. All 0s for regression.
#'}
#' @section Examples:
#' Call the function with a "RDTRegressor" object rfr:
#' \preformatted{
#' > predict(rfr, data, key = 'ID')
#' }
#' @keywords Regression
#' @export
predict.RDTRegressor <-
  function(model,
           data,
           key,
           features = NULL,
           block.size = NULL,
           missing.replacement = NULL) {
    model$predict(data = data,
                  key = key,
                  features = features,
                  verbose = NULL,
                  block.size = block.size,
                  missing.replacement = missing.replacement)
  }

#' @export
summary.RDTClassifier <- function(object, ...) {
  writeLines("RDTClassifier model DataFrame:")
  print(object$model$Collect())
  writeLines("\n")
  writeLines("RDTClassifier feature.importances DataFrame:")
  print(object$feature.importances$Collect())
  writeLines("\n")
  writeLines("RDTClassifier oob.error DataFrame:")
  print(object$oob.error$Collect())
  writeLines("\n")

}

#' @export
print.RDTClassifier <- function(x, ...) {
  writeLines("\n")
  writeLines("Random Decision Trees Classifier attributes:")
  writeLines("\n")
  cat(sprintf("n.estimators : %s", to.null(x$n.estimators)))
  writeLines("\n")
  cat(sprintf("max.features : %s", to.null(x$max.features)))
  writeLines("\n")
  cat(sprintf("pmml.export : %s", to.null(x$max.depth)))
  writeLines("\n")
  cat(sprintf("min.samples.leaf : %s", to.null(x$min.samples.leaf)))
  writeLines("\n")
  cat(sprintf("split.threshold : %s", to.null(x$split.threshold)))
  writeLines("\n")
  cat(sprintf("calculate.oob : %s", to.null(x$calculate.oob)))
  writeLines("\n")
  cat(sprintf("random.state : %s", to.null(x$random.state)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("allow.missing.dependent : %s", to.null(x$allow.missing.dependent)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("sample.fraction : %s", to.null(x$sample.fraction)))
  writeLines("\n")
}

#' @export
summary.RDTRegressor <- function(object, ...) {
  writeLines("RDTRegressor model DataFrame:")
  print(object$model$Collect())
  writeLines("\n")
  writeLines("RDTRegressor feature.importances DataFrame:")
  print(object$feature.importances$Collect())
  writeLines("\n")
  writeLines("RDTRegressor oob.error DataFrame:")
  print(object$oob.error$Collect())
  writeLines("\n")
}

#' @export
print.RDTRegressor <- function(x, ...) {
  writeLines("\n")
  writeLines("Random Decision Trees Regressor attributes:")
  writeLines("\n")
  cat(sprintf("n.estimators : %s", to.null(x$n.estimators)))
  writeLines("\n")
  cat(sprintf("max.features : %s", to.null(x$max.features)))
  writeLines("\n")
  cat(sprintf("pmml.export : %s", to.null(x$max.depth)))
  writeLines("\n")
  cat(sprintf("min.samples.leaf : %s", to.null(x$min.samples.leaf)))
  writeLines("\n")
  cat(sprintf("split.threshold : %s", to.null(x$split.threshold)))
  writeLines("\n")
  cat(sprintf("calculate.oob : %s", to.null(x$calculate.oob)))
  writeLines("\n")
  cat(sprintf("random.state : %s", to.null(x$random.state)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("allow.missing.dependent : %s", to.null(x$allow.missing.dependent)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("sample.fraction : %s", to.null(x$sample.fraction)))
  writeLines("\n")
}




RandomForestClassifier <- R6Class(
  "RandomForestClassifier",
  inherit = RDTClassifier
)
#' @export
hanaml.RandomForestClassifier <- function(data = NULL,
                                          key = NULL,
                                          features = NULL,
                                          label = NULL,
                                          formula = NULL,
                                          n.estimators = NULL,
                                          max.features = NULL,
                                          max.depth = NULL,
                                          min.samples.leaf = NULL,
                                          split.threshold = NULL,
                                          calculate.oob = NULL,
                                          random.state = NULL,
                                          thread.ratio = NULL,
                                          allow.missing.dependent = NULL,
                                          categorical.variable = NULL,
                                          sample.fraction = NULL,
                                          strata = NULL,
                                          priors = NULL,
                                          compression = NULL,
                                          max.bits = NULL,
                                          quantize.rate = NULL) {
  RandomForestClassifier$new(data, key, features, label, formula,
                             n.estimators, max.features,
                             max.depth, min.samples.leaf, split.threshold,
                             calculate.oob, random.state, thread.ratio,
                             allow.missing.dependent, categorical.variable,
                             sample.fraction, strata, priors, compression,
                             max.bits, quantize.rate)
}


RandomForestRegressor <- R6Class(
  "RandomForestRegressor",
  inherit = RDTRegressor
)
#' @export
hanaml.RandomForestRegressor <- function(data = NULL,
                                         key = NULL,
                                         features = NULL,
                                         label = NULL,
                                         formula = NULL,
                                         n.estimators = NULL,
                                         max.features = NULL,
                                         max.depth = NULL,
                                         min.samples.leaf = NULL,
                                         split.threshold = NULL,
                                         calculate.oob = NULL,
                                         random.state = NULL,
                                         thread.ratio = NULL,
                                         allow.missing.dependent = NULL,
                                         categorical.variable = NULL,
                                         sample.fraction = NULL,
                                         compression = NULL,
                                         max.bits = NULL,
                                         quantize.rate = NULL,
                                         fittings.quantization = NULL) {
  RandomForestRegressor$new(data, key, features, label, formula,
                            n.estimators, max.features,
                            max.depth, min.samples.leaf, split.threshold,
                            calculate.oob, random.state, thread.ratio,
                            allow.missing.dependent, categorical.variable,
                            sample.fraction, compression,
                            max.bits, quantize.rate,
                            fittings.quantization)
}

#' @export
predict.RandomForestClassifier <-
  function(model,
           data,
           key,
           features = NULL,
           verbose = NULL,
           block.size = NULL,
           missing.replacement = NULL) {
    model$predict(data = data,
                  key = key,
                  features = features,
                  verbose = verbose,
                  block.size = block.size,
                  missing.replacement = missing.replacement)
  }

#' @export
predict.RandomForestRegressor <-
  function(model,
           data,
           key,
           features = NULL,
           block.size = NULL,
           missing.replacement = NULL) {
    model$predict(data = data,
                  key = key,
                  features = features,
                  verbose = NULL,
                  block.size = block.size,
                  missing.replacement = missing.replacement)
  }

#' @export
summary.RandomForestClassifier <- function(object, ...) {
  writeLines("RandomForestClassifier model DataFrame:")
  print(object$model$Collect())
  writeLines("\n")
  writeLines("RandomForestClassifier feature.importances DataFrame:")
  print(object$feature.importances$Collect())
  writeLines("\n")
  writeLines("RandomForestClassifier oob.error DataFrame:")
  print(object$oob.error$Collect())
  writeLines("\n")

}

#' @export
print.RandomForestClassifier <- function(x, ...) {
  writeLines("\n")
  writeLines("Random Decision Trees Classifier attributes:")
  writeLines("\n")
  cat(sprintf("n.estimators : %s", to.null(x$n.estimators)))
  writeLines("\n")
  cat(sprintf("max.features : %s", to.null(x$max.features)))
  writeLines("\n")
  cat(sprintf("pmml.export : %s", to.null(x$max.depth)))
  writeLines("\n")
  cat(sprintf("min.samples.leaf : %s", to.null(x$min.samples.leaf)))
  writeLines("\n")
  cat(sprintf("split.threshold : %s", to.null(x$split.threshold)))
  writeLines("\n")
  cat(sprintf("calculate.oob : %s", to.null(x$calculate.oob)))
  writeLines("\n")
  cat(sprintf("random.state : %s", to.null(x$random.state)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("allow.missing.dependent : %s", to.null(x$allow.missing.dependent)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("sample.fraction : %s", to.null(x$sample.fraction)))
  writeLines("\n")
}

#' @export
summary.RandomForestRegressor <- function(object, ...) {
  writeLines("RandomForestRegressor model DataFrame:")
  print(object$model$Collect())
  writeLines("\n")
  writeLines("RandomForestRegressor feature.importances DataFrame:")
  print(object$feature.importances$Collect())
  writeLines("\n")
  writeLines("RandomForestRegressor oob.error DataFrame:")
  print(object$oob.error$Collect())
  writeLines("\n")
}

#' @export
print.RandomForestRegressor <- function(x, ...) {
  writeLines("\n")
  writeLines("Random Decision Trees Regressor attributes:")
  writeLines("\n")
  cat(sprintf("n.estimators : %s", to.null(x$n.estimators)))
  writeLines("\n")
  cat(sprintf("max.features : %s", to.null(x$max.features)))
  writeLines("\n")
  cat(sprintf("pmml.export : %s", to.null(x$max.depth)))
  writeLines("\n")
  cat(sprintf("min.samples.leaf : %s", to.null(x$min.samples.leaf)))
  writeLines("\n")
  cat(sprintf("split.threshold : %s", to.null(x$split.threshold)))
  writeLines("\n")
  cat(sprintf("calculate.oob : %s", to.null(x$calculate.oob)))
  writeLines("\n")
  cat(sprintf("random.state : %s", to.null(x$random.state)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("allow.missing.dependent : %s", to.null(x$allow.missing.dependent)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("sample.fraction : %s", to.null(x$sample.fraction)))
  writeLines("\n")
}
