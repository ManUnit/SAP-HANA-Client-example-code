#' @title Unified API for model training
#' @description Unified API for model training with parameter tuning
#' @name hanaml.train
#' @seealso \code{\link{hanaml.range}}
#' @template args-data
#' @param method \code{character}\cr
#'  Name of HANA ML functions.\cr
#' @param trControl \code{train.control}\cr
#'  Pass train.control function.\cr
#' @param tuneGrid \code{param.grid}\cr
#'  Pass param.grid function.\cr
#' @param metric \code{character}\cr
#'  Scoring metric. Identical to evaluation.metric in HANA ML functions.
#'  then no model evaluation or parameter selection will be activated.\cr
#'  No default value.
#' @param  param.search.strategy   \code{c('grid', 'random'), optional}\cr
#'         Specifies the method to activate parameter selection.
#'         If not specified, model parameter selection shall not be triggered.
#' @param  resampling.method   \code{character, optional}\cr
#'         Specifies the resampling values.\cr
#' @param  ... Reserved parameter.
#' @return
#' a HANA ML object.
#'
#' @section Examples:
#' \preformatted{
#' > trctrl <- hanaml.trainControl(resampling.method = "cv",
#'                                 param.search.strategy = "grid",
#'                                 fold.num = 2, repeat.times = 2,
#'                                 random.state = 1,
#'                                 progress.indicator.id = "TEST")
#' > paramgrid <- hanaml.expand.grid(enet.lambda = c(1e-2, 1e-3, 0.05),
#'                                 enet.alpha = c(0.1, 0.5, 0.03))
#' > lr <-  hanaml.train(data = df.fit.enet,
#'                       method = "LinearRegression",
#'                       trControl = trctrl,
#'                       tuneGrid = paramgrid,
#'                       metric = "rmse",
#'                       key = "ID", label = "Y",
#'                       solver = "admm")
#' }
#' @export
hanaml.train <- function(data,
                         method,
                         trControl = NULL,
                         tuneGrid = NULL,
                         metric,
                         param.search.strategy = NULL,
                         resampling.method = NULL,
                         ...) {
  temp.params <- list()
  if (!is.null(trControl)) {
    for (item in names(trControl)) {
      temp.params <- append(temp.params, list(tuple(item, trControl[[item]])))
    }
  }
  if (!is.null(tuneGrid)) {
    if (length(tuneGrid) > 1){
      values <- tuneGrid[unlist(sapply(sapply(tuneGrid, names),
                                              is.null))]
      ranges <- tuneGrid[!unlist(sapply(sapply(tuneGrid, names),
                                        is.null))]
    } else if (is.null(names(tuneGrid[[1]]))){
      values <- tuneGrid
      ranges <- NULL
    } else {
      values <- NULL
      ranges <- tuneGrid
    }
    if (length(values) > 0){
      temp.params <- append(temp.params,
                            list(tuple("parameter.values", values)))
    }
    if (length(ranges) > 0){
      temp.params <- append(temp.params,
                            list(tuple("parameter.range", ranges)))
    }
  }
  temp.params <- append(temp.params, list(tuple("evaluation.metric", metric)))
  additional.params <- list(...)
  for (item in names(additional.params)) {
    temp.params <- append(temp.params, list(tuple(item,
                                                  additional.params[[item]])))
  }
  param.list <- list()
  count <- 1
  for (param in temp.params) {
    param.list <- c(param.list,
                    sprintf("%s = temp.params[[%s]][[2]]",
                            param[[1]],
                            count))
    count <- count + 1
  }
  param.str <- paste(param.list, collapse = ", ")
  exec.str <- sprintf("hanaml.%s(data, %s)", method, param.str)
  return (eval(parse(text = exec.str)))
}

#' @title Train Control Parameters for Model Selection
#' @description Generate list of parameters for controlling the training process
#' @name hanaml.trainControl
#' @param  resampling.method   \code{character, optional}\cr
#'         Specifies the resampling values.\cr
#' @param  param.search.strategy   \code{c('grid', 'random'), optional}\cr
#'         Specifies the method to activate parameter selection.
#'         If not specified, model parameter selection shall not be triggered.
#' @param  ... Reserved parameter.
#' @seealso \code{\link{hanaml.train}}
#' @export
hanaml.trainControl <- function(resampling.method = "cv",
                                param.search.strategy = "grid",
                                ...) {
  return(list(resampling.method = resampling.method,
              param.search.strategy = param.search.strategy,
              ...))
}

#' @title Parameter Grid Expansion
#' @description List of parameter values as the space for grid search.
#' @name hamaml.expand.grid
#' @param  ... Reserved parameter.
#' @seealso \code{\link{hanaml.train}}
#' @export
hanaml.expand.grid <- function (...) {
  return(list(...))
}

#' @title Range values in a named list
#' @name hanaml.range
#' @description Generate a named list that specifies
#' a range for parameter selection in hanaml.train.
#' @seealso \code{\link{hanaml.train}}
#' @param start \code{numeric}\cr
#'   Specifies the start value of a range.
#' @param stop \code{numeric}\cr
#'   Specifies the stop value(i.e. end) of a range.
#' @param step \code{numeric, optional}]\cr
#'   Specifies the step of a range.\cr
#'   Unnecessary and ineffective when \code{param.search.strategy} is set to "random".
#' @return
#' A named list that specifies a range with start value,
#' increment(step, omitted if not provided) and stop value.
#' @keywords Unified API
#' @export
hanaml.range <- function(start,
                         stop,
                         step = NULL) {
  start <- validateInput("start value of a range",
                         start,
                         "numeric",
                         required = TRUE)
  stop <- validateInput("stop value of a range",
                         stop,
                         "numeric",
                         required = TRUE)
  step <- validateInput("Step size of a range",
                        step,
                        "numeric")
  x <- c(start, step, stop)
  if (length(x) == 2){
    names(x) <- c("start", "stop")
  } else {
    names(x) <- c("start", "step", "stop")
  }
  return(x)
}
