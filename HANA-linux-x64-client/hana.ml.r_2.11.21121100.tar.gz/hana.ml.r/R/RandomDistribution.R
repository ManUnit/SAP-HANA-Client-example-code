random.distribution <- function(connection.context,
                                distr.param = NULL,
                                m = NULL,
                                seed = NULL,
                                thread.ratio = NULL){
  m <- validateInput("m", m, "integer")
  if (m < 1) {
    msg <- "Number of random data to be generated m should be a positive integer."
    flog.error(msg)
    stop(msg)
  }
  seed <- validateInput("Random seed", seed, "integer")
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
  tables <- list()
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  for (name in c("DISTRIBUTION_PARAMETER",
                 "PARAMETER",
                 "RESULT")) {
    tables <-
      append(tables,
             sprintf("#PAL_DISTRIBUTION_RANDOM_%s_TBL_%s",
                     name, unique.id))
  }
  distribution.parameter.tbl <- tables[[1]]
  param.tbl <- tables[[2]]
  result.tbl <- tables[[3]]
  in.tables <- list(distribution.parameter.tbl, param.tbl)
  out.tables <- list(result.tbl)
  dist.params <- list()
  for (i in seq_len(length(distr.param))) {
    dist.params <- append(dist.params,
                          list(tuple(as.character(names(distr.param[i])),
                               as.character(distr.param[[i]]))))
  }
  param.array <- list(
    tuple("NUM_RANDOM", m, NULL, NULL),
    tuple("SEED", seed, NULL, NULL),
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL)
  )
  tryCatch({
    errorhelper(CreateTWithConnection(connection.context, (Table$new(
      distribution.parameter.tbl, list(
        tuple("NAME", nvarchar(100)),
        tuple("VALUE", nvarchar(100)))))$WithData(dist.params)))
    errorhelper(CreateTWithConnection(connection.context,
      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(connection.context,
                                          "PAL_DISTRIBUTION_RANDOM",
                                          in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(connection.context, tables)
    stop(msg)
  })
  return(connection.context$table(result.tbl))
}

remove.null <- function(lst) {
  null.idx <- sapply(lst, is.null)
  res <- lst
  if (any(null.idx))
    res <- lst[-which(null.idx)]
  return(res)
}
#' @title Multinomial Distribution
#' @name hanaml.Multinomial
#' @description This is a random generation procedure with a given
#'  multinomial distribution.
#' @template args-conn
#' @template args-m
#' @param size \code{integer, optional}\cr
#' Number of trails.
#' @param prob \code{list of numerics, optional}\cr
#' Success probability of each category, must sum up to 1.
#' @template args-seed
#' @template args-threadratio
#' @return
#'  DataFrame containing the generated random samples, structured as follows:
#'  \itemize{
#'    \item{} ID, type INTEGER, ID column.\cr
#'    \item{}Generated random number columns, named by appending index number
#'         (starting from 1 to length of `pvals`) to \emph{Random_P},
#'         type DOUBLE. There will be as many columns here as there are values
#'  in \emph{pvals}.
#' }
#' @section Examples:
#' Draw samples from a multinomial distribution:
#' \preformatted{
#' > multi <- hanaml.Multinomial(connection.context = conn,
#'                               m = 10,
#'                               size = 10,
#'                               prob = c(0.2, 0.3, 0.25, 0.25),
#'                               seed = 1,
#'                               thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#' > multi$collect()
#'    ID RANDOM_P1 RANDOM_P2 RANDOM_P3 RANDOM_P4
#' 1   0         0         2         4         4
#' 2   1         2         2         4         2
#' 3   2         4         0         5         1
#' 4   3         0         0         5         5
#' 5   4         1         4         2         3
#' 6   5         4         1         4         1
#' 7   6         1         4         2         3
#' 8   7         2         3         2         3
#' 9   8         3         0         6         1
#' 10  9         2         2         3         3
#' }
#' @export
hanaml.Multinomial <- function(connection.context,
                               m = NULL,
                               size = NULL,
                               prob = NULL,
                               seed = NULL,
                               thread.ratio = NULL){
  m <- validateInput("m", m, "integer")
  size <- validateInput("size", size, "integer")
  seed <- validateInput("seed", seed, "integer")
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")

  if (length(prob) != 0){
    if (!(all(sapply(prob, is.numeric)) && all(prob > 0) &&
         sum(unlist(prob)) == 1)){
      msg <- paste("Parameter prob should be a list of positive numbers",
                   "that sum up to 1.")
      flog.error(msg)
      stop(msg)
    }
  }
  names.prob <- names(prob)
  name.flag <- is.null(names.prob)
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  tables <- list()
  for (name in c("DISTRIBUTION_PARAMETER", "PARAMETER", "RESULT")) {
    tables <-
      append(
        tables,
        sprintf(
          "#PAL_SAMPLING_MVAR_%s_TBL_%s",
          name,
          unique.id
        )
      )
  }
  distribution.parameter.tbl <- tables[[1]]
  param.tbl <- tables[[2]]
  result.tbl <- tables[[3]]
  in.tables <- list(distribution.parameter.tbl, param.tbl)
  out.tables <- list(result.tbl)
  param.array <- list(
    tuple("DISTRIBUTIONNAME", NULL, NULL, "MULTINOMIAL"),
    tuple("NUM_RANDOM", m, NULL, NULL),
    tuple("SEED", seed, NULL, NULL),
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL)
  )
  param.spec <- list()
  param.spec <- append(param.spec, list(tuple("TRAILS", nvarchar(100))))
  for (i in 1:length(prob)) {
    if (name.flag){
      pname <- paste0("P", i)
    } else {
      pname <- names.prob[[i]]
    }
    param.spec <- append(param.spec, list(tuple(pname, "DOUBLE")))
  }
  dist.params <- list(as.tuple(append(as.character(as.integer(size)),
                                      as.list(prob))))
  tryCatch({
    errorhelper(CreateTWithConnection(connection.context, (Table$new(
      distribution.parameter.tbl, param.spec))$WithData(dist.params)))
    errorhelper(CreateTWithConnection(connection.context,
      (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(connection.context,
                                          "PAL_DISTRIBUTION_RANDOM_MULTIVARIATE",#nolint
                                          in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(tables)
    stop(msg)
  })
  return(connection.context$table(result.tbl))
}

#' @title Bernoulli Distribution Sampling
#' @name hanaml.bernoulli
#' @description Draw samples from a Bernoulli distribution.
#' @template args-conn
#' @template args-m
#' @param p \code{numeric, optional}\cr
#' Success fraction. The value range is from 0 to 1.\cr
#' Defaults to 0.5.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#'  Draw samples from a bernoulli distribution:
#' \preformatted{
#' > bernoulli <- hanaml.bernoulli(connection.context = conn,
#'                                  m = 20,
#'                                  p = 0.5,
#'                                  seed = 1,
#'                                  thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'    > bernoulli$labels
#'       ID     GENERATED_NUMBER
#'    1   0               0
#'    2   1               0
#'    3   2               1
#'    4   3               1
#'    5   4               0
#'    6   5               1
#'    7   6               1
#'    8   7               0
#'    9   8               1
#'    10  9               0
#' }
#' @export
hanaml.bernoulli <- function(connection.context,
                             m = NULL,
                             p = NULL,
                             seed = NULL,
                             thread.ratio = NULL){

  p <- validateInput("p", p, "numeric")
  if (length(p) != 0 && (p < 0 || p > 1)) {
    msg <- "Parameter p should be valued between 0 and 1."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "BERNOULLI",
                   SUCCESS_FRACTION = p)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m,
                             seed,
                             thread.ratio))
}
#' @title Beta Distribution Sampling
#' @description Draw samples from a Beta distribution.
#' @name hanaml.beta
#' @template args-conn
#' @template args-m
#' @param a \code{numeric, optional}\cr
#' The 1st shape parameter, positive.\cr
#' Defaults to 0.5.
#' @param b \code{numeric, optional}\cr
#' The 2nd shape parameter, positive.\cr
#' Defaults to 0.5.
#' @template args-seed
#' @template args-threadratio
#'
#' @return
#'  DataFrame containing the generated random samples, structured as follows:
#'  \itemize{
#'  \item{}ID, type INTEGER, ID column.
#'  \item{}Generated random number columns, named by appending index number
#'  (starting from 1 to length of \emph{pvals}) to \emph{Random_P},
#'  type DOUBLE. There will be as many columns here as there are values
#'  in \emph{pvals}.
#'  }
#' @section Examples:
#' Draw samples from a beta distribution:
#' \preformatted{
#' > beta <- hanaml.beta(connection.context = conn,
#'                       a = 1,
#'                       b = 1,
#'                       m = 20,
#'                       seed = 1,
#'                       thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'  > beta$collect()
#'     ID  GENERATED_NUMBER
#'  1   0          0.976130
#'  2   1          0.308346
#'  3   2          0.853118
#'  4   3          0.958553
#'  5   4          0.677258
#'  6   5          0.489628
#'  7   6          0.027733
#'  8   7          0.278073
#'  9   8          0.850181
#'  10  9          0.976244
#' }
#' @export
hanaml.beta <- function(connection.context,
                        m = NULL,
                        a = NULL,
                        b = NULL,
                        seed = NULL,
                        thread.ratio = NULL){
  a <- validateInput("a", a, "numeric")
  b <- validateInput("b", b, "numeric")
  if ( (!is.null(a) && a < 0) || (!is.null(b) && b < 0)) {
    msg <- "Parameter a and b should both be positive."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "BETA",
                   SHAPE1 = a,
                   SHAPE2 = b)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}
#' @title binomial Distribution Sampling
#' @name hanaml.binomial
#' @description Draw samples from a binomial distribution
#' multivariate distribution
#' @template args-conn
#' @template args-m
#' @param n \code{integer, optional}\cr
#' Number of trails.\cr
#' Defaults to 1.
#' @param p code{tuple of double or integer, optional}\cr
#' Success fractions of each category.\cr
#' Defaults to 0.5.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a binomial distribution:
#' \preformatted{
#' > binomial <- hanaml.binomial(connection.context = conn,
#'                               n = 10,
#'                               p = 0.6,
#'                               m = 20,
#'                               seed = 1,
#'                               thread.ratio = 0)
#' }
#' Call the function:
#' \preformatted{
#' > binomial$collect()
#'    ID RANDOM_P1 RANDOM_P2 RANDOM_P3 RANDOM_P4
#' 1   0         0         2         4         4
#' 2   1         2         2         4         2
#' 3   2         4         0         5         1
#' 4   3         0         0         5         5
#' 5   4         1         4         2         3
#' 6   5         4         1         4         1
#' 7   6         1         4         2         3
#' 8   7         2         3         2         3
#' 9   8         3         0         6         1
#' 10  9         2         2         3         3
#' }
#' @export
hanaml.binomial <- function(connection.context,
                            m = NULL,
                            n = NULL,
                            p = NULL,
                            seed = NULL,
                            thread.ratio = NULL){
  n <- validateInput("n", n, "integer")
  p <- validateInput("p", p, "numeric")
  if (!is.null(n) && n < 0) {
    msg <- "Parameter n should be a nonnegative integer."
    flog.error(msg)
    stop(msg)
  }
  if ( (!is.null(p) && (p < 0 || p > 1))) {
    msg <- "Parameter p should be valued between 0 and 1."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "BINOMIAL",
                   TRIALS = n,
                   SUCCESS_FRACTION = p)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}

#' @title Cauchy Distribution Sampling
#' @description  Draw samples from a Cauchy distribution.
#' @name hanaml.Cauchy
#' @template args-conn
#' @template args-m
#' @param location \code{numeric, optional}\cr
#' Defaults to 0.
#' @param scale code{double, optional}\cr
#' Defaults to 1.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a Cauchy distribution:
#' \preformatted{
#' > cauchy <- hanaml.Cauchy(connection.context = conn,
#'                           m = 20,
#'                           location = 0.9,
#'                           scale = 1.1,
#'                           seed = 1,
#'                           thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'    > cauchy$collect()
#'       ID  GENERATED_NUMBER
#'    1   0          1.827259
#'    2   1         -1.877612
#'    3   2        -18.241436
#'    4   3         -1.216243
#'    5   4          2.091336
#'    6   5       -317.131147
#'    7   6         -2.804251
#'    8   7         -0.338566
#'    9   8          0.143280
#'    10  9          1.277245
#'
#' }
#' @export
hanaml.Cauchy <- function(connection.context,
                          m = NULL,
                          location = NULL,
                          scale = NULL,
                          seed = NULL,
                          thread.ratio = NULL){
  location <- validateInput("location", location, "numeric")
  scale <- validateInput("scale", scale, "numeric")
  if (!is.null(scale) && scale <= 0) {
    msg <- "Parameter scale should be larger than zero."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "CAUCHY",
                   LOCATION = location,
                   SCALE = scale)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m,
                             seed,
                             thread.ratio))
}
#' @title Chisquared Distribution Sampling
#' @description  Draw samples from a chisquared distribution.
#' @name hanaml.chisquared
#' @template args-conn
#' @template args-m
#' @param d \code{integer, optional}\cr
#' Degrees of freedom.\cr
#' Defaults to 1.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a Chisquared distribution:
#' \preformatted{
#' > chisquared <- hanaml.chisquared(connection.context = conn,
#'                                   d = 4,
#'                                   m = 20,
#'                                   seed = 1,
#'                                   thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'  > chisquared$collect()
#'     ID  GENERATED_NUMBER
#'  1   0          0.040571
#'  2   1          2.680756
#'  3   2          1.119563
#'  4   3          1.174072
#'  5   4          0.872421
#'  6   5          0.327169
#'  7   6          1.113164
#'  8   7          1.549585
#'  9   8          0.013953
#'  10  9          0.011735
#' }
#' @export
hanaml.chisquared <- function(connection.context,
                              m = NULL,
                              d = NULL,
                              seed = NULL,
                              thread.ratio = NULL){
  d <- validateInput("Degree of freedom", d, "integer")
  if (!is.null(d) && d < 1) {
    msg <- "Degrees of freedom d should be positive."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "CHI_SQUARED",
                   DEGREES_OF_FREEDOM = d)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}

#' @title Exponential Distribution Sampling
#' @description  Draw samples from a exponential distribution.
#' @name hanaml.exponential
#' @template args-conn
#' @template args-m
#' @param lambda \code{numeric, optional}\cr
#' The rate parameter, which is the inverse of the scale parameter.\cr
#' Defaults to 1.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a Exponential distribution:
#' \preformatted{
#' > exponential <- hanaml.exponential(connection.context = conn,
#'                                     m = 20,
#'                                     lambda = 1.5,
#'                                     seed = 1,
#'                                     thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#' > exponential$collect()
#'    ID  GENERATED_NUMBER
#' 1   0          0.035207
#' 2   1          0.559248
#' 3   2          0.122307
#' 4   3          2.339937
#' 5   4          1.130033
#' 6   5          0.985565
#' 7   6          0.030138
#' 8   7          0.231040
#' 9   8          1.233268
#' 10  9          0.876022
#' }
#' @export
hanaml.exponential <- function(connection.context,
                               m = NULL,
                               lambda = NULL,
                               seed = NULL,
                               thread.ratio = NULL){
  lambda <- validateInput("lambda", lambda, "numeric")
  if (!is.null(lambda) && lambda <= 0) {
    msg <- "Rate parameter lambda should be positive."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "EXPONENTIAL",
                   RATE = lambda)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}
#' @title Gumbel Distribution Sampling
#' @description Draw samples from a Gumbel distribution, which is one of a class
#'  of Generalized Extreme Value (GEV) distributions used in modeling extreme
#'  value problems.
#' @name hanaml.gumbel
#' @template args-conn
#' @template args-m
#' @param location \code{numeric, optional}\cr
#' Defaults to 0.
#' @param scale \code{numeric, optional}\cr
#' Defaults to 1.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a Gumbel distribution:
#' \preformatted{
#' > gumbel <- hanaml.gumbel(connection.context = conn,
#'                           location = 1.3,
#'                           scale = 1.2,
#'                           m = 20,
#'                           seed = 1,
#'                           thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#' > gumbel$collect()
#'    ID  GENERATED_NUMBER
#' 1   0          1.544054
#' 2   1          0.339531
#' 3   2          0.394224
#' 4   3          3.161123
#' 5   4          1.208050
#' 6   5         -0.276447
#' 7   6          1.694589
#' 8   7          1.406419
#' 9   8         -0.443717
#' 10  9          0.156404
#' }
#' @export
hanaml.gumbel <- function(connection.context,
                          m = NULL,
                          location = NULL,
                          scale = NULL,
                          seed = NULL,
                          thread.ratio = NULL){
  location <- validateInput("location", location, "numeric")
  scale <- validateInput("scale", scale, "numeric")
  if (!is.null(scale) && scale <= 0) {
    msg <- "Parameter scale should be positive."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "EXTREME_VALUE",
                   LOCATION = location,
                   SCALE = scale)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}

#' @title fisher.f Distribution Sampling
#' @description  Draw samples from an f distribution.
#' @name hanaml.fisher.f
#' @template args-conn
#' @template args-m
#' @param d1 \code{integer, optional}\cr
#' One degrees of freedom parameter.\cr
#' Defaults to 1.
#' @param d2 \code{integer, optional}\cr
#' The other degrees of freedom parameter.\cr
#' Defaults to 1.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a fisher.f distribution:
#' \preformatted{
#' > fisher.f <- hanaml.fisher.f(connection.context = conn,
#'                               m = 20,
#'                               d1 = 2,
#'                               d2 = 3,
#'                               seed = 1,
#'                               thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'  > fisher.f$collect()
#'     ID  GENERATED_NUMBER
#'  1   0          6.494985
#'  2   1          0.054830
#'  3   2          0.752216
#'  4   3          4.946226
#'  5   4          0.167151
#'  6   5        351.789925
#'  7   6          0.810973
#'  8   7          0.362714
#'  9   8          0.019763
#'  10  9         10.553533
#'
#' }
#' @export
hanaml.fisher.f <- function(connection.context,
                            m = NULL,
                            d1 = NULL,
                            d2 = NULL,
                            seed = NULL,
                            thread.ratio = NULL){
  d1 <- validateInput("d1", d1, "integer")
  d2 <- validateInput("d2", d2, "integer")
  if ( (!is.null(d1) &&  d1 < 1) || (!is.null(d2) && d2 < 1)) {
    msg <- paste("Parameter d1 and d2 both should be",
                 "positive.")
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "FISHER_F",
                   DEGREES_OF_FREEDOM1 = d1,
                   DEGREES_OF_FREEDOM2 = d2)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m,
                             seed,
                             thread.ratio))
}

#' @title Gamma Distribution Sampling
#' @description  Draw samples from a gamma distribution.
#' @name hanaml.gamma
#' @template args-conn
#' @template args-m
#' @param shape \code{numeric, optional}\cr
#' A shape parameter.\cr
#' Defaults to 1.
#' @param scale \code{numeric, optional}\cr
#' A scale parameter.\cr
#' Defaults to 1.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a gamma distribution:
#' \preformatted{
#' > gamma <- hanaml.gamma(connection.context = conn,
#'                         m = 20,
#'                         shape = 1.1,
#'                         scale = 1.2,
#'                         seed = 1,
#'                         thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'  > gamma$collect()
#'     ID  GENERATED_NUMBER
#'  1   0          0.082794
#'  2   1          0.084031
#'  3   2          0.159490
#'  4   3          1.063100
#'  5   4          0.530218
#'  6   5          1.307313
#'  7   6          0.565527
#'  8   7          0.474969
#'  9   8          0.440999
#'  10  9          0.463645
#'
#' }
#' @export
hanaml.gamma <- function(connection.context,
                         m = NULL,
                         shape = NULL,
                         scale = NULL,
                         seed = NULL,
                         thread.ratio = NULL){
  shape <- validateInput("shape", shape, "numeric")
  scale <- validateInput("scale", scale, "numeric")
  if (!is.null(shape) && shape <= 0) {
    msg <- "Parameter shape should be positive."
    flog.error(msg)
    stop(msg)
  }
  if (!is.null(scale) && scale <= 0) {
    msg <- "Parameter scale should be positive."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "GAMMA",
                   SHAPE = shape,
                   SCALE = scale)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m,
                             seed,
                             thread.ratio))
}
#' @title Geometric Distribution Sampling
#' @description  Draw samples from a geometric distribution.
#' @name hanaml.geometric
#' @template args-conn
#' @template args-m
#' @param p \code{numeric, optional}\cr
#' Successful fraction. The value range is from 0 to 1.\cr
#' Defaults to 0.5.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a geometric distribution:
#' \preformatted{
#' > geometric <- hanaml.geometric(connection.context = conn,
#'                                 m = 20,
#'                                 p = 0.6,seed = 1,
#'                                 thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'  > geometric$collect()
#'     ID  GENERATED_NUMBER
#'  1   0               1.0
#'  2   1               1.0
#'  3   2               1.0
#'  4   3               0.0
#'  5   4               1.0
#'  6   5               0.0
#'  7   6               0.0
#'  8   7               0.0
#'  9   8               0.0
#'  10  9               0.0
#'
#' }
#' @export
hanaml.geometric <- function(connection.context,
                             m = NULL,
                             p = NULL,
                             seed = NULL,
                             thread.ratio = NULL){
  p <- validateInput("p", p, "numeric")
  if (length(p) != 0 && (p < 0 || p > 1)) {
    msg <- "Parameter p should be valued between 0 and 1."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "GEOMETRIC",
                   SUCCESS_FRACTION = p)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}


#' @title Lognormal Distribution Sampling
#' @description  Draw samples from a lognormal distribution.
#' @name hanaml.lognormal
#' @template args-conn
#' @param m \code{integer, optional}\cr
#' Standard deviation of the underlying normal distribution.
#' Defaults to 1
#' @param location \code{numeric, optional}\cr
#' Location parameter for lognormal distribution.\cr
#' Defaults to 0.
#' @param scale \code{numeric, optional}\cr
#' Scale parameter for lognormal distribution.\cr
#' Defaults to 1.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a lognormal distribution:
#' \preformatted{
#' > lognormal <- hanaml.lognormal(connection.context = conn,
#'                                 m = 20,
#'                                 location = 0.6,
#'                                 scale = 1,
#'                                 seed = 1,
#'                                 thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#' > exponential$collect()
#'    ID  GENERATED_NUMBER
#' 1   0          0.461803
#' 2   1          0.548432
#' 3   2          0.625874
#' 4   3          3.038529
#' 5   4          3.582703
#' 6   5          1.867543
#' 7   6          1.853857
#' 8   7          0.378827
#' 9   8          1.104031
#' 10  9          0.840102
#' }
#' @export
hanaml.lognormal <- function(connection.context,
                             m = NULL,
                             location = NULL,
                             scale = NULL,
                             seed = NULL,
                             thread.ratio = NULL){
  location <- validateInput("location", location, "numeric")
  scale <- validateInput("scale", scale, "numeric")
  if (!is.null(scale) && scale <= 0) {
    msg <- "Parameter scale should be positive."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "LOGNORMAL",
                   LOCATION = location,
                   SCALE = scale)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}

#' @title negative.binomial Distribution Sampling
#' @description  Draw samples from a negative binomial distribution.
#' @name hanaml.negative.binomial
#' @template args-conn
#' @template args-m
#' @param r \code{numeric, optional}\cr
#' Number failures until success.\cr
#' Defaults to 1.
#' @param p \code{numeric, optional}\cr
#' Successful fraction. The value range is from 0 to 1.\cr
#' Defaults to 0.5.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a negative.binomial distribution:
#' \preformatted{
#' > negative.binomial <- hanaml.negative.binomial(connection.context = conn,
#'                                                 m = 20,
#'                                                 r = 10,
#'                                                 p = 0.6
#'                                                 seed = 1,
#'                                                 thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'  > negative.binomial$collect()
#'     ID  GENERATED_NUMBER
#'  1   0               0.0
#'  2   1               2.0
#'  3   2               3.0
#'  4   3               1.0
#'  5   4               1.0
#'  6   5               0.0
#'  7   6               2.0
#'  8   7               1.0
#'  9   8               2.0
#'  10  9               3.0
#'
#' }
#' @export
hanaml.negative.binomial <- function(connection.context,
                                     m = NULL,
                                     r = NULL,
                                     p = NULL,
                                     seed = NULL,
                                     thread.ratio = NULL){
  r <- validateInput("r", r, "numeric")
  p <- validateInput("p", p, "numeric")
  if (!is.null(r) && r <= 0) {
    msg <- "Parameter r should be positive."
    flog.error(msg)
    stop(msg)
  }
  if (!is.null(p) && (p < 0 || p > 1)) {
    msg <- "Parameter p should be valued between 0 and 1."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "NEGATIVE_BINOMIAL",
                   SUCCESSES = r,
                   SUCCESS_FRACTION = p)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}

#' @title Normal Distribution Sampling
#' @description  Draw samples from a normal distribution.
#' @name hanaml.normal
#' @template args-conn
#' @template args-m
#' @param mean \code{numeric, optional}\cr
#' Mean value of the underlying normal distribution.\cr
#' Defaults to 0.
#' @param sd \code{numeric, optional}\cr
#' Standard deviation of the underlying normal distribution.\cr
#' Defaults to 1.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a normal distribution:
#' \preformatted{
#' > normal <- hanaml.normal(connection.context = conn,
#'                           mean = 1,
#'                           sd = 2,
#'                           m = 20,
#'                           seed = 1, thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#' > normal$collect()
#'     ID  GENERATED_NUMBER
#' 1   0          0.321078
#' 2   1         -1.327626
#' 3   2          0.798867
#' 4   3         -0.116128
#' 5   4         -0.213519
#' 6   5          0.008566
#' 7   6          0.251733
#' 8   7          0.404510
#' 9   8         -0.534899
#' 10  9         -0.420968
#'
#' }
#' @export
hanaml.normal <- function(connection.context,
                          m = NULL,
                          mean = NULL,
                          sd = NULL,
                          seed = NULL,
                          thread.ratio = NULL){
  mean <- validateInput("mean", mean, "numeric")
  sd <- validateInput("sd", sd, "numeric")
  if (length(sd) != 0 && sd <= 0) {
    msg <- "Standard deviation sd should be positive."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "NORMAL",
                   MEAN = mean,
                   SD = sd)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}

#' @title PERT Distribution Sampling
#' @description  Draw samples from a PERT distribution.
#' @name hanaml.PERT
#' @template args-conn
#' @param min \code{numeric, optional}\cr
#'  Minimum value.\cr
#'  Defaults to -1
#' @param mode \code{numeric, optional}\cr
#'  Most likely value.\cr
#'  Defaults to 0.
#' @param max \code{numeric, optional}\cr
#'  Maximum value.\cr
#'  Defaults to 1.
#' @param scale {double, optional}\cr
#'  Defaults to 4.
#' @template args-m
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a pert distribution:
#' \preformatted{
#' > pert <- hanaml.pert(connection.context = conn,
#'                       m = 20,
#'                       minimum = 2,
#'                       mode = 3,
#'                       maximum = 4,
#'                       scale =4,
#'                       seed = 1,
#'                       thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'  > pert$collect()
#'     ID  GENERATED_NUMBER
#'  1   0          0.360781
#'  2   1         -0.023649
#'  3   2          0.106465
#'  4   3          0.307412
#'  5   4         -0.136838
#'  6   5         -0.086010
#'  7   6         -0.504639
#'  8   7          0.335352
#'  9   8         -0.287202
#'  10  9          0.468597
#' }
#' @export
hanaml.PERT <- function(connection.context,
                        m = NULL,
                        min = NULL,
                        mode = NULL,
                        max = NULL,
                        scale = NULL,
                        seed = NULL,
                        thread.ratio = NULL){
  min <- validateInput("min", min, "numeric")
  mode <- validateInput("mode", mode, "numeric")
  max <- validateInput("max", max, "numeric")
  scale <- validateInput("scale", scale, "numeric")
  if (length(c(min, mode, max)) >= 2){
    if (min >= mode || mode >= max || min >= max){
      msg <- paste("It must be TRUE that",
                   "min < mode < max.")
      flog.error(msg)
      stop(msg)
    }
  }
  if (!is.null(scale) && scale <= 0) {
    msg <- "Parameter scale should be positive."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "PERT",
                   MIN = min,
                   MODE = mode,
                   MAX = max,
                   SCALE = scale)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}


#' @title Poisson Distribution Sampling
#' @description  Draw samples from a Poisson distribution.
#' @name hanaml.Poisson
#' @template args-conn
#' @template args-m
#' @param theta \code{numeric, optional}\cr
#' The average number of events in an interval.\cr
#' Defaults to 1.0.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a Poisson distribution:
#' \preformatted{
#' > poisson <- hanaml.Poisson(connection.context = conn,
#'                             m = 20,
#'                             theta = 0.5,
#'                             seed = 1,
#'                             thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'  > poisson$collect()
#'     ID  GENERATED_NUMBER
#'  1   0               0.0
#'  2   1               1.0
#'  3   2               1.0
#'  4   3               1.0
#'  5   4               1.0
#'  6   5               1.0
#'  7   6               0.0
#'  8   7               2.0
#'  9   8               0.0
#'  10  9               1.0
#' }
#' @export
hanaml.Poisson <- function(connection.context,
                           m = NULL,
                           theta = NULL,
                           seed = NULL,
                           thread.ratio = NULL){
  theta <- validateInput("theat", theta, "numeric")
  if (!is.null(theta) && theta <= 0) {
    msg <- "Rate parameter theta should be positive."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "POISSON",
                   THETA = theta)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}

#' @title Student's t Distribution Sampling
#' @description  Draw samples from a  Student's t-distribution.
#' @name hanaml.student.t
#' @template args-conn
#' @template args-m
#' @param nu \code{numeric, optional}\cr
#' Degrees of freedom, must be positive.\cr
#' Defaults to 1.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a student.t distribution:
#' \preformatted{
#' > student.t <- hanaml.student.t(connection.context = conn,
#'                                 m = 20,
#'                                 nu = 3,
#'                                 seed = 1,
#'                                 thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#' > student.t$collect()
#'     ID  GENERATED_NUMBER
#' 1   0         -0.433802
#' 2   1          1.972038
#' 3   2         -1.097313
#' 4   3         -0.225812
#' 5   4         -0.452342
#' 6   5          2.242921
#' 7   6          0.377288
#' 8   7          0.322347
#' 9   8          1.104877
#' 10  9         -0.017830
#' }
#' @export
hanaml.student.t <- function(connection.context,
                             m = NULL,
                             nu = NULL,
                             seed = NULL,
                             thread.ratio = NULL){
  nu <- validateInput("nu", nu, "numeric")
  if (!is.null(nu) && nu <= 0) {
    msg <- "Degrees of freedom nu should be positive."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "STUDENT_T",
                   DEGREES_OF_FREEDOM = nu)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m, seed,
                             thread.ratio))
}

#' @title Uniform Distribution Sampling
#' @description  Draw samples from a uniform distribution.
#' @name hanaml.uniform
#' @template args-conn
#' @template args-m
#' @param min \code{numeric, optional}\cr
#' The lower bound.\cr
#' Defaults to 0.
#' @param max \code{numeric, optional}\cr
#' The upper bound.\cr
#' Defaults to 1.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a uniform distribution:
#' \preformatted{
#' > uniform <- hanaml.uniform(connection.context = conn,
#'                             m = 20,
#'                             low = 1,
#'                             high = 5,
#'                             seed = 1,
#'                             thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'  > uniform$collect()
#'     ID  GENERATED_NUMBER
#'  1   0          0.032920
#'  2   1          0.201923
#'  3   2          0.823313
#'  4   3         -0.495260
#'  5   4         -0.138329
#'  6   5          0.677732
#'  7   6          0.685200
#'  8   7          0.363627
#'  9   8          0.024849
#'  10  9         -0.441779
#'
#' }
#' @export
hanaml.uniform <- function(connection.context,
                           m = NULL,
                           min = NULL,
                           max = NULL,
                           seed = NULL,
                           thread.ratio = NULL){
  min <- validateInput("min", min, "numeric")
  max <- validateInput("max", max, "numeric")
  if (!is.null(min) && !is.null(max) && min >= max) {
    msg <- "min should be strictly less than max."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "UNIFORM",
                   MIN = min,
                   MAX = max)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m,
                             seed,
                             thread.ratio))
}

#' @title weibull Distribution Sampling
#' @description  Draw samples from a weibull distribution.
#' @name hanaml.weibull
#' @template args-conn
#' @template args-m
#' @param shape \code{numeric, optional}\cr
#' Defaults to 1.
#' @param scale \code{numeric, optional}\cr
#' Defaults to 1.
#' @template args-seed
#' @template args-threadratio
#' @template random-distribution-return
#' @section Examples:
#' Draw samples from a weibull distribution：
#' \preformatted{
#' > weibull <- hanaml.weibull(connection.context = conn,
#'                             m = 20,
#'                             shape = 2,
#'                             scale = 3,
#'                             seed = 1,
#'                             thread.ratio = 0)
#' }
#' Output:
#' \preformatted{
#'  > weibull$collect()
#'     ID  GENERATED_NUMBER
#'  1   0          2.188750
#'  2   1          0.247628
#'  3   2          0.339884
#'  4   3          0.902187
#'  5   4          0.909629
#'  6   5          0.514740
#'  7   6          4.627877
#'  8   7          0.143767
#'  9   8          0.847514
#'  10  9          2.368169
#'
#' }
#' @export
hanaml.weibull <- function(connection.context,
                           m = NULL,
                           shape = NULL,
                           scale = NULL,
                           seed = NULL,
                           thread.ratio = NULL){
  shape <- validateInput("shape", shape, "numeric")
  scale <- validateInput("scale", scale, "numeric")
  if (!is.null(shape) && shape <= 0) {
    msg <- "Parameter shape should be positive."
    flog.error(msg)
    stop(msg)
  }
  if (!is.null(scale) && scale <= 0) {
    msg <- "Parameter scale should be positive."
    flog.error(msg)
    stop(msg)
  }
  par.list <- list(DISTRIBUTIONNAME = "WEIBULL",
                   SHAPE = shape,
                   SCALE = scale)
  par.list <- remove.null(par.list)
  return(random.distribution(connection.context,
                             par.list,
                             m,
                             seed,
                             thread.ratio))
}


#' @title Markov chain Monte Carlo
#' @name hanaml.mcmc
#' @description hanaml.mcmc is a R wrapper
#' for SAP HANA PAL Markov chain Monte Carlo algorithm.
#' @details Given a distribution, this function generates samples
#' of the distribution using Markov chain Monte Carlo simulation.\cr
#' @param conn \code{ConnectionContext}\cr
#' SAP HANA Database connection object.
#' @param distribution \code{character}\cr
#'     Specifies the name of distribution. Valid options include: 'normal', 'skew.normal',
#'     'student.t', 'cauchy', 'laplace', 'logistic', 'gumbel', 'exponential', 'chi.square'.\cr
#'     The valid parameters for each distribution are shown as follows:\cr
#'     \itemize{
#'       \item{1. 'normal':} \code{mu}(location), \code{sigma}(scale).
#'       \item{2. 'skew.normal':} \code{mu}(location), \code{omega}(scale), \code{alpha}(shape).
#'       \item{3. 'student.t':} \code{nu}(dof), \code{mu}(location), \code{sigma}(scale).
#'       \item{4. 'cauchy':} \code{mu}(location), \code{sigma}(scale).
#'       \item{5. 'laplace':} \code{mu}(location), \code{sigma}(scale).
#'       \item{6. 'logistic':} \code{mu}(location), \code{sigma}(scale).
#'       \item{7. 'gumbel':} \code{mu}(location), \code{beta}(scale).
#'       \item{8. 'exponential':} \code{beta}(inverse-scale).
#'       \item{9. 'chi.square':} \code{nu}(dof).
#'       \item{10. 'invchi.square':} \code{nu}.
#'       \item{11. 'gamma':} \code{alpha}, \code{beta}.
#'       \item{12. 'weibull':} \code{alpha}, \code{sigma}.
#'       \item{13. 'frechet':} \code{alpha}, \code{sigma}.
#'       \item{14. 'rayleigh':} \code{sigma}.
#'       \item{15. 'multinormal':} \code{mu}, \code{sigma}.
#'       \item{16. 'multinormalprec':} \code{mu}, \code{omega}.
#'       \item{17. 'multinormalcholesky':} \code{mu}, \code{L}.
#'       \item{18. 'multistudent.t':} \code{nu, mu, sigma}.
#'       \item{19. 'dirichlet':} \code{alpha}.
#'       \item{20. 'beta':} \code{alpha, beta}.
#'       \item{21. 'invgamma':} \code{alpha, beta}.
#'       \item{22. 'lognormal':} \code{mu, sigma}.
#'       \item{23. 'pareto':} \code{y.min, alpha}.
#'       \item{24. 'lomax':} \code{lambda, alpha}.
#'     }
#'
#' @param location \code{double, optional(deprecated)}\cr
#'     Specifies the location parameter for a distribution.
#'     Valid when \emph{distribution} is set to one of the following values:
#'     'normal', 'skew.normal', 'student.t', 'cauchy', 'laplace', 'logistic'.\cr
#'     Defaults to 0.\cr
#'     Deprecated, please use \code{mu}.
#' @param scale \code{double, optional(deprecated)}\cr
#'     Specifies the scale parameter for a distribution.
#'     Valid only when \emph{distribution} is set to one of the following values:
#'     'normal', 'skew.normal', 'student.t', 'cauchy', 'laplace', 'logistic', 'exponential'.\cr
#'     Defaults to 1.0.\cr
#'     Deprecated, please use \code{sigma} or \code{beta}(whichever depends on the type of distributions).
#' @param shape \code{double, optional(deprecated)}\cr
#'     Specifies the shape parameter for a distribution.
#'     Valid only when \emph{distribution} is set to 'skew.normal'.\cr
#'     Defaults to 1.0.\cr
#'     Deprecated, please use \code{alpha}.
#' @param dof \code{double, optional(deprecated)}\cr
#'     Specifies the degree of freedom of a distribution.
#'     Valid only when \emph{distribution} is 'student.t' or 'chi.square'.\cr
#'     Defaults to 1.0.\cr
#'     Deprecated, please use \code{nu}.
#' @param chain.iter \code{integer, optional}\cr
#'     Specifies number of iterations for each Markov chain including warmup.\cr
#'     Defaults to 2000.
#' @param random.state \code{integer, optional}\cr
#'     Specifies the seed used to initialize the random number generator,
#'     where 0 means current system time as seed, while other values are
#'     simply seed values.\cr
#'     Defaults to 0.
#' @param init.radius \code{double, optional}\cr
#'     Specifies the radius to initialize the process.\cr
#'     Defaults to 2.0.
#' @param adapt  \code{logical, optional}\cr
#'     Specifies whether or not to use adaption.\cr
#'     Defaults to True.
#' @param warmup \code{integer, optional}\cr
#'     Specifies the number of warm-up iterations.
#'     Defaults to half of \emph{chain.iter}.
#' @param thin \code{integer, optional}\cr
#'     Specifies the period for saving samples.\cr
#'     Defaults to 1.
#' @param adapt.gamma \code{double, optional}\cr
#'     Specifies the regularization scale for adaption, must be positive.
#'     Invalid when \emph{adapt} is FALSE.\cr
#'     Defaults to 0.05.
#' @param adapt.delta \code{double, optional}\cr
#'     Specifies the target Metropolis acceptance rate, must be restricted
#'     between 0 and 1(inclusive of both limits).
#'     Only valid when \emph{adapt} is TRUE.\cr
#'     Defaults to 0.8.
#' @param adapt.kappa \code{double, optional}\cr
#'     Specifies the relaxation exponent, must be positive.
#'     Only valid when \emph{adapt} is TRUE.\cr
#'     Defaults to 0.75.
#' @param adapt.offset \code{double, optional}\cr
#'     Specifies the adaption iteration offset, must be positive.
#'     Only valid when \emph{adapt} is TRUE.\cr
#'     Defaults to 10.0.
#' @param adapt.init.buffer \code{integer, optional}\cr
#'     Specifies the width of initial fast adaption interval.
#'     Only valid when \emph{adapt} is TRUE.\cr
#'     Defaults to 75.
#' @param adapt.term.buffer \code{integer, optional}\cr
#'     Specifies the width of terminal(final) fast adaption interval.
#'     Only valid when \emph{adapt} is TRUE.\cr
#'     Defaults to 50.
#' @param adapt.window \code{integer, optional}\cr
#'     Specifies the initial width of slow adaption interval.
#'     Only valid when \emph{adapt} is TRUE.\cr
#'     Defaults to 25.
#' @param stepsize \code{double, optional}\cr
#'     Specifies the value for discretizing the time interval.\cr
#'     Defaults to 1.0.
#' @param stepsize.jitter \code{double, optional}\cr
#'     Specifies the uniform random jitter of step-size.\cr
#'     Defaults to 0.
#' @param max.depth \code{integer, optional}\cr
#'     Specifies the maximum tree depth.\cr
#'     Defaults to 10.
#' @param alpha \code{numeric, optional}\cr
#'     Specifies the value of parameter \code{alpha} in a distribution.\cr
#'     Mandatory and valid only if the corresponding distribution contains \code{alpha}
#'     as a parameter.
#' @param beta \code{numeric, optional}\cr
#'     Specifies the value of parameter \code{beta} in a distribution.\cr
#'     Mandatory and valid only if the corresponding distribution contains \code{beta}
#'     as a parameter.
#' @param lambda \code{numeric, optional}\cr
#'     Specifies the value of parameter \code{lambda} in a distribution.\cr
#'     Mandatory and valid only if the corresponding distribution contains
#'     \code{lambda} as a parameter.
#' @param mu \code{numeric, optional}
#'     Numerical value or vector that represents the mean value of a distribution.\cr
#'     Mandatory and valid if the corresponding distribution contains \code{mu} as a parameter.
#' @param nu \code{numeric, optional}\cr
#'     Specifies the value of parameter \code{nu}(often representing the degree of freedom)
#'     in a distribution.\cr
#'     Mandatory and valid only if the corresponding distribution contains \code{nu}
#'     as a parameter.
#' @param omega \code{numeric, optional}\cr
#'     Numerical value or vector for parameter \code{omega} in a distribution.\cr
#'     Mandatory and valid only if the corresponding distribution contains \code{omega}
#'     as a parameter.
#' @param sigma \code{numeric, optional}\cr
#'     Numerical value or vector for parameter \code{sigma} in a distribution.\cr
#'     Mandatory and valid only if the corresponding distribution contains \code{omega}
#'     as a parameter.
#' @param xi \code{numeric, optional}\cr
#'     Specifies the value of parameter \code{xi}(i.e. the mean) in skew-normal distribution.\cr
#'     Mandatory and valid only if \code{distribution} is 'skew.normal'.
#' @param xi \code{numeric, optional}\cr
#'     Specifies the value of parameter \code{xi}(i.e. the mean) in skew-normal distribution.\cr
#'     Mandatory and valid only if \code{distribution} is 'skew.normal'.
#' @param L \code{numeric, optional}\cr
#'     A numeric vector that specifies lower triangular matrix in the cholesky decomposition
#'     of the covariance matrix in multi-normal distribution.\cr
#'     Mandatory only if \code{distribution} is 'multinormalcholesky'.
#' @param y.min \code{numeric, optional}\cr
#'     Specifies the value of parameter \code{y.min} in Pareto distribution.\cr
#'     Mandatory and valid only if \code{distribution} is 'pareto'.
#'
#' @return
#' DataFrame\cr
#' Samples of the specified distribution generated from Markov Chain Monte-Carlo process.
#'
#' @section Examples:
#' The following line of code shows how to generate MCMC samples from student.t
#' distribution with specified distribution parameters:
#' \preformatted{
#' > res <- hanaml.mcmc(conn, distribution = 'student.t',
#'                      location = 0, dof = 1,
#'                      chain.iter = 50, thin = 10,
#'                      init.radius = 0)
#' > res$Collect()
#'    ID   SAMPLES
#' 1   0 -1.728452
#' 2   1  1.575337
#' 3   2  1.185957
#' 4   3  4.913828
#' 5   4  0.220282
#' 6   5 -5.588809
#' }
#' @export
hanaml.mcmc <- function(conn, distribution, location=NULL,
                        scale=NULL, shape=NULL, dof=NULL, chain.iter=NULL,
                        random.state=NULL, init.radius=NULL, adapt=NULL,
                        warmup=NULL, thin=NULL, adapt.gamma=NULL,
                        adapt.delta=NULL, adapt.kappa=NULL, adapt.offset=NULL,
                        adapt.init.buffer=NULL, adapt.term.buffer=NULL,
                        adapt.window=NULL, stepsize=NULL, stepsize.jitter=NULL,
                        max.depth=NULL, alpha=NULL, beta=NULL, lambda=NULL, mu=NULL,
                        nu=NULL, omega=NULL, sigma=NULL, xi=NULL,
                        L=NULL, y.min=NULL) {
    get.attr <- function(elm, obj) {
      return(obj[[elm]])
    }
    val.to.str <- function(x, obj) {
      valstr <- sprintf("\"%s\":%s", toupper(gsub("\\.", "_", x)),
                        sprintf("[%s]", paste(obj[[x]],
                                              collapse = ",")))

      return(valstr)
    }
    distribution.map <- list("normal" = "normal", "skew.normal" = "skew_normal",
                             "student.t" = "student_t", "cauchy" = "cauchy",
                             "laplace" = "laplace", "logistic" = "logistic",
                             "gumbel" = "gumbel", "exponential" = "exponential",
                             "chi.square" = "chi_square", "lognormal" = "lognormal",
                             "invchi.square" = "invchi_square", 'gamma" = "gamma",
                             "invgamma" = "invgamma", "weibull" = "weibull",
                             "frechet" = "frechet", "rayleigh" = "rayleigh",
                             "beta" = "beta", "pareto" = "pareto", "lomax" = "lomax",
                             "multinormal" = "multinormal",
                             "multinormalprec" = "multinormalprec",
                             "multinormalcholesky" = "multinormalcholesky",
                             "multistudent.t" = "multistudent_t",
                             "dirichlet" = "dirichlet')
    require.list <- list(mu = c("normal", "student", "cauchy", "laplace",
                                "gumbel"),
                         nu = c("student", "chi.square", "student"),
                         alpha = c("skew", "gamma", "weibull", "frechet",
                                   "dirichlet", "beta", "invgamma",
                                   "pareto", "lomax"),
                         beta = c("gumbel", "exponential", "gamma",
                                  "beta", "invgamma"),
                         omega = c("skew", "normalprec"),
                         sigma = c("normal", "cauchy", "laplace", "student.t",
                                   "logistic", "weibull", "frechet",
                                   "multinormal", "multistudent.t",
                                   "lognormal"))
    valid.param.map <- list(normal = c("mu", "sigma"),
                            skew.normal = c("xi", "omega", "alpha"),
                            student.t = c("nu", "mu", "sigma"),
                            cauchy = c("mu", "sigma"),
                            laplace = c("mu", "sigma"),
                            logistic = c("mu", "sigma"),
                            gumbel = c("mu", "beta"),
                            exponential = c("beta"),
                            chi.square = c("nu"),
                            invchi.square = c("nu"),
                            gamma = c("alpha", "beta"),
                            weibull = c("alpha", "sigma"),
                            frechet = c("alpha", "sigma"),
                            rayleigh = c("sigma"),
                            multinormal = c("mu", "sigma"),
                            multinormalprec = c("mu", "omega"),
                            multinormalcholesky = c("mu", "L"),
                            multistudent.t = c("mu", "nu", "sigma"),
                            dirichlet = c("alpha"),
                            beta = c("alpha", "beta"),
                            invgamma = c("alpha", "beta"),
                            lognormal = c("mu", "sigma"),
                            pareto = c("y.min", "alpha"),
                            lomax = c("lambda", "alpha"))
    distribution <- validateInput("distribution", distribution,
                                  distribution.map, required = TRUE)
    if (distribution %in% c("normal", "skew.normal",
                            "student.t", "cauchy",
                            "laplace", "logistic")) {
      location <- validateInput("location", location, "double")
      if (is.null(location)) {
        location <- 0
      }
      mu <- location
    }
    if (distribution %in% c("normal", "skew.normal",
                            "student.t", "cauchy",
                            "laplace", "logistic",
                            "exponential")) {
      scale <- validateInput("scale", scale, "double")
      if (is.null(scale)) {
        scale <- 1.0
      }
      sigma <- scale
      omega <- scale
    }
    if (distribution == "skew.normal") {
      shape <- validateInput("shape", shape, "double")
      if (is.null(shape)) {
        shape <- 1.0
      }
      alpha <- shape
    }
    if (distribution %in% c("student.t", "chis.quare")) {
      dof <- validateInput("dof", dof, "double")
      if (is.null(dof)) {
        dof <- 1.0
      }
      nu <- dof
    }
    alpha <- validateInput("alpha", alpha, "numeric",
                           required =  any(sapply(require.list[["alpha"]],
                                                  grepl,
                                                  x = distribution)))
    beta <- validateInput("beta", beta, "numeric",
                          required =  any(sapply(require.list[["beta"]],
                                                 grepl,
                                                 x = distribution)))
    lambda <- validateInput("lambda", lambda, "numeric",
                            required =  distribution == "lomax")
    mu <- validateInput("mu", mu, "numeric",
                        required = any(sapply(require.list[["mu"]],
                                              grepl,
                                              x = distribution)))
    nu <- validateInput("nu", nu, "numeric",
                        required = any(sapply(require.list[["nu"]],
                                              grepl,
                                              x = distribution)))
    omega <- validateInput("omega", omega, "numeric",
                           required = any(sapply(require.list[["omega"]],
                                                 grepl,
                                                 x = distribution)))
    sigma <- validateInput("sigma", sigma, "numeric",
                           required = distribution %in% require.list[["sigma"]])
    xi <- validateInput("xi", xi, "numeric",
                        required = distribution == "skew.normal")
    L <- validateInput("L", L, "numeric",
                       required = grepl("cholesky", distribution))
    y.min <- validateInput("y.min", y.min, "numeric",
                           required = distribution == "pareto")
    chain.iter <- validateInput("chain.iter", chain.iter, "integer")
    random.state <- validateInput("random.state", random.state, "integer")
    init.radius <- validateInput("init.radius", init.radius, "double")
    adapt <- validateInput("adapt", adapt, "logical")
    warmup <- validateInput("warmup", warmup, "integer")
    thin <- validateInput("thin", thin, "integer")
    adapt.gamma <- validateInput("adapt.gamma", adapt.gamma, "double")
    adapt.delta <- validateInput("adapt.delta", adapt.delta, "double")
    adapt.kappa <- validateInput("adapt.kappa", adapt.kappa, "double")
    adapt.offset <- validateInput("adapt.offset", adapt.offset, "double")
    adapt.init.buffer <- validateInput("adapt.init.buffer", adapt.init.buffer, "integer")
    adapt.term.buffer <- validateInput("adapt.term.buffer", adapt.term.buffer, "integer")
    adapt.window <- validateInput("adapt.window", adapt.window, "integer")
    stepsize <- validateInput("stepsize", stepsize, "double")
    stepsize.jitter <- validateInput("stepsize.jitter", stepsize.jitter, "double")
    max.depth <- validateInput("max.depth", max.depth, "integer")
    distr.param <- list(alpha = alpha, beta = beta, lambda = lambda,
                        mu = mu, nu = nu, omega = omega,
                        sigma = sigma, xi = xi, L = L,
                        y.min = y.min)
    dim <- 1
    if (grepl("multi", distribution)) {
      dim <- length(mu)
    }
    valid.param.vals <- sapply(valid.param.map[[distribution]],
                               get.attr, obj = distr.param)
    param.str <- paste(sapply(names(valid.param.vals), val.to.str,
                              obj = valid.param.vals), collapse = ", ")
    param.str <- sprintf("{%s}", param.str)
    param.array <- list(
      tuple("DISTRIBUTION_NAME", NULL, NULL,
            map.null(distribution,
                     distribution.map)),
      tuple("DISTRIBUTION_PARAM", NULL, NULL, param.str),
      tuple("DIMENSION", dim, NULL, NULL),
      tuple("ITER", chain.iter, NULL, NULL),
      tuple("RANDOM_SEED", random.state, NULL, NULL),
      tuple("INIT_RADIUS", NULL, init.radius, NULL),
      tuple("ADAPT_ENGAGED", to.integer(adapt), NULL, NULL),
      tuple("WARMUP", warmup, NULL, NULL),
      tuple("THIN", thin, NULL, NULL),
      tuple("STEPSIZE", stepsize, NULL, NULL),
      tuple("STEPSIZE_JITTER", stepsize.jitter, NULL, NULL),
      tuple("MAX_TREEDEPTH", max.depth, NULL, NULL),
      tuple("ADAPT_GAMMA", NULL, adapt.gamma, NULL),
      tuple("ADAPT_DELTA", NULL, adapt.delta, NULL),
      tuple("ADAPT_KAPPA", NULL, adapt.kappa, NULL),
      tuple("ADAPT_T0", NULL, adapt.offset, NULL),
      tuple("ADAPT_INIT_BUFFER", adapt.init.buffer, NULL, NULL),
      tuple("ADAPT_TERM_BUFFER", adapt.term.buffer, NULL, NULL),
      tuple("ADAPT_WINDOW", adapt.window, NULL, NULL))

    unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
    param.tbl <- sprintf("#PAL_MCMC_PARAM_TBL_%s", unique.id)
    result.tbl <- sprintf("#PAL_MCMC_RESULT_TBL_%s", unique.id)
    in.tables <- list(param.tbl)
    out.tables <- list(result.tbl)
    tables <- c(param.tbl, out.tables)

    tryCatch({
      errorhelper(CreateTWithConnection(conn,
                                        (ParameterTable$new(param.tbl))$WithData(param.array)))
      errorhelper(CallPalAutoWithConnection(conn,
                                            "PAL_MCMC",
                                            in.tables, out.tables))
    },
    error = function(err) {
      msg <- paste("Error:", err$message)
      flog.error(msg)
      TryDropWithConnection(conn, tables)
      stop(msg)
    })
    return(conn$table(result.tbl))
    }
