#Base Class for MultiLayer Perceptron Algorithm
MLPBaseClass <- R6Class(
  "MLPBaseClass",
  inherit = MlBase,
  public = list (
    activation.map = list("tanh" = 1,
                          "linear" = 2,
                          "sigmoid-asymmetric" = 3,
                          "sigmoid-symmetric" = 4,
                          "gaussian-asymmetric" = 5,
                          "gaussian-symmetric" = 6,
                          "elliot-asymmetric" = 7,
                          "elliot-symmetric" = 8,
                          "sin-asymmetric" = 9,
                          "sin-symmetric" = 10,
                          "cos-asymmetric" = 11,
                          "cos-symmetric" = 12,
                          "relu" = 13),
    style.map = list("batch" = 0,
                     "stochastic" = 1),
    norm.map = list("no" = 0,
                    "z-transform" = 1,
                    "scalar" = 2),
    weight.map = list("all-zero" = 0,
                      "normal" = 1,
                      "uniform" = 2,
                      "variance-scale-normal" = 3,
                      "variance-scale-uniform" = 4),
    resampling.list = list("cv", "stratified_cv",
                           "bootstrap", "stratified_bootstrap"),
    evaluation.metric.map = list("accuracy" = "ACCURACY",
                                 "f1_score" = "F1_SCORE",
                                 "auc_1vsrest" = "AUC_1VsRest",
                                 "auc_pairwise" = "AUC_pairwise",
                                 "rmse" = "RMSE"),
    param.search.strategy.list = list("grid", "random"),
    value.param.list = list("activation", "output.activation",
                            "hidden.layer.size", "learning.rate",
                            "momentum", "batch.size"),
    range.param.list = list("learning.rate", "momentum",
                            "batch.size"),
    activation = NULL,
    output.activation = NULL,
    hidden.layer.size = NULL,
    training.style = NULL,
    learning.rate = NULL,
    momentum = NULL,
    batch.size = NULL,
    max.iter = NULL,
    normalization = NULL,
    weight.init = NULL,
    parameter.range = NULL,
    parameter.values = NULL,
    random.state = NULL,
    functionality = NULL,
    progress.indicator.id = NULL,
    categorical.variable = NULL,
    thread.ratio = NULL,
    resampling.method = NULL,
    random.search.times = NULL,
    evaluation.metric = NULL,
    fold.num = NULL,
    repeat.times = NULL,
    param.search.strategy = NULL,
    timeout = NULL,
    model = NULL,
    log.output = NULL,
    statistics = NULL,
    optim.param = NULL,
    initialize = function(functionality,
                          data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          hidden.layer.size = NULL,
                          activation = NULL,
                          output.activation = NULL,
                          learning.rate = NULL,
                          momentum = NULL,
                          training.style = NULL,
                          max.iter = NULL,
                          normalization = NULL,
                          weight.init = NULL,
                          thread.ratio = NULL,
                          categorical.variable = NULL,
                          batch.size = NULL,
                          resampling.method = NULL,
                          evaluation.metric = NULL,
                          fold.num = NULL,
                          repeat.times = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          random.state = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL) {
      super$initialize()

      if (!is.null(data)){
        has.learning.rate <- FALSE
        has.momentum <- FALSE
        if (!is.null(parameter.range)) {
          if ("learning.rate" %in% names(parameter.range)) {
            has.learning.rate <- TRUE
          }
          if ("momentum" %in% names(parameter.range)) {
            has.momentum <- TRUE
          }
        }
        if (!is.null(parameter.values)) {
          if ("learning.rate" %in% names(parameter.values)) {
            has.learning.rate <- TRUE
          }
          if ("momentum" %in% names(parameter.values)) {
            has.momentum <- TRUE
          }
        }
        if (!is.null(learning.rate)) {
          has.learning.rate <- TRUE
        }
        if (!is.null(momentum)) {
          has.momentum <- TRUE
        }
        key <- validateInput("key", key, "character")
        if (inherits(features, "list")){
          features <- validateInput("features", features, "LISTOFSTRINGS")
        }
        self$functionality <- functionality
        param.data <- list()
        if (functionality == 0){
          label <- validateInput("label", label, "character")
        } else {
          if (length(label) <= 1){
            label <- validateInput("label", unlist(label), "character")
          } else {
            label <- validateInput("label", as.list(label), "LISTOFSTRINGS")
          }
        }
        self$activation <- validateInput("activation", activation,
                                         self$activation.map)
        self$output.activation <- validateInput("output.activation",
                                                output.activation,
                                                self$activation.map)
        if (is.null(self$activation) &&
            (! "activation" %in% names(parameter.values))){
          msg <- paste("Activation function must be specified either in",
                       "`activation` or `parameter.values`, while the later",
                       "case is for model evaluation or",
                       "parameter selection.")
          flog.error(msg)
          stop(msg)
        }
        if (is.null(self$output.activation) &&
            (! "output.activation" %in% names(parameter.values))){
          msg <- paste("Output activation function must be specified either",
                       "in `output.activation` or `parameter.values`, while the",
                       "later case is for model evaluation or",
                       "parameter selection.")
          flog.error(msg)
          stop(msg)
        }
        self$hidden.layer.size <- validateInput("hidden.layer.size",
                                                unlist(hidden.layer.size),
                                                "integer")
        if (is.null(self$hidden.layer.size) &&
            !("hidden.layer.size" %in% names(parameter.values))){
          msg <- paste("Size of hidden layers must be specified in either",
                       "`hidden.layer.size` or `parameter.values`,",
                       "while the later case is",
                       "for model evaluation or parameter selection.")
          flog.error(msg)
          stop(msg)
        }
        if (!is.null(self$hidden.layer.size)){
          param.data <- append(param.data,
                               list(
                                 tuple("HIDDEN_LAYER_SIZE",
                                       NULL,
                                       NULL,
                                       paste(as.character(self$hidden.layer.size),#nolint
                                             collapse = ", "))))
        }
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        self$training.style <- validateInput("training.style", training.style,
                                             self$style.map)
        self$learning.rate <-
          validateInput("learning.rate",
                        learning.rate,
                        "numeric",
                        required = isTRUE(! "learning.rate" %in% names(parameter.values) &&#nolint
                                          ! "learning.rate" %in% names(parameter.range) &&#nolint
                                          grepl("sto",
                                                  self$training.style)))
        self$momentum <-
          validateInput("momentum", momentum, "numeric",
                        required = isTRUE(! "learning.rate" %in% names(parameter.values) &&#nolint
                                          ! "learning.rate" %in% names(parameter.range) &&#nolint
                                          grepl("sto", self$training.style)))
        self$batch.size <-
          validateInput("batch.size", batch.size, "integer")
        if (self$training.style ==  "batch"){
          if (has.learning.rate | has.momentum) {
            error.msg <- paste("Values of `learning.rate` and `momentum`",
                               "have no effect, since they are valid",
                               "only when `training.style` is 'stochastic'.")
            flog.warn(error.msg)
          }
        }
        self$normalization <- validateInput("normalization", normalization,
                                            self$norm.map)
        self$weight.init <- validateInput("weight.init", weight.init,
                                          self$weight.map)
        if (inherits(categorical.variable, "character")) {
          categorical.variable <- as.list(categorical.variable)
        }
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   data$columns,
                                                   case.sensitive = TRUE)
        self$thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                           "numeric")
        self$resampling.method <- validateInput("resampling.method",
                                                resampling.method,
                                                "character")
        if (!is.null(self$resampling.method)){
          self$resampling.method <- tolower(self$resampling.method)
          if (! self$resampling.method %in% self$resampling.list) {
            error.msg <- paste("Invalid resampling method",
                               self$resampling.method)
            flog.error(error.msg)
            stop(error.msg)
          }
          if (functionality == 1) {
            if (self$resampling.method %in% c("stratified_cv",
                                              "stratified_bootstrap")) {
              msg <- paste("`resampling.method` as 'stratified_cv'",
                           "or stratified_bootstrap'",
                           "is invalid for regression.")
              flog.error(msg)
              stop(msg)
            }
          }
        }
        self$evaluation.metric <- validateInput("evaluation.metric",
                                                evaluation.metric,
                                                self$evaluation.metric.map)
        self$fold.num <-
          validateInput("fold.num", fold.num,
                        "integer",
                        required = isTRUE(grepl("cv",
                                                self$resampling.method)))
        self$repeat.times <- validateInput("repeat.times",
                                           repeat.times,
                                           "integer")
        self$param.search.strategy <- validateInput("param.search.strategy",
                                                    param.search.strategy,
                                                    "character")
        if (!is.null(self$param.search.strategy)){
          self$param.search.strategy <- tolower(self$param.search.strategy)
          if (! self$param.search.strategy %in%
              self$param.search.strategy.list) {
            error.msg <- paste("Invalid parameter search strategy '",
                               self$param.search.strategy, "'",
                               sep = "")
            flog.error(error.msg)
            stop(error.msg)
          }
        }
        self$random.search.times <-
          validateInput("random.search.times",
                        random.search.times,
                        "integer",
                        required = isTRUE(grepl("rand",
                                                self$param.search.strategy)))
        self$random.state <- validateInput("random.state", random.state, "integer")
        self$timeout <- validateInput("timeout", timeout, "integer")
        self$progress.indicator.id <- validateInput("progress.indicator.id",
                                                    progress.indicator.id,
                                                    "character")
        if (length(c(self$resampling.method,
                     self$param.search.strategy)) < 2 &&
            (!is.null(parameter.range) || !is.null(parameter.values))){
          msg <- paste("resampling.method and param.search.strategy",
                       "are mandatory for MLP model selection.")
          flog.error(msg)
          stop(msg)
        }
        value.names <- names(parameter.values)

        if (!is.null(value.names)) {
          validateInput("Parameters for value specification",
                        value.names,
                        self$value.param.list,
                        case.sensitive = TRUE)
          activation.values <- parameter.values["activation"][[1]]
          if (!is.null(activation.values)){
            activation.values <-
              as.character(self$activation.map[unlist(activation.values)])
            activation.values <-
              paste("{", paste(activation.values, sep = "", collapse = ", "),
                    "}", sep = "")
          } else {
            activation.values <- NULL
          }
          out.activation.values <- parameter.values["output.activation"][[1]]
          if (!is.null(out.activation.values)){
            out.activation.values <-
              as.character(self$activation.map[unlist(out.activation.values)])
            out.activation.values <-
              paste("{", paste(out.activation.values, sep = "", collapse = ", "),
                    "}", sep = "")
          } else {
            out.activation.values <- NULL
          }
          hidden.layer.size.values <- parameter.values["hidden.layer.size"][[1]]
          if (!is.null(hidden.layer.size.values)){
            if (!inherits(unlist(hidden.layer.size.values), c("numeric", "integer"))){
              msg <- "Layer size must be numeric."
              flog.error(msg)
              stop(msg)
            }
            temp <- c()
            for (values in hidden.layer.size.values){
              values <- paste("\"",
                              paste(as.character(values), sep = "",
                                    collapse = ", "),
                              "\"",
                              sep = "",
                              collapse = "")
              temp <- c(temp, values)
            }
            hidden.layer.size.values <- paste(temp, sep = "", collapse = ", ")
            hidden.layer.size.values <- paste("{", hidden.layer.size.values,
                                              "}", sep = "", collapse = "")
          } else {
            hidden.layer.size.values <- NULL
          }
          learning.rate.values <- parameter.values["learning.rate"][[1]]
          if (!is.null(learning.rate.values)) {
            if (!inherits(unlist(learning.rate.values), "numeric")){
              msg <- "Learning rate must be numeric."
              flog.error(msg)
              stop(msg)
            }
            learning.rate.values <- as.character(learning.rate.values)
            learning.rate.values <-
              paste("{", paste(learning.rate.values, sep = "", collapse = ", "),
                    "}")
          } else {
            learning.rate.values <- NULL
          }
          momentum.values <- parameter.values["momentum"][[1]]
          if (!is.null(momentum.values)) {
            if (!inherits(unlist(momentum.values), "numeric")){
              msg <- "Momentum must be numeric."
              flog.error(msg)
              stop(msg)
            }
            momentum.values <- as.character(momentum.values)
            momentum.values <-
              paste("{", paste(momentum.values, sep = "", collapse = ", "),
                    "}")
          } else {
            momentum.values <- NULL
          }
          batch.size.values <- parameter.values["batch.size"][[1]]
          if (!is.null(batch.size.values)) {
            if ( (!inherits(unlist(batch.size.values), c("numeric", "integer"))) ||
                 (inherits(unlist(batch.size.values), "numeric") &&
                  any(round(unlist(batch.size.values)) !=
                      unlist(batch.size.values)))
            ){
              msg <- "Size of mini batches must be integer."
              flog.error(msg)
              stop(msg)
            }
            batch.size.values <- as.character(batch.size.values)
            batch.size.values <-
              paste("{", paste(batch.size.values, sep = "", collapse = ", "),
                    "}")
          } else {
            batch.size.values <- NULL
          }
        } else {
          if (!is.null(parameter.values)){
            msg <- "Parameter names must be supplied for values specification."
            flog.error(msg)
            stop(msg)
          }
          activation.values <- NULL
          out.activation.values <- NULL
          hidden.layer.size.values <- NULL
          momentum.values <- NULL
          learning.rate.values <- NULL
          batch.size.values <- NULL
        }
        self$parameter.values <- parameter.values
        range.names <- names(parameter.range)
        if (!is.null(range.names)){
          validateInput("Parameters for range specification",
                        range.names,
                        self$range.param.list,
                        case.sensitive = TRUE)
          learning.rate.range <- parameter.range["learning.rate"][[1]]
          if (!is.null(learning.rate.range)) {
            if (!inherits(unlist(learning.rate.range), "numeric")){
              msg <- "Learning rate must be numeric."
              flog.error(msg)
              stop(msg)
            }
            learning.rate.range <- as.character(learning.rate.range)
            if (length(learning.rate.range) == 3){
              learning.rate.range <-
                paste("[", paste(learning.rate.range, sep = "", collapse = ", "),
                      "]")
            } else if (length(learning.rate.range) == 2){
              learning.rate.range <-
                paste("[", paste(learning.rate.range, sep = "", collapse = ",,"),
                      "]")
            } else {
              msg <- paste("Wrong number of values for learning rate",
                           "range specification.")
              flog.error(msg)
              stop(msg)
            }
          } else {
            learning.rate.range <- NULL
          }
          momentum.range <- parameter.range["momentum"][[1]]
          if (!is.null(momentum.range)) {
            if (!inherits(unlist(momentum.range), "numeric")){
              msg <- "Momentum must be numeric."
              flog.error(msg)
              stop(msg)
            }
            momentum.range <- as.character(momentum.range)
            if (length(momentum.range) == 3){
              momentum.range <-
                paste("[", paste(momentum.range, sep = "", collapse = ", "),
                      "]")
            } else if (length(momentum.range) == 2){
              momentum.range <-
                paste("[", paste(momentum.range, sep = "", collapse = ",,"),
                      "]")
            } else {
              msg <- paste("Wrong number of values for",
                           "momentum range specification.")
              flog.error(msg)
              stop(msg)
            }
          } else {
            momentum.range <- NULL
          }
          batch.size.range <- parameter.range["batch.size"][[1]]
          if (!is.null(batch.size.range)) {
            if ( (!inherits(unlist(batch.size.range), c("numeric", "integer"))) ||
                 (inherits(unlist(batch.size.range), "numeric") &&
                  any(round(unlist(batch.size.range)) !=
                      unlist(batch.size.range)))){
              msg <- "Size of mini batches must be integer."
              flog.error(msg)
              stop(msg)
            }
            batch.size.range <- as.character(batch.size.range)
            if (length(batch.size.range) == 3){
              batch.size.range <-
                paste("[", paste(batch.size.range, sep = "", collapse = ", "),
                      "]")
            } else if (length(batch.size.range) == 2){
              batch.size.range <-
                paste("[", paste(batch.size.range, sep = "", collapse = ",,"),
                      "]")
            } else {
              msg <- paste("Wrong number of values for mini",
                           "batch size range specification.")
              flog.error(msg)
              stop(msg)
            }
          } else {
            batch.size.range <- NULL
          }
        } else {
          if (!is.null(parameter.range)){
            msg <- "Parameter names must be supplied for range specification."
            flog.error(msg)
            stop(msg)
          }
          momentum.range <- NULL
          learning.rate.range <- NULL
          batch.size.range <- NULL
        }
        self$parameter.range <- parameter.range
        cols.left <- data$columns
        key <- validateInput("key", key, cols.left, case.sensitive = TRUE)
        if (inherits(formula, "formula")){
          parseformula <- ParseFormula(data, formula)
          label <- parseformula[[1]]
          features <- parseformula[[2]]
          features <- features[! features %in% key]
        }
        if (!is.null(key)){
          id.col <- list(key)
          cols.left <- cols.left[! cols.left %in% key]
        } else {
          id.col <- list()
        }
        label <- validateInput("label", label, cols.left,
                               case.sensitive = TRUE)
        if (length(label) == 0){
          label <- cols.left[[length(cols.left)]]
        }
        cols.left <- cols.left[! cols.left %in% label]
        features <- validateInput("features", features, cols.left,
                                  case.sensitive = TRUE)
        if (length(features) == 0){
          features <- cols.left
        }
        id.col <- append(append(id.col, features), label)

        if (!inherits(data, "DataFrame")) {
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        conn <- data$connection.context
        CheckConnection(data)

        data <- data$Select(id.col)

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <-
          sprintf("#MLP_PARAMS_TBL_%s_%s", self$id, unique.id)
        model.tbl <-
          sprintf("#MLP_MODEL_TBL_%s_%s", self$id, unique.id)
        log.tbl <-
          sprintf("#MLP_LOG_TBL_%s_%s", self$id, unique.id)
        stats.tbl <-
          sprintf("#MLP_STATS_TBL_%s_%s", self$id, unique.id)
        optparam.tbl <-
          sprintf("#MLP_OPTPARAM_TBL_%s_%s", self$id, unique.id)
        in.tables <-
          list(data,
               param.tbl)
        out.tables <-
          list(model.tbl,
               log.tbl,
               stats.tbl,
               optparam.tbl)
        tables <- c(param.tbl, out.tables)
        param.data <-
          append(param.data,
                 list(
                   tuple("HIDDEN_LAYER_ACTIVE_FUNC",
                         map.null(self$activation, self$activation.map),
                         NULL, NULL),
                   tuple("OUTPUT_LAYER_ACTIVE_FUNC",
                         map.null(self$output.activation,
                                  self$activation.map),
                         NULL, NULL),
                   tuple("TRAINING_STYLE",
                         map.null(self$training.style, self$style.map),
                         NULL, NULL),
                   tuple("NORMALIZATION",
                         map.null(self$normalization, self$norm.map),
                         NULL, NULL),
                   tuple("WEIGHT_INIT",
                         map.null(self$weight.init, self$weight.map),
                         NULL, NULL),
                   tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
                   tuple("FUNCTIONALITY", self$functionality, NULL, NULL),
                   tuple("LEARNING_RATE", NULL, self$learning.rate, NULL),
                   tuple("MOMENTUM_FACTOR", NULL, self$momentum, NULL),
                   tuple("MINI_BATCH_SIZE", self$batch.size, NULL, NULL),
                   tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
                   tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL),
                   tuple("RESAMPLING_METHOD", NULL, NULL,
                         self$resampling.method),
                   tuple("FOLD_NUM", self$fold.num, NULL, NULL),
                   tuple("REPEAT_TIMES", self$repeat.times, NULL, NULL),
                   tuple("PARAM_SEARCH_STRATEGY", NULL, NULL,
                         self$param.search.strategy),
                   tuple("RANDOM_SEARCH_TIMES", self$random.search.times,
                         NULL, NULL),
                   tuple("SEED", self$random.state, NULL, NULL),
                   tuple("TIMEOUT", self$timeout, NULL, NULL),
                   tuple("PROGRESS_INDICATOR_ID", NULL, NULL,
                         self$progress.indicator.id),
                   tuple("HIDDEN_LAYER_ACTIVE_FUNC_VALUES", NULL, NULL,
                         activation.values),
                   tuple("HIDDEN_LAYER_SIZE_VALUES", NULL, NULL,
                         hidden.layer.size.values),
                   tuple("OUTPUT_LAYER_ACTIVE_FUNC_VALUES", NULL, NULL,
                         out.activation.values),
                   tuple("LEARNING_RATE_RANGE", NULL, NULL, learning.rate.range),
                   tuple("LEARNING_RATE_VALUES", NULL, NULL, learning.rate.values),
                   tuple("MOMENTUM_FACTOR_VALUES", NULL, NULL, momentum.values),
                   tuple("MOMENTUM_FACTOR_RANGE", NULL, NULL, momentum.range),
                   tuple("MINI_BATCH_SIZE_VALUES", NULL, NULL, batch.size.values),
                   tuple("MINI_BATCH_SIZE_RANGE", NULL, NULL, batch.size.range),
                   tuple("EVALUATION_METRIC",
                         NULL, NULL,
                         map.null(self$evaluation.metric,
                                  self$evaluation.metric.map))))
        if (!is.null(self$categorical.variable)) {
          for (each in self$categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
            param.data <- append(param.data, tuple(temp.list))
          }
        }
        for (name in label) {
          temp.list <- tuple("DEPENDENT_VARIABLE", NULL, NULL, name)
          param.data <- append(param.data, tuple(temp.list))
        }
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
                      ParameterTable$new(param.tbl)$WithData(param.data)))
          errorhelper(CallPalAutoWithConnection(conn,
                                                "PAL_MULTILAYER_PERCEPTRON",
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })

        self$model <- conn$table(model.tbl)
        self$log.output <- conn$table(log.tbl)
        self$statistics <- conn$table(stats.tbl)
        self$optim.param <- conn$table(optparam.tbl)
      }
    },
    predict = function(data, key, features = NULL, thread.ratio = NULL){
      if (!inherits(self$model, "DataFrame") ){
        msg <- "Model does not contain DataFrame. Perform a fit first."
        stop(msg)
      }
      if (!inherits(data, "DataFrame")) {
        msg <- "Data for predction must be DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)

      thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      if (length(features) == 0) {
        features <- cols
      }
      features.id <- list(key)
      features.id <- append(features.id, features)
      df <- data$Select(features.id)
      if (self$functionality == 0){
        mlp.type <- "MLPCLASSIFIER"
      } else {
        mlp.type <- "MLPREGRESSOR"
      }
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      in.tables <- list()
      for (name in c("PARAMETER")) {
        in.tables <- append(
          in.tables,
          sprintf(
            "#PAL_%s_%s_TBL_%s_%s",
            mlp.type,
            name,
            self$id,
            unique.id
          )
        )
      }
      out.tables <- list()
      for (name in c("RESULT", "SOFTMAX")) {
        out.tables <- append(
          out.tables,
          sprintf(
            "#PAL_%s_%s_TBL_%s_%s",
            mlp.type,
            name,
            self$id,
            unique.id
          )
        )
      }
      in.tables <- append(list(df, self$model$name), in.tables)
      param.tbl <- in.tables[[3]]
      result.tbl <- out.tables[[1]]
      softmax.tbl <- out.tables[[2]]
      tables <- c(param.tbl, out.tables)
      param.data <- list(tuple("THREAD_RATIO", NULL, thread.ratio, NULL))
      tryCatch({
        errorhelper(CreateTWithConnection(conn,
                    ParameterTable$new(param.tbl)$WithData(param.data))) #nolint
        errorhelper(CallPalAutoWithConnection(conn,
                                              "PAL_MULTILAYER_PERCEPTRON_PREDICT",
                                              in.tables,
                                              out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn, tables)
        stop(msg)
      })

      return (list(conn$table(result.tbl),
                   conn$table(softmax.tbl)))
    }

  )
)


MLPClassifier <- R6Class(
  "MLPClassifier",
  inherit = MLPBaseClass,
  public = list(
    score = function(data,
                     key,
                     features= NULL,
                     label= NULL){
      if (!inherits(self$model, "DataFrame") ){
        msg <- "Model not initialized. Perform a fit first."
        stop(msg)
      }
      if (!inherits(data, "DataFrame")) {
        msg <- "Data for scoring must be DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)
      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features))
        features <- cols
      prediction <- self$predict(data, key = key, features = features)
      prediction <- prediction[[1]]
      prediction <- prediction$Select(list(key, "TARGET"))
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      acc.score <- accuracy.score(conn,
                                  joined,
                                  label.true = "ACTUAL",
                                  label.pred = "PREDICTION")
      return(acc.score)
    })
)
#' @title Multi-Layer Perceptron (MLP) Classifier
#' @name hanaml.MLPClassifier
#' @description hanaml.MLPClassifier is a R wrapper for SAP HANA PAL
#'  Multi-layer Perceptron algorithm for classification.
#' @seealso \code{\link{predict.MLPClassifier}}

#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @param  activation    \code{character}\cr
#' Activation function for the hidden layer options:
#' \code{'tanh',
#'       'linear',
#'       'sigmoid-asymmetric',
#'       'sigmoid-symmetric',
#'       'gaussian-asymmetric',
#'       'gaussian-symmetric',
#'       'elliot-asymmetric',
#'       'elliot-symmetric',
#'       'sin-asymmetric',
#'       'sin-symmetric',
#'       'cos-asymmetric',
#'       'cos-symmetric',
#'       'relu' }\cr
#' @param output.activation    \code{character}\cr
#' Output activation function for the hidden layer options:
#' \code{'tanh',
#'        'linear',
#'        'sigmoid-asymmetric',
#'        'sigmoid-symmetric',
#'        'gaussian-asymmetric',
#'        'gaussian-symmetric',
#'        'elliot-asymmetric',
#'        'elliot-symmetric',
#'        'sin-asymmetric',
#'        'sin-symmetric',
#'        'cos-asymmetric',
#'        'cos-symmetric',
#'        'relu' }\cr
#' @param  hidden.layer.size  \code{vector/list of integers, mandatory}\cr
#'         Specifies the sizes of hidden layers.\cr
#'         The value 0 will be ignored, for example, c(2, 0, 3) is equivalent to c(2, 3).
#' @param  max.iter  \code{integer, optional}\cr
#'         The maximum number of iterations.\cr
#'         Defaults to 100.
#' @param  training.style  \code{{"batch", "stochastic"}, optional}\cr
#'         Specifies the training style.\cr
#'         Defaults to "stochastic".
#' @param  learning.rate  \code{double, optional}\cr
#'         Specifies the learning rate.\cr
#'         Only valid when \emph{training.style} is "stochastic".\cr
#'         No default value.
#' @param  momentum  \code{double, optional}\cr
#'         Specifies the momentum for gradient descent update.\cr
#'         Only valid when \emph{training.style} is "stochastic".\cr
#'         No default value.
#' @param  batch.size  \code{integer, optional}\cr
#'         Specifies the size of mini batch.\cr
#'         Only valid when \emph{training.style} is stochastic.\cr
#'         Defaults to 1.
#' @param  normalization  \code{{"no", "z-transform", "scalar"}, optional}\cr
#'         Specifies the normalization type.\cr
#'         Defaults to 'no' .
#' @param  weight.init  \code{character, optional}\cr
#'         Specifies the initial value of weight from the options below.
#'         \code{'all-zeros',
#'               'normal',
#'               'uniform',
#'               'variance-scale-normal',
#'               'variance-scale-uniform'}\cr
#'          Defaults to 'all-zeros'.
#' @param   categorical.variable  \code{character or list of characters, optional }\cr
#'          Column names in the data table used as category variable.\cr
#'          No default value.
#' @param   thread.ratio  \code{double, optional}\cr
#' Controls the proportion of available threads to use.
#' The value range is from 0 to 1, where 0 indicates a single thread,
#' and 1 indicates up to all available threads. Values between 0 and 1
#' will use that percentage of available threads. Values outside this
#' range tell PAL to heuristically determine the number of threads to use.\cr
#' Defaults to 0.
#' @param   resampling.method     \code{character, optional}\cr
#' Specifies the resampling values.\cr
#' \code{'cv',
#'       'stratified_cv',
#'       'bootstrap',
#'       'stratified_bootstrap'}\cr
#' If no value is specified for this parameter, neither model evaluation
#' nor parameter selection is activated.\cr
#'       No default value.
#' @param   evaluation.metric      \code{character, optional}\cr
#'          Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'          Valid values include: \code{'ACCURACY', 'F1_SCORE',
#'                                      'AUC_1VsRest', 'AUC_pairwise'}\cr
#'          No default value.
#' @param   fold.num   \code{integer, optional}\cr
#'          Specifies the fold number for the cross validation method.\cr
#'          Mandatory and valid only when \emph{resampling.method} is set to
#'          "cv" or "stratified_cv".\cr
#'          No default value.
#' @param   repeat.times  \code{integer, optional}\cr
#'          Specifies the number of repeat times for resampling.\cr
#'          Defaults to 1.
#' @param   param.search.strategy   \code{character, optional}\cr
#'          Specifies the method to activate parameter selection.\cr
#'          values should either be 'grid' or 'random'\cr
#'          No default value.
#' @param   random.search.times    \code{integer, optional}\cr
#'          Specifies the number of times to randomly select candidate parameters for selection.\cr
#'          No default value.
#' @param   random.state    \code{integer, optional}\cr
#'          Specifies the seed for random generation. \cr
#'          Use system time when 0 is specified.
#' @param   timeout   \code{integer, optional}\cr
#'          Specifies maximum running time for model evaluation or parameter selection,
#'          in seconds. No timeout when 0 is specified.\cr
#'          Default value is 0.
#' @param   progress.indicator.id     \code{character, optional}\cr
#'          Sets an ID of progress indicator for model evaluation or parameter selection.\cr
#'          No progress indicator is active if no value is provided.\cr
#'          No default value.
#' @param parameter.values   \code{list, optional}\cr
#'       Specifies values of the following parameters for parameter selection:\cr
#'       \code{action}, \code{output.action}, \code{hidden.layer.size}, \code{learning.rate}, \code{momentum}, \code{batch.size}.
#' @param parameter.range   \code{list, optional}\cr
#'      Specifies range of the following parameters for parameter selection:\cr
#'      \code{learning.rate}, \code{momentum}, \code{batch.size}.
#'
#' @return
#' A "MLPClassifier" object with the following attributes:\cr
#'\cr
#'    \code{model:  DataFrame}
#'          \itemize{
#'             \item{\code{ROW_INDEX} - model row index.}
#'             \item{\code{MODEL_CONTENT} - model content.}
#'         }
#'    \code{log:   DataFrame}
#'         \itemize{
#'             \item{\code{ITERATION} - iteration number.}
#'             \item{\code{ERROR} - Mean squared error between predicted values
#'             and target values for each iteration. }
#'         }
#'   \code{statistics:  DataFrame}
#'         \itemize{
#'             \item{\code{STAT_NAME} - statistics name. }
#'             \item{\code{STAT_VALUE} - values of the statistics. }
#'         }
#'   \code{optim.param: DataFrame}
#'         \itemize{\item{Selected optimal parameters.}}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    V000  V001 V002  V003 LABEL
#' 1     1  1.71   AC     0    AA
#' 2    10  1.78   CA     5    AB
#' 3    17  2.36   AA     6    AA
#' 4    12  3.15   AA     2     C
#' 5     7  1.05   CA     3    AB
#' 6     6  1.50   CA     2    AB
#' 7     9  1.97   CA     6     C
#' 8     5  1.26   AA     1    AA
#' 9    12  2.13   AC     4     C
#' 10   18  1.87   AC     6    AA
#' }
#' Training the model:
#' \preformatted{
#' > mlpc <- hanaml.MLPClassifier(data = data,
#'                                hidden.layer.size = c(10,10),
#'                                activation = "TANH",
#'                                output.activation ="TANH",
#'                                learning.rate = 0.001,
#'                                momentum = 0.0001,
#'                                training.style = "stochastic",
#'                                max.iter = 100,
#'                                normalization = "z-transform",
#'                                weight.init = "normal",
#'                                thread.ratio = 0.3,
#'                                categorical.variable = "V003")
#'
#' }
#' Output:
#' \preformatted{
#'     > mlpc$train.log$Collect()
#'
#'         ITERATION     ERROR
#'     1           1  1.080261
#'     2           2  1.008358
#'     3           3  0.947069
#'     4           4  0.894585
#'     5           5  0.849411
#'     ..        ...       ...
#'     92         92  0.317840
#'     93         93  0.316630
#'     94         94  0.315376
#'     95         95  0.314210
#'     96         96  0.313066
#'     97         97  0.312021
#'     98         98  0.310916
#'     99         99  0.309770
#'     100       100  0.308704
#' }
#' \code{Model evaluation example:}
#' Training the model:
#' \preformatted{
#' > mlpc <- hanaml.MLPClassifier(data = df, label= "LABEL",
#'                                hidden.layer.size = c(10,10),
#'                                activation = "tanh" ,output.activation = "tanh",
#'                                learning.rate = 0.001, momentum=0.00001,
#'                                training.style = "stochastic",
#'                                categorical.variable = "V003", max.iter = 100,
#'                                normalization = "z-transform",
#'                                weight.init = "normal", thread.ratio = 0.3,
#'                                resampling.method = "cv",
#'                                evaluation.metric = "f1_score",
#'                                fold.num = 10, repeat.times = 2,
#'                                random.state = 1, progress.indicator.id = "TEST")
#' }
#'
#' \code{Parameter Selection Example:}
#' \preformatted{
#' > mlpc <- hanaml.MLPClassifier(data = df, label= "LABEL",
#'                               learning.rate=0.001, momentum=0.00001,
#'                               training.style="stochastic",
#'                               categorical.variable = "V003",
#'                               max.iter = 100, normalization = "z-transform",
#'                               weight.init = "normal", thread.ratio = 0.3,
#'                               resampling.method = "stratified_bootstrap",
#'                               evaluation.metric = "ACCURACY",
#'                               param.search.strategy = "grid",
#'                               repeat.times = 2, random.state = 1,
#'                               progress.indicator.id = "TEST",
#'                               parameter.values = list("hidden.layer.size" =
#'                                                    list(c(10,10), c(5,5,5)),
#'                                                   "activation" =
#'                                                   c("tanh",
#'                                                   "linear",
#'                                                   "sigmoid-asymmetric"),
#'                                                   "output.activation" =
#'                                                   c("sigmoid-symmetric",
#'                                                   "gaussian-asymmetric",
#'                                                   "gaussian-symmetric")))
#'
#' }
#' Output:
#' \preformatted{
#' Optimal Parameters:
#'
#' 1   PARAM_NAME                  INT_VALUE   DOUBLE_VALUE  STRING_VALUE
#' 2   HIDDEN_LAYER_SIZE            NA             NA             10,10
#' 3   OUTPUT_LAYER_ACTIVE_FUNC      4             NA             <NA>
#' 4   HIDDEN_LAYER_ACTIVE_FUNC      1             NA             <NA>
#' }
#' @keywords Classification
#' @export
hanaml.MLPClassifier <- function (data = NULL,
                                  key = NULL,
                                  features = NULL,
                                  label = NULL,
                                  formula = NULL,
                                  hidden.layer.size = NULL,
                                  activation = NULL,
                                  output.activation = NULL,
                                  learning.rate = NULL,
                                  momentum = NULL,
                                  training.style = NULL,
                                  max.iter = NULL,
                                  normalization = NULL,
                                  weight.init = NULL,
                                  thread.ratio = NULL,
                                  categorical.variable = NULL,
                                  batch.size = NULL,
                                  resampling.method = NULL,
                                  evaluation.metric = NULL,
                                  fold.num = NULL,
                                  repeat.times = NULL,
                                  param.search.strategy = NULL,
                                  random.search.times = NULL,
                                  random.state = NULL,
                                  timeout = NULL,
                                  progress.indicator.id = NULL,
                                  parameter.range = NULL,
                                  parameter.values = NULL){
  MLPClassifier$new(0, data, key, features, label,
                    formula, hidden.layer.size,
                    activation, output.activation,
                    learning.rate, momentum,
                    training.style, max.iter,
                    normalization, weight.init,
                    thread.ratio, categorical.variable,
                    batch.size, resampling.method,
                    evaluation.metric, fold.num,
                    repeat.times, param.search.strategy,
                    random.search.times,
                    random.state, timeout, progress.indicator.id,
                    parameter.range, parameter.values)
}


#' @title Make Predictions from a "MLPClassifier" Object
#' @name predict.MLPClassifier
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "MLPClassifier" object.
#' @seealso \code{\link{hanaml.MLPClassifier}}
#' @format \code{\link{S3}} methods
#' @param  model \code{R6Class object}\cr
#'  A 'MLPCLassifier' object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @return
#' Returns a list of DataFrame.\cr
#' \code{DataFrame 1 :}\cr
#'   Prediction result, structured as follows:
#'     \itemize{
#'       \item{\code{ID, integer} - ID column,
#'       with the same name and type as data's ID column}
#'       \item{\code{TARGET, nvarchar} - predicted class name.}
#'       \item{\code{VALUE, double} - softmax value for the predicted class.}
#'   }
#'\cr
#' \code{DataFrame 2 :}\cr
#'   Softmax values, structured as follows:
#'    \itemize{
#'      \item{\code{ID, integer} - ID column,
#'      with the same name and type as data's ID column}
#'      \item{\code{CLASS, nvarchar} -  class name.}
#'      \item{\code{VALUE, double} - softmax value for that class.}
#'   }
#' @section Examples:
#' Call the function and predict with a 'MLPClassifier' object mplc:
#' \preformatted{
#' > predict (mplc, data, key = "ID")
#' }
#' @keywords Classification
#' @export
predict.MLPClassifier <- function(model, data, key, features = NULL){
  model$predict(data = data, key = key, features = features)
}

MLPRegressor <- R6Class(
  "MLPRegressor",
  inherit = MLPBaseClass,
  public = list(
    score = function(data,
                     key,
                     features= NULL,
                     label= NULL){
      if (!inherits(self$model, "DataFrame") ){
        msg <- "Model not initialized. Perform a fit first."
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")) {
        msg <- "Data for scoring must be DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)
      cols <- data$columns
      key <- validateInput("key", key, cols,
                           required = TRUE,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols,
                             case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      prediction <- self$predict(data, key = key, features = features)
      prediction <- prediction[[1]]
      prediction <- prediction$Select(list(key, "VALUE"))
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      if (length(label)  == 1) {
        actual <- data$Select(list(key, label))
      } else {
        select.list <- list()
        for (lb in label) {
          select.list <- append(select.list, list(c(key, lb[[1]])))
        }
        actual <- Union.all(data, select.list)
      }
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      r2.score <- r2.score(conn,
                           joined,
                           label.true = "ACTUAL",
                           label.pred = "PREDICTION")
      return(r2.score)
    }
  )
)

#' @title Multi-Layer Perceptron (MLP) Regressor
#' @name hanaml.MLPRegressor
#' @description hanaml.MLPRegressor is a R wrapper for SAP HANA PAL
#'  Multi-layer Perceptron algorithm for Regression.
#' @seealso \code{\link{predict.MLPRegressor}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @param  activation    \code{character}\cr
#' Activation function for the hidden layer options:
#' \code{'tanh',
#'       'linear',
#'       'sigmoid-asymmetric',
#'       'sigmoid-symmetric',
#'       'gaussian-asymmetric',
#'       'gaussian-symmetric',
#'       'elliot-asymmetric',
#'       'elliot-symmetric',
#'       'sin-asymmetric',
#'       'sin-symmetric',
#'       'cos-asymmetric',
#'       'cos-symmetric',
#'       'relu' }\cr
#' @param output.activation    \code{character}\cr
#' Output activation function for the hidden layer options:
#' \code{'tanh',
#'        'linear',
#'        'sigmoid-asymmetric',
#'        'sigmoid-symmetric',
#'        'gaussian-asymmetric',
#'        'gaussian-symmetric',
#'        'elliot-asymmetric',
#'        'elliot-symmetric',
#'        'sin-asymmetric',
#'        'sin-symmetric',
#'        'cos-asymmetric',
#'        'cos-symmetric',
#'        'relu' }\cr
#' @param  hidden.layer.size  \code{vector/list of integers, mandatory}\cr
#'         Specifies the sizes of hidden layers.\cr
#'         The value 0 will be ignored, for example, c(2, 0, 3) is equivalent to c(2, 3).
#' @param  max.iter  \code{integer, optional}\cr
#'         The maximum number of iterations.\cr
#'         Defaults to 100.
#' @param  training.style  \code{{"batch", "stochastic"}, optional}\cr
#'         Specifies the training style.\cr
#'         Defaults to "stochastic".
#' @param  learning.rate  \code{double, optional}\cr
#'         Specifies the learning rate.\cr
#'         Only valid when \emph{training.style} is "stochastic".\cr
#'         No default value.
#' @param  momentum  \code{double, optional}\cr
#'         Specifies the momentum for gradient descent update.\cr
#'         Only valid when \emph{training.style} is "stochastic".\cr
#'         No default value.
#' @param  batch.size  \code{integer, optional}\cr
#'         Specifies the size of mini batch.\cr
#'         Only valid when \emph{training.style} is stochastic.\cr
#'         Defaults to 1.
#' @param  normalization  \code{{"no", "z-transform", "scalar"}, optional}\cr
#'         Specifies the normalization type.\cr
#'         Defaults to 'no' .
#' @param  weight.init  \code{character, optional}\cr
#'         Specifies the initial value of weight from the options below.
#'         \code{'all-zeros',
#'               'normal',
#'               'uniform',
#'               'variance-scale-normal',
#'               'variance-scale-uniform'}\cr
#'          Defaults to 'all-zeros'.
#' @param   categorical.variable  \code{character or list of characters, optional }\cr
#'          Column names in the data table used as category variable.\cr
#'          No default value.
#' @param   thread.ratio  \code{double, optional}\cr
#' Controls the proportion of available threads to use.
#' The value range is from 0 to 1, where 0 indicates a single thread,
#' and 1 indicates up to all available threads. Values between 0 and 1
#' will use that percentage of available threads. Values outside this
#' range tell PAL to heuristically determine the number of threads to use.\cr
#' Defaults to 0.
#' @param   resampling.method     \code{character, optional}\cr
#' Specifies the resampling values.\cr
#' \code{'cv',
#'       'stratified_cv',
#'       'bootstrap',
#'       'stratified_bootstrap'}\cr
#' If no value is specified for this parameter, neither model evaluation
#' nor parameter selection is activated.\cr
#'       No default value.
#' @param   evaluation.metric      \code{character, optional}\cr
#'          Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'          Valid values include: \code{'RMSE'}\cr
#'          No default value.
#' @param   fold.num   \code{integer, optional}\cr
#'          Specifies the fold number for the cross validation method.\cr
#'          Mandatory and valid only when \emph{resampling.method} is set to
#'          "cv" or "stratified_cv".\cr
#'          No default value.
#' @param   repeat.times  \code{integer, optional}\cr
#'          Specifies the number of repeat times for resampling.\cr
#'          Defaults to 1.
#' @param   param.search.strategy   \code{character, optional}\cr
#'          Specifies the method to activate parameter selection.\cr
#'          values should either be 'grid' or 'random'\cr
#'          No default value.
#' @param   random.search.times    \code{integer, optional}\cr
#'          Specifies the number of times to randomly select candidate parameters for selection.\cr
#'          No default value.
#' @param   random.state    \code{integer, optional}\cr
#'          Specifies the seed for random generation. \cr
#'          Use system time when 0 is specified.
#' @param   timeout   \code{integer, optional}\cr
#'          Specifies maximum running time for model evaluation or parameter selection,
#'          in seconds. No timeout when 0 is specified.\cr
#'          Default value is 0.
#' @param   progress.indicator.id     \code{character, optional}\cr
#'          Sets an ID of progress indicator for model evaluation or parameter selection.\cr
#'          No progress indicator is active if no value is provided.\cr
#'          No default value.
#' @param   parameter.values   \code{list, optional}\cr
#'          Specifies values of the following parameters for parameter selection:\cr
#'          \code{action}, \code{output.action}, \code{hidden.layer.size}, \code{learning.rate}, \code{momentum}, \code{batch.size}.
#' @param   parameter.range   \code{list, optional}\cr
#'          Specifies range of the following parameters for parameter selection:\cr
#'          \code{learning.rate}, \code{momentum}, \code{batch.size}.
#'
#' @return
#' A "MLPRegressor" object with the following attributes:\cr
#' \cr
#'    \code{model:   DataFrame}
#'          \itemize{
#'             \item{\code{ROW_INDEX} - model row index.}
#'             \item{\code{MODEL_CONTENT} - model content.}
#'         }
#'    \code{log:   DataFrame}
#'         \itemize{
#'             \item{\code{ITERATION} - iteration number.}
#'             \item{\code{ERROR} - Mean squared error between predicted values
#'             and target values for each iteration. }
#'         }
#'   \code{statistics:   DataFrame}
#'         \itemize{
#'             \item{\code{STAT_NAME} - statistics name. }
#'             \item{\code{STAT_VALUE} - values of the statistics. }
#'         }
#'   \code{optim.param:  DataFrame}\cr
#'       \itemize{\item{Optimal parameters selected.}}
#' @section Examples:
#' Input DataFrame df:
#' \preformatted{
#' > df$Collect()
#'     V000  V001 V002  V003  T001  T002  T003
#' 1     1  1.71   AC     0  12.7   2.8  3.06
#' 2    10  1.78   CA     5  12.1   8.0  2.65
#' 3    17  2.36   AA     6  10.1   2.8  3.24
#' 4    12  3.15   AA     2  28.1   5.6  2.24
#' 5     7  1.05   CA     3  19.8   7.1  1.98
#' 6     6  1.50   CA     2  23.2   4.9  2.12
#' 7     9  1.97   CA     6  24.5   4.2  1.05
#' 8     5  1.26   AA     1  13.6   5.1  2.78
#' 9    12  2.13   AC     4  13.2   1.9  1.34
#' 10   18  1.87   AC     6  25.5   3.6  2.14
#' }
#' Training the model:
#' \preformatted{
#' > mlpr <- hanaml.MLPRegressor(data = df,
#'                               label= c("T001", "T002", "T003"),
#'                               hidden.layer.size = c(10,5),
#'                               activation = "SIN-ASYMMETRIC",
#'                               output.activation = "SIN-ASYMMETRIC",
#'                               learning.rate = 0.001, momentum = 0.00001,
#'                               training.style = "batch",
#'                               max.iter = 10000, normalization = "z-transform",
#'                               weight.init = "normal", thread.ratio = 0.3)
#'
#' }
#' Training result may look different from the following results due
#' to model randomness.
#' \preformatted{
#' > mlpr$train.log$Collect()
#'        ITERATION       ERROR
#'   1            1   34.525655
#'   2            2   82.656301
#'   3            3   67.289241
#'   4            4  162.768062
#'   5            5   38.988242
#'   6            6  142.239468
#'   7            7   34.467742
#'   ..         ...         ...
#'   732        732   11.891081
#'   733        733   11.891081
#'   734        734   11.891081
#'   735        735   11.891081
#'
#'}
#' @keywords Regression
#' @export
hanaml.MLPRegressor <- function (data = NULL,
                                 key = NULL,
                                 features = NULL,
                                 label = NULL,
                                 formula = NULL,
                                 hidden.layer.size = NULL,
                                 activation = NULL,
                                 output.activation = NULL,
                                 learning.rate = NULL,
                                 momentum = NULL,
                                 training.style = NULL,
                                 max.iter = NULL,
                                 normalization = NULL,
                                 weight.init = NULL,
                                 thread.ratio = NULL,
                                 categorical.variable = NULL,
                                 batch.size = NULL,
                                 resampling.method = NULL,
                                 evaluation.metric = "RMSE",
                                 fold.num = NULL,
                                 repeat.times = NULL,
                                 param.search.strategy = NULL,
                                 random.search.times = NULL,
                                 random.state = NULL,
                                 timeout = NULL,
                                 progress.indicator.id = NULL,
                                 parameter.range = NULL,
                                 parameter.values = NULL) {
  MLPRegressor$new(1, data, key, features, label,
                   formula, hidden.layer.size, activation,
                   output.activation, learning.rate, momentum,
                   training.style, max.iter, normalization, weight.init,
                   thread.ratio, categorical.variable, batch.size,
                   resampling.method, evaluation.metric, fold.num,
                   repeat.times, param.search.strategy, random.search.times,
                   random.state, timeout, progress.indicator.id, parameter.range,
                   parameter.values)
}

#' @title Make Predictions from a "MLPRegressor" Object
#' @name predict.MLPRegressor
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "MLPRegressor" object.
#' @seealso \code{\link{hanaml.MLPRegressor}}
#' @format \code{\link{S3}} methods
#' @param  model \code{R6Class object}\cr
#'  A 'MLPRegressor' object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#'
#' @return
#'  \code{DataFrame}\cr
#'  \itemize{
#'      \item{\code{ID, integer} - ID column, with the same name
#'      and type as data's ID column}
#'       \item{\code{TARGET, nvarchar} - predicted class name.}
#'       \item{\code{VALUE, double} - softmax value for
#'       the predicted class.}
#'          }
#' @keywords Regression
#' @section Examples:
#' Call the function and predict with a 'MLPRegressor' object mplr:
#' \preformatted{
#' > predict (mplr, data, key = "ID")
#' }
#' @export
predict.MLPRegressor <- function( model, data, key, features = NULL) {
  model$predict(data = data, key = key, features = features)
}



Union.all <- function(df, col.name.list) {
  select.statm <- sprintf("SELECT %s FROM (%s)",
                          paste(QuoteName(col.name.list[[1]]), collapse = ", "),
                          df$select.statement)
  for (col.name in col.name.list[2:length(col.name.list)]){
    select.statm <- paste(select.statm,
                          "UNION ALL",
                          sprintf("SELECT %s FROM (%s)",
                                  paste(QuoteName(col.name), collapse = ", "),
                                  df$select.statement))
  }
  return(df$GetDf(new.select.statement = select.statm))
}
