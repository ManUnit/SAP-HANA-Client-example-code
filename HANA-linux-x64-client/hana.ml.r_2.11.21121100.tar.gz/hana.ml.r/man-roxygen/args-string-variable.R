#' @param string.variable \code{character or list of character, optional}\cr
#' Indicates a string column storing non-categorical data.
#' Levenshtein distance is used to calculate similarity between two strings. Ignored if it is not a string column.\cr
#' New parameter added in SAP HANA Cloud and SPS05.\cr
#' Defaults to NULL.

