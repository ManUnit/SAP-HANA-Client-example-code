#'@param      features \code{character of list of characters, optional}\cr
#'            Name of feature columns.\cr
#'            If not provided, it defaults all non-key, non-label columns of \emph{data}.
