#' @param verbose \code{logical, optional}\cr
#'        If TRUE, output all classes and the corresponding
#'        confidences for each data point.\cr
#'        Defaults to FALSE.
