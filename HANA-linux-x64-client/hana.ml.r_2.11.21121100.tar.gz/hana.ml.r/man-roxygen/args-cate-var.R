#' @param  categorical.variable \code{character or list/vector of characters, optional}\cr
#'         Indicates features should be treated as categorical variable.\cr
#'         The default behavior is dependent on what input is given:
#'         \itemize{
#'           \item{"VARCHAR" and "NVARCHAR"}: categorical\cr
#'           \item{"INTEGER" and "DOUBLE"}: continuous.
#'         }
#'         VALID only for variables of "INTEGER" type, omitted otherwise.\cr
#'         No default value.
