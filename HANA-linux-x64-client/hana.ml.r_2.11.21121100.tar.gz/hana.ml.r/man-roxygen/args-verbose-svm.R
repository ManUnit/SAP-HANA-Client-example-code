#' @param verbose \code{logical, optional}\cr
#' If TRUE, output scoring probabilities for each class.\cr
#' Defauts to FALSE.
