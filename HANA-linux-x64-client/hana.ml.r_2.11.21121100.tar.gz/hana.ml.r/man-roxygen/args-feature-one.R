#'@param      features \code{character, optional}\cr
#'            Name of the feature column.\cr
#'            If not provided, it defaults the first non-key, non-label column of \emph{data}.
