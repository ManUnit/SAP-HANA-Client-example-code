#' @return
#'  DataFrame containing the generated random samples, structured as follows:
#'  \itemize{
#'   \item{ID}: type INTEGER, ID column
#'   \item{GENERATED_NUMBER}: type DOUBLE, sample values
#' }
