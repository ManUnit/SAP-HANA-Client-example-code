#' @param decomposition \code{{"LU", "QR", "SVD", "Cholesky"}, optional}\cr
#'  Specifies decomposition method(case-insensitive).
#'  \itemize{
#'          \item{\code{"LU":} Doolittle decomposition.}
#'          \item{\code{"QR":} QR decomposition.}
#'          \item{\code{"SVD":} singular value decomposition.}
#'          \item{\code{"Cholesky":} Cholesky decomposition.}
#'  }
#'  Defaults to "QR".
