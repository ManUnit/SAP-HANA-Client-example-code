#' @param connection.context \code{ConnectionContext}\cr
#' SAP HANA Database connection object.
