#'@param      label \code{character, optional}\cr
#'            Name of the column which specifies the dependent variable.\cr
#'            Defaults to the last column of \emph{data} if not provided.
