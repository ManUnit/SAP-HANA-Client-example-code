#' @param model.format \code{character, optional}\cr
#'  Choose the format of mdoel for prediction. optional are 'coefficients' or 'pmml'.\cr
#'  Defaults to 'coefficients'.
