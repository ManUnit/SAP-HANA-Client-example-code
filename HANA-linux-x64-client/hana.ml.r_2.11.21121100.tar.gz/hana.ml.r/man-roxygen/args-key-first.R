#'@param      key \code{character, optional}\cr
#'            Name of the ID column.\cr
#'            Defaults to the first column if not provided.
