#' @param variable.weight \code{named list, optional}\cr
#' Specifies the weight of a variable participating in distance calculation.
#' The value must be greater or equal to 0. Defaults to 1 for variables not specified.\cr
#' New parameter added in SAP HANA Cloud and SPS05.\cr
#' Defaults to NULL.
