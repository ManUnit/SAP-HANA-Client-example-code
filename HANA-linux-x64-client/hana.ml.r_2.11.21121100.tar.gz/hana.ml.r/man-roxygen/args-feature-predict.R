#'@param      features \code{character of list of characters, optional}\cr
#'            Name of feature columns for prediction.\cr
#'            If not provided, it defaults to all non-key columns of \emph{data}.
