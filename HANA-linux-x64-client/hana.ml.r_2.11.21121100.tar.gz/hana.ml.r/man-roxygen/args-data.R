#' @param data \code{DataFrame}\cr
#' DataFrame containting the data.
