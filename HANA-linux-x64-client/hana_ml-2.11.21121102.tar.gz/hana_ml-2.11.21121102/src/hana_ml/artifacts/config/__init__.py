"""
Artifacts config.
"""
from .config_handler import ConfigHandler
from .config_handler import ConfigConstants
